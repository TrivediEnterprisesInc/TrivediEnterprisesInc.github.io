var dojoConfig = {
    // loader configuration...
    packages:[{
        name:dojo,
        location:"../../dojo"
    },{
        name:dijit,
        location:"../../dijit"
    },{
        name:gfxBld,
        location:"../../gfxBld"
    }],
    deps:["main"],

    // point basePath to ~/wwwroot
    basePath:"../../",

    // point releaseDir to ~/wwwroot/gfxBld-deploy
    releaseDir:"../../gfxBld-deploy"
}