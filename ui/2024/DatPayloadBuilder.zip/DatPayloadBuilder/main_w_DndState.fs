//what follows below is the loggedUIRunner in its entirity...
(*  Wwnn.  HP. QP. (TM)
    Copyright (c) M. P. Trivedi 2016-2023.  All rights reserved. 
    TrivediBldHdr->
    |Trivedi SrcCtrlHdr File.  Copyright (c) 2015-2022 M. P. Trivedi.  All rights reserved.|637901455|test.fs|none|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|

    "src\UI\loggedUIRunner.fs  --platform:x64 --target:exe --out:logdUIRunr.exe -r:bin\Trivedi.Core.dll -r:bin\Trivedi.CoreAux.dll -r:bin\Trivedi.UI.dll -I:C:\Windows\Microsoft.NET\Framework\v4.0.30319"
    "src\UI\loggedUIRunner.fs  --platform:x64 --target:exe --out:load_logdUIRunr.exe -r:bin\Trivedi.Core.dll -r:bin\Trivedi.UI.dll -I:C:\Windows\Microsoft.NET\Framework\v4.0.30319"

    (*
        This ver uses Trivedi.UI_Nov02_Color+Grids.dll + UIAux + ...

                   સાદુ_પાન_Jan
                    મીઠૂ_પાન_Mar23

    *)

*)

namespace Trivedi

#nowarn "20" "25" "58" "66" "67" "64" "760" "1125" "1182" "1558"

module datBldr = 
    open System
    open System.Diagnostics
    open System.Drawing
    //requires Win open System.Drawing.Imaging
    open System.IO
    open System.Text
    open System.Text.RegularExpressions
    open System.Globalization
    //requires Win open System.Windows.Forms
    open Trivedi
    open Trivedi.Core
    open Trivedi.Control
    open Trivedi.Brij
    open Trivedi.UI
    open Trivedi.UI.Form
    open Trivedi.UI.Dlg
    open Trivedi.UIAux
    open FSharp.Reflection

    printfn "hey datBldr 1"

    //let pagOptsDec = DVPaginationOpts(200,1,2000, 200, 400, 800000)
    //let tkDt = deSerBA (File.ReadAllBytes("baseTkDatAux.bdf")) // :?> list<list<_>>
    let tplFLi = baseTkDatAux tDef tkFldLiLocalAux |> fst
    let tkDt = baseTkDatAux tDef tkFldLiLocalAux |> snd
    printfn "pgOpts:\n %A" pagOptsAux
    printfn "tDef:\n %A" tDef



module dndState = 
    open System
    open System.Diagnostics
    open System.Drawing
    //requires Win open System.Drawing.Imaging
    open System.IO
    open System.Text
    open System.Text.RegularExpressions
    open System.Globalization
    //open System.Windows.Forms
    open Trivedi
    open Trivedi.Core
    open Trivedi.Control
    open Trivedi.Brij
    open Trivedi.UI
    open Trivedi.UI.Form
    open Trivedi.UI.Dlg
    open Trivedi.UIAux
    open FSharp.Reflection

(*
Nov 15 '23:
Here's the deal:
  - For scope within ob (after ctor in monad), we got working mechanics but no get/put.  POSSIBLY this is coz in the new scope (inside) it does NOT continue outside scope; in which case the 'let x = getS' will assign a fn to x.  Check/verify with simple console app if necc.  and then simply revert to getting local state for ea Monaic fn (this is NO PROB coz ea event is indiv & won't adversely affect state in any case)
  - For now, try the foll.:
    - Tinker w/ctor (do!)
    - Perhaps removing the inner {} scope will let getS work
  - If not, rever to approach identified above.
*)

    printfn "hey dnd"

    //impl console state test w/bind + doPrnLayout() 
    //on ty ext Control; impl basic flow to see if works; 
    //use timer.pause() etc. 4 updates
    //INCLUDE stubs 4 all handlers reqd 4 cpy/paste into dzOps mod
    (*
    Actions:
      = Move
      - Change Props (Sz)
      - Change Props (Details)
      - Ins BlankRow
      - New Tbl ColSz
    Consider: match inside bind with cmd.RequiresLayout -> doL()
    *)
    let adder = fun l -> ("adder" + (List.length l).ToString()) :: l
    //(List.tail l @ l)

    let dndBind_v1 k m = 
      fun s -> 
        let (s', a) = m s
        printfn "Step (a) bind #1: %A" s'
        let s'' = adder s'
        printfn "adder res: %A" s''
        let tmp = (k a) s''
        printfn "Step (b) bind #2 for inSt: %A %A" tmp s'
        tmp

    let dndBind k m = 
      fun s -> 
        let (s', a) = m s in (k a) s'

    type DnDStateBuilder() =
        member this.Return(a) : State<'M,'T> = fun s -> (s,a)
        member this.ReturnFrom(m:State<'M, 'T>) = m
        member this.Bind(m:State<'M,'T>, k:'T -> State<'M,'U>) : State<'M,'U> =  dndBind k m
        member this.Zero() = this.Return()
        member this.Delay(f) = this.Bind(this.Return (), f)
    let ``⍒`` = new DnDStateBuilder()


    type StatefulC(inS:string) as c =
      //inherit Control()
      do printfn "new with ctor:%A" inS
      let moveCmd =
        let eachSec = new System.Timers.Timer(Interval = 1000)
        eachSec.Elapsed.AddHandler(fun o e -> 
              printfn "eachSec timer triggered @ %A" e.SignalTime
              ``⍒`` {
                    let! currS = getS
                    do! putS ((e.SignalTime).ToString() :: currS)
                    } |> ignore)
        eachSec.Enabled <- true
      let propsCmd =
        let twoSec = new System.Timers.Timer(Interval = 2000)
        twoSec.Elapsed.AddHandler(fun o e -> 
              printfn "**TwoSec timer triggered @ %A" e.SignalTime
              ``⍒`` {
                  let! currS = getS
                  do printfn "**current State: %A" (liToString currS)
                  do! putS ((e.SignalTime).ToString() :: currS)
                  } |> ignore)
        twoSec.Enabled <- true
      do printfn "*** outside initControl..."
      member c.prnStat() = 
          ``⍒`` {
                do printfn "prnStat.."
                let! currS = getS
                do printfn "current State: %A" (liToString currS)
          } |> ignore

(*    mucho issues with this...
      override c.ToString() =
          ``⍒`` {
                let! currS = getS
                return "current State: " + (liToString currS)
                } |> eval
*)

    let statAsync(inst:StatefulC) =
        async {
            try
                do Console.WriteLine("in statAsync, press any key...")
                while (not( Console.ReadKey().Key = ConsoleKey.Enter)) do inst.prnStat()
            with
                | ex -> printfn "err in statAsync: %s" (ex.Message)
            }

//        ["init"] |>
    let sRunnr = 
      fun inpt ->
        ``⍒`` {
                let instance = StatefulC("testRun")
                do statAsync(instance)
                  |> Async.RunSynchronously
                  |> ignore
              }

    let sRun = 
      fun inS -> 
        ``⍒`` {
               printfn "DnDStateful init()"
               let! a = getS
               printfn "Step (c) tplRun 1: %A" a
               do! putS ("ob2" :: a)
               let! b = getS
               printfn "Step (d) tplRun 2: %A" b
               return b
            }


    [<EntryPoint>]
    [<STAThread>]
    let main ag =
        try
            printfn "dat main():1"
        with
            | ex -> printfn "%s" (ex.Message)
                    System.Console.Write("back in main...pls press any key to continue...")
                    let c = System.Console.ReadKey(true)
                    match c.Key with
                    | ConsoleKey.Escape -> printfn "Esc..."
                    | _ -> printfn "..."
        0