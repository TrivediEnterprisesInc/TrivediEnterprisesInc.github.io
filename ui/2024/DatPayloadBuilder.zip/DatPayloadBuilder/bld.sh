#!/bin/bash
dotnet publish --self-contained dat.fsproj -r win10-x64 -c Release /p:PublishSingleFile=true -o out
