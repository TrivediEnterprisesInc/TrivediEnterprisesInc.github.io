Legacy eoy stuff removed from this plnk for space reasons
see /plunk/nbqy3jpNOHCFwET0