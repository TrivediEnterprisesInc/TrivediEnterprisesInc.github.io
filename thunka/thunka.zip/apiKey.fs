open System.Security.Cryptography //.RandomNumberGenerator

  let GenerateApiKey =
    fun tblHsh intKeyL ->
      let _prefix = (b64EndB tblHsh) + "^"
      let bArr = Array.zeroCreate intKeyL
      (RandomNumberGenerator.Create()).GetBytes(bArr)
      let base64String = Convert.ToBase64String(bArr).Replace("+", "-").Replace("/", "_")
      _prefix + base64String.Substring(0, (intKeyL - _prefix.Length - 1))
