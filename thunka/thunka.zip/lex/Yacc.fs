(*  brij (TM)
    Copyright (c) M. P. Trivedi 2016-2025.  All rights reserved.

Evaluate > @
in getFOP2...
outpt ty: Parser+getFOP2@18
Parser+getFOP2@18

Evaluate > @
in getFOP2...
in getFOP2...
outpt ty: Microsoft.FSharp.Quotations.FSharpExpr
test

*)

namespace Trivedi

type mOut =  | Num of int
                    | Str of string