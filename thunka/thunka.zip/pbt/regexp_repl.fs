module rTest = 
    open System
    open System.Text.RegularExpressions
    

    let textForm = "| {this.title} | {this.docF} | {this.colSpan} | {this.rowSpan} | {(this.Pos |> fst)} | {(this.Pos |> snd)} | {this.lblFont} |{this.dataFont} | {this.foreCol} | {this.backCol} | {this.CanUhear} | {this.fldTtip} |"
    let text = "| title | docF | colSpan | rowSpan | Posfst | Possnd | lblFont | dataFont | foreCol | backCol | CanUhear | fldTtip |"
    let rx = new Regex(@"\|\s(?<fld>\w+)", RegexOptions.IgnoreCase)
    

    let replIdx idx = 
        let matches = rx.Matches(text) |> List.ofSeq
        let m = matches
        List.fold (fun s (v:Match) -> 
                let (i, st) = s
                printfn "i%A: " i
                let groups = v.Groups
                match (i=idx) with 
                | true -> 
                    printfn "%A" (groups.[0].Value)
                    printfn "%A) '%A' fnd at position %A" (i.ToString()) (groups.["fld"].Value) (groups.[1].Index)
                    i + 1, st
                | _ -> i + 1, st) (0,"") m
        |> ignore
        
    replIdx 2
    

    printfn "eom..."