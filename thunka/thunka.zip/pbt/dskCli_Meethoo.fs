see phat or uO9Cw16aFj9GkZg3
the latter also contains related stuff incl svr_gg
  + webCli_pg.fs + userSettings