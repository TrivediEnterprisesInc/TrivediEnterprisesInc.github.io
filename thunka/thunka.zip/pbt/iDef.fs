(*  Brij (TM)
    Copyright (c) M. P. Trivedi 2016-2025.  All rights reserved. 
    TrivediBldHdr->
    |Trivedi SrcCtrlHdr File.  Copyright (c) 2015-2025 M. P. Trivedi.  All rights reserved.|637901455|test.fs|none|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS 

    <<glot>>
    Last updated: Wed Jul 02

*)
namespace Trivedi

#nowarn "20" "25" "58" "66" "67" "64" "760" "1182" "1558"

[<AutoOpen>]
module IDef =

open System
open System.Windows.Forms

type IDef_old  =
    abstract member fromDef: unit -> unit
    abstract member toDef: unit -> unit

    //The latest/updated ver of this is in 'dskCli_Meethoo_pbt.fs'
    type IDef<'t> = 
        inherit IUndoable<'t> //added Oct03 for currSt
        member loadDef(d:'t): 
            this.currSt <- d
            scatterAll()
        //tgHost: Since instd of !!~ we're going to use a bossCtrl OR a Map; add a scatterAll which takes all flds in order (so easy to chk/verify b4 testing) Oct03: Policy: Use tc; else tblP
        //@chk: necc.? remmed 4 now (we're using a let in meethoo)
        //abstract member tgHost with get,set
        abstract member scatterAll(): unit -> unit
    
    //Notes for Form Impl (most others _in situ_)
    //Here's the FormTy modified 4 Dnd flow ->
#if forRef
    type DndWid(tbl) as f = 
        let bmRef = ref bm
        let selCells = ref []
        let BanarasiMasaloAux(unid,dispNm,સુપારી,usrFlds,lblFont,dataFont,foreCol, backCol, docInf) = bm
        let (unid,tit,docF, colSp, roSp,colPos,roPos,lblFont,dataFont,foreCol,backCol,soopari,vFn,CanUhear,fldTtip,tblTy) = usrFlds
        let initState = 
            ([bm], 0, [], [])  |>
            ``⍾`` { ...}
	...<snip>
        member f.bldState() = 
	   //(BMdzTbl -> UIModel)
	    member f.rebldUIlayout() = 
#endif //forRef
(*
    - We already have ScaterAll as a fn of bldState+rebldUILayout (above)
    - @ToDo: 
       - Save refs 2 currSt on modif via .add(); getState via currSt
       - Chk that tgHost is consistent w/other tys.
*)