/*

Apr 21:  Decided to go w/KeySet pag after all: clear performance wins + we no longer nd the TenantID_TableNm as part of the UnId.  Therefore the code below is unnecc but kept for ref

Created: Feb 23 2026
Last upd: Feb 24 (added Vw tys on top)
Notes:
Keyset pagination is overkill for our purps; we cn do better w/Offset + svr-app controlled massaging of the qry results (Approach: The _only_ issue w/offset is if recs're added/removed in the pgRange.  So we just get a few before/after and handle all cases incl lastRec deleted...)

PsuedoCode but shd flow except for final note

Note on Settings: certain settings like the tbl/li for tenantVwPgOffsets (larger if tenant's db has high writes) can be stored in svr mem on startup BUT how do we dynamically load changes?  Do a daily reload via cron? TBD.  Move this to the arch doc.



*/

  //eventually isolate these 4 ea dzEl in diff mods
  type VwOp = | VwNavOp of ctx
              | VwFilterOp of ctx
              | VwQkUpdOp of ctx
              | VwTagCloudOp of ctx with
    member handle = 
      //Call the indiv existing fns by OpTy; move CalcuttiHandlers etc. into this mod
  
  type VwNavOp = | ExpandCat of cat:string
                 | CollapseCat of cat:string
                 | ExpandAll
                 | CollapseAll
                 | NextPg
                 | PrevPg
                 | JumpToPg of pg:int 

  let getStoredVwPagParams = 
    fun tenId vwId ->
      match (getQryStoredParams tenID vwID) with
      | Some r -> r
      | _ -> getDefaults vwId (will contain defaultPgSizeOffset, no Top/Bott cursors)

  let getQryParams = 
    fun ctx ->
      match ((isWebCli ctx),  (isFirstQryVisit)) with
      | true, true -> getStoredVwPagParams tenId vwId
      | _ -> getFromCtx()

  let getPaginationWin =
    fun tenID -> 
      //returns default of, say, 100 OR custom
      //ONLY custom tenIDs in BrijCore hardCoded li with custom winSz depending on freq of writes/deletes
      // 1k or so shd be OK, this saves a svr trip

  let openCalcutti = 
    fun ctx ->
      let tenID = getTenID ctx
      let PgSiz, TopCursorId, BotCursorId = getQryParams ctx
      let PaginationWindow = getPaginationWin tenID
      //runQry and get [offsetCursor - PaginationWin, offsetCursor + PgSz + PaginationWin] recs  (customize if moving fwd/back)
      //populate to Mtpl, THEN
      match Mtpl.contains topCursorId with
      | true -> getTopIdx |> List.after li PgSz
      | -> 
        //the Cursor rec has been deleted, so just get the regular window (no attempt to find position; assume it remains the same)
        List.after li PgSz 100

  /*
    Note Gotcha: 
      Somewhere in the flow we nd to match for:
      match isFirstQryVisitForSession with
      | true -> runQry w/offset 0, limit PgSz
      | _ -> //use the params
  */