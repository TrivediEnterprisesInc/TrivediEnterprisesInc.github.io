module Program

open System
open System.Text
open System.Security.Claims
open System.ComponentModel.DataAnnotations
open Microsoft.AspNetCore.Builder
open Microsoft.AspNetCore.Identity
open Microsoft.AspNetCore.Mvc
open Microsoft.AspNetCore.Authentication.JwtBearer
open Microsoft.IdentityModel.Tokens
open Microsoft.EntityFrameworkCore
open Microsoft.Extensions.DependencyInjection
open Microsoft.Extensions.Hosting
open Microsoft.AspNetCore.Http.Results // ← crucial for Results.Ok
open Microsoft.IdentityModel.JsonWebTokens // ← for JwtSecurityTokenHandler().WriteToken

// === Custom user ===
type ApplicationUser() =
    inherit IdentityUser()
    member val FirstName = "" with get, set
    member val LastName = "" with get, set
    member val DepartmentName = "" with get, set
    member val Salary = 0.0 with get, set
    member val Manager = "" with get, set

// === DbContext ===
type ApplicationDbContext(options: DbContextOptions<ApplicationDbContext>) =
    inherit IdentityDbContext<ApplicationUser>(options)

// === DTOs ===
type RegisterModel = {
    [<Required>] Email: string
    [<Required>] Password: string
    FirstName: string
    LastName: string
    DepartmentName: string
    Salary: float
    Manager: string
}

type LoginModel = {
    [<Required>] Email: string
    [<Required>] Password: string
}

type ForgotPasswordModel = { Email: string }

type ResetPasswordModel = {
    Email: string
    Token: string
    NewPassword: string
}

// JWT settings
let jwtSecretKey = "my-super-secret-jwt-key-32-chars-long!!"
let jwtKey = Encoding.UTF8.GetBytes(jwtSecretKey)

// === Controller ===
[<ApiController>]
type AccountController
    (
        userManager: UserManager<ApplicationUser>,
        signInManager: SignInManager<ApplicationUser>
    ) =
    inherit ControllerBase()

    [<HttpPost("/api/account/register")>]
    member _.Register(model: RegisterModel) = task {
        let user = ApplicationUser(
            UserName = model.Email,
            Email = model.Email,
            FirstName = model.FirstName,
            LastName = model.LastName,
            DepartmentName = model.DepartmentName,
            Salary = model.Salary,
            Manager = model.Manager
        )

        let! result = userManager.CreateAsync(user, model.Password)

        return
            if result.Succeeded then
                Ok "User registered successfully" :> obj
            else
                BadRequest result.Errors :> obj
    }

    [<HttpPost("/api/account/login")>]
    member _.Login(model: LoginModel) = task {
        let! result = signInManager.PasswordSignInAsync(model.Email, model.Password, false, false)

        if not result.Succeeded then
            return Unauthorized() :> obj

        let! user = userManager.FindByEmailAsync(model.Email)
        if isNull user then return Unauthorized() :> obj

        let claims = [
            Claim(ClaimTypes.NameIdentifier, user.Id)
            Claim(ClaimTypes.Name, user.UserName)
            Claim(ClaimTypes.Email, user.Email)
        ]

        let key = SymmetricSecurityKey(jwtKey)
        let creds = SigningCredentials(key, SecurityAlgorithms.HmacSha256)

        let token = JwtSecurityToken(
            issuer = "grok-api",
            audience = "grok-client",
            claims = claims,
            expires = DateTime.UtcNow.AddHours(2.0),
            signingCredentials = creds
        )

        let tokenString = JsonWebTokenHandler().WriteToken(token)

        return Ok {| token = tokenString |} :> obj
    }

    [<HttpPost("/api/account/forgot-password")>]
    member _.ForgotPassword(model: ForgotPasswordModel) = task {
        let! user = userManager.FindByEmailAsync(model.Email)
        // Always return OK for security (don’t leak user existence)
        if isNull user then
            return Ok() :> obj
        else
            let! token = userManager.GeneratePasswordResetTokenAsync(user)
            return Ok {| token = token |} :> obj
    }

    [<HttpPost("/api/account/reset-password")>]
    member _.ResetPassword(model: ResetPasswordModel) = task {
        let! user = userManager.FindByEmailAsync(model.Email)
        if isNull user then
            return BadRequest "Invalid request" :> obj

        let! result = userManager.ResetPasswordAsync(user, model.Token, model.NewPassword)

        return
            if result.Succeeded then
                Ok "Password reset successfully" :> obj
            else
                BadRequest result.Errors :> obj
    }

// === Program entry point ===
[<EntryPoint>]
let main args =
    let builder = WebApplication.CreateBuilder(args)

    // DbContext + Identity
    builder.Services
        .AddDbContext<ApplicationDbContext>(fun (opts: DbContextOptionsBuilder) ->
            opts.UseInMemoryDatabase("IdentityInMemoryDb") |> ignore)
        .AddIdentity<ApplicationUser, IdentityRole>(fun opts ->
            opts.Password.RequireDigit <- false
            opts.Password.RequiredLength <- 6
            opts.Password.RequireNonAlphanumeric <- false
            opts.Password.RequireUppercase <- false
            opts.Password.RequireLowercase <- false)
        .AddEntityFrameworkStores<ApplicationDbContext>()
        .AddDefaultTokenProviders()
    |> ignore

    // JWT Authentication
    builder.Services
        .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(fun opts ->
            opts.TokenValidationParameters <- TokenValidationParameters(
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = "grok-api",
                ValidAudience = "grok-client",
                IssuerSigningKey = SymmetricSecurityKey(jwtKey)
            ))
    |> ignore

    builder.Services.AddAuthorization() |> ignore
    builder.Services.AddControllers() |> ignore

    let app = builder.Build()

    app.UseAuthentication() |> ignore
    app.UseAuthorization() |> ignore
    app.MapControllers() |> ignore

    app.Run()
    0