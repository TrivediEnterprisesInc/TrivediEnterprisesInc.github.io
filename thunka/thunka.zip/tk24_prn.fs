(*  Brij.  HP. QP. (TM)
    Copyright (c) M. P. Trivedi 2016-2025.  All rights reserved. 
    TrivediBldHdr->
    |Trivedi SrcCtrlHdr File.  Copyright (c) 2015-2025 M. P. Trivedi.  All rights reserved.|637901455|test.fs|none|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|

    "src\UI\loggedUIRunner.fs  --platform:x64 --target:exe --out:logdUIRunr.exe -r:bin\Trivedi.Core.dll -r:bin\Trivedi.CoreAux.dll -r:bin\Trivedi.UI.dll -I:C:\Windows\Microsoft.NET\Framework\v4.0.30319"
    "src\UI\loggedUIRunner.fs  --platform:x64 --target:exe --out:load_logdUIRunr.exe -r:bin\Trivedi.Core.dll -r:bin\Trivedi.UI.dll -I:C:\Windows\Microsoft.NET\Framework\v4.0.30319"

  This module contains fns 2 fmt/output the tkLi, incl a condensed
  ver from tk24_Addenda.fs (shd l8r be expanded to incl tkL)

  NOTE: tk24_Addenda contains total 149 itms

  Updated Jan 9th 4 glot
    to filter4Brij + add subMod, output in z_PseudoDV_Categs

*)

namespace Trivedi

#nowarn "20" "25" "58" "66" "67" "64" "760" "1182" "1558"


module tkPrn =
    open System
    open System.Text.RegularExpressions

    //type Tk24(proj, mod, submod, title, contnt, complOn, tgs, cr8d_for_id);
    type Tk24 = | Tk24 of (string * string * string * string * string * string * string * string)

    //A stand-in dataset
    let addenda = [

    Tk24("Brij", "UI", "dzClient", "Grping &c.", """
    
    In the grpingDlg (+ poss other sites) we nd to add a radioBox to choose amongst UpperCase/Lower/Proper/As-Is
    CtxtHelp shld explain that this feat cn be used to unify diverse/unclean data, e.g. "ProjNm/projnm" into one categ instd. of otherwise.  Shd also mention that the _correct_ way to handle data discrepencies is to select/updateAll to correct the spelling.
    
    """, "", "", "12-19-2024")]

    let toOneLine = 
        fun s ->
            let CRs = Regex.Replace(s, "\n", "~", RegexOptions.IgnoreCase)
            let CR2 = Regex.Replace(CRs, "~~", "~", RegexOptions.IgnoreCase)
            let Spcs = Regex.Replace(CR2, "     ", "~", RegexOptions.IgnoreCase)
            match Spcs.Length > 500 with
            | true -> Spcs.Substring(0,250) + "\n" + Spcs.Substring(250,250) + "..."
            | _ -> 
                match Spcs.Length > 250 with
                | true -> Spcs.Substring(0,250) + "..."
                | _ -> Spcs

#if notReqd
    let addendaAsTks =
      addenda
      |> List.map (fun t -> 
                let (Tk24(proj, modu, submod, title, contnt, complOn, tgs, cr8d_for_id)) = t
                let m = CoreMod(CoreM((getUNID "^Task"), DateTime.TryParse(cr8d_for_id), now(), title, contnt, tgs, ""))
                Task([m], proj, modu, submod, "", 0, 0, "", false, defDt, TgtVer(""), "", CustID_Trivedi_TaskTbl())
              )
#endif //notReqd

    let recsToProc = (addenda) // @ addendaAsTks)

    //we also nd to filter out some of the grps (legacy etc.)

    recsToProc
    |> List.filter (fun itm -> 
                    let (Tk24(proj, modu, submod, title, contnt, complOn, tgs, cr8d_for_id)) = itm
                    proj = "Brij")
    |> List.groupBy(fun itm -> 
                        let (Tk24(proj, modu, submod, title, contnt, complOn, tgs, cr8d_for_id)) = itm
                        proj + "/" + modu + "/" + submod)
    |> List.sort
    |> List.map(fun gping ->
                    let (key, li) = gping
                    printfn "[[[%A (%A recs)]]]" key (li.Length)
                    )
#if onlyCats
                    List.map(fun itm -> 
                        let (Tk24(proj, modu, submod, title, contnt, complOn, tgs, cr8d_for_id)) = itm
                        printfn "|||%A" (title + "|" + tgs + "|||") //plus anything else useful
                        printfn "%A" (toOneLine contnt)
                        ) li)
#endif //onlyCats
                        
    |> ignore
    
    //For grps: Find what: \[\[\[*\]\]\]  Repl w: ^& + Highlight
    //For recs: Find what: |||*|||  Repl w: ^& + Font Bold
    
    printfn "eof"