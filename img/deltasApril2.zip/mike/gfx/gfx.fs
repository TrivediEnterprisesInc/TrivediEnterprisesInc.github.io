namespace Trivedi

//see alt type/bld @ https://github.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/blob/main/ui/2024/menu/ModelBuilder.fs

//to avoid confusion for the tree ren tags to 'path', rem list
type TreeModelItm = | TreeModelItm of unid:string * divId:string * title:string * tags:string list * parent:string * layer:string with
    member this.toString() = 
        let (TreeModelItm(u,d,t,tg,p,l)) = this
        "Unid: " + u.ToString() + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " ParentId: " + p + " Layer: " + l
    member this.toWobblyString() = 
        let (TreeModelItm(u,d,t,tg,c,l)) =   this
        """{ Unid:"{u.ToString()}", divId: "{d}", Title:"{t}" Tags:"{tg.ToString()}"  ParentId:"{p}" Layer:{l}"""

//@ToDo: add imgUrl etc.
type TreeDataItm = | TreeDataItm of unid:DocUNID * divId:string * title:string * tags:string list * content:string * notes:string with
    member this.toString() = 
        let (TreeDataItm(u,d,t,tg,c,n)) = this
        "Unid: " + u.ToString() + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " Content len: " + (c.Length).ToString() + " Notes: " + n

[<AutoOpen>]
module wwwHelpers =
    open System
    open Trivedi.Core
    open Trivedi.Brij

    //@HardCoded @ToDo: repoint to usrCurrVal after config hooks are in place
    let TitlePnTolerence = 9
    let getTitlePane =
        fun dId tit opn cont ->
            """<div id={dId} data-dojo-type="dijit/TitlePane" data-dojo-props="title: {tit}, open:{opn}">
                  {cont}
               </div>
            """
    let getMBox = 
        fun dId tit opn ->
            """
                tbfo
            """

    let getSingleDiv = 
        fun dId tit cont ->
            """<div id={dId}>
                  {cont}
               </div>
            """
    let wrapInDiv = 
        fun txt ->
            """<div>
                   {txt}
               </div>"""


[<AutoOpen>]
module gfx =
    open System
    open System.IO
    open System.Diagnostics
    open Trivedi.Core
    open Trivedi.Brij

#if tbfo
    let mShowTxtDiv =
        fun divId ->
            let allMatches = dat |> List.filter(fun itm -> itmHasTags divId)
            match (allMatches.length <= TitlePnTolerence) with
            | true when (allMatches.length = 1) ->
                allMatches |> List.head |> getSingleDiv dId tit cont
            | true when (allMatches.length > 1) ->
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getTitlePane dId tit opn cont)
            | _ -> 
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getMBox dId tit opn cont)
#endif

(*
            if (strId == "misc_www_dojo_jsonp") {
              	getDojoPulls();
            } else if (strId == "filmMain") {
		...
            } else if (strId == "changeLog") {
		... manual blds (cld feed or gen) 
            calls fetchHtmlAsText brijLog23...
          } else if (strId == "devFS") {
		let titles = ["Links", "Core", "Combinators", "Editors", "Compiler", "Snippets", "Freeware", "Reading", "Crypto", "UI"];
	        (titles.map(function (tVal, idx) {....
		...
            } else if (strId == "db") {
		let titles = ["mongo", "other"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "devMisc") {
		let titles = ["dojo", "www_Links", "www_dojo_links", "www_dojo_jsonp", "www_other","www_console","domino","crypto", "java_funct", "java_hotSwap", "java_spxDesign", "java_nlp"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "film") {
		...
            } else {
              	curDivId = dom.byId(strId);
	        var newTxt = (curDivId.innerHTML);
		mainDiv.innerHTML = newTxt;
*)


    let modelDat = [TreeModelItm("gfxTMI^1","root","Root",[],"","base");
                TreeModelItm("gfxTMI^10","dev","dev",["career"], "career","layer2");
                TreeModelItm("gfxTMI^5","devFS","F#/.net",["career";"dev"], "dev","layer3");
                TreeModelItm("gfxTMI^52","gearpers","personal",["gear"], "gear","layer2");
                TreeModelItm("gfxTMI^11","sartorial","sartorial",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm("gfxTMI^14","planning","acc.",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm("gfxTMI^12","audio","audio/ht",["gear"], "gear","layer2");
                TreeModelItm("gfxTMI^13","furniture","furniture",["gear"], "gear","layer2");
                TreeModelItm("gfxTMI^15","film","film",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^16","food","food",["body"], "body","layer2");
                TreeModelItm("gfxTMI^51","exercise","exercise",["body"], "body","layer2");
                TreeModelItm("gfxTMI^17","NYCeat","NYC Eating Out",["body";"food"], "food","layer3");
                TreeModelItm("gfxTMI^53","miscFood","food misc",["body";"food"], "food","layer3");
                TreeModelItm("gfxTMI^18","re","real estate",["gear"], "gear","layer3");
                TreeModelItm("gfxTMI^19","NYCStorage","storage",["gear"], "gear","layer2");
                TreeModelItm("gfxTMI^20","NYCdesi","Desi Stuff",["mind";"mindAmuse";"social"], "social","layer2");
                TreeModelItm("gfxTMI^33","db","db",["career";"dev"], "dev","layer3");
                TreeModelItm("gfxTMI^39","corp","corp",["career";"dev"], "dev","layer3");
                TreeModelItm("gfxTMI^350","devAPI","currentAPI",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm("gfxTMI^351","flowcharts","flowcharts",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm("gfxTMI^352","changeLog","log",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm("gfxTMI^353","eagleEye","eagleEye",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm("gfxTMI^37","career","work",[],"","layer1");
                TreeModelItm("gfxTMI^34","mind","mind",[],"","layer1");
                TreeModelItm("gfxTMI^35","body","body",[],"","layer1");
                TreeModelItm("gfxTMI^36","gear","gear",[],"","layer1");
                TreeModelItm("gfxTMI^46","music","music",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^38","social","social",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^339","devNotes","notes",["career"], "career","layer2");
                TreeModelItm("gfxTMI^50","miscJob","jobs",["career"], "career","layer2");
                TreeModelItm("gfxTMI^90","fin","finance",["career"], "career","layer2");
                TreeModelItm("gfxTMI^44","mindAmuse","amuse",["mind"], "mind","layer2");
                TreeModelItm("gfxTMI^40","mindInstr","instruct",["mind"], "mind","layer2");
                TreeModelItm("gfxTMI^45","elevate","elevate",["mind"], "mind","layer2");
                TreeModelItm("gfxTMI^270","elevateLinks","elevateLinks",["mind";"elevate"], "elevate","layer3");
                TreeModelItm("gfxTMI^271","buddhism","buddhism",["mind";"elevate"], "elevate","layer3");
                TreeModelItm("gfxTMI^21","lrnlang","languages",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm("gfxTMI^41","lrnFrench","french",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm("gfxTMI^42","lrnUrdu","urdu",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm("gfxTMI^43","lrnGujarati","gujarati",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm("gfxTMI^48","artLit","art/lit",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm("gfxTMI^49","edOther","other",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm("gfxTMI^47","miscReading","reading",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^50","amusetravel","travel",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^51","travelNYC","nyc",["mind";"mindAmuse";"amusetravel"], "amusetravel","layer4");
                TreeModelItm("gfxTMI^96","tv","tv",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^399","devMisc","misc",["career";"dev"], "dev","layer3");
                TreeModelItm("gfxTMI^118","recM2S","m2s",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm("gfxTMI^119","recOther","other",["mind";"mindAmuse"], "mindAmuse","layer3")]

    let dat = 
        [ TreeDataItm((getUNID "gfxItm"), "root", "Root Pane", [], """
<div id="mainNotesPane0" data-dojo-props="title:'Freq. Accessed', open:true" data-dojo-type="dijit/TitlePane"> 
<!--LINKS BEGIN-->
<table id="linksTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>
    <td style="width: 20%;">
      <ul>
	<li><a href="https://forecast.weather.gov/MapClick.php?w0=t&w2=hi&w3=sfcwind&w3u=1&w4=sky&w7=rain&w10u=0&w12u=1&w13u=1&AheadHour=48&FcstType=graphical&textField1=27.9093&textField2=-82.2966&site=all&unit=0&dd=&bw=&BackDay.x=76&BackDay.y=5">weather.gov</a><br>
	<li><a href="https://www.accuweather.com/en/us/bloomingdale/33596/minute-weather-forecast/2230854">accuWthr</a>
	<li><a href="https://ap.org">ap</a>&nbsp;&nbsp;<a href="https://reuters.com">reuters</a>
	<li><a href="https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml">nyt</a>&nbsp;<a href="https://www.theguardian.com/uk">Guardian</a><br>
	<li><a href="http://www.mid-day.com/">mid-day</a>
	<li><a href="http://www.wikipedia.org">Wikipedia</a>
        </ul>

	</td>
	
<td style="width: 40%;">
<ul>
  <li>APIs-><A HREF="https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.checkbox?view=windowsdesktop-6.0&viewFallbackFrom=netframework-6.0">.net</A>&nbsp;<A HREF="https://docs.microsoft.com/en-us/dotnet/fsharp/tour">F#</A>; <a href='https://fsharp.github.io/fsharp-core-docs/reference/fsharp-collections-listmodule.html'>mods</a></li>
  <li>dotNet <A HREF="https://github.com/dotnet/installer">installer</A></li>
  <li>Compiler.<A HREF="https://www.nuget.org/packages/FSharp.Compiler.Tools/4.0.1.20">Tools</A></li>
  <li><a href='https://try.fsharp.org'>fable</a>&nbsp;
  <a href='https://tryfsharp.fsbolero.io/'>Bolero</a>&nbsp;
  <a href='https://repl.it/languages/fsharp'>repl.it</a>&nbsp;
  <a href='https://paiza.io/en/languages/fsharp'>paiza</a>&nbsp;
  <a href='https://glot.io/new/fsharp'>glot</a>&nbsp;
  <A HREF="https://dotnetfiddle.net/">.netFiddle</A></li>
  <li>.Net&nbsp;src:<A HREF="https://github.com/dotnet/fsharp/search?p=2&q=repo%3Adotnet%2Ffsharp+isassignablefrom&type=">F#</a>&nbsp;<a href='https://github.com/dotnet/winforms/tree/main/src/System.Windows.Forms/src/System/Windows/Forms'>WinForms</a></li>
  <li>unitTests:&nbsp; <a href='https://github.com/dotnet/fsharp/tree/main/tests/FSharp.Core.UnitTests/FSharp.Core/Microsoft.FSharp.Collections'>Collections</a></li>
</ul></td>
	
    <td style="width: 40%;">
      <ul>
		  <li><a href="https://www.diffchecker.com/diff">1</a>&nbsp;<a href="https://www.ddginc-usa.com/text-compare-tool.htm">2</a>&nbsp;<a href="http://www.mergely.com/editor">mergely</a>&nbsp;<a href="http://www.diffnow.com/editor">diffNow</a>
		  <li><a href='https://regex101.com'>RegEx101</a>&nbsp;<a href='https://regexr.com/'>RegExr</a></li>
          <li>.Net&nbsp;<a href='https://docs.microsoft.com/en-us/dotnet/standard/base-types/regular-expression-language-quick-reference#character-escapes'>Regex</a>&nbsp;<a href='https://docs.microsoft.com/en-us/dotnet/standard/base-types/regular-expression-options'>options</a></li>
		  <li>Regexp <a href='http://www.molbiotools.com/textextractor.html'>textracter</a></li>
		  <li><a href='http://7-zip.com'>7zip</a>&nbsp;&nbsp;<a href='https://www.motobit.com/util/base64-decoder-encoder.asp?charset=utf-8&acharset='>motoBit</a></li>
      <li><a href="http://plnkr.co/edit/">Plnkr</a></li>
      <li>Word<a href='http://www.tools.zenverse.net/word-wrap/'>Wrap</a>&nbsp txt</li>
        </tr>
      </ul>
	  </td>
	</tr>
    </tbody>
</table>
</div><!--mainNotesPane0-->
<p>
<div id="mainNotesPane1" data-dojo-props="title:'Other', open:true" data-dojo-type="dijit/TitlePane"> 

| <mark onclick="window.open('https://gist.github.com/TrivediEnterprisesInc/51c145a2b1de80cdac0c0e11024064c4#templating', '_blank').focus();"">FlowCharts</mark> | <mark onclick="window.open('https://gist.github.com/TrivediEnterprisesInc/51c145a2b1de80cdac0c0e11024064c4#table-of-contents', '_blank').focus();"">Notes</mark> | <mark onclick="window.open('https://gist.github.com/TrivediEnterprisesInc/51c145a2b1de80cdac0c0e11024064c4#outstanding-tks', '_blank').focus();"">TaskList</mark> | <mark onclick="mAlert('Tibbie: Incorp. into mBoxes...');">Snippets</mark> |
<p>
<hr>
<p>
Avoiding .Net regex <a href='https://docs.microsoft.com/en-us/dotnet/standard/base-types/backtracking-in-regular-expressions'>timeouts</a> w/backtracking & grouping
<p>
<hr>
<p>

<details> <br /> <summary><span class='mHG'>Other reading</span></summary>
<br>DanLuu|HN: the <a href="https://danluu.com/hn-comments/">good</a> parts
<br><a href="https://www.case-podcast.org/">Conversations</a> about Software Engineering (some chkd)
<br><a href="https://hbr.org/2017/05/what-the-best-transformational-leaders-do">Harvard Biz Rev</a>
<br>Frontline <a href="https://www.pbs.org/wgbh/pages/frontline/shows/diet/">Shows</a>
<br>Movie <a href="scripts.com">scripts</a>
<br><a href="https://www.ted.com/search?q=transcript">TED</a> Talk transcripts
<hr>
<br>p.m: lake mule layer blossom pill shoe obvious current toast senior gesture until
<br>rp: (num) YYOD + ### nr agitProp + (txt) riot-oriented hollins + (FN) iit bobby prem
<br>ml: (col) flow'd like de river + (txt) 100EDOok + (numTxt) hollins bonMotty
<br>g: (reg) hollins BangAcn
<hr><br>Jan:
<br>rp:"Bananas x 3 (hin, FN)"; "(txt) hollins suscept. to this kalam"; "TIK acr from Prem's place"; 
<br>ml:"Band's narrow? Breakout, probly (1st)";"(num) MMDDOdipti"; "mercurialRepo chinese equiv."; 
<br>fin:"(txt) hollins surpei"; "Change b/h pool 2 get (1st)"; "Huge chap w/a secretary fan (nick)"
<hr><br>
May eom:
<br>rp:"(num) YYOBS + ##SiteOfHammer"; "(col) ashD or orcl";"(1 wd) 1 lvl up frm advSpkrs"
<br>ml:"(num) YYOD + ### nr agitProp"; "(col) TrikeBkCol"; "(1 wd) ei-di-ding (x2) goldee"
<hr>
June:
<br>"(col) ashD or orcl", "(num) tri cld've been flooded if in nyc", "(F wd) astr Pan had william's candy"
<br>"(col) RMGSHouse", "(num) ##ReiSol + ###Haussm.", "(1 wd) Paresh: isi qual __ refl"
<hr>

</details>
</div> <!--id="mainNotesPane1"-->

""", "")
    ]

(*
    Regexp for divs

//TreeDataItm of unid:string * divId:string * title:string * tags:string list * content:string * notes:string
        NOTE that the divID is the 1st listed in the model (not the readable one) is 'devFS' not 'F#/.net'
*)




    let appendAble =
    [ TreeDataItm((getUNID "gfxItm"), "devFS", "Compiler", [], """
                <section>
                    <div id="F_Compiler">
            <br>F# Compiler service <a href='https://fsharp.github.io/FSharp.Compiler.Service/reference/FSharp.Compiler.SourceCodeServices.html'>examples</a>
            <br> (has both FSharpSyntaxTokenKind.Function & FSharpSyntaxTokenKind.Val)
            <br>Tokenizing / <a href='https://raw.githubusercontent.com/fsharp/FSharp.Compiler.Service/master/src/fsharp/service/ServiceLexing.fs'>Lexing</a> src. code 
            <br>https://fsharp.github.io/FSharp.Compiler.Service/index.html
            <br>Using <a href='https://github.com/dotnet/roslyn'>Roslyn</a> to <a href='https://docs.microsoft.com/en-us/archive/msdn-magazine/2015/february/the-working-programmer-rise-of-roslyn-part-2-writing-diagnostics'>parse</a> the AST.
<br>fcs samples <A HREF="https://raw.githubusercontent.com/dotnet/fsharp/main/fcs-samples/Tokenizer/Program.fs">Tokenization</a> example (uses & requires FSharp.Compiler.SourceCodeServices)
<br>fsprojects snippet which uses <a href='http://fsprojects.github.io/FSharp.Formatting/codeformat.html'>Fsharp.Formatting.CodeFormat.dll</a> to tokenize F# source.
            <br>Understand the .NET Compiler Platform <a href='https://docs.microsoft.com/en-us/dotnet/csharp/roslyn-sdk/compiler-api-model'>SDK model</a>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Editors", [], """
                <section>
                    <div id="F_Editors">
<br>
            <ul><li>
            no line#s...takes whatever you enter and wraps it in a Main method which is then <A HREF="https://matthewmanela.com/projects/fastsharp/">wrapped in a class</A> </li>
            <li><A HREF="https://github.com/fsharpn00b/Tagger">Tagger: A WPF-based text editor</A></li>
            <li>Menu, undo, fonts -> <A HREF="https://github.com/seabass189/FSharp-Notepad">seabass189/FSharp-Notepad</A></li>
              <li>no line#s...Less than 300 lines but console-> <A HREF="https://github.com/JustinPealing/fs-kilo">Port of Kilo editor</A></li>
              <li><A HREF="https://github.com/mmanela/FastSharp">FastSharp</a> is a text editor which lets you quickly compile and run C#, F# and Visual Basic code without opening up Visual Studio.</li>
              <li>Adding line#s <A HREF="https://www.codeproject.com/Articles/12152/Numbering-lines-of-RichTextBox-in-NET-2-0">(.net20)</A></li>
                <li>also see <a href='https://stackoverflow.com/questions/17994674/c-sharp-wpf-line-and-column-number-from-richtextbox'>this</a></li>  
                <li>Line col in <a href='https://stackoverflow.com/questions/11229507/line-column-in-richtextbox-wpf/17995824#17995824'>richTxtBox</a></li>
                <li>srch in <a href='https://stackoverflow.com/questions/1756844/making-a-simple-search-function-making-the-cursor-jump-to-or-highlight-the-wo'>richTxtBox</a></li>
                <li>Space After New Lines in <a href='https://stackoverflow.com/questions/9897582/space-after-new-lines-in-richtextbox/9897847#9897847'>RichTextBox</a></li>
                </ul>
<br>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Crypto", [], """
                <section>
                    <div id="F_Crypto">
            <BR>.net5 PBE <A HREF="https://docs.microsoft.com/en-us/dotnet/api/system.security.cryptography.pbeparameters?view=net-5.0">api</A>
 
            <BR>CodeProj: <A HREF="https://www.codeproject.com/Articles/16450/Emulating-PBEWithMD5AndDES-Encryption-under-NET">emulating</A> PBE under .net
 
            <BR>.net/Java interop <A HREF="https://galfar.vevb.net/wp/2014/net-and-java-generating-interoperable-aes-key-and-iv/">AES</A> w IV
 
            <BR><A HREF="http://lamahashim.blogspot.cz/2009/08/encyptiondecryption-in-c-and-java.html">crypto</A> in C & Java
 
            <BR><A HREF="http://steelmon.wordpress.com/2013/07/01/simple-interoperable-encryption-in-java-and-net/">InterOp</A> encr in Java/dotNet
 
            <BR>Translate PBE from <A HREF="https://cuteprogramming.wordpress.com/2015/02/20/translate-pbe-codes-from-java-to-c/">Java to C</A>

<br>A <a href='https://github.com/SalusaSecondus/CryptoGotchas'>collection</a> of common (interesting) cryptographic mistakes and learning resources.
<br>Representing SHA-256 Hashes As <a href='https://francoisbest.com/posts/2021/hashvatars'>Avatars</a> 
<br><a href='https://robohash.org/'>related</a>: generate unique images from any text (above art also refers to github/goog using this methd)

                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Core", [], """
                <section>
                    <div id="F_Core">

<div id="MonadPane" data-dojo-props="title:'Monads'" data-dojo-type="dijit/TitlePane"> 
<!--LINKS BEGIN-->
<table id="MonadTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>

<details><summary>Cont Monad</summary>
School of Haskell:The Mother of all Monads (<a href='https://www.schoolofhaskell.com/school/advanced-haskell/the-mother-of-all-monads'>Dan Piponi</a>)'s exc. intro; refers to his <a href='http://sneezy.cs.nott.ac.uk/fplunch/weblog/?m=200712'>post</a>
<br>
per riptutorial.com; async in F# is a Continuation Monad; A coroutine Monad.
<br>
from brian McNamara(msft)'s blog (catamorphisms <a href='https://lorgonblog.wordpress.com/2008/06/07/catamorphisms-part-seven/'>series</a>):
<br><pre><code>
type ContinuationBuilder() =
    member this.Return(x) = (fun k -> k x) 
    member this.ReturnFrom(x) = x 
    member this.Bind(m,f) = (fun k -> m (fun a -> f a k))
    member this.Delay(f) = f()
let K = new ContinuationBuilder()
</code></pre>
This def isn't congruent to Haskell's (since they use the predefined m)<br>
...(I) wrote CallCC at the representation level; I think this is maybe also the "traditional" approach for such monads...
<br>(see <a href='http://fpish.net/topic/Some/1/58050'>discussion</a> on fpish)
<br>Some other definitions:
<ul><li>
Scott Wlaschin's <a href='https://swlaschin.gitbooks.io/fsharpforfunandprofit/content/posts/computation-expressions-continuations.html'>article</a> on continuations with CE.</li>
<li><a href='http://fssnip.net/7VQ'>Brian Berns</a>' version on fssnip</li>
<li><a href='http://fssnip.net/7c'>Ryan Riley</a>'s version on fssnip</li>
<li>one more <a href='https://fsharpcode.blogspot.com/2009/12/f-continuation-monad.html'>F# def</a> </li></ul>
</details><p>

<details>
  <summary>Monad Transformers etc.</summary>
  <br>
  (OCaml) Monad Transformers <a href='https://github.com/rgrinberg/ocaml-mtl/blob/master/lib/mtl.ml'>Lib</a> w/links to further reading etc.
& [[lots of stuff <a href='http://lambda.jimpryor.net/'>here</a>]]
<br>also see for tranformers:
<ul><li>
http://lambda.jimpryor.net/topics/week9_monad_transformers/</li>
<li>https://gist.github.com/naoto-ogawa/97fe0e1236f31aac9bbfd4a6c73a91b7</li>
<li>http://patryshev.com/books/Transformers.pdf (Haskell)
</li></ul>
<br>
<br>manual Transformers ->
<br><pre><code>
let hoist (a: option<a>): Async<option<a>> = async {return a}
let lift (a: Async<a>): Async<option<a>> = a |> Async.map Some
</code></pre>
<br>
<br>https://github.com/ocaml-batteries-team/batteries-included/
<br>
here's the batInterface.ml def of Monad:
<br><pre><code>
module type Monad = sig
  type 'a m
  val bind : 'a m -> ('a -> 'b m) -> 'b m
  val return: 'a -> 'a m
end
</code></pre>
<br>
Here's how oCaml defines State (reversed) ->
<br>(<a href='https://github.com/Chattered/ocaml-monad/blob/master/src/monad.ml'>Chattered</a>/ocaml-monad) ln # 473
<br><pre><code>
module State(T : sig type s end) =
struct
  include Make(struct
                type 'a m = T.s -> (T.s * 'a)
                let return x s  = (s, x)
                let bind xf f s =
                  let s',x = xf s in
                  f x s'
              end)
  let read s    = (s,s)
  let write x s = (x,())
  let run x s   = x s
  let eval x s  = snd (x s)
  let modify f  = bind read (fun s -> write (f s))
end
</code></pre>
Also chk <a href='https://github.com/Chattered/ocaml-monad/blob/master/src/applicative.ml'>Chattered</a> applicative <br>
<br>

<span class='mTitle'>Monad</span> threads, mostly from fpish:
Monad for Composing <a href='http://fpish.net/topic/Some/1/58741'>UI Elements</a><br>
continuation monad and <a href="http://fpish.net/topic/Some/1/58050">call/cc</a><br>
A Few Questions about F# Workflows <a href="http://fpish.net/topic/Some/1/57733">one </a> 
<a href="http://fpish.net/topic/Some/1/59392">two </a> 
<a href="http://fpish.net/topic/Some/1/59713">three </a> 
<a href="http://fpish.net/topic/Some/0/59208">four </a>
<a href="http://fpish.net/topic/Some/0/59830">five </a>
<a href="http://fpish.net/topic/Some/0/59129">six </a>
<a href="http://fpish.net/topic/Some/0/57839">seven</a>
<a href="http://fpish.net/topic/Some/0/74214">eight</a>
<a href="http://fpish.net/topic/Some/0/58003">nine</a>
<a href="http://fpish.net/topic/Some/0/58003">ten</a>

<br>

</details>
<p>
<details>
  <summary>Links to OCaml reading on Monads</summary>
'Can monads help me my refactor code for an enhanced <a href='https://discuss.ocaml.org/t/can-monads-help-me-my-refactor-code-foran-enhanced-data-structure/1064'>data structure?</a><br>
 
An <a href='https://discuss.ocaml.org/t/an-intermediate-abstraction-between-applicatives-and-monads/3441'>intermediate abstraction</a> between applicatives and monads<br>
              <a href='https://discuss.ocaml.org/t/ann-monads-the-missing-monad-transformers-library/830'>[ANN] Monads</a> - the missing monad transformers library<br>
<a href='https://discuss.ocaml.org/t/error-handling-with-ocaml-github/4478'
>Error handling</a> with `ocaml-github`<br>
 
<br>Threading/ <a href='https://discuss.ocaml.org/t/threading-io-monad-vs-threads-the-case-of-web-app-servers/6935'
>IO monad vs threads</a>: the case of web-app servers
 
<br>'Interfacing mutable operations within a functional <a href='https://discuss.ocaml.org/t/interfacing-mutable-operations-within-a-functional-core-program-design/6243'>core</a> - program design'
</details>
<br>
</details>
<p>

Wikipedia on Generalizations of monads:
<br><a href='https://en.wikipedia.org/wiki/Arrow_(computer_science)'>Arrows</a> use additional structure to bring plain functions and monads under a single interface
<br>Monad <a href='https://en.wikipedia.org/wiki/Monad_transformer'>transformers</a> act on distinct monads to combine them modularly
Alternatives for modeling computations:
<br><a href='https://en.wikipedia.org/wiki/Effect_system'>Effect systems</a> are a different way to describe side effects as types
<br><a href='https://en.wikipedia.org/wiki/Uniqueness_type '>Uniqueness types</a> are a third approach to handling side-effects in functional languages (mpt: no gd.)
<p>



</tr>
</tbody>
</table>
</div>

<br><hr><br>

<div id="QuotationsPane" data-dojo-props="title:'Quotations'" data-dojo-type="dijit/TitlePane"> 
<!--LINKS BEGIN-->
<table id="QuotationsTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>
Quotations <a href="https://ghostbin.com/EpVTI/">snippet</a>
<p>
from the F# Repo:
<br>This has a fn traversing/using MANY quotPatterns -> Quotations <a href='https://github.com/dotnet/fsharp/blob/dbf9a625d3188184ecb787a536ddb85a4ea7a587/tests/fsharp/core/quotesDebugInfo/test.fsx'>debug</a>
<br>Here are all the patterns (Line#2251) <a href='https://github.com/dotnet/fsharp/blob/00397560ad3d6777f5a5181123bda731bdf875b6/src/fsharp/FSharp.Core/quotations.fs'>quotations.fs</a>
<p>

<details>
  <summary>The three main things you should know about the quotations API</summary>
(from Traversing and transforming F# quotations: A guided <a href='http://fortysix-and-two.blogspot.com/2009/06/traversing-and-transforming-f.html'>tour</a>)<br>
<ul><li>
Quotations.Expr and Quotations.Patterns are each others dual: they are used for constructing and deconstructing Expr types respectively;</li>
<li>Quotations.ExprShape contains the workhorse of any quotations-using implementation: a zipper-like pattern for traversing and transforming any quotation in a straightforward way</li>
<li>Splicing is used to effectively and readably construct parameterized expressions as an alternative to Expr.Whatever calls.</li></ul><p>
<pre><code>
// tryFindOne to get an Option<'t> 
let john = people.tryFindOne q fun person , person.Name = "John" @> 
// findOne to get a single existing document 
let firstAlbum = albums.findOne <@ fun album -> album.Id = 1 @> 
// findMany to get many documents of seq<'t> that match the query 
let popularAlbums = albums.findMany <@ fun album -> album.IsPopular @> 
// using "not" function let unverifiedEmails = accounts.findMany <@ fun ace -> not acc.EmailVerified @> 
// with comparison operators 
let albumsWithManySongs = albums.findMany q fun album -> album.SongCount > 50 
// composite operators 
let popularAndHaveManySongs = albums.findMany q fun album -> album.IsPopular && album.SongCount 50 
// full search with a customized predicate 
let releasedThisYear = albums.fullSearch <@ fun album -> album.DateReleased @> (fun dateReleased -> dateReleased.Year = DateTime.Now.Year) 
</code></pre>
</details>
<p>

<details>
  <summary>Dec'21 Task: @Rsch ex quot work for feeding string to cmp/eval</summary>

<br>This suffices -> (uniLicense; based on the old PowerPack)
<br>https://fsprojects.github.io/FSharp.Quotations.Evaluator/tutorial.html
<br>On-the-fly code generation
<br>You can generate lambdas and compile them dynamically:
<pre><code>
	let tupler = 
	    let v = Var("x",typeof<int>)
	    let v = Expr.Lambda(v, Expr.NewTuple [Expr.Var v; Expr.Var v]) // codegen (fun x -> (x,x))
	    v.CompileUntyped() :?> (int -> (int * int))

	tupler 78  // (78, 78)
</code></pre>
</details>
<p>
<hr>
I can't talk about Clojure since I have't used it, but I know a bit about DSLs in F#. F# provides two main language oriented programming features (which is what Don Syme likes to call them): code quotations and computation expressions.
<hr>
Code quotations are closer to what you would get with macros in a language like Lisp. They allow you to <a href='https://brandewinder.com/2016/02/20/converting-dsl-to-fsharp-code-part-1/'>generate expressions programmatically</a> which you can then execute. By using the ReflectedDefinition attribute on F# expressions you get access to their ASTs. See <a href='http://msdn.microsoft.com/en-us/library/dd233212.aspx'>msdn</a> for more details.
<hr>

<h5>Wrapping <a href='https://bugsquash.blogspot.com/2012/03/wrapping-visitors-with-active-patterns.html'>visitors</a> with active patterns in F#</h5><br>
(this is one of the guys bhd FSharpx)<br>
(using Visitors + a dsl-like (from scratch) evaluator for simple logicOps
cn be extended...)  See also  Juliet Rosenthal's SO post mentioned.
<p>
</tr>
</tbody>
</table>
<br>
                </div>
<br><hr><br>
<div id="PointFreePane" data-dojo-props="title:'Point-Free/Tacit'" data-dojo-type="dijit/TitlePane"> 
<table id="PointFreeTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>
<p>
<a href='https://blog.jayway.com/2012/05/08/point-free-programming-style-in-f/'>Point-free</a> programming style in F#
<p>
Tom P's ans to an SO qn inv lazy seq / <a href='https://stackoverflow.com/questions/9386255/write-f-sequence-expression-point-free'>point-free</a>
<p>
<a href='https://stackoverflow.com/questions/5671271/what-are-advantages-and-disadvantages-of-point-free-style-in-functional-progra'>SO: Advantages</a> and disadvantages of "point free" style (1st resp v gd., f# eg below)
<p>
<a href='https://dev.to/shimmer/f-tip-4-when-not-to-use-point-free-style-57m3'>Brian Berns</a> on point-free style
<pre><code>let safeSqrt = Option.filter ((<=) 0.0) >> Option.map sqrt</code></pre>
<p>
Eric T.'s <a href='https://eiriktsarpalis.wordpress.com/2017/04/02/programming-in-the-point-free-style/'>Programming</a> in the Point-Free Style
<pre><code>let f = Option.map sqrt << Option.filter ((<=) 0.)</code></pre>
<p>
...Eventually you end up in <a href='https://danielbmarkham.com/f-good-and-bad/'>point-free world</a>, where foo|>bar|>baz and so on.
<p>

</tr>
</tbody>
</table>
</div>

                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Combinators", [], """
                <section>
                    <div id="F_Combinators">
    <div id='birdsTable'>
    <h6>From <a href='Chris.Rathman@gmail.com'>Chris Rathman</a>'s <a href='https://www.angelfire.com/tx4/cus/combinator/birds.html'>site</a></h6>
    <table border='2' width='100%'>

   <tr style='font-weight:bold'><td nowrap> Function Abstraction                                          </td><td nowrap> Symbol                            </td><td nowrap> Bird                        </td><td nowrap> Combinator            </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.a(bc)                                </td><td nowrap> B                                 </td><td nowrap> Bluebird                    </td><td nowrap> S(KS)K                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.a(bcd)                              </td><td nowrap> B<sub>1</sub>                     </td><td nowrap> Blackbird                   </td><td nowrap> BBB                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.a(bcde)                            </td><td nowrap> B<sub>2</sub>                     </td><td nowrap> Bunting                     </td><td nowrap> B(BBB)B               </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.a(b(cd))                            </td><td nowrap> B<sub>3</sub>                     </td><td nowrap> Becard                      </td><td nowrap> B(BB)B                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.acb                                  </td><td nowrap> C                                 </td><td nowrap> Cardinal                    </td><td nowrap> S(BBS)(KK)            </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.ab(cd)                              </td><td nowrap> D                                 </td><td nowrap> Dove                        </td><td nowrap> BB                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.abc(de)                            </td><td nowrap> D<sub>1</sub>                     </td><td nowrap> Dickcissel                  </td><td nowrap> B(BB)                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.a(bc)(de)                          </td><td nowrap> D<sub>2</sub>                     </td><td nowrap> Dovekies                    </td><td nowrap> BB(BB)                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.ab(cde)                            </td><td nowrap> E                                 </td><td nowrap> Eagle                       </td><td nowrap> B(BBB)                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcdefg.a(bcd)(efg)                      </td><td nowrap> &#202;                            </td><td nowrap> Bald Eagle                  </td><td nowrap> B(BBB)(B(BBB))        </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.cba                                  </td><td nowrap> F                                 </td><td nowrap> Finch                       </td><td nowrap> ETTET                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.ad(bc)                              </td><td nowrap> G                                 </td><td nowrap> Goldfinch                   </td><td nowrap> BBC                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.abcb                                 </td><td nowrap> H                                 </td><td nowrap> Hummingbird                 </td><td nowrap> BW(BC)                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>a.a                                      </td><td nowrap> I                                 </td><td nowrap> Identity Bird (aka Idiot)   </td><td nowrap> SKK                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.ab(adc)                             </td><td nowrap> J                                 </td><td nowrap> Jay                         </td><td nowrap> B(BC)(W(BC(B(BBB))))  </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.a                                     </td><td nowrap> K                                 </td><td nowrap> Kestrel (True)              </td><td nowrap> K                     </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.a(bb)                                 </td><td nowrap> L                                 </td><td nowrap> Lark                        </td><td nowrap> CBM                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>a.aa                                     </td><td nowrap> M                                 </td><td nowrap> Mockingbird                 </td><td nowrap> SII                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.ab(ab)                                </td><td nowrap> M<sub>2</sub>                     </td><td nowrap> Double Mockingbird          </td><td nowrap> BM                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.b(ab)                                 </td><td nowrap> O                                 </td><td nowrap> Owl                         </td><td nowrap> SI                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.b(ac)                                </td><td nowrap> Q                                 </td><td nowrap> Queer Bird                  </td><td nowrap> CB                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.a(cb)                                </td><td nowrap> Q<sub>1</sub>                     </td><td nowrap> Quixotic Bird               </td><td nowrap> BCB                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.b(ca)                                </td><td nowrap> Q<sub>2</sub>                     </td><td nowrap> Quizzical Bird              </td><td nowrap> C(BCB)                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.c(ab)                                </td><td nowrap> Q<sub>3</sub>                     </td><td nowrap> Quirky Bird                 </td><td nowrap> BT                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.c(ba)                                </td><td nowrap> Q<sub>4</sub>                     </td><td nowrap> Quacky Bird                 </td><td nowrap> F*B                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.bca                                  </td><td nowrap> R                                 </td><td nowrap> Robin                       </td><td nowrap> BBT                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.ac(bc)                               </td><td nowrap> S                                 </td><td nowrap> Starling                    </td><td nowrap> S                     </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.ba                                    </td><td nowrap> T                                 </td><td nowrap> Thrush                      </td><td nowrap> CI                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.b(aab)                                </td><td nowrap> U                                 </td><td nowrap> Turing                      </td><td nowrap> LO                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.cab                                  </td><td nowrap> V                                 </td><td nowrap> Vireo (aka Pairing)         </td><td nowrap> BCT                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.abb                                   </td><td nowrap> W                                 </td><td nowrap> Warbler                     </td><td nowrap> C(BMR)                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.baa                                   </td><td nowrap> W<sup>1</sup>                     </td><td nowrap> Converse Warbler            </td><td nowrap> CW                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>a.a(<font face='symbol'>&#108;</font>a)  </td><td nowrap> Y                                 </td><td nowrap> Why Bird (aka Sage Bird)    </td><td nowrap> SLL                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.ab                                    </td><td nowrap> I*                                </td><td nowrap> Identity Bird Once Removed  </td><td nowrap> S(SK)                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.abcc                                 </td><td nowrap> W*                                </td><td nowrap> Warbler Once Removed        </td><td nowrap> BW                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.abdc                                </td><td nowrap> C*                                </td><td nowrap> Cardinal Once Removed       </td><td nowrap> BC                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.acdb                                </td><td nowrap> R*                                </td><td nowrap> Robin Once Removed          </td><td nowrap> C*C*                  </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.adcb                                </td><td nowrap> F*                                </td><td nowrap> Finch Once Removed          </td><td nowrap> BC*R*                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.acbd                                </td><td nowrap> V*                                </td><td nowrap> Vireo Once Removed          </td><td nowrap> C*F*                  </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abc.abc                                  </td><td nowrap> I**                               </td><td nowrap> Identity Bird Twice Removed </td><td nowrap> &nbsp;                </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcd.abcdd                               </td><td nowrap> W**                               </td><td nowrap> Warbler Twice Removed       </td><td nowrap> B(BW)                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.abced                              </td><td nowrap> C**                               </td><td nowrap> Cardinal Twice Removed      </td><td nowrap> BC*                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.abdec                              </td><td nowrap> R**                               </td><td nowrap> Robin Twice Removed         </td><td nowrap> BR*                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.abedc                              </td><td nowrap> F**                               </td><td nowrap> Finch Twice Removed         </td><td nowrap> BF*                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>abcde.abecd                              </td><td nowrap> V**                               </td><td nowrap> Vireo Twice Removed         </td><td nowrap> BV*                   </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.b                                     </td><td nowrap> KI                                </td><td nowrap> Kite (False)                </td><td nowrap> KI                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>                                         </td><td nowrap> <font face='symbol'>&#087;</font> </td><td nowrap> Omega                       </td><td nowrap> MM                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.bb                                    </td><td nowrap> KM                                </td><td nowrap> Konstant Mocker             </td><td nowrap> KM                    </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>ab.aa                                    </td><td nowrap> C(KM)                             </td><td nowrap> Crossed Konstant Mocker     </td><td nowrap> C(KM)                 </td></tr>

   <tr valign='top'><td nowrap> <font face='symbol'>&#108;</font>                                         </td><td nowrap> <font face='symbol'>&#081;</font> </td><td nowrap> Theta                       </td><td nowrap> YO                    </td></tr>
</table>
</div><!--birdsTable-->
<p>
<hr>
<br>
A <b>combinator</b> is a higher-order function that uses only function application and earlier defined combinators to define a result from its arguments.
<br>
inv. (1920)...Schnfinkel's system was essentially equivalent to a combinatory logic based upon the combinators 
<div class="tooltip">B<span class="tooltiptext">
-- | B combinator - bluebird - Haskell ('.').
<br>bluebird :: (b -> c) -> (a -> b) -> a -> c
<br>bluebird = (.)
</span></div>, 
<div class="tooltip">C
  <span class="tooltiptext">
-- | C combinator - cardinal - Haskell 'flip'.
<br>cardinal :: (a -> b -> c) -> b -> a -> c
<br>cardinal = flip
 </span></div>, 
I, 
<div class="tooltip">K
  <span class="tooltiptext">
<br>-- | K combinator - kestrel - Haskell 'const'.
<br>-- Corresponds to the encoding of @true@ in the lambda calculus.
<br>kestrel :: a -> b -> a
<br>kestrel = const </span></div>, and 
<div class="tooltip">S
  <span class="tooltiptext">
-- | S combinator - starling. 
<br>-- Haskell: Applicative\'s @(\<*\>)@ on functions.
<br>-- Substitution.
<br>starling :: (a -> b -> c) -> (a -> b) -> a -> c
<br>starling f g x = f x (g x)
</span></div>, 
 
. Schonfinkel was able to show that the system could be reduced to just K and S (i.e., SKI calculus) and outlined a proof that a version of this system had the same power as predicate logic.
<br>
His paper also showed that functions of two or more arguments could be replaced by functions taking a single argument (i.e., Currying)
<p>
    Haskell <a href='https://hackage.haskell.org/package/data-aviary-0.4.0/docs/src/Data-Aviary-Birds.html#bluebird'>Aviary</a>
<br>&nbsp;&nbsp;&nbsp;&nbsp;
<a href='https://www.angelfire.com/tx4/cus/combinator/birds.html'>(more compl.) Bird list</a>
<br>

<details><summary>raganwald</summary>
... more @ his <a href='https://github.com/raganwald-deprecated/homoiconic'>backup</a> repo; addresses Ruby/js but v. useable ...
<br>
<details>
  <summary>
(raganwald) Given fn;  {do! (side-effect) (fn) (side-effect) }
  </summary>
A combinator that takes a function and imposes some 
side effects before and after the function
<br>e.g.,
<br>Free memory (C) after using it (B) whenever we have allocated it (A)
<br>or
<br>open files/sockets (A), reading/writing (B), then closing them (C)
<br>or
<br>accessing mutexen (A), working therein (B), and leaving (C)
<br>A composition of Kestrel and Thrush gets the job done:
<br>	K(Txy) = Kyx = y
<br>	K(Txyz) = Kyxz = yz
<br>	<b>K(K(Txyz))</b> = K(Kyxz) = Kyz = y
</details>
<br>
<details>
  <summary>(raganwald) Kestrels for DSL  </summary>
<br>HardDrive.new.capacity(150).external.speed(7200)
<br>Instead of:
<br>hd = HardDrive.new
<br>hd.capacity = 150
<br>hd.external = true
<br>hd.speed = 7200
OR instead of
<br>def fizz(arr)
<br>&nbsp;&nbsp;&nbsp;&nbsp;	arr.pop
<br>&nbsp;&nbsp;&nbsp;&nbsp;	arr.map! { |n| n * 2 }
<br>end
<br>We can write:
<br>
<br>def fizz(arr)
<br>&nbsp;&nbsp;&nbsp;&nbsp;  arr.tap(&:pop).map! { |n| n * 2 }
<br>end
<br>also, (@ lst in Ruby) K:Object#dont is the Ruby-semantic equivalent of commenting out a method call, only it can be <br>inserted inside of an existing expression, eg.
<br>JoinBetweenTwoModels.dont.create!(...) do |new_join|
</details>
<br>
<details>
  <summary>(raganwald) Using a 3-param-C as a fn generator  </summary>
<br>The Cardinal is written Cxyz = xzy. In Ruby:
<br>&nbsp;&nbsp;&nbsp;&nbsp;cardinal.call(proc_over_proc).call(a_value).call(a_proc)
<br>&nbsp;&nbsp;&nbsp;&nbsp;  => proc_over_proc.call(a_proc).call(a_value)
<br>This implies that proc_over_proc is a function that takes a function as its argument and returns a function; i.e., you want a cardinal when you would like to modify what a function does.
<br>
</details>
<br>
<details>
  <summary>(raganwald) Using the 
<!--div class="tooltip"-->Quirky <!--span class="tooltiptext"--><br>-- | Q3 combinator - quirky bird.<br>quirky :: (a -> b) -> a -> (b -> c) -> c<br>quirky f x g = g (f x)<!--/span--> Bird </summary>
<br>The quirky bird is written Q3xyz = z(xy). In Ruby:
<br>&nbsp;&nbsp;&nbsp;&nbsp;quirky.call(value_proc).call(a_value).call(a_proc)
<br>&nbsp;&nbsp;&nbsp;&nbsp;  => a_proc.call(value_proc.call(a_value))
<br>Like the cardinal, the quirky bird reverses the order of application. But where the cardinal modifies the function that is applied to a value, the quirky bird modifies the value itself. 
<br><b>ie, Q  addOne 2 squareFirst  = 5</b>
</details>
</details>
<br>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Reading", [], """
                <section>
                    <div id="F_Reading">
<BR><A HREF="https://fsharpforfunandprofit.com/series/thinking-functionally/">Steve W.</A>
<br><a href='https://github.com/raganwald-deprecated/homoiconic/blob/master/2008-10-29/kestrel.markdown'>raganwald</a>
            <BR><A HREF="https://sergeytihon.com/fsharp-weekly/"> Sergey Tihon's Blog (Chk past posts)</A>
            <br>fpish.net
            <br>sturmnet.org
            <br>ikriv.com
<details>
  <summary>From Eirik Tsarpalis' blog  (more remains to be chkd)</summary>
<BR>Practical <a href='https://eiriktsarpalis.wordpress.com/2016/08/05/typeshape-practical-generic-programming-in-f/'>Generic programming</a> in f# 
<br>F# and <a href='https://eiriktsarpalis.wordpress.com/2017/03/06/f-and-purity/'>purity</a> (note the comments) 
<br>Encoding <a href='https://eiriktsarpalis.wordpress.com/2019/07/02/applying-the-tagless-final-pattern-in-f-generic-programs/'>Higher-Kinded Types</a> in F# (workaround)
<br><a href='https://eiriktsarpalis.wordpress.com/2016/11/19/reconciling-stacktraces-with-computation-expressions-revisited/
'>Reconciling Stacktraces</a> with Computation Expressions
</details>
<br>
FSharpX library contribs-><br><ul>
<li><a href='http://www.navision-blog.de/blog/'>Steffen Forkmann</a></li>
<li><a href='http://tomasp.net/'>Tomas Petricek</a></li>
<li><a href='https://github.com/panesofglass'>Ryan Riley</a></li>
https://github.com/panesofglass/computation-expressions-workshop</li>
<li><a href='http://bugsquash.blogspot.com/'>Mauricio Scheffer</a></li>
<li><a href='http://jackfoxy.com/'>Jack Fox</a> </li></ul>

<br><a href='https://lorgonblog.wordpress.com/2010/05/'>Brian McNamara (msft)</a>'s Blog: 
Graphing a subReddit using F# & DGML
<br>Matt Thornton's <a href='https://dev.to/choc13/series/12008'>Monad</a> Series
            <BR>https://geekeh.com/
            <BR>https://thinkbeforecoding.com/
            <BR>https://www.wtfsharp.net/hosts/stachu
            <BR>https://devonburriss.me/tag/fsharp/
<p>
<a href="https://ghostbin.com/L4tve/">SO</a> threads on F# (some selected; + more remain to chk)
<p>
<details>
  <summary>Some reading & links from fpish</summary><br>
<br>F# web <a href='https://marketplace.visualstudio.com/items?itemName=JomoFisherMSFT.FWebDataFeedASPNETOData'>data feed</a>
<br>Should I use monads to carry the <a href='http://fpish.net/topic/Some/7/58252'>"context"</a> of my program?
<br>Apparently, I don't understand <a href='http://fpish.net/topic/Some/7/56857'>pattern matching</a><br>
How-to <a href='http://fpish.net/topic/Some/7/58985'>Use FParSec</a> for parsing simple text<br>
<a href='http://fpish.net/topic/Some/7/59738'>Type</a> classes in F#<br>
How to convert C# windows form <a href='http://fpish.net/topic/Some/7/58788'>application to F#</a> codes.. T_T heeellpp<br>
Decorating ASTs with <a href='http://fpish.net/topic/Some/9/57438'>line numbers</a><br>
ASP.NET and F# - Creating <a href='http://fpish.net/topic/Some/10/59407'>MVC web applications</a> in F#<br>
</details>
<p>

<hr>
<details> 
 <summary><span class='mHG'>Forums</span></summary> 
  <li><a href='https://www.reddit.com/'>Reddit</a></li>
	<li> <a href='https://www.dzone.com/'>dZone</a></li>
	<li><a href='https://news.ycombinator.com/'>HackerNews</a></li>
<li><a href="https://lobste.rs">Lobster</a> forums: 
tagged by <a href="https://lobste.rs/t/dotnet">dotnet</a> 
<a href="https://lobste.rs/t/haskell">haskell</a>
<a href="https://lobste.rs/t/ml">ml</a>
<a href="https://lobste.rs/t/ruby">ruby</a>
<a href="https://lobste.rs/t/wasm">wasm</a>
<a href="https://lobste.rs/t/windows">windows</a></li>

<li><a href="https://forums.codeguru.com">codeGuru</a></li>
<li><a href="https://www.codeproject.com">codeProject</a></li>
<li><a href="https://bytes.com/browse/">Bytes</a></li>
<li><a href="https://www.dreamincode.net">dreamInCode</a></li>
<li><a href="http://lambda-the-ultimate.org/">Lambda the ultimate</a></li>
</details>
<p>

<details>
  <summary>
    Some reading links (Aug 7 2021; mostly from codeproject.com)
  </summary>
<br>
<br>
<Sacha Barber has a series on F#><br>
https://www.codeproject.com/Articles/246323/A-Coder-Interview-With-Sacha-Barber<br>
	https://www.codeproject.com/Articles/767639/Fsharp-Generics<br>
	https://www.codeproject.com/Articles/769819/Fsharp-Reflection<br>
	https://www.codeproject.com/Articles/775751/Fsharp-Interop<br>
<br>
https://www.codeproject.com/Tips/125781/Reading-Zip-files-in-F<br>
**https://www.codeproject.com/Reference/315638/List-of-freely-available-programming-books<br>
https://www.codeproject.com/Articles/680100/Overview-of-the-NET-Framework<br>
https://www.codeproject.com/Articles/235221/Monadic-Parsing-in-Fsharp<br>
https://www.codeproject.com/Articles/241577/Embedded-scripting-using-Fsharp<br>
https://www.codeproject.com/Articles/95656/Using-a-DataRader-like-a-List-in-F<br>
https://www.codeproject.com/Articles/30999/ScriptEngine-User-Defined-Calculations-in-C-VB-JSc<br>
https://www.codeproject.com/Tips/137779/Optimize-references-in-closures-in-F<br>
https://www.codeproject.com/Articles/5301612/Using-an-Fsharp-DSL-to-generate-Csharp-code<br>
https://www.codeproject.com/Articles/5165750/How-I-Got-Started-with-Bolero<br>
<br>
<series>https://www.codeproject.com/Articles/277701/A-Coder-Interview-With-Dan-Mohl<br>
<br>
<blog site; poss more f#>http://blogs.tedneward.com/patterns/closurebasedstate-fsharp/<br>
** https://www.openfsharp.org/ -> spkrs often have github links<br>
<br>
https://github.com/fsharp/fslang-suggestions/issues?q=is%3Aissue+is%3Aopen+sort%3Areactions-%2B1-desc<br>
<br>
https://medium.com/hackernoon/reflecting-on-f-in-2017-5ac67fb138ff -><br>
* Suave and Giraffe emerged as two dominant libraries to use when writing web services on .NET Core, with Freya as a brilliant alternative that everyone should try out as well.<br>
* Fable rapidly evolved from an interesting project with potential into an impressive and fully-fledged alternative for JavaScript in the browser, allowing you to write Full-Stack F# applications.<br><br>
<br>
</details>
<p>
<details>
  <summary>
    New('21 May04) F# reading from HN 
  </summary>
  <br>
  I just sat in a Mathematical Planning seminar with a guy from Quicken Loans who uses F# in production at work (Matthew Crews). He is also an author behind the Flips F# library.
<br>
<br>A quick list of F# libs for real world, everyday uses:
 
<br>* Pulumi / Farmer - code as infrastructure
 
<br>* FAKE - build tool
 
<br>* Fable - javascript transpiler
 
<br>* Feliz - react elements
 
<br>* FSharp.Data - parsing csvs, html pages
 
<br><a href='https://github.com/haf'>http.fs</a> : A simple, functional HTTP client library for F# 
  
<hr>
<br>Note:
<br>Poss. reason behind the @MBIs trying to force 'earlier version' adoption ->
 
<br>,,,(if you're targetting) Mono assemblies ... do lag .NET CLR in functionality, so 
you'll probably need to use an F# version a few minor releases earlier 
than the official one.
 
<br>(So if they want to steal/use code elsewhere (bastas prefer macs) they'd have to... )
 
<br>
<br><a href='http://danielbachler.de/2020/12/23/what-i-wish-i-knew-when-learning-fsharp.html'>what i wish i knew when learning fsharp</a>
<br>
<br>https://ericsink.com/entries/fsharp_chasm.html
<br>
<br>https://github.com/Kavignon/fsharp-companies
<br>
<br>F# using companies: Jet did, but they're now dead...or do they still live on inside of the greater Walmart (Labs?) organization?
Their F# projects under github.com/jet are still active
<br>
<br>Quant finance: G-Research
<br>
<br>Q: Can anyone recommend a a project or two that is small enough for a newcomer to wrap their minds around, that also exemplifies what makes a high quality F# codebase?
 
<br><a href='https://news.ycombinator.com/item?id=25305650'>2021</a>
<br><a href='https://news.ycombinator.com/item?id=15578592'>2017</a>
<br><a href='https://news.ycombinator.com/item?id=11771266'>2016</a>
 
<br>* Compositional IT has a lot of good blog posts on how they use F# to solve real world problems.
<br>* Kit Eason's Stylish F# is a good book.
 
<br><a href='https://hn.algolia.com/?dateRange=all&page=0&prefix=false&query=F%23&sort=byPopularity&type=all'>HN F# threads (only read one)</a>
</details>
<p>
<hr>
<p>
<details>
  <summary>
    Notes from Podcasts
  </summary>
  <br>
<h3>Rachel Reese (Jet)</h3>
<ul>
<li>300+ microsvcs in F#
</li><li>TypeProv.s with CSV files
</li><li>Heavy Xamarin.Forms usage
</li></ul>
<br>
<h3>Bob Martin (Uncle Bob)</h3>
<ul>
<li>TopDnDev 4 mocks (sketch out top 1st instd of botm)
</li><li>Lazy Lists
</li><li>Assignment (rewrite w/o using); use rec
</li><li>cleanCode (closure site)
</li><li>koans + katas exist forAll SICP stuff
</li></ul>
<br>
<h3>Phil Carter (MSFT F# hd)</h3>
<ul>
<li>as part of dotNet eventually expect F# to native
</li><li>FSIs provide: TypeDefs + API + doc
</li><li>The compiler can be customized for use
</li></ul>
<br>
</details>


</details>
<p>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "FreeWare", [], """
                <section>
                    <div id="F_Freeware">
          <h4>Unlicense or cc0-1.0(no attrib) f# projects</h4>
              <br> Github srch <a href='https://github.com/search?q=license%3Aunlicense++language%3AF%23+license%3Acc0-1.0&type=Repositories'>query</a>
 
              <br>Chessie.ErrorHandling (<a href='https://raw.githubusercontent.com/fsprojects/Chessie/master/src/Chessie/ErrorHandling.fs'>Railway-oriented</a> programming)
 
              <br><a href='http://fsprojects.github.io/FSharpx.Extras/'>FSharpx.Extras</a>
              has Reader/Writer/Async, Regexp stuff & some other stuff, gd examples
 
              <br>FSharp.Quotations.Evaluator.Tools (contains <a href="https://raw.githubusercontent.com/fsprojects/FSharp.Quotations.Evaluator/master/src/FSharp.Quotations.Evaluator/Tools.fs">7tpl</a> & expression stuff)
 
              <br>fsprojects/FSharp.Compiler.CodeDom (has a  <a href="https://raw.githubusercontent.com/fsprojects/FSharp.Compiler.CodeDom/master/src/FSharp.Compiler.CodeDom/CodeDomVisitor.fs">CodeDom Visitor</a> and compiler for ides
 
              <br>REF: This contains a file 'waitUntilExists' func:
              https://github.com/microsoft/fsharplu/blob/master/FSharpLu/File.fs
              (use w = new System.IO.FileSystemWatcher(parentDir, fileName, IncludeSubdirectories = false, EnableRaisingEvents = true))
 
              <br>REF: <a href='https://github.com/CraftyFella/TableStorageLocal'>Azure Db</a> locally stored (using LiteDb) entirely in f#, with emulator
<br>
<br>
 
<hr>
<br>fsharplu: MIT License (displ lic on substantial reuse)
<br>/// State machine-based asynchronous agents
<br>/// ... supports fork/join, continuations
<br>namespace <a href='https://raw.githubusercontent.com/microsoft/fsharplu/master/FSharpLu/StateMachine.fs'>Microsoft.FSharpLu.Actor.StateMachine</a>
 
<br>// This module implements a lightweight Http server using HttpListener.
<br>/// The purpose of the server is to enable inter-process communication
<br>module <a href='https://github.com/microsoft/fsharplu/blob/master/FSharpLu/HttpCommunication.fs'>Microsoft.FSharpLu.HttpCommunication</a>
<hr>
<br>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Snippets", [], """
                <section>
                    <div id="F_Snippets">
            <BR><a href="https://github.com/fssnippets/fssnip-website">fs snip</a>
 
            <br> nice <a href='http://fssnip.net/1q/title/Memoization-and-Tail-Recursive-Function'>Memoize</a> example
 
            <BR>https://github.com/mikhailshilkov/azure-functions-fsharp-examples 
            Regexp (straight net api calls):
            <pre><code>
            let TestConnString = 
                """<add name="MyConnString" connectionString="Server=MyServer;Database=MyDatabase;User ID=me;Password=secret;Encrypt=True;TrustServerCertificate=True;Enlist=False;" />"""
            Regex.Match(connectionString, "[dD]atabase=(?<database>.*?);").Groups.["database"].Value
            </code></pre>
            <p>
<p>
</details>
<br>
           
            <details><summary>SecureString</summary>
            <pre><code>
            For console.readPwd; look @ Security.SecureString;
            <br>pump into Marshal.SecureStringToGlobalAllocUnicode
            <br>then to Marshal.PtrToStringUni & finallly Marshal.ZeroFreeGlobalAllocUnicode
            <br>match (Console.ReadKey true).KeyChar 
            <br>with 
            | '\r' | '\n' -> 
                            Console.WriteLine ()
                            charList
            | chr -> 
                            Console.Write '*'
                            readKey <| chr :: charList
            </code></pre>
</details>    <p>
<hr>
<p>
<details><summary>CSV parsing</summary>
<pre><code>
// An example of how you might manually parse a CSV file in F#.
 
open System
open System.IO
Environment.CurrentDirectory <- __SOURCE_DIRECTORY__
 
let file = @"..\..\data\FootballResults.csv"
type Result =
    { Date : DateTime
      Home : string
      Away : string
      HomeGoals : int
      AwayGoals : int }
 
let data =
    file
    |> File.ReadAllLines
    |> Seq.skip 1
    |> Seq.map(fun row ->
        let fields = row.Split ','
        { Date = DateTime.ParseExact(fields.[0], "MM/dd/yyyy", null)
          Home = fields.[1]
          Away = fields.[2]
          HomeGoals = int fields.[3]
          AwayGoals = int fields.[4] })
 
data
|> Seq.filter(fun row -> row.HomeGoals > row.AwayGoals)
|> Seq.countBy(fun row -> row.Home)
|> Seq.sortByDescending snd
|> Seq.take 3
</code></pre>
</details><br>
<hr>
<details>
<summary>List fold snippet from EventSourcing-DIY</summary>
<br>
<pre><code>
module List
 
    /// Map a Result producing function over a list to get a new Result
    /// ('a -> Result<'b>) -> 'a list -> Result<'b list>
    let traverseResult f list =
 
      // define the monadic functions
      let (>>=) x f = Result.bind f x
      let retn = Result.Ok
 
      // right fold over the list
      let initState = retn []
      let folder head tail =
          f head >>= (fun h ->
          tail >>= (fun t ->
          retn (h :: t) ))
 
      List.foldBack folder list initState
</code></pre>
</details>
<p>
<hr>
fslang-suggestions: Allow <a href='https://github.com/fsharp/fslang-suggestions/issues/1079'>Unicode</a> <a href='https://en.wikipedia.org/wiki/Miscellaneous_Symbols'>symbols</a> to be used as operators -> has a working workaround

<br>Unicode Symbol <a href='http:\\www.unicode-symbol.com\block\Misc_Technical.html'>Table</a>
<hr><br>
Fpish: <a href='http://fpish.net/topic/Some/0/59733'>Event.guard</a> to run Async if race conditions
<br>Event.guard takes a lambda and an event, and returns that same event except it will run the lambda after subscribing so that you never 'miss' the event if the lambda may provoke it.
<hr><br>
Composing <a href='https://gist.github.com/kurt-mueller-osumc/0dffb4eb30b7dd7f8c2682f241d72a2b'>validations</a> together to parse a csv file (no invalid inpt allowed via only valid types resulting.)
<hr><br>
<details>
<summary>(DSyme) Operators You Might Need to Know</summary>
<br>f1 &gt;&gt; f2                         Function composition<br>(expr1, expr2) ||&gt; f             Two-argument pipelining <br>(expr1, expr2, expr3) |||&gt; f     Three-argument pipelining <br><br>n..step..m                       Range with step (within a list or sequence or loop)<br><br>let (|A|_|) arg = &hellip;              Defining active patterns<br>let (|A|B|) arg = &hellip;              Defining active patterns<br><br>&lt;@ &hellip; @&gt;                          Code quotation (expression tree)<br>&lt;@@ &hellip; @@&gt;                        Code quotation (expression tree, untyped)<br><br>Operators You Don't Need to Know<br>!cell                            Dereference a mutable reference cell.  Use cell.Value instead<br>:=                               Assign a mutable reference cell.  Use &quot;cell.Value &lt;- expr&quot; instead<br>@                                Append one list to another.  Can normally use a computed list expression or List.append instead<br><br>&lt;&lt;                               Backward function composition, discouraged in favour of forward composition<br><br>&lt;|                               Back-piping, discouraged in favour of forward piping <br>&lt;||                              Back-piping, discouraged in favour of forward piping <br>&lt;|||                             Back-piping, discouraged in favour of forward piping <br><br>*?, +? &hellip;                         Nullable operators (these are used exceptionally rarely in LINQ queries, ignore these)<br><br>Should I Define My Own Operators?<br>Almost certainly not. See msft design <a href='https://docs.microsoft.com/en-us/dotnet/fsharp/style-guide/component-design-guidelines#avoid-defining-custom-symbolic-operators'>guidelines</a><br><br>
<br>
</details>
<p>
<p>
<details><summary>Reflection on Nested Types in DU</summary>
<pre><code>
    open System

    type OptModID = | OptModID of i_modNm: string

    type DocVersionModule = | DocVersionModule of OptModID * lastVerNum:int * hasPriorVers:bool with
        member this.desc() = 
         let (DocVersionModule(OptModID(modNm), lastVerNum, hasPriorVers)) = this
         "Optional Module: " + modNm + 
           match hasPriorVers with
           | true -> " has PriorVersions = true; lastVersionNumber: " + lastVerNum.ToString()
           | _ -> " doesn't have PriorVersions"

    let oldM = DocVersionModule( OptModID("ver 2") , 2, false)

    type CustomVer =
        | DocVersionModule of DocVersionModule
        | CustomVer of DocVersionModule * newFld:string

    let oldM2 = CustomVer.DocVersionModule(oldM)
    let newM = CustomVer(oldM, "newFld")

    let li:list<_> = [oldM2; newM]

    List.map(fun (x) -> 
                match x with
                | DocVersionModule m -> printfn "found old mod:%A " m
                | _ -> printfn "found new mod:%A " x

            ) li |> ignore

> typeof<Shape>.GetNestedTypes()
|> Seq.iter (fun t -> 
    let p = t.GetProperties() 
    let s = 
        p
        |> Array.map (fun p -> sprintf "%s: %s" p.Name p.PropertyType.Name) 
        |> String.concat "; "
    printfn "Nested type %s: %i Properties %s" t.Name p.Length s
)
</code></pre>
<br><b>Also, from quotations.fs (f# repo)</b>
  <pre><code>
    let getUnionCaseInfoField(unionCase:UnionCaseInfo, index) =
        let fields = unionCase.GetFields()
        if index < 0 || index >= fields.Length then invalidArg "index" (SR.GetString(SR.QinvalidCaseIndex))
        fields.[index]
  </code></pre>
<p>
</details>
<br>
                </div>
                </section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "Links", [], """
<section>
<div id="F_Links">
<br>
<div data-dojo-id="F_Links1" data-dojo-type="dijit/TitlePane" data-dojo-props='title:"Card Games", open:false'>
<details><summary>Card Games</summary>
<ul><li>Google public domain <a href='https://code.google.com/archive/p/vector-playing-cards/downloads'>playing cards</a> image set (PNG/SVG)
</li><li>A brief <a href='https://www.mrgamez.com/casino-games/bridge/apps/'>review</a> of 3 bridge apps (incl freeware)
</li><li>Contract Bridge bidding <a href='https://tedmuller.us/Bridge.htm'>puzzles</a>
</li><li>More Bridge <a href='http://www.rpbridge.net/rppz.htm'>puzzles</a>
</li></ul>
<br>
</div>
<p>
<div data-dojo-id="F_Links2" data-dojo-type="dijit/TitlePane" data-dojo-props='title:"Chess", open:false'>
pgn <a href='https://www.chessclub.com/help/PGN-spec'>spec</a><br>
Tons of pgn games by player/<a href='http://www.pgnmentor.com/files.html#openings'>opening</a><br>
Online FEN position <a href='https://www.dailychess.com/chess/chess-fen-viewer.php'>viewer</a><br>
Garden of Chess <a href='https://dwheeler.com/chess-openings/'>Openings</a><br>
Annotated Games <a href='https://www.angelfire.com/games3/smartbridge/'>repo</a><br>
WikiMedia <a href='https://commons.wikimedia.org/wiki/Chess_pieces'>chess</a> icons<br>
<a href='https://github.com/AndoBando/pgn2fen'>C & C++</a> versions of pgn2fen
<hr>
<details><summary>F# chess progs</summary>
<br>
<a href='https://github.com/pbbwfc/FsChessPgn'>FsChessPgn</a>: a library for chess scripting using F#
<br>FsChessPgn is a library for scripting in F# that provides chess facilities such as move generation, move validation and support for common chess formats such as FEN and PGN.
<br><a href='https://pbbwfc.github.io/FsChessPgn/'>Docs</a>
<br><ul><li>Generates images of a Board in PNG format.
</li><li>Can make moves given a Board. Can both make and unmake moves given a Game.
</li><li>Show a simple ASCII board | Detects checkmates and stalemates | Detects checks and attacks
</li><li>Reads and writes PGNs. Supports headers, comments, NAGs and a tree of variations
</li></ul>
<hr>
<a href='https://github.com/JordanMarr/FsharpChess'>FsharpChess</a>
<br>Chess with an F# domain engine and a simple WPF UI.
<br>Console version (C#) using <a href='https://github.com/JordanMarr/FsharpChess/blob/master/Chess.ConsoleUI/Program.cs'>emoji</a> glyphs
<hr>
<a href='https://github.com/simon-reynolds/FsChess'>FsChess</a>
<br>A toy chess engine written in F#.  So far it only implements basic moves, more complicated moved like en passant and castling are still to do
</details>
<p>
                Chess links:
                <br> Pgn board <a href='http://pgn4web-board-generator.casaschi.net/board-generator.html#game_preview'>generator</a>
                <br>Understanding the <a href='http://www.ez-net.com/~mephisto/Understanding%20King's%20Indian%20Attack.html'>KIA</a>
                <br>KIA <a href='https://en.wikipedia.org/wiki/King%27s_Indian_Attack#Famous_games'>famous</a> games
                <br>
<p>

</div>
<p>
<div data-dojo-id="F_Links3" data-dojo-type="dijit/TitlePane" data-dojo-props='title:"Assemblies", open:false'>
<br><a href='https://docs.microsoft.com/en-us/dotnet/standard/assembly/versioning'>Version checking</a> only occurs with strong-named assemblies.
<br>You can also <a href='https://docs.microsoft.com/en-us/dotnet/framework/configure-apps/redirect-assembly-versions#redirect-versions-at-the-app-level'>Limit/require</a> assembly bindings to a specific version, etc.
<br>To use two or more versions of an assembly in the same application (<a href="https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/extern-alias">extern alias</a>); e.g.
<br>(cmdLine) /r:GridV1=grid.dll /r:GridV2=grid20.dll
<br>This creates the external aliases GridV1 and GridV2; use via GridV1::Grid or GridV2::Grid
<br>
<br>Set assembly attribs via (inline in code) ->
<br>
<br>[assembly:AssemblyVersionAttribute("2.0.1")] //major.minor.build.revision
<br>AssemblyCompanyAttribute("company name")
<br>AssemblyCopyrightAttribute("copyright information")
<br>AssemblyProductAttribute("product information")
<br>AssemblyDescriptionAttribute("") nature and purpose of the assembly.
<br>AssemblyDefaultAliasAttribute("") <-String specifying a default alias to be used by referencing assemblies.  can also be used as a short form of the full assembly name.
<br>AssemblyTitleAttribute("") <-String specifying a friendly name for the assembly. For example, an assembly named comdlg might have the title Microsoft Common Dialog Control.
</div>
<p>
<div data-dojo-id="F_Links4" data-dojo-type="dijit/TitlePane" data-dojo-props='title:"WebSockets", open:false'>
<p>
<br><a href='https://github.com/dotnet/AspNetCore.Docs/blob/main/aspnetcore/fundamentals/websockets.md'>github .net: websockets on ASP</a>
<br><a href='https://github.com/dotnet/AspNetCore.Docs/blob/main/aspnetcore/fundamentals/websockets/samples/2.x/WebSocketsSample/Startup.cs'>webSock echo</a>
<br><a href='https://docs.microsoft.com/en-us/aspnet/core/fundamentals/servers/kestrel?view=aspnetcore-5.0'>Kestrel</a> on ASP .net core
<br>MDN: Writing a WebSocket server <a href='https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API/Writing_WebSocket_server'>in C#</a>
<br>MDN: Writing WebSocket servers (gen workflow, <a href='https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API/Writing_WebSocket_servers'>lang agnostic</a>)
<br>High-performance, idiomatic, zero-dependency, Async-based, F# WebSocket server with supervision and ticker <a href='https://github.com/erpuno/ws'>in 200 LOC</a>
<br>Reddit <a href='https://www.reddit.com/r/fsharp/comments/ksl8dz/f_websocket_server/'>Code review req.</a> for above
<br><a href='https://github.com/TheAngryByrd/FSharp.Control.WebSockets'>FSharp.Control.WebSockets</a> wraps dotnet websockets in FSharp friendly functions and has a ThreadSafe version.
<br>F# <a href='https://gist.github.com/panesofglass/03589f24f14f7c1e5899'>WebSockets</a> : panesofglass (dated but v gd; even has pointers to other work)
<br>FSharp-WebSocket-Server-Client using Asp.net Core's <a href='https://github.com/jmhickman/FSharp-WebSocket-Server-Client'>Kestrel server</a>
<br><a href='https://github.com/SuaveIO/suave'>Sauve</a>
</div>
<p>
<h3>Jack Pappas</h3> (<a href='https://github.com/jack-pappas'>ExtCore</a> + F# yaccs + parsing + logic/theorem proving )
<p>
<hr>
<br>Google <a href='https://github.com/google/jimfs'>Jimfs</a> and <a href="https://raw.githubusercontent.com/google/jimfs/master/jimfs/src/test/java/com/google/common/jimfs/WindowsPathTypeTest.java">Windows</a> test
<br>Google DiffMatchPatch <a href='https://raw.githubusercontent.com/google/diff-match-patch/master/csharp/DiffMatchPatch.cs'>c#</a> version and <a href='https://github.com/google/diff-match-patch/blob/62f2e689f498f9c92dbc588c58750addec9b1654/csharp/tests/DiffMatchPatchTest.cs#L92'> tests</a>
<p>
Github markdown <a href='https:\\docs.github.com\en\github\writing-on-github\getting-started-with-writing-and-formatting-on-github\basic-writing-and-formatting-syntax'>Syntax</a>
<p>
<hr>
    <BR>F# <a href='https://github.com/dungpa/fsharp-cheatsheet'>cheatsheet</a>
    <BR>F# <a href='https://github.com/ccdschool/fsharpdaybyday'>Day by Day</a>
          <BR>Get programming <a href='https://github.com/isaacabraham/get-programming-fsharp'>w/F#</a>
        <BR><A HREF="https://docs.microsoft.com/en-us/archive/msdn-magazine/2019/september/fsharp-do-it-all-with-fsharp-on-net-core">F# - Do It All with F# on .NET Core | Microsoft Docs</A>
        <BR><A HREF="https://dl.acm.org/doi/pdf/10.1145/3386325">The Early History of F#</A>
        <BR><A HREF="https://www.whoishostingthis.com/resources/f-sharp/">F# resources, incl eBks</A>
<p>
<hr>
(old stuff from the other bookmarks file) f#  .netCore<br>
<p>
<br><A HREF="https://docs.microsoft.com/en-us/dotnet/">.NET</A> documentation | Microsoft Docs
<br>.NET <A HREF="https://docs.microsoft.com/en-us/dotnet/core/introduction">introduction</A> and overview | Microsoft Docs
<br>Building a <A HREF="http://www.fssnip.net/9q/title/Building-a-WPF-application-in-functional-way">WPF</A> application in functional way | F# Snippets
<br>Develop <A HREF="https://docs.microsoft.com/en-us/dotnet/core/tutorials/libraries">libraries</A> with the .NET CLI - .NET | Microsoft Docs
<br>F# - Do <A HREF="https://docs.microsoft.com/en-us/archive/msdn-magazine/2019/september/fsharp-do-it-all-with-fsharp-on-net-core">It All</A> with F# on .NET Core | Microsoft Docs
<br>F# - <A HREF="https://docs.microsoft.com/en-us/archive/msdn-magazine/2019/october/fsharp-safe-stack-functional-web-programming-for-net-core">SAFE</A> Stack: Functional Web Programming for .NET Core | Microsoft Docs
<br>F# coding <A HREF="https://docs.microsoft.com/en-us/dotnet/fsharp/style-guide/conventions">conventions</A> | Microsoft Docs
<br><A HREF="https://docs.microsoft.com/en-us/dotnet/fsharp/">F# docs</A> - get started, tutorials, reference. | Microsoft Docs
<br><A HREF="https://www.tangiblesoftwaresolutions.com/product_details/java_to_csharp_converter.html">java2c#</A> Commercial, free demo
<br>paulirwin/<A HREF="https://github.com/paulirwin/JavaToCSharp">JavaToCSharp</A>
<br><A HREF="https://medium.com/@pauldbau/a-guide-to-sharpen-a-great-tool-for-converting-java-to-c-1a1892a239ca" ADD_DATE="1615308815">Sharpen</A> (java to c#)
<br><A HREF="https://docs.microsoft.com/en-us/dotnet/core/compatibility/unsupported-apis">Unsupported APIs</A> on .NET Core and .NET 5+ | Microsoft Docs
<br>Using F# on <A HREF="https://docs.microsoft.com/en-us/dotnet/fsharp/using-fsharp-on-azure/">Azure</A> | Microsoft Docs
<br>What's new in .NET <A HREF="https://docs.microsoft.com/en-us/dotnet/core/dotnet-five">5</A> | Microsoft Docs
<br><A HREF="https://docs.microsoft.com/en-us/previous-versions/troubleshoot/visualstudio/general/jlca-available-download">JLCA</A> is available now - Visual Studio | Microsoft Docs
<p>
</div></section>
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "", [], """
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "", [], """
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "", [], """
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "", [], """
""", "");
 TreeDataItm((getUNID "gfxItm"), "devFS", "", [], """
""", "")
]

    ...lico for appendable...

    let writeModelFile() = File.WriteAllBytes("gfxModel.bdf", (serBA modelDat))
    let writeDatFile() = File.WriteAllBytes("gfxDat.bdf", (serBA dat))
    //let prnDat = fun dat -> dat |> List.mapi (fun i x -> printfn "%A) %A" i (x.toString())) |> ignore
  
    let chkFile =
        fun fn -> 
            hr()
            printfn "now trying to read %A ..." fn
            let body = (File.ReadAllBytes(Path.Combine("C:\\Users\\inets\\Desktop\\mike\\bin\\gfx",fn)))
            let li = (deSerBA body) :?> list<TreeModelItm>
            printfn "len: %A" li.Length
            //prnDat li
            hr()

(*    

    let getTreeOb = fun dat -> List.fold (fun s v -> s + "\n" + v.toWobblyString() + ",\n") "" dat
            
    let genDjConfig = 
        fun dat ->
            let hdr = """
    var djConfig = {
      isDebug: true, 
      popup:true, 
      parseOnLoad: true, 
      useCustomLogger:true,
      mData : [
"""
            let ftr = """
],
      debugPrintStr : "dojoConfig"
    };
"""
            let newCfg = hdr + (getTreeOb dat) + ftr
            File.WriteAllText("djconfig.js", newCfg) //overwrite
*)

    [<EntryPoint>]
    [<STAThread>]
    let main ag =
        printfn "main:1"
        match ag.Length = 0 with 
        | true -> 
            printfn "main:2"
            try
                hr()
                printfn "*******chk file : "
                chkFile "gfxDat.bdf"
                System.Console.Write("back in main...pls press any key to continue...")
            with
                | e -> 
                    printfn "Exc in main: %A" e.Message
                    let st = ((new StackTrace(e, true)).GetFrames()).[0]
                    printfn "Immed.-> method: %A lineNo:%A col: %A" (st.GetMethod().Name) (st.GetFileLineNumber()) (st.GetFileColumnNumber())
                    printfn "StackTr -> \r\n%A" (getStTrace e)
        | false ->
            System.Console.Write("back in main...pls press any key to continue...")
        let c = System.Console.ReadKey(true)
        match c.Key with
        | ConsoleKey.Escape -> printfn "Esc..."
        | _ -> printfn "..."
        0