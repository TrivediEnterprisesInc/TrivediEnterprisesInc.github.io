﻿namespace Trivedi


type GfxCalItm = | GfxCalItm of unid:string * divId:string * title:string *  content:string * notes:string with
    member this.toString() = 
        let (GfxCalItm(u,d,t,c,n)) = this
        "Unid: " + u + " entryDate: " + d + " Title: " + t + " Content len: " + (c.Length).ToString() + " Notes: " + n
    member this.toWob() = 
        let (GfxCalItm(u,dt,t,c,n)) = this
        //let d = System.DateTime.Parse(d); //"May-24-24"
        match System.DateTime.TryParse dt with
        | true, d -> 
            //@Watchout: no logic 4 end of month; but the Cal accepts dates like (2024,4,32) ...
            let strt = "new Date(" + d.Year.ToString() + "," + (d.Month - 1).ToString()+ "," + (d.Day).ToString() + ")";
            let endd = "new Date(" + d.Year.ToString() + "," + (d.Month - 1).ToString()+ "," + (d.Day + 1).ToString() + ")";
            "{\n" + 
            "\tid: \"" + u + "\",\n" + 
            "\tsummary: \"" + t + "\",\n" + 
            "\tcontent: \"" + c + "\",\n" +
            "\tnotes: \"" + n + "\",\n" +
            "\tstartTime: " + strt + ",\n" + 
            "\tendTime: " + endd + ",\n" +
            "\tcalendar: \"cal1\",\n" + 
            "\tallDay: true\n}"
        | _       -> 
            printfn "ERROR: Couldn't parse date for %A" (this.toString())
            ""

        

module calDataImport = 
    open System

    let stmp = ref ((int) ((System.DateTime.Now).Ticks))    
    let gfxGetUNID =
        fun s ->
            stmp.Value <- stmp.Value + 1
            "gfxCalItm^" + ((string) stmp.Value)

    let LogItms_24 = 
        [ GfxCalItm((gfxGetUNID "gfxItm"), "Apr-06-24" , "gfx DnD" , """
ContainerDnD + TreeDnd, poss last stable ver""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Apr-09-24" , "gfx Tree; Dat" , """
Worked on further treeMods  + porting mBoxes 'both = dat + appendAble""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Apr-13-24" , "Core; Perms" , """
Created + Worked on eggAmish.fs""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Apr-17-24" , "gfx Dat" , """
Created gfxDat.fs w/ appendable devNotes stuff""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Apr-23-24" , "gfx Dat; Tp; rtEd" , """
mBoxes_in_TP + inLineEditBox + some notes""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Apr-27-24" , "gfx Dat" , """
Cumulative Dat created""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-16-24" , "gfx Dat; D3" , """
May03_itms in gfxAddenda.fs + d3 stuff""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-04-24" , "gfx Tree" , """
updated expandoIcns css as in grid + coded way to pop treeIcons custom (vs reg folders) for CPanel""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-22-24" , "arc" , """
Reconciled files & created gfxThinMay22a.exe
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-23-24" , "gfx Dat; Cal" , """
Ported logEntries from b 2 import into Cal
Link to logDat <a href='https://raw.githubusercontent.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/main/procdLog.txt'>here</a>
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-24-24" , "gfx Dat; Cal" , """
Further work on Porting logEntries from b 2 import into Cal
<a href='https://pst.innomi.net/paste/tbng642wnmad47g7zskbmn5y'>May24a</a>
(Contains 2023 items)
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-25-24" , "gfx Dat; Cal" , """
Further work on Porting logEntries from b 2 import into Cal
See <a href='https://pst.innomi.net/paste/8bphcrcv3mher3oa9xfc2wxuestzdwr6/authenticate
'>this</a>
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-27-24" , "gfx Dat;Tree" , """
DnDsrc to trap onDragDrop for treeItm moves _within_ tree.
Moves stopped working (threshold) on examples; much testing to recreate (poss @mbi)""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-28-24" , "gfx Dat;Tree" , """
Located the relevant handler(s) which handle 'move'.
extended DnDsrc to trap onDragDrop for treeItm moves; (no nd to send whole dat 2 svr, this suffices) still nd to call super() for rest, curr embedded in ext. For Dat, parsed some more Logfiles 4 cal; almost done w/existing data (still nd to create new entries for '24)""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-29-24" , "gfx Core; Tree" , """
Rsch + testing 4 using less 4 claro substitutes; identified dll (dotless) will nd to bld piecemeal but essential 4 dynamic subst.  Updated CPnl treeCfg""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-30-24" , "gfx Tree" , """
Further work on CfgPnl; created Ttips 4 itms + assigned materialIcns
Tree uses embedded NodeL wid which's hard to update to embed materialIcns for the iconNode; might have to forego using Tree (p'haps not necc anyway) in favor of buttons.""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "May-31-24" , "gfx Cal; arc" , """
Created calImp.fs to gen webOb repr from cal Log files
Updated arc
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Jun-04-24" , "gfx idx" , """
Began working on the index file; all css refs; embedded Cal (stable but nds work)
New arc w/all plunks consolid8ted.
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Jun-05-24" , "gfx idx" , """
Continued working on the index file; updated Settings etc.
""", "");

]

    let LogItms_23 = 
        [ GfxCalItm((gfxGetUNID "gfxItm"), "Nov-07-23" , "mod winFrms/<mark>DnDMonad</mark>" , """
refactor, retrofit 2 use existing S monad w/only bind 4 ce""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Nov-07-23" , "mod winFrms/<mark>propBox</mark>" , """
init work: logic, monadBldr, initial tests OK""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Nov-06-23" , "blazor/wasm" , """
refactored tys, dragDrop handlers""", "");
         

GfxCalItm((gfxGetUNID "gfxItm"), "Oct-19-23" , "blazor/wasm" , """
	refactored tys""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Oct-17-23" , "blazor/wasm" , """
	more Pages, tabCtrl""", "");
          
GfxCalItm((gfxGetUNID "gfxItm"), "Oct-16-23" , "blazor/wasm" , """
	init work: logic, TabPages, initial flow<br>
<b>mod winFrms/<mark>DnD_ops<mark></b>""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Oct 11-12" , "blazor/wasm" , """
	refactored tys""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Oct-07-23" , "blazor/wasm" , """
	  further work: blankCell logic, tests""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Oct-06-23" , "blazor/wasm" , """
	  further work: tests, produces DzCell Struct""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Oct-04-23" , "blazor/wasm" , """
	  init work: logic, types, init flow""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Sep 2-30" , "blazor/wasm" , """
create frm.html (webCli)<br>
Sep much reOrg, planning/notes updates; dojo work; evals gridx/dgrid/dojox; setup SignalR svr & repo for static, etc.<br>
<b>mod winFrms/<mark>frmDelta</mark></b>
""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Sep-02-23" , "blazor/wasm" , """further work: svrPromoteHandler""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Sep-01-23" , "blazor/wasm" , """further work: ViewPriorVersions handler""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Aug-31-23" , "blazor/wasm" , """further work: PriorVers CarryFwd logic for deltas<br>""", "");
   
GfxCalItm((gfxGetUNID "gfxItm"), "Aug 16-18" , "blazor/wasm" , """
          
              @rsch + srid: ran bld: issues w/net5-7 upgrd (CEs 4 bldg els)<br>
              Got Blazor wasm ToDo launching locally""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-15-23" , "blazor/wasm" , """
          
           @rsch + srid: setup/local static run as-is""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-14-23" , "test/winFrms.fs" , """
          
           lazy (gen on Demand) success! typical res window (this is 13 not 12):<br>
		[["W25"; "V_119"; "V2"; "Cd"; "V_215"]; ["W25"; "V_119"; "V2"; "Cd"; "V_216"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_217"]; ["W25"; "V_119"; "V2"; "Cd"; "V_218"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_219"]; ["W25"; "V_119"; "V2"; "Cd"; "V_220"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_221"]; ["W25"; "V_119"; "V2"; "Cd"; "V_222"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_223"]; ["W25"; "V_119"; "V2"; "Cd"; "V_224"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_225"]; ["W25"; "V_119"; "V2"; "Cd"; "V_226"];<br>
		 ["W25"; "V_119"; "V2"; "Cd"; "V_227"]]""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug 11,12" , "test/winFrms.fs" , """
          
           Further work w/mockADO<br>
            Bombs also (outOfMem) one last try w/HashMaps & then we nd 2<br>
             try blding the entire collectn lazily, ie for a bucket w/seed<br>
             123458, skip & retn exactly bucketSz itms.<br>
            Warning: not too much effort; this is easy as pie w/a db BUT<br>
             poss useful in scenarios such as wasm.<br>
            Aug12: introduced async & T.K to mod perms, @mbi choked _hard_ as expctd. (hehe, monkeys)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-10-23" , "test/winFrms.fs" , """
          
           Created mod mockADO, ported earlier fable work & refined it; <br>
            Bucketing logic in place""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-09-23" , "test/winFrms.fs" , """
          
           Further work w/permsHarness: ran a few tests, created blders etc.<br>
            Basic harness is in place""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-08-23" , "test/winFrms.fs" , """
          
           Further work w/Cambattable; was able to use intfcs/phTys w/DUs (see notes Aug7)<br>
            Further work w/perms: added new Cfgs<br>
              * Gathered nos 4 all scenarios<br>
              * Decided on optimal cfg (5M tot) genned 20 files on replIt<br>
            Created mod permsHarness, init. work; Ado.net bombs @ ~ 2M recs""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-07-23" , "test/winFrms.fs" , """
          
           Created mod Cambattable, assoc tys 4 Bfty, Btpl...<br>
           Some issues w/sealed types & tyConstraints so removed constr.<br>
           The mods'll still be constrained tho...<br>
<b>gen</b>
          
           All APIs were way out of date (from Janish) so gend/repl/extracted to extnal<br>
           Reinst. Op once again, still persistent @mbi""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-05-23" , "test/winFrms.fs" , """
          
            Merged mods permsBase/Red<br>
             created permCfg ty; some deltas<br>
<b>gen</b>
          
            Repl ripGrep w/fnr""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-04-23" , "gen" , """
          
            generated winFrms map (perms repl); uploaded + modified b.html""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Aug-03-23" , "utils/shorty.cs" , """
          
            Some shortcuts in src subDir were missing, so setup/reRan shorty/updated lnkOut<br>
<b>test/winFrms.fs</b>
          
            Further work with ule permsBase: produced 2.35M * 20<br>
            Created mod permsRed: produced 60k * 20 = 1.2M (30 ea for V1|V2; def 4 Ps)<br>
            - still nd 2 combine these & ensure unique<br>
            - can persist a single tbl & use as `seed` to gen indiv. (TBimpl)<br>
            (10 * 200) * 50 = 100k<br>
            Created ule dizCopy, some work compl<br>""", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Aug-02-23" , "test/winFrms.fs" , """
          
            Created ule clientInit w/UI/UIAux/Brij updates<br>
              related 2 tracking openTbls + versioning etc.<br>
            Further work with perms; recreated outOfMem err (snafu w/conc)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-31-23" , "gen" , """
          
            @rsch FsCheck/QuickCheck""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-29-23" , "test/winFrms.fs" , """
          
            Some work with perms until monkey bastas interfered too much... (hopeless effers)<br>
<b>repl/diff</b>
          
            Began/completed work on diff (html 2 rtf); stable<br>
            @ToDo: 2 wins/merge impl.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-28-23" , "test/winFrms.fs" , """
          
            Created mod uiDelta""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-27-23" , "utils/shorty.cs" , """
          
            Collectd info 4all shortcuts into src\lnkOut.txt (c# issues w/a single win32 call 2 getPath)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-26-23" , "test/winFrms.fs" , """
          
            Added Card.intVal(), CardHand.chkSelBySuit(s, selL)
            Added perms.cacheVvals()<br>
<b>general</b>
          
            Reinstalled Op (monkeyBastas disabled vpn)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-25-23" , "test/winFrms.fs" , """
          
            Replaced mod FilePnl/'getFilePnl' (monkeyBastas went nutz again & played w/clipbd)<br>
            Some work on mod perms 2 chk/optimise totLen BUT as before spaces out; <br>
             two possibilities: (i)lazy eval chokes (chk) (ii)@mbi""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-24-23" , "test/winFrms.fs" , """
          
            more @rsch PropertyTesting<br>
            setup two tys for same; <br>
            1st poss impl shd be to test 4 "isSufficientlyR()'""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-22-23" , "test/winFrms.fs" , """
          
            Added tab2spc in rtb.keyDn<br>
            Further work w/getFilePnl() incl. new treeView.DblClick<br>
            Incorp. replIt work on Folding/Outliner/Tokenizer ici""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-21-23" , "test/winFrms.fs" , """
          
            Refactor rPnl to typeof&lt;BhojPuri&gt;""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul 19-20" , "test/token.fs + replIt/winFrms" , """
          
            FS.Cmplr.Svcs pkg test 2 tokenize; offers EditorSvcs incl Color/Keywd/tokTy<br>
            Entirely sufficient 4 synHilighting<br>
            Much @rsch into other synH applications incl OCaml""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-18-23" , "test/winFrms.fs" , """
          Further updates 2 deckstuff/CardHand (added enum, some fns 4 isOneEyed()/genDeckTpl() etc)<br>
           @Rsch into Syntax Highlighting<br>
           Resumed work on mod FilePanelUpdates (poss created sometime last wk); reverted to TreeView""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-17-23" , "test/winFrms.fs" , """
          
           Further updates 2 cyclical 2 rndomize<br>
<b>replit/winForms repl</b>
          
           Some work on Foldables 4 rtb""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-15-23" , "ikvms" , """
          
           Further work, dnloads, tests, works fine but will have to code API in j; put on bkBurner<br>
<b>test/winFrms.fs</b>
          
           Added cyclical (see note below)<br>
           We nd CYCLICAL not Random for pGen<br>
             coz we nd to prevent adjacents which Random won't do.<br>
             Therefore we nd an algo 2 retrofit: cld be as simple as manually iter 0..29""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-14-23" , "tmp" , """
          
           Downloaded ikvm (jar -> .net) for testing; both approaches seem viable<br>
<b>test/winFrms.fs</b>
          
           Added ty CardHand, some assoc fns.<br>
<b>@Rsch</b>
          
           Property-based testing a la haskell/QuickChk (wlaschin et al)
           Adding tys 4 exhaustive testing appears enticing""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul 12-13" , "test/winFrms.fs" , """
          
           Beauc updates incl new mod perms<br>
           Ran many generators; res above expectations: .7M w/one iter 2 go<br>
           monkeyBastas blew a gasket & bunged a spanner""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-11-23" , "standaloneBld.fs" , """
          
           updated/blt bld4 on replIt; gen new dirs; issues w/FSCore ver (4.4 nded)
           either get(preferred) or recompile(redactions pour l'mbi)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-10-23" , "shorty.fs" , """
          
           Some work on impl Win32 interop to collect shortcuts; beauc. @mbi
           Worked fine if compiled via csc (effers)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-08-23" , "CC" , """
          
           Worked on new impl of CC in new mod UI.Utils, two tabs ready-ish""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-07-23" , "Cards" , """
          
           Worked on old Cards stuff: updated types, 
            wrote some fns & created .bdf dump w/imgs.  Stable/uploaded to gh.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-06-23" , "Legacy" , """
          
           Repl.it: much work hunting dn art db fr ~Feb18; two files located<br>
            (feb & oct17) but both unusable.  .64 tampered? @mbi probably coz none<br>
            of the anonGistLinks work from '18.<br>
            Put off for now; was enthusiastic abt dumping jdk once/for all but apparently not yet.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-06-23" , "test/winFrms.fs" , """
          
           Imported Cards mod & made changes to import Google deck imgs; typework etc.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-05-23" , "Legacy" , """
          
           Repl.it: edited Importer.j into oPls.j from 2018 to <br>
            dump all FT arts; successful.  Some code deltas reqd; committed.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jul-03-23" , "Core" , """
          
           Rebuilt/added liShuffle, getRand(), getRandS(), [a2z""", "");]
GfxCalItm((gfxGetUNID "gfxItm"), "Jun 23-30" , "test/winFrms.fs" , """
          var. updates incl a new splitPnl to house Proj bar (user-adjustable)<br>
               some work on zipArchives on replIt (stable code using Zstd dll but it only works w/single files)<br>
               work continues on winFrms w/o debugger (@mbi, heh heh)</td>|||<br>
<b>.Net TextEditor</b>
          
           examined src code for folding to port<br>
<b>replIt</b>
          
            created scaffolding/tests w/hdr file 2 use ZStd lib<br> (@ToDo: expand/incorp into Core)<br>
           stable, but it only works w/single files<br> (not archives)  Cld still be useful l8r""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun-26-23" , "test/drive.fs" , """
          module SubstDrive: interOp using win32 calls to create a disk-based mappable virtual drive<br>
           stable, but will not be used (we nd a mem-based soln, pro'lly homebrewed)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun-23-23" , "test/winFrms.fs" , """
          Updated launcher w/ToolStrip 4 TaggedView blt from mBoxes.bdf.  Stable.<br>
           (note: w/o mbi it took only minutes to rejig the whole thing; they soon returned)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun 20-22" , "mBoxes" , """
          Ported all mBoxes to bdf<br>
              Resolved missing/renamed itms (mongo/mBoxes.fs)<br>
              mBoxes.bdf now ~45Mb (self-contnd).  @ToDo: port to mongo (poss along w/FT/legArts?)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun-21-23" , "data\deepAI.txt" , """
          (deepai.org) Ran text-generator<br> w/instr. to generate examples like... (for choices based on training txt)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun 14-20" , "sWin" , """
          Built SignalR cli/svr, used winFrms (below) for flash.PaintRow.  Stable.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun 08-13" , "test/winFrms.fs" , """
          General Grid/UI skeleton for testing; to be extended per use case<br>
                          Impl flash.  Stable.<br>
<b>mBoxes</b>
          FSharp.Data for resolving/lookup wikip infobox via css selectors.  Stable.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jun 05-08" , "TaggedVw" , """
          Rebuilt dojo TaggedVw 4 mBoxes""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "May 01-09" , "Docs/docFx" , """
          docFx udpates incl Mermd porting; <br>
            publishing; created Discussion/ids; went live with pitch 4 brij""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr 20-May01" , "Docs/docFx" , """
          Built entire doc set (directly in GitHub repo)<br>
            Curr status -> Complete exc4 currFigs + 50% snapshots + priorVers (js/java)<br>
            Blt Mermaid timeline/much hunting down prior code/snapshots as reqd.<br>
            Added docFx pg to bkmarks as pullout<br>
            Retrieved FT.jar; earlier c.jar + sys.jar (issues w/baseDir) for snapshots<br>
            e:/mike/*.* deleted @mbi sleigh-of-hand; we have this+all curr backups @ tan~tahd@outlook.com""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-19-23" , "DocFx" , """
          Worked on generating fn sigs via FSharp.Formatting (codeFmt.fs)<br>
            Put on backburner (security issues)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-18-23" , "DocFx" , """
          Generated APIdocs manually via call to --metadata<br>
            Brij.dll processed; UI works as well; probems w/Core (poss. issues w/Core versions)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-17-23" , "DocFx" , """
          Further docfx work: gen ApiDocs doesn't work on fsproj""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-15-23" , "DocFx" , """
          Further docfx work: gen ApiDocs<br>
            Unable to run directly on .fs; so ran on Assemblies""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-14-23" , "DocFx" , """
          setup/customization incl setEnv et al<br>
            Further testing to bld sample proj (success BUT api fails: consLog mentions proj file err)<br>
            Built example docset (Seed)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-13-23" , "Brij/Parser.fs" , """
          Some further work on the new predMods</td>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "DocFx" , """
          
           rsch, init testing to bld sample proj (failed)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-11-23" , "Brij/Parser.fs" , """
          Some further work on the new predMods</td>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-10-23" , "off/echo" , "", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Apr-01 - 08" , "Brij/Parser.fs" , """
          
             Contd. work on mod Parser.predNL harness/fleshed out (Apr7 off/cis)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-31-23" , "general" , """<mark>
          src backup</mark>
           """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-29 - 31" , "BrijSvr" , """
          
             Began work on mod Parser.predNL harness""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-27 - 28>" , "BrijSvr" , """
          
             Hectic rsch/coding around using Linq (expects ty)<br>
             see Notes under 'Linq provis Type' tagged Linq/Mongodb<br>
             Linq Qry is now running on local mongo instance against mTasks & working as expected.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-24 to 26" , "BrijSvr" , """
          
           FParsec contd; ported Json example to monadic ver""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-23-23" , "BrijSvr" , """
          
           FParsec deep dive""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-22-23" , "loggedUIRunner" , """
          <mark>
           extracted TblSetup pg to ty & worked on it<br>
           added rec genFldSlg (tbImpl)<br>
           (@ToDo: this nds 2 be ported to tblID too)
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "Core, UIAux" , """
          <mark>
           Further work on Core.i18n; updates to UI.fs
           @ToDo: Complete
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-21-23" , "loggedUIRunner" , """
          
           Interned મીઠૂ_પાન_Mar23 for work on new MM ver w/tC (stable)<br>
           Added 2 pgs: TblSetup/FrmSetup; modified latter for instr<br>
           var updates/workarounds to comp (mbi w/state/currUISchm refs et al)<br>
<b>UIAux</b>
          
           altered tyExt for namespace compErr<br>
<b>Core</b>
          
           Began setup for Core.i18n; added li + lookup (stable)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-20-23" , "Brij" , """
          
           (MongoDeSer.fs)Began work on DeSer mod in this file<br>
<b>UIAux</b>
          
           Added tyExt for RichTextBox to add Expr.flds in diff col<br>
           Updates to એક્સ_પેનલ tbdb (methd render, toTxt now not Relev)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-10 to 19" , "Brij" , """
          
           Mostly MongoDB work: completed Qry for 2/3 Cats (MongoQry.fs)<br>
           Some work on gen mockDb for Mongo per D'wd reqs<br>
           Located zip/nm tbls; we have enuff to gen 3.2M recs<br>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar-09-23" , "Brij" , """
          
          Added tys બોક્સ_પાન, mBoxMasaloAux, mBoxSize<br>
          Added tys/fns 4 TgDV""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Mar7,8-23" , "Brij" , """
          
          Some work on importing mBoxes to Mongo""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-23 to Mar6-23" , "Brij" , """
          <mark>
           Generated tkDat/pumped into Mongo; dumped out<br>
          Nailed down generic Agg pipelines<br>
          (@ToDo: svrSide WD work to bldDat)<br>
          Some work on TgDV; incl regen superscripts 4 tagBtns
           </mark>

|||Feb-28||general||<mark>
          src backup</mark>
           """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-21,22-23" , "general" , """
          
           Further MongoDb reading/rsch/testing; setup utils.  Wrote a small F# script to import tkDat into Mongo as JsonEls (success); created a dump.<br>
<b>general</b>
          
           Updated Bookmarks: pulled out Mongo links; moved local links to sep. file""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-20-23" , "general" , """
          
           Further MongoDb reading/rsch; some Qry/Linq rsch; some util work""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-18-23" , "general" , """
          
           MongoDb reading/rsch<br>
           Updated bkmarks/logs online""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-17-23" , "UIAux" , """
          <mark>
           Further work on BM refactor/ફીલ્ડ_પેનલ_Aux;<br>
            Added getBPHnd (@ToDo cases remain) can't pullOut coz diff params + scope<br>
            Combined fns BM.updSlg + BM.setFldTT to BM.update (@ToDo cases remain)
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "general" , """
          
           Some more messing w net7<br>
<b>Brij</b>
          
Added fn datGetAllOfTy, datGetAllDocOfTy, datGetAllDizOfTy""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-16-23" , "UIAux" , """
          
           Further work on BM refactor/ફીલ્ડ_પેનલ_Aux; added tBar w/AppTab stuff; <br>
            added fns BM.updSlg + BM.setFldTT""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-15-23" , "UIAux" , """
          
           BM recovery in am (@mbi overwrote yest. pm work) (again, the bastas)<br>
           Began work on total બનારસી_પાન refactor:<br>
            new fn setupFlds; incl slotter et al; <br>
            updated ફીલ્ડ_પેનલ_Aux ctor + all calls; added ctxtMenus<br>
           selectedPanl saved to ownr + p""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-14-23" , "UIAux" , """
          
           Fixed all frmFld issues; we now have the BM tab pages on +<br>
           BM lv dbl-click launches FldDef dlg<br>
           BM is online (tho beauc. @mbi)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-13-23" , "UIAux" , """
          
           BM_ValidationBldr<br>
               Fixed issues w/condCB selection losing focus (dataSrc related)<br>
               @Note: This is poss @mbi related; this worked quite okay before<br>
               Note also that combiner et al losing selection; <br>
                again poss @mbi; leave the rest 4 l8r<br>
               Updated predConds for 1st blank as unSelected<br>
               At this pt. we have the params in place and Fld auto-populated +<br>
                non-selectable (as it shd be).  ctor docFlds all correct.<br>
<b>BP</b>
          
            Resumed work on new layout.  BP Online(!)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-11-23" , "UIAux" , """
          
            CompileErr on new DU case 4 expandoPanel; so edited match<br>
            st 4 ઍક્સપાનડો_પીચાક to not refer to Validation case (using _); logic retained.<br>
            BM: @mbi w/tC sidestepped via bypass harness (1 pg @ time)<br>
                Contd. work on the new ValidnBldr w/fld popul8d;<br>
                matching on ctor.xPandoPnl<br>
                Changed SelectedIdxChanged handler (trigger to pop condnCB)<br>
                coz in Validation/Enabled=false; never runs<br>
<b>Core</b>
          
            Added fn runChk dir for testing w/flags<br>
<b>logged</b>
          
            "currScheme_Wref": @mbi w/var SM issues (esply wldRef) so <br>
            created bypass harness ("SM_bypass") 4 working w/ "tabCtrl_MidP'""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-10-23" , "Brij" , """
          
            tkDat: outpt 2 Brij&lt;_&gt;; new ser ver 4 baseTkDatAux; added to BrijDat<br>
<b>UIAux</b>
          
            baseTkDatAux Updated for new ty sig; BrijDat all Brij(_) now<br>
            Spurious err for TStripItm.AddRange remmed as '//@Feb10_mbi_bogusErr '<br>
            Repurposing એક્સ_પેનલ for BM validation::<br>
              Case Union 'FldValidation' added 2 ty expandoPanel<br>
              Updates 2 ઍક્સપાનડો_પીચાક + એક્સ_પેનલ to layout new caseTy (disabled + vErr)<br>
            Moved DzTypes & the new Dat ty from Aux 2 Brij<br>
            Some further work on Expr (mod Validatn)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-09-23" , "UIAux" , """
          <mark>
            Added fn defaultImg; reset CP to use wldRef<br>
            Updated all expand.png refs to add_circle / remove_circle (esp.ly dvs)<br>
            Updated getTSButtonAux: now takes wRef 4 TSBtn imgs, uses getImgDat<br>
            Updated all refs to above for wRef (in loggedUIR too)<br>
            <@ToDo: ALL changes to Aux 4 wRef above remmed as '//@Feb9_mbi '<br>
            (Lookup indet. ty fake errs)  Remmed to compile 4 BDoc etc.<br>
            Note: These also Ǝ in loggedUIRnr<br>
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "general" , """
          
           Some more messing w net7; using Ǝing libs w/logged.fsproj<br>
           Throws on assembly ref Sys.Drawing.Imaging; err persists (poss @mbi on Linux)<br>
<b>Brij</b>
          
           Began proc to unify DesDocAux/BrijTy to type Brij<br>
           NOTE: Multiple copies of DesDoc exist (two in Brij/etc) @mbi<br>
           This work nds 2 be xferred to Brij but kept in Aux for refs 2 DesDocAux""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-08-23" , "UIAux" , """
          
            Added fn getDefErrProv; updates to એક્સ_પેનલ<br>
            Debugging of CM led 2 many updates incl ફીલ્ડ_પેનલ_Aux સુપારી<br>
                which cascaded (incl calls)<br>
            Similarly 4 BM; both showing now tho layout issues""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-07-23" , "general" , """
          
           Productivity enh.mts (contd): redacted sections/maps frm bkmarks.<br>
           Updated res/created Addenda w/links<br>
<b>UIAux</b>
          <mark>
           Added the foll validation trips to એક્સ_પેનલ:<br>
              <ul><li>Connector (and/or) sel reqd</li>
              <li>inp fld nds 2 match fldty (currently unchecked)</li>
              <li>@ToDo: nd to resolve "isEmpty" cases (non-unique)</li>
              <li>Q: REMOVE isEmpty altogether?  We're insisting on defaultVals, y?</li></ul>
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-06-23" , "UIAux" , """
          
           Debugged/Compiled lib; note that the Nov18 UI.fs nd'd 2 be changed<br>
             (src file has notes) for fldTy changed from FldType to FrmFldType<br>
             (was raising circular errors in Brij via UI + preventing UIAux)<br>
             This err also raised in BanarasiM (ref in logd), fixed<br>
             Fixed minor bugs in BM/CategTester validErrHndlr<br>
<b>general</b>
          
           Some attempts to get symbols.fs to compile using Corev4/CompSvcs7""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-04-23" , "UIAux" , """
          
           Minor updates 2 બનારસી_પીચાક_fld_eoy + ઍક્સપાનડો_પીચાક<br>
<b>utils</b>
          
           Some work on symbols.fs + net7 setup""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-03-23" , "Brij" , """
          
           ren ty FldTy to FrmFldType for disambig; + all refs<br>
           ren fn DocFldTy2FldTy 2 DocFldTy2FrmFldTy; + all refs<br>
<b>UIAux</b>
          
           Added placeholder tys 4 કલકતી_પીચાક: CM_SortPg, CM_FilterPg<br>
           Refactored ફીલ્ડ_પેનલ_Aux for:<br>
            * tags set NOT in pnl but in d<br>
                in btns use em to update d tags<br>
                use fldNm (intl) 4 ctrlTag; NOT slg<br>
                REMOVED defaultTags + assoc logic<br><br>
<b></b>
          <mark>
  @ToDo 4 callers:<br>
        * SET: pass in defaultInitVals via cTor<br>
        * GET: (for frmFldVals)<br>
             AFTER ctor in caller just map thro all flds; <br>
             (hasTag fldNm)? populate else skip </span><br>
           Some init work on frmValidation (mod Validn)
           </mark>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-02-23" , "general" , """
          
           Updated bookmarks w/new maps 4 ???? elements + ported log into it""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Feb-01-23" , "general" , """
          
           Updated bookmarks w/new maps 4 ???? elements + ported log into it""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-31-23" , "UIAux" , """
          
                    tabCtrl refactors ->
                                        àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy 
                        Done: added tys BM_FldPg + BM_AppPg
                                        àª•àª²àª•àª¤à«€_àªªà«€àªšàª¾àª•
                        Done: added tys 4 CM_ColPg + CM_AppPg + CM_CategPg</td>
                    
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-30-23" , "Brij" , """
          
                    Further updates 3 BaseBrijTy deltas: removed imgDatK 
                    (all func. incorp into AdDatK incl rids)
                    Unified all dats since they're now BrijTys: spoo, adDat, img, tk (some @mbi)</td><tr class = "BrijLogtr"><br>
<b>UIAux</b><br>

          
                    Updated errProvs + all comboBxs to use Text: àª•à«‡àªŸ_àªªà«‡àª¨àª², àªàª•à«àª¸_àªªà«‡àª¨àª²
                     (apparently if you set a DataSrc you can't use .txt)</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-28-23" , "" , """  @MBI note: 
                        as soon as we made state changes (adDatK) bastas went splat(!)<br>so we're offline 4 now, let them twiddle their thumbs|||


        |||||UIAux</td>
        
                    Updated getImgDat per new datLi ty; added fn getImageFromDat<br>
<b></b><br>

        <mark>        
                    @ToDo: TSBtns nd to use this new fn<br>
                    Added tabCtrls/Pgs 2 BM/CM; skeleton edits/refactors are in
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-27-23" , "" , """
          <mark>  Last Stable ver (BUT w/o any subseq deltas; see note above)
        <tr class = "BrijLogtr"></mark>logged</td>
                    Restored statMsg vwr in SP<br>
<b>UIAux</b><br>

                   
                    3 new screens impl:<br>
                    (i) CategTester stable; nds some tuning (only 2 cols vis; no +)<br>
                    (ii) BM_FldDef stable; nds some tuning<br>
                         Fix:<br>
                            1st col of 3 is half size<br>
                            move FldW after fldTy (up)<br>
                            B8r lbls<br>
                            new Ty for fldW (curr uses fldTy) << same(ish) <br>logic as predBldr<br>
                    (iii) CalcattiDef:<br>
                            Added ty dvSetupDlg() to UIAux; some further work<br>
<b>Brij/others</b><br>

                     Added new ty DocFldType (to be used in DocFld) vs exising UI fldTys
                     Plus new fn DocFldTy2FldTy to translate / feed default wids.
                     Updated/recompiled all bins
                     Updated adDatK to insert local images
                    Downloaded all referenced icons to disk</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-26-23" , "UIAux" , """
                    Many updates to àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy et al; BanarasiM_FldDef form shows now
                        (nxt: nd to persist fld changes to def)
                    Also updated all getImgBtn calls to tryPick from State; stable (BanarasiM)
                    Also impl ttips for reg btns (as TSItms but nds diff impl) (BanarasiM)<br>
<b>Brij</b><br>

                    Some work on AdDatK et al for imgs + prep 4 BaseBrijTy deltas
                    Began work w/GoogIcns</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-25-23" , "UIAux" , """
                    Updated getImg (again! @mbi); deltas stable across PredBldr addBtns
                                    àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy persist to wld<br>
<b>Brij & all libs</b><br>

                    Added fn db to allow targetted db stmts; 
                    updated ALL debug calls to clean up cons</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-24-23" , "" , """  (Below stuff part of BanarasiM -> P)</td><br>
<b>Core/Brij</b><br>

                   var updates to prnDat et al<br>
<b>UIAux</b><br>

                    Beauc upds to àª¬àª¨àª¾àª°àª¸à«€_àªªàª¾àª¨<br>
                    All work on àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy complete (apparently)<br>
                    cld't confirm coz the bastas began throwing casting errs again<br>
                    Switch to tkDatAux:<br>
                        Added catCols, width logic (cleanup reqd); some debugging done</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-23-23" , "UIAux" , """
                    Further updates to àª•à«‡àªŸ_àªªà«‡àª¨àª² et al; alm done, splat(!) @ mbi<br>
                    Added validation to àªàª•à«àª¸àªªàª¾àª¨àª¡à«‹_àªªà«€àªšàª¾àª•</td><br>
<b>Core</b><br>

                     Added a new fn HR<br>
<b>BanarasiM</b><br>

                     Stable; ready to launch into BanarasiP (nds work on mut state)|||||àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy</td>
                     Many updates to dynamically bld mut state (repurpose later via dlg)
                     for testing pop flow to BanarasiP.ctor (line #598 logged)<br>
                   Updated All api maps; website had Dec 02; some Oct! WAY outdated</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-21-23" , "" , """
            àª•à«‡àªŸ_àª¬àª¾àª¯_àªªà«€àªšàª¾àª• nds to be totally refactored 
                    (for Brevity(dupl) + modularity (call from DV tBar))<br>
                    The curr version has ~5 catPanels manually blt in midP;
                      we shd instead use the same approach as àªªà«àª°à«‡àª¡_àªªà«€àªšàª¾àª• w/AddButton<br>
                    Basically the current PredBldr workFlw is -><br>
                                        àª—àªªà«àªªàª¾_àªªàª¾àª¨_Pred  ->  àªªà«àª°à«‡àª¡_àªªà«€àªšàª¾àª• ->  which instantiates àªàª•à«àª¸_àªªà«‡àª¨àª²<br>
                    (1) Ren àªªà«àª°à«‡àª¡_àªªà«€àªšàª¾àª• to àªàª•à«àª¸àªªàª¾àª¨àª¡à«‹_àªªà«€àªšàª¾àª•; rewire PredTester<br>
                    (2) Add new ty expandoPanel | Pred | Cat | ..<br>
                    (3) Refactor àª•à«‡àªŸ_àª¬àª¾àª¯_àªªà«€àªšàª¾àª• to use above + inst àª•à«‡àªŸ_àªªà«‡àª¨àª² et les autres.<br>
                    (4) Also refactor to switch on expPanel for custom behav<br>
                    (5) Modify àªàª•à«àª¸àªªàª¾àª¨àª¡à«‹_àªªà«€àªšàª¾àª• cTor to accept expPanel<br>
                  Most of the work listed above completed; PredTester stable.<br>
                  CategTester alm done; nxt: nd 2 add errHandling</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-20-23" , "Core" , """ updated optOr to make more generic (basically @mbi as usu)<br>
<b>UIAux</b><br>

                    Current UI didn't contain both àª•à«‡àªŸ_àª¬àª¾àª¯_àªªà«€àªšàª¾àª• + àª•àª²àª•àª¤à«€_àªªà«€àªšàª¾àª•;<br>
                      so brought em in from another UI file.<br>
                      @ sometime nd 2 diff/ensure all deltas merged.</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-19-23" , "UIAux" , """
                    Some updates to PredTester (connecter logic, order of flds, colStyles etc.)<br>
                    CalcuttiMasaloAux categBy/et al updated to options for ref in Dz cTor<br>
                    DzDV back online with the new Aux stuff/Masalas/et al</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-18-23" , "UIAux" , """
                                  àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy: single fld gappa<br>
                                  àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_fld_eoy (stable; some work compl)<br>
                   Added ty àª«à«€àª²à«àª¡_àªªà«‡àª¨àª²_Aux for changes (NumUpDn etc)</td><br>
<b>Brij</b><br>

                   remmed 'let WD' in canned Suppliers 
                    (@mbi has compile issues + we're using it locally) 
                   Updated ty FldType</td>

|||||general||<mark>
          src backup</mark>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "Lib net shutdown (connectivity issues)", "");

GfxCalItm((gfxGetUNID "gfxItm"), "Jan-13-23" , """UIAux
                    major updates to àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•_eoy 
                    (removing btns to consolidate edit single fld gappa)
                    Stable
                  Generated new set of screenshots
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-12-23" , "
                    subCategDisp Completed; now nd to generisize/port [much mbi w/display but it is stable]
        <tr class = "BrijLogtr">" , """both</td>
                    Considerable work on DzAux as a prelude to bakaaNoM; alm compl exc 4 mbi w/ITblTy
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-11-23" , "UIAux" , """
                    Added new ty CalcPred<'t> for all preds (categ/flt/sort)
                    Note: CalcMAux now has only 1 genericParam comme les autres; instd of earlier 3<br>
<b>logged</b><br>

                    Updated the CalcMAux refs (for above; these flds were earlier opts w/None passed in)
                    Brij: @ present tkDv uses hardCoded categs which were left as is<br>
<b>catCols Impl (both)</b><br>

                    Added musicDat_Jan (new categSchme) to UIAux
                    mbi SPLAT(!) w/ return vals from musicDat (expects string * obj * Type') in kathoHandlerAux
                    Several pieces hardCoded in lieu of mbi BUT everthing working exc subCategDisp
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-10-23" , "" , """
           FlkBrg pour sId</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-09-23" , "UIAux/logged" , """
                    Some work on DzAux; splat(!) nd 2 revert to leaving them compilerLess...
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-07-23" , "UIAux/logged" , """
                    Further updates to colorSchemes in gappa/pich/etc. to confirm across the board
                    Some more work on the PredBldr; added errorProv & toTpl()
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-06-23" , "UIAux" , """
                    Some updates to PredTester<br>
<b>logged</b><br>

                    updated the openWin stuff in SaadooP; removed the genTyParam
                    Added ty BrijWin + Saadoo menu<br>
<b>Both</b><br>
<mark>
                    Added a new colorScheme (bblgm) + var updates to store/retrieve currSel frm State
                    @ToDo: if colSchm names are the same as the MenuItems we can
                        rem 4 lines (to set marked) via moving into the fn
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-05-23" , "Bakaa_no_Masalo" , """basic sketch + pseudoC 
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-04-23" , "UIAux" , """
                    Interned all PredTester assoc stuff ici; stable
                    Upd: Added tys | àª—àªªà«àªªàª¾_àªªàª¾àª¨_Pred | àªªà«àª°à«‡àª¡_àªªà«€àªšàª¾àª• | àªàª•à«àª¸_àªªà«‡àª¨àª²
                    Some work on xTpl type/expr.ToStr() etc.
                    Impl getImg (despite much mbi); BanarM hangs coz of their ineptitude
                    Cleaned up dsk itms
                    Upd. hlp w/a more complete set of screenshots of all major Paans/Masalas
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Jan-03-23" , "UIAux" , """
                    As mentioned below issues w/àª•àª²àª•àª¤à«€_àªªàª¾àª¨_Nov (can't find old(er) ver of DVDef)
                    Ported the refs to curr ver of Brij.CalcuttiMasalo
                    Updated àª®à«€àª à«‚_àªªàª¾àª¨_eoy cTor param SaadoMasalo to SaadoMasaloAux
                    SadooP	Applied Dec08 ClrSchm to curr""", "")]

    let LogItms_22 = 
    [ GfxCalItm((gfxGetUNID "gfxItm"), "Dec-30-22" , "UIAux" , """
            ported BM/MeethoM to main fork in UIAux (ren to ~Aux + ~eoy)<br>
                  (nded to up the UI ass to 11.17 which causes some issues w/Calcut)<br>
                  gen screenshots of all major Paans/Masalas, to be compl.</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-29-22" , "" , """
           Phat_Nov17_LastWithFormCfgMeethoo_Patch4<br>
                    FrmCfg opts are now wired to ctorDef (stable)<br>
                    Label Font default to ital</td><br>
<b>Brij.fs</b><br>

                    Colors default frm currSchm (in Brij:BanarasiMasalo.getDeflt)<br>
                    Ttip subCol<br>
                    defUpd hndlrs on OK/Save</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-28-22" , "" , """
           Phat_Nov17_LastWithFormCfgMeethoo_Patch3<br>
                    ren frm_pich to àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª• (per current UI)<br>
                    added Thingy ty (placehldr)<br>
<b>Brij.fs</b><br>

                    inserted/updated BM/BFld tys in patch Brij.fs per new constraints<br>
<b>loggedUIRunner.fs</b><br>
<mark>
                    moved banarasiPich_eoy + gappa_eoy here to use the new Core; stable
                    ALL subseq. updates will be made ici
                    generated BanarasiM
                    added getDefault() to BanarasiMasalo + BanarasiFld; stable
                    issues w/GK et al BUT stable impl of àªŸà«‡àª¨à«àª—/GT (effortless!)
                        needs followup: can see the Ks in iLspy but compiler doesn't ?!
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-27-22" , "" , """ Phat_Nov17_LastWithFormCfgMeethoo_Patch2<br>
                    Further updates to meethoo paan:<br>
                    updated gappa to work w/frmSetup<br>
                    fixed bugs: lv itm#1 can't be moved down<br>
                                lv itm#1 crashes on 1st itm MoveUp
                                on frmClose "ArgumentOutOfRangeException" <br>bug on lV (arising from items.clear())<br>
                    moved btns in tbar(wider/shorter...) to above lV/BtnBar<br>
                    updated btnTxt for FontBtns/ClrBtns<br>
                    added icons for all frmBtns<br>
                    added fn (getImg nm w)<br>
                    updated gappa wldRef for above (NDS 2 go to UI_current)<br>
                        added tmpWorkaround (@mbi w/hkt) to return brijLogo<br>
                        DOESN'T nd to be grafted (getImg tmp returns icon since mbi w/wld)</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-22-22" , "" , """
           Phat_Nov17_LastWithFormCfgMeethoo_Patch1<br>
                    Further updates to meethoo paan:<br>
                    merged handlers to one: tblDefAddModFld
                      (uses àªŸà«‡àª¬àª²_àª¡à«‡àª«_àªàª¡_àª®à«‹àª¡_àª«àª¿àª²à«àª¡_àªªà«€àªšàª¾àª• )<br>
                    added inline handler for RemoveFld<br>
<b>Brij.fs</b><br>

            Minor updates to bring type SaadoMasalo to current</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-21-22" , "Brij.fs" , """
            Added isCateg/Parent flds 2 CoreM; compileErrs shd cascade
        <br>
<b> UI.fs</b><br>

             Worked w/(UI+Brij Phat_Nov17)<br>
                        Several updates incl meethoo paan<br>
                        blt 2 pichaak handlers mostly tested<br>
                                Deltas merged into UI current (nd to create patches for continual updates)<br>
                                nxt: nd to add a SaveBtn
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-20-22" , "loggedUIRunner; UIAux" , """
                            Various stuff moved to UIAux, rejiggered dsk etc<br>
                            (basically all yesterday pm's stuff redone coz
                             @mbi: deleted archive files pre-save) along w/some deltas</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-19-22" , "Core.fs" , """
           Updated some Core fns, incl to3Tpl -> to3T ...<br>
<b>Brij.fs</b><br>

                  Added isDeleted fld 2 CoreM; compileErrs shd cascade
                  loggedUIRunner<br>>
                    Some updates incl to SaaduPaan; dsk imgs/moving menuItms to dsk;
                    updates to ColorSchms etc.</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-17-22" , "SignalR   " , """</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-16-22" , "SignalR" , """   Ported missing fns to allow standalone CScli; it works (svr still cs)
                            Began creating FScli
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-15-22" , "" , """           Archive recovery/rebuilding
                            tkDat ser; ported the new tkDV to Nov ver for tbdb<br>
                  BrijServer.fs several updates to datRoutines for ttips etc.</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "general" , """<mark>
          src backup</mark>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-14-22" , "BrijServer.fs" , """<mark>
            rewrote rec tkDatAux; tkDV is stable with the foll caveats:<br>
                                - tkDat doesn't work (no colHdrs/Cats) w/either new or old Calcutti<br>
                                - musicDat behaves similarly (chk) as above<br>
                                - issue is poss related 2 colOrdr; tbdb</mark>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-13-22" , "           SignalR
        ]]]
[[[Dec-12-22" , """BrijServer.fs||
                            tkDV/Brij.Server
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-10-22" , "" , """           Moved all new dat mods to UIAux for concurrent ref
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-09-22" , "" , """<mark>           tkDV (stable-ish)
            </mark>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "" , "var updates (tbfo)</td>
        ]]]
[[[Dec-05-22" , """Brij.fs||   nailed down tkDat w/gen from hardCoded flds; some updates to UI calcti.</td>
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-03-22" , "Brij.fs" , """
           updated tkPics for testing the new calcutti stuff
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-02-22" , "gen" , """
               updated bookmarks w/latest maps
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Dec-01-22" , "Brij.fs" , """
           added BrijTy<'t></td><br>
<b>UI.fs</b><br>

             further work on UI.àª•à«‡àªŸ_àª¬àª¾àª¯_àªªà«€àªšàª¾àª•
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-30-22" , "UI.fs" , """
             further work on UI.àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•<br>
                            some work on àª®à«€àª à«‚_àªªà«€àªšàª¾àª• + àª•àª²àª•àª¤à«€_àªªà«€àªšàª¾àª•<br>
                            added àªšà«‡àª•à«àª¡_àªªà«€àªšàª¾àª• + àª®à«€àª à«‚_àªªà«€àªšàª¾àª• + àª•à«‡àªŸ_àª¬àª¾àª¯_àªªà«€àªšàª¾àª•
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-29-22" , "UI.fs" , """
             deltas from earlier work + flash (compl tho @mbi) moved into this<br>
                            changes to UI.àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª• to incl CanUHear
        <br>
<b>Brij.fs</b><br>

           added type Thingy for UI.àª¬àª¨àª¾àª°àª¸à«€_àªªà«€àªšàª¾àª•
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-28-22" , "loggedUIRunner" , """
                                                àª¬àª¨àª¾àª°àª¸à«€_àªªàª¾àª¨ work completed on fldPop w/noSkips<br>
<b>
                  UI.fs</b>
         àª«à«€àª²à«àª¡_àªªà«‡àª¨àª² ctor now accepts fldVal & sets ea ctrl to (optOr ~~)<br>
                        TtipMngr.formatTtip (wrap+ell)</td>|||

<br>
<b>loggedUIRunner||
         (Nov2ver w/ClrSchemes/Grid/etc.; much remmed in this ver;
                                  also nded Brij from Nov02)<br>
                        Some work on g.Flash
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-22-22" , "UI.fs" , """<mark>
         Brij.gullo + hdnlr framewrk
                        @ToDo: Some renaming to bring all terms in line (pichaak); more remains: 
                          run a FindFiles on "masalo"
                        Added runG impl + runGDlg() ty/pichaak
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-22-22" , "UI.fs" , """
         expandoState & svrCmd "openDVexpando" + added tbarBtns to g<br>
                        dsk.ms + winSwitch
        </b><br>
<br>
<b>loggedUIRunner</b><br>

                        getDatImgNov22: shim to avoid @mbi w/BaseBrij
                        updated all getTSBtn calls w/actual icons from dat
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-21-22" , "UI.fs" , """
         mdiUpdates incorp ici
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-19-22" , "general" , """<mark>
         src backup
        """, "");
GfxCalItm((gfxGetUNID "gfxItm"), "Nov-18-22" , "UI.fs" , """
         All work on FrmCfg+Meethoo incorp ici 
        """, "")]


    let LogItms_20 = [ GfxCalItm((gfxGetUNID "gfxItm"), "28-Dec-20" , "spxClient" , """
added helperMethod listOf; some fiddling w/compiler
<br>debugged/prepped copyFileToJar for autoSpxToJar""", "");
 GfxCalItm((gfxGetUNID "gfxItm"), "23-Dec-20" , "spxClient" , """
added diff; some more shuffledKeys
<br>tot keys/riddles in vault=20""", "");
 GfxCalItm((gfxGetUNID "gfxItm"), "22-Dec-20" , "GridTester" , """
(note: this is not in the file but in a patch; beaucoup @MBI)
<br>worked a bit on Grid Srch button before realizing that it might be moot (can use filter)
<br>created/added new dvView '/by TgtVer'
<br>added versionMap to consts w/alpha/bet in unicode esc""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "18-Dec-20" , "spxClient" , """
removed log (to tkDat)
<br>remmed bookmarksPaintCode for ide
<br>renamed some classes
<br>added keys""", "");
   GfxCalItm((gfxGetUNID "gfxItm"), "16-Dec-20" , "Grid" , """
reconciled updates from last couple of days; updateed dat w/some addendas
<br>set JTbl horizScrPol
<br>upd priorityRndrr""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "15-Dec-20" , "General" , """
	mostly worked w/clj & predicates""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "14-Dec-20" , "Grid" , """
	Some work on dvSwitcher; comboBox""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "13-Dec-20" , "Grid" , """
	Added SubMod/TgtVer to Grid, cal, dat
<br>some other minor grid updates
<br>An incomplete update to the JButton("Switch View")""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "11-Dec-20" , "Grid" , """
updates to mTpl/matcher
<br>utilDlg uses matcherPreds & dClone bypass for sysUpdates
<br>other minor updates to refresh tbl etc.""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "09-Dec-20" , "" , """
minor updates to importer to fix content fld; add default proj etc.
<br>new cls utilDlg""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "08-Dec-20" , "" , """
minor update to importer to add recs to tkTbl""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "01-Dec-20 to 08-Dec-20" , "Grid" , """
postCovid imports into allData""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "06-Oct-20" , "<br>" , """
  more minor bugfixes; the unid turned out to be a tblModel issue""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "05-Oct-20" , "<br>" , """  minor bugfixes""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "02-Oct-20" , "<br>" , """  Edited dblFn to accept intSplitOn""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "01-Oct-20" , "<br>" , """  Added Function&lt;List&lt;String&gt;, List&lt;String&gt;&gt; fixDblLines (finds/removes wrapped dblLines)""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "30-Sept-20" , "<br>" , """  Various updates incl new funcs to parseDblRecs""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "29-Sept-20" , "<br>" , """  Reverted to 9.23 version; will have to patch/debug each modification peacemeal.""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "28-Sept-20" , "<br>" , """  Further work on imports; discovered that the monkeys have messed with the data file (updates) and added""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "25-Sept-20" , "<br>" , """  Further work on populating/cleaning/formatting dat &amp; docRefs; impl fluentMapping""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "24-Sept-20" , "<br>" , """  Added comparator for TgtVer; completed import work; UNID -&gt; existing empty col; docRefs""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "23-Sept-20" , "<br>" , """  applied a couple of bugFixes; data much cleaner; shows various docRefs etc.""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "22-Sept-20" , "<br>" , """  Updated docRef regExp to accept &gt;1 space betw ea. + minor fixes elsewhere;""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "21-Sept-20" , "<br>" , """    Some updates to this file for createdDt/docRefs; not compiled/chked""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "11-18-Sept-20" , "<br>" , """  Explored alt ways to avoid monkeyBastaInterference; they seem to be hacking into the JVM""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "10-Sept-20" , "<br>" , """  Added form (jTxtPane-based)""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "09-Sept-20" , "<br>" , """  Added fnGetShorty (util fn for now to be used in generating tgtVer comparator)""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "08-Sept-20" , "<br>" , """  Incorporated the tbl file (w pred, datClass etc) into this file as an inner class to work w/jre8""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "04-Sept-20" , "<br>" , """  Considerable headway; fixed tpl issues w/mapping etc; impl dvDefLift() method in tpl &amp; tested; assignable""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "03-Sept-20" , "<br>" , """  mTpl testing; working as exp so work continues on dvDef etc.""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "02-Sept-20" , "<br>" , """  Minor update to mTpl file (flatMap unwrap, errs w/empty); recompiled lib to common jar""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "01-Sept-20" , "<br>" , """  Minor updates incl fn getRschItms""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "31-Aug-20" , "<br>" , """  Further work on predSupplier in file postCovidTbl""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "28-Aug-20" , "<br>" , """  Some updates + early testing w/mTpl""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "27-Aug-20" , "<br>" , """  Resumed work on mTpl; compiled files using jdk8""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "26-Aug-20" , "<br>" , """  Added readJarArch(), readEntry() etc. methods to access prior archives""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "25-Aug-20" , "<br>" , """  Continued working on import Mod""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "24-Aug-20" , "<br>" , """  Decided to use update tks instd of sample data""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "21-Aug-20" , "<br>" , """  Began work on swing-filterWindow; predBldr""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "20-Aug-20" , "<br>" , """  Tested available security (insufficient; the meher.zip file doesn't contain""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "10-20Aug-20" , "<br>" , """            Entered taskList (&gt;200 items).""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "17-Aug08-20" , "&nbsp;" , """Post-COVID shutdown, i.e., 03/17 to 08/08 was spent planning/taskList (offline)""", "");
    GfxCalItm((gfxGetUNID "gfxItm"), "06-Mar17-20" , "&nbsp;" , """
        At this point the monkeyBastas began throwing WAY too many 
        fake compiler errors and generally began being real pests; it became
        impossible to be productive with their antics.  Therefore the rest of this
        period was spent mostly planning/updating the taskList; with occasional updates,
        mostly to the Grid; until even that was halted when the library closed on Mar17 (COVID)""", "");

    GfxCalItm((gfxGetUNID "gfxItm"), "6-Feb-20" , "" , """further refactoring to remove tries &amp; impl
  mTuple usage
    Removed ALL of 'em (exc some
  commented stuff)
  next-&gt;remove cls tuple (riddle extends)
    refactor cypher (also
  upgradeVer? poss AFTER?)
  refactor grid""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "5-Feb-20", """
  &nbsp;
  (GridTester.spx) This is the
  stable gridTester ported to the stable (encapsulated) spxClient
  Note: BOTH the grid &amp; the client've been
  refactored further; but not stable
    So this is essentially the
  version frozen into 01.29's client
  w/A few caveats: Alltbls moved into mTbl; renamed
  treeV to dvT
    spxCli menuBar left
  _in_situ_ &amp; dataMenu inserted w/updates
  NO other changes; so once (mTuple/map) refactoring
  is complete;
    we shd be able to merge it
  into this file w/o many probs.
  (spxCli) Repl mTuple w/tested version containing
  all missing stuff + lift7""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "4-Feb-20", """
  &nbsp;
  Some tinkering w/functional
  EitherTree (Either+Tree) but it's practically
  useless (redundant) in the spxTbl context; in fact
  a little naive like
    the chap who inserted an
  entire tree in col1 of a table to make a &quot;tree-table&quot;.
  heh.Typical
  freshman; a more exp guy will always snicker @ this
    but it works, &quot;i used
  an OCR library to create an IDE that reads pictures!!&quot;.
  hehe.clever.very clever.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "3-Feb-20", """
  &nbsp;
  Began refactoring GridTester
  w/encapsulation refactoring but the
  monkeyBastas began throwing way too many fake
  CompilerErrs,
    so forced to postone.
  Some further refactoring in this file (untested
  because they're throwing
    fake errs here too, of
  course)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "2-Feb-20", """
  (Wkend) reading; mostly functional; some testing""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "1-Feb-20", """
  &nbsp;
  (Wkend) Created a shell for
  testing/building rowRenderer(s) from supplied preds""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "31-Jan-20", """
  some further cleanup; many fakeMonkeyBastaErrMsgs
    (for instance; renamed class UI since it
  looks for a nonExistent class;
  probably
  existing on the basta's machine.Now
  it finds one static method but
    not another.Perhaps the bastas are simply effing lazy
  and only steal/copy
  SOME of the
  code at one time.Anyway, effers.)
    Changed meth
  createDesktopMenu to a fn
  Updated desktopIcn builder to new build
    Removed a few more tries,
  repl w mTuple/map
  (eventually we want to get to &quot;there IS no
  try&quot;)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "30-Jan-20", """
  &nbsp;
  ren curr stuff to
  &quot;old&quot; (oldmTuple, oldbuild, _Build, oldFinisher)
  in order to refactor w/ new classes/methods while
  testing piecemeal
    REALLY must save more often,
  the effing monkeys are behaving like their innate selves""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "29-Jan-20", """
  created new class Constants; moved static global
  stuff there.
    further work on incr
  encapsulation; removing global refs; removing static""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Jan-20", """
  NOTE: 3:02pm commit has the latest/stable/tested
  mTuple w/Generic Types
    backported this file to
  01.24 stable; applied appropriate deltas
  The last couple of days were spent updating stuff
  and mapping over
    optionals; which won't do
  (no try; we need to map over mTuple)
  so the plan is now to
    - make encapsulation cleaner
  by just passing the ide ref in constr.s
  - make mTuple generic, test &amp; THEN update the
  build stmts etc.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Jan-20", """
  &nbsp;
  Further refactoring; worked
  on removing fn.getTA (repl w/getTab.tA)
  as a part of incr encapsulation (removing global
  refs incl ide)
    MonkeyBastards throwing
  fakeErrs again; additions marked @01.27TBD""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Jan-20", """
  Added 2 new interfaces (TriFunction/Quad) +
  testcode (@eof) for lift3/4""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Jan-20", """
  &nbsp;
  Added 2 util classes
  tuple2/3 using Optional, so mappable
  remmed (@monkeyBastaFakeCompilerErrs)
    updated ideCons to repaint
  container on init (@ToBeTested since icons are off)
  Removed global var i (for ide) &amp; changed all
  refs
    couple of changes remain
  (outline -remmed), getTA()""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-Jan-20", """
  backported this file to 01.21 stable; applied all
  deltas
    @Present this file contains
  the new build ren to _Build_ in the interface
  &amp; all 1.21 build() calls remmed &amp; inserted
  _in_situ_
  @ToDo
  EXCEPT desktopIcon.build()
  which needs to be ported to _Build()
  @ToDo
  1st bld() (File|Open(ui.listDlg)) throwing
  zipFileSystem err
    &amp; also mapping errs
  (seems like @monkeyBastaInterference) postponed.
  Fixed outline issues (cls regexp &amp; escHTML)
    Some other minor edits""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-Jan-20", """
  minor update to lineNumPanel
    Many updates to GridTester
  (deepClone/saveNewRevision)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-Jan-20", """
  Some updates to GridTester (new interface dataProc)
    Some updates to buildable in
  this file (added finisher to build())
  &amp; updated all the bld stmts w/new fmt;
  @monkeyBastaInterf fakeErrMsgs
    Some work on
  fn.cypher.backupToJar""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "18-Jan-20", """
  Many updates to tuple/lift/etc., all stable/working
  as expected
    Copied latest outline
  regexes; changes not updating
  (ie bastas are showing incorrect version of dlg);
  postponed
    Did some work on the
  desktopIcon builder
  it's possible that, like the other stuff; the
  bastas have tampered with
    this section (desktop says
  the components are there, but not visible
  Check location etc. from old src).""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Jan-20", """
  &nbsp;
  (spxCli) Applied mTuple
  changes from GridTester to this file.
  Much new work as well.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Jan-20", """
  &nbsp;
  (spxCli) Further changes to
  mTuple (added lift) &amp; buildable.build()
  some updates after using online compilers (local
  one still throwing
    fake monkeyErrs)
  refactored all refs to strBaseURL to use new
  Supplier&lt;String&gt; strBaseURL
  @ToDo
  16-Jan-20</font>
  (GridTester.spx) Added SubMod fld to tkFrm
    The subMods have disappeared
  (the monkeyBastas probably~)
  created menuItm to reInsert and the bastas
  immediately
    began tampering w/the
  compiler (so postponed).
  Reinserted mTuple type info (from jdk.Optional)
  which the
    monkeyBastas managed to
  remove yesterday (via fake compilerMsgs)
  Began work on redoing yesterdays' monkeySpoilt
  mapping
    (look for UPDATED ON 01.16)
  **Yesterday's fn to remove fakeCompilerErrors
  rendered defunct
    (now the bastas are showing
  ONLY fakeErrors, no real ones @ all)
  -&gt; with the result that the monkeys are now on
  their own
    (no compiler, screw you,
  learn on your own you hopeless losers)
  Our prev work w/o compiler has been quite solid;
  we'll just debug l8r.
    NEED TO ENSURE that deltas
  are properly labelled for isolated testing/debugging
  Updated all current (3) calls to buildable.build()
  w/new Tuple fmt. &amp; map""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "15-Jan-20", """
  &nbsp;
  (GridTester.spx) Pasted in
  the latest mTuple from spxCli (mapR returns tuple)
  updated the class (removed R refs; updated
  flatMap/map)
    Shall be working further on
  it in this file; ensure it gets copied over
  Separated docRevision logic into new fn
  (saveNewRevision) to work on later
    REPLACED existing ui.listDlg
  fns (3) with more concise mTuple versions
  Created a sml util fn using regex to remove
  fakeCompilerMsgs from output""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "14-Jan-20", """
  &nbsp;
  (GridTester.spx) many
  updates but all of em probably unnecc; caused by fakeCompilerErrs
  from the monkeyBastards""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "13-Jan-20", """
  &nbsp;
  (GridTester.spx) Further
  updates to mTbl.put for docVersioning""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Jan-20", """
  (GridTester.spx) turned on docVersioning;
    various updates incl
  mTbl.put &amp; mData incl new flds related""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "10-Jan-20", """
  (GridTester.spx) removed old treeTbl""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "9-Jan-20", """
  &nbsp;
  Continued w/reduction:
  removed dMngr commented methods kept for
  reference (we're almost stable now &amp; it's avail
  anyway online)
    Removed class AnimFactory
  (remmed single ref: iconifyFrame/snapShot)
  mTuple: incorporated try within mapR which now
  returns an mTuple
    Updated fns to read
  BufferedImg instd of Img
  work interrupted @monkeyBastaInterference
    Tested/compiled Stable
  ObjEchoClient (requires netty 4.0)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "8-Jan-20", """
  updated Outline func class/int regexp to incl
  extends/Implements info
    further work on fx
  Added new _Build() to buildable interface; &amp;
  naturally -&gt;
  @ToDo
  @monkeyBastaInterference;
  remmed/postponed (search for &quot;Openv2&quot;);
  The monkeys are now effing w/the class regexp
  Pattern (they're weak at regexp)
  @ToDo
  this is postponed too; the
  debug stmts don't print
  @monkeyBastaInterference
    Removed beaucoup unnecc
  meths from textLN, resulting in
  @ToDo
  (probably monkeyBastaInduced) reset of tlnPanel
  width to 1 digit
    updates to desktopIcon.bld
  (buildable)
  icons not showing (poss @monkeyBastaInt) so added
  alt way of launching ide""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "7-Jan-20", """
  &nbsp;
  inc spxDlg images from
  legacy jarFile
  updated Outline labels to all grey (except names)
    some further work on ui.dlgs
  (interrupted; look for -&gt;
  @ToDo
  //@monkeyBastaInterference; postponed @0107""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "6-Jan-20", """
  &nbsp;
  @monkeyBastaInterference;
  lost all deltas; spent the rest of the day reading functional articles""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "5-Jan-20", """
  reCommented exit calls for badPaddingEx et.al in
  cypher
    updated Outline func regexps
  to highlight ONLY names in color
  @ToDo
  ported ui classes (spxDlg &amp; related) from spx.j
  into this file
    Also ported chkAuth which
  invokes above (for testing)
  &lt;&lt;the animation code was ported from
  dlgs.j_08.05&gt;&gt;
  @ToDo
  Also ported jarFileRelated
  fns for ideAutoSave impl.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "4-Jan-20", """
  backported desktopIcon img changes to stable ver
    (2 deltas; marked @remmed
  01.04)
  Built new fatty.jar &amp; recompiled launcher for
  options;
    resulting in various crashes
  poss related to @monkeyBastas
  trying to launch their add-ons/agents/etc.(a little slow, them)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "3-Jan-20", """
  &nbsp;
  Ported mTuple (from
  spxSvr);
  added interface fx using mTuple
    added cls toaster
  Modified regexp for methods in fnOutline (tested;
  Stable)""", "") ]

 let LogItms_19 = 
    [ GfxCalItm((gfxGetUNID "gfxItm"), "30-Dec-19", """

Updated prnEx to printOut exceptions only once per line # Removed extra logMsgs for compiler (&quot;skipping writing class file...&quot;) etc.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Dec-19", """

added ui BufferedImg fns from spx + popupMenu for paginationBar @ToDo
added defaultColor tint to desktopIcons<span style='mso-spacerun:yes'> </span>(@ToBeTested) removed the legacy GraphicsUtils stuff""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Dec-19", """

continuing the refactor; esp. data stuff...""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Dec-19", """

removed svr stuff""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-Dec-19", """

refactoring -&gt; removed actions (moved useful snippets to disable menuItems) added prnEx / prnOut @ToDo
some work on desktopAnim (left off @ ln 1642)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-Dec-19", """

worked on spanTbl (popDat/expandCollapse etc.) in another file (spxServer.spx)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "20-Dec-19", """

Many updates made on 12.18 lost (monkeys messed w/clipBd &amp; pasted crap) another reminder to backup often; the devil does not sleep. Re-instated changes from 12.18; incl desktopIco blur""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "19-Dec-19", """

Worked on asyncSockCli/Svr; some progress.<span style='mso-spacerun:yes'> </span>Either the code snippet<span style='mso-spacerun:yes'></span> contains major errors OR the monkeyBastas up to their usu tricks (display doesn't reflect actual code)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Dec-19", """

Added support for pasting last item from clipBdHistory (via keybd shortcut) Added new interfaces userInt, srcRelated &amp; moved fns into them for org""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "16-Dec-19", """

Repl all lstDlg calls w/new buildable calls; removed earlier ver. of class Repl outline fn w/version that uses new listDlg""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "13-Dec-19", """

Created new shell for testing interface buildable independently Buildable working, stable, ported into system First impl used to load embedded srcFiles from jar; working &amp; stable""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Dec-19", """

Created cryptoEd.j w/all the latest updates.<span style='mso-spacerun:yes'> </span>Stable <span style='mso-spacerun:yes'></span>updated Fatty.jar by importing all regularly used src files; worked on auto-loading <span style='mso-spacerun:yes'></span>updates to launcher.j to offer embedded choices.<span style='mso-spacerun:yes'> </span>Stable. <span style='mso-spacerun:yes'></span>updates to enStrComp.j to suppress/auto-fill class/pkg names; monkeys jam the compiler, shelved for now <span style='mso-spacerun:yes'></span>(note that we ported the functionality into the menu (internal) so launcher was backported for above changes) spxTbl stable, showing categs.<span style='mso-spacerun:yes'> </span>Last work on wonkyTbl (stable) ported into cryptoEd.j""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "11-Dec-19", """

The monkeys are now jamming the nettySvr (only allows 1 connection; using Stable netty-provided example) <span style='mso-spacerun:yes'> </span>There's a sm chance one import is missing, will investigate.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "10-Dec-19", """

The monkeys began jamming the server work (as usu) so decided to use Netty (as we did jetty for ht httpSvr) <span style='mso-spacerun:yes'> </span>(the reasoning: get the handlers etc. working &amp; then repl the server w/a custom impl) """, "");

GfxCalItm((gfxGetUNID "gfxItm"), "09-Dec-19", """

worked on asyncSocketSvr/Cli (contd. from legacy work)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "08-Dec-19", """

spxTbl stable, spanning, several updates to categRenderer""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "07-Dec-19", """

Created new paginationToolBar; added icons (NOTE: subseq. Monkey removed these; might have to recover)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "06-Dec-19", """

debugging log (monkeys put in non-ascii chars etc.); these need to be reset - fn createAndConfigTab try/catch remmed - fn publicKeyCheckCommented whole fn remmed (fakeCompiler fails) - meth Boolean save() remmed - fn getNewRiddle remmed they're still throwing fakeA$$ errMsgs so we'll pause for now Testing the new features/additions: (using the wonkyTbl-dec2 ver) - winDisp() PASSES - addIconsFromBytes PASSES - testIconFromAdmin(no objInpStrm) FAILED with IllegalArgumentException: Illegal base64 character <span style='mso-spacerun:yes'> </span>(ie, content not base64, ie, binDirect) and now (updated code) PASSES Updated fnGetIcon w/changes; as well as the spxTbl Henceforth we shall apply changes to this file &amp; test w/wonkyTbl""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "05-Dec-19", """

further work on openEmbedded prior to testing w/builder, incl. builder""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "04-Dec-19", """

Added BiCons prnEx, updated all catch sts. lstDlg fontSize superSized File|winDispose() Added addBookmark(menu) &amp; next/prev func (in keyAdapter) TO BE DEBUGGED; needs icons Added 3 new testMenu icon-related items Updated some refs to riddle.getRiddle() to rid.getQn() (baseEnc inside cls) Added listDlg (impl buildable) TO BE TESTED w/FileLister list (or similar) Added File|openEmbedded menuitem to test above list w/blder""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "03-Dec-19", """

ported dslBuilderFactoryImpl.j into this file applied SHAChk in loadFn; much debugging (the hashes didn't match) but eventually fixed it all. Many updates incl. new params to allow createPane to set title/txt of new pane plus check hash on Load<span style='mso-spacerun:yes'></span> Other updates as a result of sRiddle extending tuple""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "02-Dec-19", """

Ported snippet to load jarFiles (from launcher.j)<span style='mso-spacerun:yes'></span> Added menuOptions to load AllTbls internally or via ide""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "01-Dec-19", """

created utilFn to print dat rows (for debugging spxTbl populateDat) some further work on outline regexp; working but need to tinker w/ positions (match.start() vs str.substring)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "30-Nov-19", """

some further work on outline regexp some work (incomplete) on table rowRollover completed/tested dslBuilderFactoryImpl.j""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Nov-19", """

lib closed 28,29""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Nov-19", """

changed/ren Consumer fontSetter to superSizer; updated relevant code""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Nov-19", """

Created/tested dslBuilderFactoryImpl.j, to be impl here""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Nov-19", """

Attempted changes to tuple/sRid classes but @monkeyBastaInterf. Added datBtn""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-Nov-19", """

Added toolbar; moved find panel to toobar<span style='mso-spacerun:yes'></span> (earlier there was unnecc. duplication: findPanel in ea tab) added openInArchive to menu &amp; removed legacy action""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-Nov-19", """

reading func stuff""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "22-Nov-19", """

some work on scanning all classLoaders to find a class etc... entire compilation routine moved to anonClass in menu added new func taGotoLine vs ~pos after outline changes""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-Nov-19", """

some updates to findPane, some other minor updates outline fixed &amp; operational new fn ui.hex2Rgb""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "20-Nov-19", """

updated enStrComp (launcher); ported methods to fns""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "19-Nov-19", """

added goTo to outliner; rewrote outliner for html output added new logger outline &amp; jEditorPane working; but unfortunately the HTML uses CSS and the monkeyBastards like to mess with that; so they're having the time of their lives :-)<span style='mso-spacerun:yes'> </span>effing children :-)<span style='mso-spacerun:yes'> </span>we'll have to find another way.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "18-Nov-19", """

fixed compiler diagMsgs, moved to menu (no methInvocations) debugged goTo func""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Nov-19", """

debugged spxTbl &amp; related classes""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "16-Nov-19", """

reconciled ALL deltas into this file; remming where necc. to allow compile moved ToolsSubMenu one over for usability reasons""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "15-Nov-19", """

cleaned up the outliner; added dsl to lstDlg added fn tAGoToPos<span style='mso-spacerun:yes'> </span>(remmed, on which the bastards crash the compiler; just like goTo) added regexp findFunc (to be tested) (&lt;- uses tuple, need to import fr wherever...)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "14-Nov-19", """

added txtA.setTabSize(); ported class files &amp; some fns from spxSvr fixed outliner to not use HTML; still need to add goTo func.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Nov-19", """

upd keys""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "10-Nov-19", """

this file contains all changes from yesterday BUT still needs deltas from 11.08 refactored all refs to textAreas etc. to use the new tabMngr npe being thrown on getPane() -- FIXED added PlainDocument doc to tabMngr added 11.08 deltas -&gt; -&gt;added fn ui.getOutlinePane -&gt;added fn cypher.SHAChk -&gt;added sphinxv1/v2 logic in getKey &amp;&amp; SphinxifyFn""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "09-Nov-19", """

added class tabMngr to store refs to tab stuff; allows resetting title removed setCurrentTitle added a tabMngr class &amp; updated all refs to currentTA &amp; textArea vars NOTE that this file @ this point does NOT contain the deltas from yesterday's changes made in the PM; will have to incorporate them here""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "08-Nov-19", """

added setCurrentPaneTitle -&gt;ported yesterday's findFn fix to this file -&gt;note: yesterday's goTo still won't compile;<span style='mso-spacerun:yes'></span> the bastas get the compiler to throw wrong errMsgs""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "07-Nov-19", """

npe bug again (set currentTA to newlyAddedTA; autoFocus on newlyAdded updated fnGetKey to use swingDlg instd of stdOut -&gt; @ this point the monkeyBastas (perhaps because they can't get the pwds) make the compiler fail.<span style='mso-spacerun:yes'> </span>New additions: -&gt; goTo line fn marked w/@monkeyBasta1107 -&gt; Find func. pos fixed (from 0 to caretPos)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "06-Nov-19", """

fixed minor bug w/tabbedPane""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "01-Nov-19", """

reset keyBd actions (the clever monkey Bastards moved the cut action to steal code, the effers) added new trigger for clipbdDlg added tabbedPane; new docPane setup; assoc menuItems/changeListener""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "31-Oct-19", """

compiler.compile was filling strAI w/dubious ecj errDiags; reset out from stdOut to baos piped into strAI added paste capability to clipBd historyDlg""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "30-Oct-19", """

delta fixes <font color="#000000">&nbsp;</font>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "14-Oct-19", """

jdk13 runImg; initial testing/compiling edited mfs""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Oct-19", """
tbl
few tblTest.j updates before the bastards begin effing w/the compiler again, the S.O.B.s 2-Oct-19
dat
imp.j - updated w/latest AllTbls in prep to export to spx svr
Created spxServer &amp; obfuscated; monkeys messed w/compiler (mTbl class) 1-Oct-19
tbl
Some work on tblTest (spxTbl/tkList, needs to be inc into old treeTbl) tbl
Added new flds (Imp, Urg) cellRenderer remains""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "30-Sep-19", """
svr
AsynchServer / Client""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "29-Sep-19", """

cits""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Sep-19", """

cits""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Sep-19", """
svr
researched / tested AsynchSocketServer""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Sep-19", """

mfs5 / tkTree -&gt; updated / poss fixed level Issues by ensuring mods added to Proj; not root""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Sep-19", """

vaca 8-Sep-19

vaca 7-Sep-19
dat
- created msf5, basically mfs2 (~0806) + mfs4 dat fns 6-Sep-19
all
- added crypto func. to mfs4; reFactored the entire module to remove every method (crucial to prevent methodInterceptors) Henceforth it will work using higher-order fns. 5-Sep-19

- Created a new file (imp.j/privRepo) for blding mfs4. Rebuilt AllTbls w/all but tkTbl. Imported icons to mAd &amp; mPanes to mATbl **NOTE** that current spx file dataClasses produce a serializationException; so used a prior version. @ToDo: verify that any/all changes made to dataClasses in spx (versioning?) are applied to curr featureSet. 4-Sep-19

- Added mAd strings for custom mT Priority ttip mappings (using adapted Covey System) to 'loadAdList' menuAction 3-Sep-19
fEnd
- Completed work on iconAnimation, created animFactory class w/DSL 1-Sep-19

closed 2-Sep-19

closed""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Aug-19", """
fEnd
(upto ~ 9th Spt)- worked on Desktop.j (icons, windows, et al.) <font color="#000000">&nbsp;</font>""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Aug-19", """
dat
- changed all occurences of LocalDate.MIN to constant LocalDateMin (in dataEng, set to 1900.1.1 coz the java MIN causes issues with n -@ToDo: any/all data containing this val needs to be updated - added new menu item to Load mPanes to mArticles (from imp.java)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Aug-19", """

- prepWork for recreating mAd tbl; downloaded materialIcons pEng
- some work on preparing (for test) an async procEng pipeline""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Aug-19", """

- Updated interface iTable; added updated srchFn ut
- added tuple to utils (?? done earlier??)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-Aug-19", """
tbl
- merged regularTbl into this file - added treeView DSL to allow regular/spxTbl creation""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-Aug-19", """

- merged MFS3 (treeView) into this file tbl
- worked on indep impl of regularTbl to use for Srch/etc.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "22-Aug-19", """
all
- removed 'that' refs from code; made most classes static tbl
- removed old treeTbl (w/tree on left &amp; table on rt) &amp; repl tbl
w/spanTbl impl i.e., tree INSIDE tbl""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-Aug-19", """
tbl
- continued spanTbl coding, incorp categPaths""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "20-Aug-19", """

- migrated menuOptions for mAd, AllTbls data actions to Menu into this file tbl
- migrated spanTbl into this file tbl
- created framework for spanTbl, funct. to launch it using existing setup (created for treeTbl) tbl
- coded some of the initial func. for spanTbl (generating top level categories)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "14-Aug-19", """

- renamed all resource imgs in obfJar to confirm to naming conventions""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "13-Aug-19", """
tbl
added new Fn tkAddLineItemToTop so that when this list is ported to the tkList we can add latest updates to the top. tbl
updated acl enum to return intVal for getToolBar() dat
added docVersNum field to mData &amp; edited mTbl.put to do versioning by default. all
updated getIcon() to use mAd resources updated treeTbl.getToolBar() to supply generic tbar udpated ACLs to int; impl rudimentary acl logic in getToolbar ren taskTree to treeView""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Aug-19", """

Updated mfs2.j (priv Repo) with coupla Admin fns to rebuild mAd + serialize AllTbls; incl DeflaterInpStrm.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "11-Aug-19", """

mostly new Icons etc since the monkey Bastas are messing again with the compiler.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "10-Aug-19", """

mostly new Icons etc since the monkey Bastas are messing again with the compiler. 9-Aug-19

dt of stable (min) obf version; has no chkKey; still saves keys &amp; uses old dlgs / perhaps we need to patch THIS ONE Some further work on genericizing taskTree created obfusc mfs_2; need to update config for: Exception in spxTaskListAction -&gt; classNotFoundException: com.trivedi.sphinx$mTbl 8-Aug-19

Added some new icons, updated tibbie Dlg reconciled ALL (prob.ly) edits/updates into sphinx.j Found some code impl JSR199 for ecj (incl an impl using ForwardingFileMngr) Cld work on that &amp; pipe results into proG 6-Aug-19

ReWrote taskTree generator to add 2nd level nodes (proj/mod) Recompiled stable-ish jar (doesn't incl dlg updates etc.) Tried to run proG but the monkeys interfered. 5-Aug-19
<font color="#000000">&nbspnbsp;</font>
Debugged/edited tkEdit form, stable-ish @ end Ported most menuItems from Action classes to anon inners. Updated code to use Serialized tkData; updated menuItems 4-Aug-19

worked on tList 3-Aug-19

worked on tList 2-Aug-19

Added a tabbedPane &amp; assoc menuItems to ide. 1-Aug-19

prepared minFeatureset compiler # 2 incl taskList the monkey Bastas messed with the VM and interfered with the compile again.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "31-Jul-19", """

pulled some remaining methods from 2018eoy &amp; refactored them into fns""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "30-Jul-19", """

Reconciled the 3 major deltas: - taskTbl; various updates incl Dlgs (presently commented inside) - legacy from Hammer - legacy from eoy lastYr Reduced to minFeatureSet; rest of the classes/mods labelled @mfs""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "29-Jul-19", """

Incorporated taskList class into sphinx.j; removed redundancies Then reconciled sphinx.j w/the FULL (non-minFeatureSet) version We shd have everything here now; poss some duplication in fns.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Jul-19", """

look &amp; feel -&gt; -&gt; changes below applied to taskList.j; ported to sphinx.j 07.29 &lt;- &lt;-""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "27-Jul-19", """

added dsl to taskForm + modes (create/edit) refactored the frm logic; put some methods to new toplevel ui class added fn treeNodeCreater to generically generate dv-like trees.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Jul-19", """

taskEditForm / backend (save etc.) handcoded for now; need to genericize later""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Jul-19", """

taskEditForm""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-Jul-19", """

more l&amp;f taskEditForm""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-Jul-19", """

changed some lookAndFeel colors; added ttips began work on adding add/edit functionality Added toolBar reconfigured jtree stuff to display allByPriority for root clicks""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "22-Jul-19", """

built jtree &amp; added tbl stuff -&gt; -&gt; changes above applied to taskList.j; ported to sphinx.j 07.29 &lt;- &lt;-""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "18-Jul-19", """

Added dataStatsAction; imported pipeLine; more categJTable work; reverted to using static (hey, the jdk uses it so it can't be bad)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Jul-19", """

Added dataEngine, utils classes; reFactored to cleanup Created/added loadTaskListAction to load serialized file to AllTbls""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Jul-19", """

Added adapters Removed mUtil class; changed other structure somewhat Refactored some actions to fns 8-Jul-19

Imported legacy classes (mA, mTbl etc.) minor edits to compile settings etc. 5-Jul-19

Major security updt -&gt; removed keySave (prompt instd for all saves). fns affected incl Load; Sphinxify; SaveFil -&gt; each of these now loads &amp; nulls a key 3-Jul-19

Imported new spxDialogs &amp; applied related updates (fifeURL etc).""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "29-Jun-19", """

Applied classNm changes (some issues related to earlier compiled class expecting a diff name)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "28-Jun-19", """

Added fn to fmt sphinxStrings to mimeLen 76 (one col) Name changes -&gt; mUtil.sphinx becomes mUtil.cipherEngine; cryptoEd becomes sphinx""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "26-Jun-19", """

upd JTable to listen to rowClicks""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Jun-19", """

dt of stable compiler version; has to be a more recent one (perhaps gitee) coz this still expects cryptoEd.java""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "25-Jun-19", """

Repl new keyVault riddles via hand-picking; checked both maps for integrity.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-Jun-19", """

monkeys going beserk; reinited the keys to keep them in order (new keyVault reduced Qns unused) 2nd sess: fixed Action4 console msgs + simplified patternMatcher; fixed compiler modPath.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "22-Jun-19", """

moved LookAndFeel to main per oracle docs.""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-Jun-19", """

The bastards are trying to steal the code again: they replaced the cut/paste classes in the editor. Fixed the theme.load but the eclipse scheme looks funny....""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "02-Jun-19", """

Separated the modules fife/sphinx; fixed sphinx to use mod declarations""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "19-Jun-19", """

Imported legacy JAR manip code (2017)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "18-Jun-19", """

Added AboutAction &amp; nested classes txtDlg, listDlg, abtDlg to ide""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "17-Jun-19", """

fixed compiler path issues for class files; other minor compiler complaints imported action4""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "15-Jun-19", """

OpenInArchiveAction (has zip spanning &amp; listDlg code now)""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "12-Jun-19", """

ClipboardKeyAdapter wasn't triggering History updates on copy/cut; added chk that text exists Attempt #2 @ classLoad after compile Added some new Actions, moved others""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "11-Jun-19", """

compl. work on reverse Sphinxify added cut/copy intercepts to feed into History""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "01-Jun-19", """

updated compiler options; began work on reverse Sphinxify""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "09-Jun-19", """

rebuilt 0609 w new keyVault &amp; slight changes; test compilation works""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "31-May-19", """

new func. sphinxifyToClipbd(byte, byte) to add to actions""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "29-May-19", """

applied all the minor fixes/updates from the last few days; we now have the popup not cutting/pasting HOWEVER the monkeys have been extra busy so it's likely we'll need to do the Action intercept (they're using prefs;datatransf;xml etc. which they've inserted very slyly into my runtime) Added a check for chkKey == false; triggering a newSession""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "24-May-19", """

stable version, save new Fmt spx; rewrote getKey for optional""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "23-May-19", """

reset riddleMe &amp; map""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "22-May-19", """

EOD STABLE! except failing sphinx chk... (probably corrupt map; chk w/only 1 entry) refactored sphinx; added sRiddle class &amp; assoc fns""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-May-19", """

PM session delayed (the bastards keep messing with the source files""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "21-May-19", """

launcher ready; last stable ver of cryptoEd is 13th Gameplan: - add compile capab &amp; see if there are too many flags#NAME? - if not, get it ready. if yes, revert to 13th version &amp; add piecemal - FOR NOW, ignore/disable clipboardPopup; use Actions to access the clipboardBuffer; we'll worry about that stuff later. re-applied yesterday's changes, added new class sRiddle to sphinx""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "19-May-19", """

Many changes incl renaming sphinx to sphinx + map etc. LOST (monkeys""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "18-May-19", """

overwrote the file. We shall persevere.) further work on wall (renamed sphinx) &amp; timer to invoke""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "15-May-19", """

new handlers for openPlainTxt actions, openInArchive etc.; moved io/utils/sys to ide local vars etc. in-Mem compiler code""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "14-May-19", """

***************new stable version*********************""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "13-May-19", """

added recent updates for clipBoard intercepts incl printScn""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "10-May-19", """

added code for &quot;LoadWithNewKey&quot;""", "");
GfxCalItm((gfxGetUNID "gfxItm"), "09-May-19", """

applied changes and saved (encr) w/new stable version""", "")]

    let show() = 
        LogItms_24
        |> List.mapi (fun i x -> 
                        printfn "%A) %A" (i) (x.toWob())) |> ignore