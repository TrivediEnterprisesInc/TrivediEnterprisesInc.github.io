﻿require(["dojo/_base/lang", "dijit/Tree"], function(lang, Tree){
  window.mCfgTree = lang.extend(Tree, {
/*
    May30: Best way to handle treeIcons is pro'ly the same as rtEd icons, viz.: 
    new Template + PostCreate (see rtEd_icons.html @ https://plnkr.co/edit/6PeGDtdKy1b7lidt)
 Material Icons ->
 System: settings             ['System', "dijitIconFilter"],
 Tasks: task                      ['Tasks', "dijitIconConfigure"],
 Calendar: calendar_today           ['Calendar', "dijitIconSearch"],
 MindMap: psychology          ['MindMap', "dijitIconApplication"],
 Rules: rule            ['Rules', "dijitIconBookmark"],
 Recycle Bin: restore_from_trash            ['Recycle Bin', "dijitIconBookmark"]

*/      
    getTooltip: function(item){
      const ttipMap = new Map([
        ['System', `      mode (lt/drk)
      colSchm customization (wid colors? ttip colors?)
      font(s) customization | select | Add new
      customCols (e.g., if Tags.contain('xx') bkColor = xx)
    - Sync/Offline Settings
    - FullText Search Settings (on/off/idx rebld freq)
    - Encryption
    - Hints (hide or slow down freq)
    - Language/timeZone/Localization
`],
        ['Tasks', `      Default vw options
      Ability 2 add custom flds`],
        ['Calendar', `      setup Reminder(s) / autoReminders / autoTkRollover opts
      Create new Cal
      tks from which cals to show by default`],
        ['MindMap', `      Default vw options
      Show ttips or not
      Create new Map; 
        Name & Allow saving > 1 defaultVw (will create treeEntries)`],
        ['Rules', `      Tasks:
        Ability to auto-create:
          (if Tags.contain('@todo') >> create Tk w/docL)
          _or_ (if fldContent.contain('@todo') >> create Tk w/docL)
      Hooks:
        Email on event (define)`],
        ['Recycle Bin', ""]]);
      return (ttipMap.has(item.name) ? ttipMap.get(item.name) : "");
    },
    getIconClass: function(item, opened){
      //@ToDo: to be customized...    
      const SettingsMap = new Map([
        ['Africa', "dijitIconTask"],
        ['System', "dijitIconFilter"],
        ['Tasks', "dijitIconConfigure"],
        ['Calendar', "dijitIconSearch"],
        ['MindMap', "dijitIconApplication"],
        ['Rules', "dijitIconBookmark"],
        ['Recycle Bin', "dijitIconBookmark"]]);
      const defIcn = (!item || this.model.mayHaveChildren(item)) ? (opened ? "dijitFolderOpened" : "dijitFolderClosed") : "dijitLeaf"

      return (SettingsMap.has(item.name) ? SettingsMap.get(item.name) : defIcn);
		},
    onLoad: function(){
			// summary:
			//		creates a TreeNode
			// description:
			//		Developers can override this method to define their own TreeNode class;
			//		However it will probably be removed in a future release in favor of a way
			//		of just specifying a widget for the label, rather than one that contains
			//		the children too.
      console.log("==========in mCfgTree.onLOAD============");
      //console.log(JSON.stringify(this._itemNodesMap));
		  let itm = this.getNodesByItem("System");
			// summary:
			//		Returns all tree nodes that refer to an item
      //console.log(allItms.length);
      //June05: the line below throws coz itm's undefined as yet...
      //itm.iconNode.innerHTML = "M";
		},
  });
});