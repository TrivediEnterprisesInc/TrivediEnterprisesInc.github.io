open System

let inL = {'a'..'m'} |> List.ofSeq
let scrL = ['a'; 'k'; 'c'; 'b'; 'd'; 'j'; 'e'; 'i'; 'l'; 'h'; 'm'; 'f'; 'g']
let r = new Random((int) DateTime.Today.Ticks)

let amish = 
    fun inLi -> 
        let mutable continueLooping = true
        let ord = List.fold (fun s v -> 
                        let mutable innerFound = 0
                        continueLooping <- true
                        while continueLooping do
                            let rand = r.Next(0,inLi.Length)
                            if (not (List.contains rand s)) then
                               continueLooping <- false
                               innerFound <- rand
                        innerFound :: s) [] [0..inLi.Length-1]
        List.map (fun x -> inLi.[x]) ord
    
let egg =
    fun li ->
        let mockLi = [0..li.Length-1] |> amish
        printfn "mockLi: %A" mockLi
        mockLi |> lim (fun x -> li.[x])


printfn "Hello World %A " (egg scrL)


