type DocUNID = | DocUNID of string

type TreeDataItm = | TreeDataItm of unid:DocUNID * divId:string * title:string * tags:string list * content:string * notes:string with
    member this.toString() = 
        let (TreeDataItm(u,d,t,tg,c,n)) = this
        "Unid: " + u.ToString() + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " Content len: " + (c.Length).ToString() + " Notes: " + n
        

module gfxDat =
    open System
    open System.IO
    open System.Diagnostics
    open System.Text.RegularExpressions
    (*open Trivedi.Core
    open Trivedi.Brij*)
    
    let unidVal = ref (((int) DateTime.Now.Ticks) - ((int) (DateTime(2001, 1, 1)).Ticks))

    let gfxGetUNID = 
        fun str -> 
            unidVal.Value <- (unidVal.Value + 1)
            DocUNID(((unidVal.Value).ToString() + "^" + str))
    
    let appendAble = 
        [ TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "              mBoxes Redux?", [" notes mBoxes postbin task"], """We nd a b8r way to org these notes; MD fine but not v searchable; so revert to mBoxes w/tags
Bld a quick/dirty input frm & persist a la snippets

<h4>Some approaches identified on Oct 4 '23</h4>
GitHub has a really great API for creating new Gists
<i><b>Use this?</b></i>
Cons:<br>
<ul><li>nd 2 be logged in</li>
<li>nd 2 clean up</li></ul>
<hr>
Pros:<br>
<ul><li>no data loss ever</li>
<li>no nd 2 cleanup pastebins</li></ul>
<b>Postbin (a pastebin API for devs)</b><br>
To add a webhook OR save outpt from Pgs to bin:<br>

This API tries to be RESTful and can be used programatically to create a bin and query it's contents to help your unit testing, your constant integration tests or your build server.<br>

<pre><code>https://www.toptal.com/developers/postbin/:binId</code></pre> returns a RequestId <br>
<pre><code>GET /developers/postbin/api/bin/:binId/req/:reqId</code></pre> returns payload""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Due Diligence", ["notes corp NoCo"], """</blockquote>
"Refine & React-Admin same tgt in the noCo space: they're going after ReTool"<br>
ReTool Dashboard maker - React - "Access on steroids" 
Refine github.com/refinedev/refine (MIT) 15k devs - "headless UI" - can use MaterialUI - No-LoCode Proj Creation Wizard <br>
React-Admin github.com/marmelab/react-admin marmelab.com/blog/2023/07/04/react-admin...<br>
<hr>
VisualDb.com: Advanced Filtering w/And-Or - upto 100k recs in Vw per Qry | Unlimited - BYOD<br>
frappeframework.com OSS LoCo<br>
Flask AppBuilder: "competes w/MS PowerApps"<br>

jinjat.com (LoCo) Uses Refine as UI framework to render data models<br>

github.com/BudiBase<hr>
github.com/appsmithorg<hr>
github.com/ToolJet<hr>
github.com/lowdefy<hr>
github.com/windmill-labs/windmill<hr>
www.superblocks.com<hr>
Hansura / Supabase: Not NoCos, lookup 4 tech<hr>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "VC Info", ["notes vc links podcasts"], """
VC Info
<a href='https://podtail.com/podcast/mixergy-startup-stories-with-1000-entrepreneurs-an/'>Mixergy stories</a><br>
In May 2014, Nick founded the 1st VC podcast, <a href='https://podtail.com/podcast/the-full-ratchet-vc-venture-capital-angel-investor/'>The Full Ratchet</a> (TFR): Venture Capital and Startup Investing Demystified, which has grown to over 90k active subscribers.<br>
VC <a href='https://www.vc-rank.com/'>Rank</a>""", "");
          
          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Founder Info", ["corp founder info"], """
Blog: Business of <a href='https://businessofsoftware.org/blog/'>Software</a><br>
<a href='https://gist.github.com/TrivediEnterprisesInc/www.indiehackers.com'>IndieHackers</a><br>
37signals<br>
<a href='https://basecamp.com/'>BaseCamp</a><br>
makerLog<br>
""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Founder Info", [" corp founder Marketing info"], """<ul>
<li>The Laws of SaaS <a href="www.motivado.co/the-laws-of-marketing-for-saas-startups/">Marketing</a></li>
<li>SaaS Metrics (ref: Gail Goodman BoS) <a href="www.forentrepreneurs.com/saas-metrics-2/">David Skok</a></li>
<li><a href="https://www.kalzumeus.com/greatest-hits/">Kalzumeus</a></li>
<li>frm SoloPren HN thread (link elsewhere) attend Trade shows, in-person, create Ideal Customer Profile.  Be <strong>very</strong> specific not just by industry, e.g. PayPal targeted eBay power sellers in their early days.  Read Secrets of Sandy Hill to understand the VC Model (summary below) <br>
In Secrets of Sand Hill Road, Kupor explains exactly how VCs decide where and how much to invest, and how entrepreneurs can get the best possible deal and make the most of their relationships with VCs. Kupor explains, for instance: Why most VCs typically invest in only one startup in a given business category.</li>
<li>read The Lean Startup (summary below) <br>
The book talks about creating a Minimum Viable Product (MVP) that can be tested with customers and making decisions based on data-driven experiments. It also talks about the idea of pivoting, which means changing a startup&#39;s direction based on feedback from customers or market conditions.</li>
<li>var articles on mktg &amp; running sml <a href="https://successfulsoftware.net/starting-a-microisv/">sw co</a></li>
<li>The more customers you have the harder to focus on service; no/few customers -&gt; move fast</li>
<li>The customers are only the validation of yr idea: if they don&#39;t come something&#39;s wrong.</li>
</ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "             Svr Hosting", [" notes hosting server"], """<ul>
<li>Free <a href="https://stackdiary.com/free-hosting-for-developers/">dev</a> hosting</li>
<li>Free <a href="https://codeless.co/free-docker-hosting/">docker</a> hosting</li>
<li>Hosting on <a href="https://blog.replit.com/powerful-servers">repl.it</a></li>
<li>&#39;The new Heroku: free TLS certs, global CDN, private netwrks, auto-deploys frm git&#39; <u>Render</u></li>
</ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "IBM Acquires Database-As-A-Service Startup Compose", [" notes DBaaS mongo server hosting"], """<p>Frederic Lardinois@fredericl / July 23, 2015 | TechCrunch</p>
<p>IBM today announced that it has acquired Compose, the Y Combinator-backed database-as-a-service startup originally known as <strong>MongoHQ</strong>. Financial terms of the acquisition were not disclosed.</p>
<p>Compose had raised $6.4 million since it launched in 2010 � most of it in a Series A round in 2012 that was led by Trinity Ventures.</p>
<p>And IBM spokesperson tells us that Compose, which has offices in San Mateo, Calif., and Birmingham, Ala., will continue to operate as usual after the acquisition closes and that current users will not be impacted by this change. Compose says about <strong>3,600</strong> companies currently use its services and that its users, which span industries from retail to IoT and marketing services, have spun up over <strong>100,000 databases</strong> so far.</p>
<p>While Compose started out as a MongoDB database specialist, the company now offers services around MongoDB, Elasticsearch, RethinkDB, Redis and PostgreSQL. The overall idea behind Compose is to allow mobile and web developers to create their apps without having to worry about their database backends.</p>
<p>Compose <strong>provisions the databases</strong> and then <strong>manages</strong> them for its customers (and <strong>scales</strong> them up and down as needed, too). Its users have access to a real-time <strong>dashboard</strong> to monitor their instances, which can be hosted on <strong>AWS, DigitalOcean and Softlayer</strong>. Now that Compose is part of IBM, it will likely soon support IBM�s Bluemix platform, too.</p>
<p>�By joining IBM, we will have an opportunity to accelerate the development of our database platform and offer even more services and support to developer teams,� said <strong>Kurt Mackey</strong>, co-founder and CEO of Compose, in a press release this morning. �As developers, we know how hard it can be to manage databases at scale, which is exactly why we built Compose �to take that burden off of our customers and allow them to get back to the engineering they love.�</p>
<p>IBM argues that this acquisition will give it access to an �enhanced framework to deliver highly sought after, production ready, cloud database services for developers.�</p>
<p>�Compose�s breadth of database offerings will expand IBM�s Bluemix platform for the many app developers seeking production-ready databases <mark>built on open source</mark>,� said Derek Schoettle, the general manager of IBM Cloud Data Services, in today�s announcement. �Compose furthers IBM�s commitment to ensuring developers have access to the right tools for the job by offering the broadest set of DBaaS service and the flexibility of hybrid cloud deployment.�</p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Going solo", [" notes corp B2B B2C Sales Enterprise"], """<li><strong><em>B2B Sales</em></strong>: same thread above, both opinons; some say landing a big contract w/lrg enterpr gd/bad.</li>
<li>Pros: <ul>
<li>Lotsa rev for lil sales effort.</li>
<li>Can get financing to facilitate big contrct</li>
<li>OK if you have <strong>Rollout Clauses</strong>: mandating training as part of pkg, requests limited 2 direct support (bugs/qns) &amp; limit new feature req from cli.</li>
<li>You get a great case study 4 yr mktg material</li>
<li>You&#39;re now legit, can draw in further big clis</li>
<li>In the US contract law can be v fair</li>
</ul>
</li>
<li>Cons:<ul>
<li>A few big cos can push you around, many sml clis can&#39;t</li>
<li>One poster says &#39;you end up becoming their b*tch&#39; (feature reqs or they leave...)</li>
<li>How does &quot;I want x feature for $y or I walk&quot; bring contract law into the qn?</li>
<li>Another resp says this sit killed his biz - didn&#39;t have time to expand the biz and didn&#39;t charge the 1st cli enuff to scale; v stressful, cli threatened to sue.</li>
<li>Yr income&#39;s more predictible with 1k customers @ $100/yr than 10 custs paying $10k/yr</li>
</ul>
</li>
</ul>
<p>If you&#39;re doing B2B, are you meeting the ppl actually the buyer?  Approve the purchase?  If not, contact em (linkedIn/coldcall)</p>
<p>On the same topic: <strong>Being solo</strong>
get advisors/contractors/biz dvlprs to put on the &quot;team&quot; pg.  Make PR announcements.  Free trials/collabs w/midsize custs &amp; put &#39;em as customers.  Get refs from endusers. </p>
<p>Have @ least a <strong>newsletter</strong> &amp; a <strong>referral prg</strong>  They cost nothing, just effort.</p>
<p>B2C over B2B: if it&#39;s valuable they&#39;ll buy happily (saves em work) - frictionless compared to enterp contract negotiation &amp; vetting, slow security audits, bad terms, scope creep.</p>
<p>Rule of Thumb: If a big cli doesn&#39;t pay you enough to hire team to service em + profit on top, not a biz relationship.</p>
<p>Solo cos/sml teams are a big risk for enterp coz if you disappear it&#39;s a problem.
Some B2B cust.s&#39;ll ask you to have millions in insurance and src code in escrow before they&#39;ll work with you.  Others are more flexible.</p>
<p>Solo shops shdn&#39;t enter the public mkt w/o $500k war chest - hit hard/fast, carve niche &amp; bail out be4 army of losers show up 2 compete.  Focus on hard small probs 2 survive.  You don&#39;t make money writing sw, but reselling the same prod many times.</p>
<p><strong>Notion</strong> is actually the poster child 4 B2C2B (can sell to both): you target a grp of people who have the JOB TITLE that&#39;d use yr prod but bld something that appeals to them on a personal lvl as consumers.  No typical B2B messaging/sales pitches, you lean into community building.(@Rsch Notion+Sigma)
This approach is called <strong>Product Led Growth</strong> (see also <a href="https://www.amity.co/blog/duolingo-figma-notion-and-hubspot-leveraged-the-power-of-community-led-growth">Community</a> Led Gr @rsch </p>
""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Markdown Links", [" notes markdown mermaid"], """<li><a href="https://mermaid.js.org/config/theming.html">Mermaid theme customization</a></li>
<li><a href="https://stackedit.io/app#">Markdown Editor</a></li>
<li><a href="https://imthenachoman.github.io/nGitHubTOC/">TOC Generator</a></li>
</ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Cookie alternatives", [" notes web storage js cookie"], """Includes localStorage and sessionStorage (autoExpires) 
Best used for client-only data.</p>
<pre><code>  localStorage.<span class="hljs-built_in">set</span>Item('value1', <span class="hljs-number">123</span>);
  localStorage.<span class="hljs-built_in">set</span>Item('value2', 'abc');
  localStorage.<span class="hljs-built_in">set</span>Item('<span class="hljs-keyword">state</span>', JSON.stringify({ a:<span class="hljs-number">1</span>, b:<span class="hljs-number">2</span>, c:<span class="hljs-number">3</span> }));
  const <span class="hljs-keyword">state</span> = JSON.parse( localStorage.getItem('<span class="hljs-keyword">state</span>') );
  localStorage.removeItem('<span class="hljs-keyword">state</span>')
  .length: the number of items stored
  .key(N): the name of the Nth key
  .clear(): delete <span class="hljs-literal">all</span> stored items
</code></pre><p>Current browsers(2013) limit total size per storage area to 5MB.
Changing any value raises a storage event in other browser tabs/windows connected to the same domain. Your application can respond accordingly:</p>
<pre><code>  <span class="hljs-built_in">window</span>.addEventListener(<span class="hljs-string">'storage'</span>, s =&gt; {
    <span class="hljs-built_in">console</span>.log(<span class="hljs-string">`item changed: <span class="hljs-subst">${ s.key }</span>`</span>);
    <span class="hljs-built_in">console</span>.log(<span class="hljs-string">`from value  : <span class="hljs-subst">${ s.oldValue }</span>`</span>);
    <span class="hljs-built_in">console</span>.log(<span class="hljs-string">`to new value: <span class="hljs-subst">${ s.newValue }</span>`</span>);
  });
</code></pre><p>(ii) IndexedDB, an in-browser database system:
While localStorage performs all of its methods synchronously, IndexedDB calls them all asynchronously. 
IndexdDB <a href="https://www.w3.org/TR/IndexedDB/">API</a>
Benefits over Web Storage:</p>
<ul>
<li>efficient searches</li>
<li>db, so can store multiple same keys</li>
<li>transactional</li>
<li>no size limits: FireFox asks if exceed 50Mb
create db:<pre><code><span class="hljs-attribute">var request</span> = indexedDB.open(�myDatabase�);
</code></pre>set obj store:<pre><code>const petData = [
  { <span class="hljs-string">id:</span> �<span class="hljs-number">00</span><span class="hljs-number">-01</span>�, <span class="hljs-string">firstname:</span> �Butters�, <span class="hljs-string">age:</span> <span class="hljs-number">2</span>, <span class="hljs-string">type:</span> �dog� },
  { <span class="hljs-string">id:</span> �<span class="hljs-number">00</span><span class="hljs-number">-02</span>�, <span class="hljs-string">firstname:</span> �Sammy�, <span class="hljs-string">age:</span> <span class="hljs-number">2</span>, <span class="hljs-string">type:</span> �dog� }
];
</code></pre>to chng schema:<pre><code> request.onupgradeneeded = <span class="hljs-function"><span class="hljs-keyword">function</span><span class="hljs-params">(event)</span> </span>{
    <span class="hljs-keyword">var</span> db = event.target.result;
    <span class="hljs-keyword">var</span> objectStore = db.createObjectStore(�customers�, {keyPath: �id�});
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">var</span> i <span class="hljs-keyword">in</span> customerData) {
      objectStore.add(customerData[i]); }}
</code></pre></li>
</ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "             Functional JS", [" notes js functional"], """<p><a href="https://github.com/lodash/lodash">loDash</a> <em>25m usrs</em>
<a href="https://lodash.com/">https://lodash.com/</a> 
Lodash makes JavaScript easier by taking the hassle out of working with arrays, numbers, objects, strings, etc.
Lodash�s modular methods are great for:</p>
<ul>
<li>Iterating arrays, objects, &amp; strings</li>
<li>Manipulating &amp; testing values</li>
<li>Creating composite functions</li>
</ul>
<p><a href="https://github.com/ramda/ramda">Ramda</a> <em>.7m usrs</em> 
<a href="https://ramdajs.com/docs/#">docs</a> &amp; repl</p>
<p><a href="https://github.com/immutable-js/immutable-js">Immutable</a>
Immutable.js provides many Persistent Immutable data structures including: List, Stack, Map, OrderedMap, Set, OrderedSet and Record. 
Immutable.js also provides a <a href="https://github.com/immutable-js/immutable-js#lazy-seq">lazy Seq</a>, allowing efficient chaining of collection methods like map and filter without creating intermediate representations. 
Lodash wrapper providing Immutable.JS support: <a href="https://github.com/brianneisler/mudash">MuDash</a></p>
<p><a href="https://github.com/jashkenas/underscore">Underscore</a> <em>2m usrs</em> is a utility-belt library for JavaScript that provides support for the usual functional suspects (each, map, reduce, filter...) without extending any core JavaScript objects.</p>
<p>(all 4 are MIT)</p>
<blockquote>
<blockquote>
<p>Super resource <a href="https://github.com/you-dont-need/You-Dont-Need-Lodash-Underscore">here</a>
(try this 1st) <strong>refered 2 as YDN in this doc</strong>
 (You Don&#39;t Need Fnal JS libs; use native instd)</p>
</blockquote>
</blockquote>
<p>Lodash seems to have HUGE support built in; but 1st try YDN; if stumped often switch.</p>
<pre><code>lodash reduce (same <span class="hljs-keyword">as</span> lifo)
_.reduce([<span class="hljs-number">1</span>, <span class="hljs-number">2</span>], <span class="hljs-function"><span class="hljs-keyword">function</span><span class="hljs-params">(sum, n)</span> <span class="hljs-comment">{
  return sum + n;
}</span>, 0);</span>
<span class="hljs-comment">// =&gt; 3</span>

<span class="hljs-comment">// Native (YDN)</span>
<span class="hljs-keyword">var</span> <span class="hljs-keyword">array</span> = [<span class="hljs-number">0</span>, <span class="hljs-number">1</span>, <span class="hljs-number">2</span>, <span class="hljs-number">3</span>, <span class="hljs-number">4</span>]
<span class="hljs-keyword">var</span> <span class="hljs-keyword">result</span> = <span class="hljs-keyword">array</span>.reduce(<span class="hljs-function"><span class="hljs-keyword">function</span> <span class="hljs-params">(previousValue, currentValue, currentIndex, <span class="hljs-keyword">array</span>)</span> <span class="hljs-comment">{
  return previousValue + currentValue
}</span>)
<span class="hljs-title">console</span>.<span class="hljs-title">log</span><span class="hljs-params">(<span class="hljs-keyword">result</span>)</span>
// <span class="hljs-title">output</span>:</span> <span class="hljs-number">10</span>
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Colors", [" notes color palette scheme brij"], """<span class="hljs-symbol">    fore:</span>Color.Black, <span class="hljs-string">back:</span>sYellow,
<span class="hljs-symbol">    AccentFore:</span>sLtGrn, <span class="hljs-string">AccentBack:</span>sYellow, 
<span class="hljs-symbol">    TitFore:</span>sDkGrn, <span class="hljs-string">TitBack:</span>sDrkYell, <span class="hljs-string">Icn:</span>sBrn))
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Agile and CI/CD", [" notes product release"], """A gd article (SVPG) commending <strong>small, frequent releases</strong> says that if you&#39;re not doing this you&#39;re by def not Agile; the whole point is that if they&#39;re small it&#39;s easy to fix the bugs else (even a 6-mo realease) will yield so many bugs that the next few releases will be spent catching up.""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Mongo Queries", [" notes mongo"], """</code></pre><p><hr>
<a href="https://learn.microsoft.com/en-us/dotnet/api/system.linq.iqueryable?view=net-7.0">IQueryable</a> Provides functionality to evaluate queries against a specific data source wherein the <em>type of the data is not specified</em>.</p>
<p>For more information about how to create your own LINQ provider, see LINQ: <a href="https://learn.microsoft.com/en-us/archive/blogs/mattwar/linq-building-an-iqueryable-provider-part-i">Building an IQueryable Provider</a>.</p>
<p>The non-generic IQueryable exist primarily to <mark>give you a <em>weakly typed</em> entry point</mark> primarily for dynamic query building scenarios.</p>
<pre><code><span class="hljs-keyword">public</span> <span class="hljs-keyword">interface</span> <span class="hljs-title">IQueryProvider</span> {
  <span class="hljs-function">IQueryable <span class="hljs-title">CreateQuery</span>(<span class="hljs-params">Expression expression</span>)</span>;
  IQueryable&lt;TElement&gt; CreateQuery&lt;TElement&gt;(Expression expression);
  <span class="hljs-function"><span class="hljs-keyword">object</span> <span class="hljs-title">Execute</span>(<span class="hljs-params">Expression expression</span>)</span>;
  TResult Execute&lt;TResult&gt;(Expression expression);
}
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Mongo Nested Docs", [" notes mongo"], """<p>Both these DrDobbs <a href="http://www.drdobbs.com/database/getting-started-with-mongodb/240151028">article</a>s use embedded dox; <a href="http://www.drdobbs.com/windows/information-rich-programming-with-f-30/240148372">this</a> one uses a TyProv.</p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Mongo Dynamic/ExpandoObject", [" notes mongo linq"], """    <span class="hljs-keyword">var</span> client = <span class="hljs-keyword">new</span> MongoClient(); 
    <span class="hljs-keyword">var</span> database = client.GetDatabase(<span class="hljs-string">"WorldCities"</span>); 
    <span class="hljs-keyword">var</span> collection = database.GetCollection&lt;BsonDocument&gt;(<span class="hljs-string">"cities"</span>); 
    <span class="hljs-keyword">return</span> collection.AsQueryable().Sample(<span class="hljs-number">1</span>).First().GetValue(<span class="hljs-string">"name"</span>).ToString(); }
</code></pre><p>Or full .Find approach--&gt;</p>
<pre><code>  <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">string</span> <span class="hljs-title">GetName</span>(<span class="hljs-params"></span>)</span>{ 
    <span class="hljs-keyword">var</span> client = <span class="hljs-keyword">new</span> MongoClient(); 
    <span class="hljs-keyword">var</span> database = client.GetDatabase(<span class="hljs-string">"WorldCities"</span>); 
    <span class="hljs-keyword">var</span> collection = database.GetCollection&lt;BsonDocument&gt;(<span class="hljs-string">"cities"</span>); 
    <span class="hljs-keyword">var</span> result = collection.Find(FilterDefinition&lt;BsonDocument&gt;.Empty) 
        .Project(Builders&lt;BsonDocument&gt;.Projection.Include(<span class="hljs-string">"name"</span>).Exclude(<span class="hljs-string">"_id"</span>)).First().ToString(); 
    <span class="hljs-keyword">return</span> result;} 
    <span class="hljs-comment">// { "name" : "les Escaldes" }</span>
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "No POCO with &amp; without LINQ", [" notes mongo linq"], """<span class="hljs-keyword">var</span> client   = <span class="hljs-keyword">new</span> MongoClient(); 
<span class="hljs-comment">//var client = new MongoClient("mongodb://localhost:27017"); </span>
<span class="hljs-keyword">var</span> database = client.GetDatabase(<span class="hljs-string">"movies_app"</span>); 
<span class="hljs-keyword">var</span> databaseNames = <span class="hljs-keyword">await</span> client 
    .ListDatabaseNames() 
    .ToListAsync(); 

<span class="hljs-keyword">foreach</span> (<span class="hljs-keyword">string</span> databaseName <span class="hljs-keyword">in</span> databaseNames){ 
    Console.WriteLine(databaseName);} 
<span class="hljs-keyword">var</span> collectionNames = <span class="hljs-keyword">await</span> database 
    .ListCollectionNames() 
    .ToListAsync(); 
<span class="hljs-keyword">foreach</span> (<span class="hljs-keyword">string</span> collectionName <span class="hljs-keyword">in</span> collectionNames){ 
    Console.WriteLine(collectionName);} 

<span class="hljs-comment">//LINQ </span>
<span class="hljs-comment">//The standard Find method provided by the MongoDB C# Driver works really well and provides a lot of flexibility. </span>
<span class="hljs-comment">//In addition to this, the MongoDB C# Driver includes a LINQ provider that allows you to write LINQ queries like you would for .NET //in-memory collections or when using Entity Framework or Entity Framework Core as your ORM. </span>
<span class="hljs-comment">//To avail of this, all you need to do is call the AsQueryable method on the IMongoCollection instance to get access to the LINQ //functionality. </span>
<span class="hljs-keyword">var</span> movies = moviesCollection 
    .AsQueryable() 
    .Where(m =&gt; m.Year == <span class="hljs-number">1979</span>) 
    .OrderBy(m =&gt; m.Title); 

<span class="hljs-comment">//If you prefer Query Syntax instead of Method Syntax, no problem. </span>
<span class="hljs-keyword">var</span> movies = <span class="hljs-keyword">from</span>  m <span class="hljs-keyword">in</span> moviesCollection.AsQueryable() 
             <span class="hljs-keyword">where</span>   m.Year == <span class="hljs-number">1979</span> 
             <span class="hljs-keyword">orderby</span> m.Title 
             <span class="hljs-keyword">select</span>  m;
</code></pre><p>Note that not every LINQ operation is supported, but the LINQ provider covers all of the essentials.</p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Qry w/o Classes (on BsonDoc)", [" notes mongo linq bsondoc"], """    <span class="hljs-keyword">var</span> db = client.<span class="hljs-type">GetDatabase</span>(<span class="hljs-string">"test"</span>);
    <span class="hljs-keyword">var</span> collection = db.<span class="hljs-type">GetCollection</span>&lt;<span class="hljs-type">BsonDocument</span>&gt;(<span class="hljs-string">"test"</span>); &lt;-- <span class="hljs-literal">this</span> <span class="hljs-keyword">is</span> a problem <span class="hljs-keyword">as</span> my collection 
                                                                 doesn't have a .<span class="hljs-type">Net</span> <span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">to</span> <span class="hljs-title">map</span> <span class="hljs-title">to</span></span>

    <span class="hljs-keyword">return</span> await collection.<span class="hljs-type">AsQueryable</span>()
        .<span class="hljs-type">Where</span>(x =&gt; x.<span class="hljs-type">ChapterName</span> == <span class="hljs-string">"SouthEast Chapter"</span>)  &lt;-- of course <span class="hljs-literal">this</span> fails
        .<span class="hljs-type">Select</span>(x =&gt; x.<span class="hljs-type">Values</span>)
        .<span class="hljs-type">ToListAsync</span>();
</code></pre><p><strong>A1</strong> dont use linq - it will work with regular querying and without a class definition.
<strong>A2</strong> You can access ChapterName via BsonDocument&#39;s indexer. So, Where condition would become: .Where(x =&gt; x[&quot;ChapterName&quot;].AsString == &quot;SouthEast Chapter&quot;)
<strong>A3</strong> You can&#39;t because LINQ doesn&#39;t support dynamic - expando objects.</p>
<p>See Dynamic <a href="https://stackoverflow.com/questions/13119264/dynamic-linq-querying-of-an-expandoobject">LINQ querying of an ExpandoObject</a>?</p>
<p>There is plenty of helpers in MongoDB C# driver, below some simple way to query BsonDocument</p>
<pre><code><span class="hljs-keyword">using</span> System;
<span class="hljs-keyword">using</span> System.Collections.Generic;
<span class="hljs-keyword">using</span> MongoDB.Bson;
<span class="hljs-keyword">using</span> MongoDB.Driver; <span class="hljs-comment">// Important to have .ToList() extensions</span>
<span class="hljs-keyword">using</span> MongoDB.Bson.Serialization;

<span class="hljs-function"><span class="hljs-keyword">static</span> <span class="hljs-keyword">void</span> <span class="hljs-title">Main</span>(<span class="hljs-params"><span class="hljs-keyword">string</span>[] args</span>)</span>{
    <span class="hljs-keyword">var</span> collection = <span class="hljs-keyword">new</span> MongoClient().GetDatabase(<span class="hljs-string">"mq"</span>).GetCollection&lt;BsonDocument&gt;(<span class="hljs-string">"Event3"</span>);
    <span class="hljs-keyword">var</span> bsf = Builders&lt;BsonDocument&gt;.Filter;

    List&lt;FilterDefinition&lt;BsonDocument&gt;&gt; example1 = <span class="hljs-keyword">new</span> List&lt;FilterDefinition&lt;BsonDocument&gt;&gt;();
    example1.Add(bsf.Eq(<span class="hljs-string">"msg"</span>, <span class="hljs-string">"master"</span>));
    example1.Add(bsf.Eq(<span class="hljs-string">"to"</span>, <span class="hljs-string">"server"</span>));
    <span class="hljs-keyword">var</span> result1 = collection.Find(bsf.And(example1)).ToList();

    FilterDefinition&lt;BsonDocument&gt; example2 = bsf.Empty;
    example2 = bsf.And(example2, bsf.Eq(<span class="hljs-string">"msg"</span>, <span class="hljs-string">"master"</span>));
    example2 = bsf.And(example2, bsf.Eq(<span class="hljs-string">"to"</span>, <span class="hljs-string">"server"</span>));
    <span class="hljs-keyword">var</span> result2 = collection.Find(example2).ToList();

    <span class="hljs-comment">// To see how to create json syntax from Filter</span>
    Console.WriteLine(example2.Render(BsonSerializer.SerializerRegistry.GetSerializer&lt;BsonDocument&gt;(), BsonSerializer.SerializerRegistry));
    <span class="hljs-keyword">string</span> example3 = <span class="hljs-string">"{ 'msg' : 'master', 'to' : 'server' }"</span>;
    <span class="hljs-keyword">var</span> result3 = <span class="hljs-keyword">await</span> collection.Find(BsonDocument.Parse(example3)).ToListAsync();

    <span class="hljs-keyword">dynamic</span> example4 = <span class="hljs-keyword">new</span> ExpandoObject();
    example4.msg = <span class="hljs-string">"master"</span>; <span class="hljs-comment">// Works only for equality</span>
    example4.to = <span class="hljs-string">"server"</span>;
    <span class="hljs-keyword">var</span> result4 = collection.Find(<span class="hljs-keyword">new</span> BsonDocument(example4)).ToList();
}
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "             query ExpandoObject with regular LINQ", [" notes mongo linq query"], """(see this <a href="https://stackoverflow.com/questions/18747058/is-it-possible-to-query-list-of-expandoobject">SO</a> post)</p>
<pre><code><span class="hljs-keyword">var</span> generatedItems = <span class="hljs-keyword">new</span> List&lt;<span class="hljs-keyword">object</span>&gt;();
<span class="hljs-keyword">foreach</span> (<span class="hljs-keyword">var</span> item <span class="hljs-keyword">in</span> items){
    <span class="hljs-keyword">var</span> modifiedItem = <span class="hljs-keyword">new</span> List&lt;KeyValuePair&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;&gt;    {
        <span class="hljs-keyword">new</span> KeyValuePair&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;(<span class="hljs-string">"Id"</span>, item.Id),
        <span class="hljs-keyword">new</span> KeyValuePair&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;(<span class="hljs-string">"FileId"</span>, item.FileId),
        <span class="hljs-keyword">new</span> KeyValuePair&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;(<span class="hljs-string">"Notes"</span>, item.Notes)
    };
    modifiedItem.AddRange(item.Fields.Select(field =&gt; <span class="hljs-keyword">new</span> KeyValuePair&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;(field.Key, field.Value)));
    generatedItems.Add(ConvertToExpandoObjects(modifiedItem)); <span class="hljs-comment">// Here I construct object from key/value pairs }</span>
<span class="hljs-keyword">return</span> generatedItems; <span class="hljs-comment">// Is it possible to query this thing?</span>
</code></pre><p><strong>A</strong>: you would be able to query a collection of dynamic objects using the dot notation.</p>
<pre><code><span class="hljs-keyword">var</span> ids = generatedItems.Cast&lt;<span class="hljs-keyword">dynamic</span>&gt;().Select(x =&gt; x.Id);
</code></pre><p>However, keep in mind that there&#39;s no type safety here and, as you stated, IntelliSense is of no use, since you&#39;re using dynamic objects.
If your code depends on whether one of those objects have an optional property (e.g., some have &quot;Title&quot;, others don&#39;t), then it will require a little more manual labor.</p>
<pre><code><span class="hljs-keyword">if</span>((generatedItems <span class="hljs-keyword">as</span> <span class="hljs-type">IDictionary</span>&lt;<span class="hljs-type">String</span>, <span class="hljs-keyword">object</span>&gt;).<span class="hljs-type">ContainsKey</span>(<span class="hljs-string">"Title"</span>)) <span class="hljs-meta">{...}</span>
</code></pre>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Mongo Expando", [" notes mongo linq"], """<pre><code><span class="hljs-keyword">var</span> lst = <span class="hljs-keyword">new</span> <span class="hljs-type">List</span>&lt;<span class="hljs-keyword">dynamic</span>&gt;();   
<span class="hljs-keyword">dynamic</span> exp1 = <span class="hljs-keyword">new</span> <span class="hljs-type">ExpandoObject</span>();
exp1.Name = <span class="hljs-string">"ddd"</span>;
lst.Add(exp1);
<span class="hljs-keyword">dynamic</span> exp2 = <span class="hljs-keyword">new</span> <span class="hljs-type">ExpandoObject</span>();
exp2.Name = <span class="hljs-string">"aaa"</span>;
lst.Add(exp2);
  When I am doing
<span class="hljs-keyword">var</span> query = from t <span class="hljs-keyword">in</span> lst
where t.Name == <span class="hljs-string">"ddd"</span>
select t;
  it works; but when I am <span class="hljs-keyword">using</span> <span class="hljs-keyword">Dynamic</span> Linq Library
<span class="hljs-keyword">var</span> query = lst.AsQueryable().Where(<span class="hljs-string">"Name==@0"</span>, <span class="hljs-string">"ddd"</span>);
</code></pre><p>  ...I am getting a parse exception from dynamic linq library.</p>
<p><strong>A</strong>: ExpandoObject implements IDictionary<string, object>, so you can take advantage of that:</p>
<pre><code>  <span class="hljs-keyword">var</span> query = <span class="hljs-function"><span class="hljs-keyword">from</span> t <span class="hljs-keyword">in</span> lst
  <span class="hljs-title">where</span> (<span class="hljs-params">(IDictionary&lt;<span class="hljs-keyword">string</span>, <span class="hljs-keyword">object</span>&gt;</span>)t)["Name"] </span>== <span class="hljs-string">"ddd"</span>
  <span class="hljs-keyword">select</span> t;
</code></pre><h4 id="expandoref">ExpandoRef</h4>
<p>All the info you cd nd for <a href="https://weblog.west-wind.com/posts/2012/Feb/08/Creating-a-dynamic-extensible-C-Expando-Object">ExpandoObj</a> 
...Although the Expando class supports an indexer, it doesn&#39;t actually implement IDictionary or even IEnumerable. It only provides the indexer and Contains() and GetProperties() methods, that work against the Properties dictionary AND the internal instance.</p>
<h4 id="expando-casting">Expando Casting</h4>
<p>(2018 from CodeProj)
i am using List<ExpandoObject> but if not getting property using linq:</p>
<pre><code><span class="hljs-keyword">var</span> grdfeatchobjlist = (<span class="hljs-built_in">List</span>&lt;ExpandoObject&gt;)grdproductitem.ItemsSource;
<span class="hljs-keyword">var</span> getlist = grdfeatchobjlist.Select(x =&gt; x.GetType().GetProperty(<span class="hljs-string">"batchId"</span>) == Txtbatchcode.Text.ToString());
</code></pre><p><strong>A</strong>:  For a dynamic property name which isn&#39;t known until runtime, cast the ExpandoObject to an IDictionary<string, object>, and use the indexer:</p>
<pre><code>var getlist = grdfeatchobjlist.Select(<span class="hljs-function"><span class="hljs-params">(IDictionary&lt;<span class="hljs-built_in">string</span>, object&gt; x)</span> =&gt;</span> x[<span class="hljs-string">"batchId"</span>] == Txtbatchcode.Text);
</code></pre><h4 id="other-links">Other links</h4>
<ul>
<li>CodeGuru <a href="https://www.codeguru.com/csharp/using-dynamicobject-and-expandoobject/">using</a> dynamic w/expandoOb</li>
<li>Accessing Dynamic obs in <a href="https://stackoverflow.com/questions/36539639/accessing-dynamic-objects-in-f">F#</a></li>
<li><a href="https://stackoverflow.com/questions/21290133/how-do-i-use-linq-to-query-nested-dynamic-bsondocuments">This</a> Qn has a 2015 way to flatten nested docs &amp; qry on a subDoc (using Linq)</li>
<li>Mongo Jira Bug (fixed, see <a href="https://www.codeguru.com/csharp/using-dynamicobject-and-expandoobject">link</a>)
Given a Collection<BsonDocument>, LINQ3 queries using doc[&quot;FieldName&quot;] syntax fail with the following exception:<pre><code>Unhandled Exception: MongoDB<span class="hljs-selector-class">.Driver</span><span class="hljs-selector-class">.Linq</span><span class="hljs-selector-class">.Linq3Implementation</span><span class="hljs-selector-class">.ExpressionNotSupportedException</span>: 
Expression not supported: doc.get_Item(<span class="hljs-string">"FieldName"</span>).
The same query works <span class="hljs-keyword">in</span> LINQ2 using doc[<span class="hljs-string">"FieldName"</span>] or <span class="hljs-keyword">in</span> LINQ3 with <span class="hljs-selector-tag">a</span> POCO using doc<span class="hljs-selector-class">.FieldName</span>.
</code></pre></li>
</ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Indie music submissions (Founder Story)", [" notes b2c marketing"], """<li>Jason blt music blog - ran it for 7 yrs - recd 300 pitches a day from artists/lbls/publicists looking to have their music featured</li>
<li>Spent 10 mos blding SubmitHub: ...my main focus was on solving my own problem. I hadn&#39;t given much consideration to the thousands of other music blogs who might want to use it. I suppose in that sense I was lucky: I was already &quot;part of the problem&quot;, and therefore had a good understanding of what was needed to &quot;solve&quot; it...</li>
<li>Over the course of my ~7 years running a blog, I had learned a few things about what folks were looking for when they sent music to blogs:<pre><code>  <span class="hljs-number">1.</span>  a quick response
  <span class="hljs-number">2.</span>  a decision <span class="hljs-keyword">about</span> whether <span class="hljs-keyword">it</span> was worthy <span class="hljs-keyword">of</span> being blogged
  <span class="hljs-number">3.</span> <span class="hljs-keyword">and</span>, <span class="hljs-keyword">if</span> <span class="hljs-keyword">not</span>, <span class="hljs-keyword">some</span> detail <span class="hljs-keyword">as</span> <span class="hljs-keyword">to</span> what needed improvement
</code></pre>Therein lied the business model: by paying a small amount ($1),  <a href="http://www.submithub.com/">SubmitHub</a>  would be able to guarantee that all three of the aforementioned boxes were checked. If not, the user would receive a refund.<ul>
<li><strong>Advice to aspiring hackers</strong>: Launch and iterate! Don&#39;t delay! I&#39;ve seen a number of startups try to build the perfect product before launching, rather than putting something out there and adapting to the needs of its users. My experience has been that building a platform around real-life, participating users is much more valuable than trying to guess what they&#39;ll need before you&#39;ve even put the product out there.</li>
<li>Payments powered by <a href="https://www.braintreepayments.com">BrainTree</a> min<h3 id="hn-comments">HN comments</h3>
<strong><em>theunixbeard</em></strong>
1.) Build an audience (~6 years)
2.) Build your business (a few months...)
That&#39;s the winning formula. I wrote about this at length regarding Ryan Hoover &amp; Product <a href="https://medium.com/@theunixbeard/product-hunt-s-rise-d49249a1a2c0">Hunt</a>
The title was &quot;Product Hunt&#39;s Rise: An overnight success 1,834 days in the making&quot;... Same exact story here except growing Indie shuffle took closer to 2,190 days!
[<br><strong><em>paulsutter</em></strong>
Or maybe the lesson is to <mark>develop a following first before developing a product</mark>. The music blog didn&#39;t happen by random chance, and his overall approach seems better than developing a product and hoping for a following.</li>
</ul>
</li>
</ul>
<p><strong><em>gloverkcn</em></strong>
If you look at any marketing funnel, the first hurdle is awareness. <mark>Getting people aware of a saas product is very difficult. Getting them to try it is even harder.</mark>
Having the blog provided both a vehicle to get the target market aware, and the credibility that the product is worth trying. It&#39;s really smart to be an active member of a community, and then provide services to the community. It&#39;s also very difficult, and takes a lot of effort. I think the post you responded to is someone who understands the amount of work you had to put into your blog to make it successful.
I don&#39;t think this is a negative, but a really good take away for new entrepreneurs.</p>
<ul>
<li>How will you market and sell your product? The &quot;If you build it, they will come&quot; tactic doesn&#39;t work.</li>
<li>How do you know it&#39;s a problem people want solved?</li>
<li>How do you know your solution adequately solves the problem ?
Your approach answered all these questions and you got to work on something you&#39;re passionate about.</li>
</ul>
<p><strong><em>blazespin</em></strong>
He missed the advice of <mark>launch and iterate below the radar with a very narrow group of customers</mark>.
For example: on the app store you can launch your app/game in countries <mark>other</mark> than the US (australia, canada). Iterate, and once you&#39;re satisfied, than launch in the US.
Launching and iterate in the fully public eye of your customer base is a risky thing to do for your general brand value.</p>
<p><strong><em>trymas</em></strong> 
It reminds me of a story how Red Digital Cinema Camera Company was born.
Few years ago I&#39;ve found a motivational article that everyone can make a successful business out of their garage even in the field of <mark>high end technology.</mark> I googled RED camera&#39;s founders name - multi-billionaire founder of Oakley. Probably his garage looked like a high tech version of Jay Leno&#39;s car garage and not like the Jobs&#39; and Wozniak&#39;s garage.
Dude have been building his blog business/image/trademark for many years and successfully capitalised on that. Kudos to him.</p>""", "");


          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Sales", [" notes sales saas"], """<p><strong><em>bushido</em></strong>
Both can be important and it really comes down to who your customer is.
For B2B (SME+) - Absolutely invest in Sales. Worth mentioning that it isn&#39;t too hard hiring seasoned sales professionals, with existing relationships who are trying to find their next career move etc. They&#39;ll often agree to a higher commission payout in-lieu of a base salary. This doubles up as a good way to get feedback from the market.
For B2C or smaller B2B - Definitely invest in marketing and customer experience if you would like the main driver behind your business to be product-led growth or some form of a self-signup/self-onboarding.
...
On sales reps: As others have mentioned the biggest factor here will be how long it takes to close a deal. If you have quick close cycles (typical in the small to mid-market), a higher commission component or commission only is possible.</p>
<p>Typically, I&#39;ve seen commissions in B2B to be about <mark>7-10%</mark> of Annual Contract Value (ACV) for the first year. Mind you this is highly generalized, based on my experience.
Most sales compensation plans aim for sales reps to earn 1x base as commissions if they meet target. So a base of $60K, would result in $120K in income if they performed.
Based on this you could try finding reps on <mark>14-20%</mark> ACV on a commission only basis, paid out on paid invoices.
To be candid, I wouldn&#39;t try doing commission-only positions for my own ventures. That said it&#39;s worth a try if there are constraints that make it hard to pay a base.
[<br><strong><em>acruns</em></strong>
Getting part-time help in sales is going to be hard. It will depend on how long your sales cycle is too.
Sales reps will happily work on commission only if they see a huge market for your product. Which might be difficult to show with a new product.
The commission rate is negotiable at the hiring point. If they are great at sales and know there is a big market they will want a lower base with a higher commission. You should also set a <mark>commission cap</mark> at some point as your variable costs increase your profit will drop and you could end up at a point where the sales team is making more than the company.</p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "SEO", [" seo marketing saas"], """<p>Just think about how you find a new service, chances are you googled it and tried the 2-3 results.
Now as for the question - is it necessary? The answer is yes. Because if you don&#39;t do it your competitor will and as the joke goes <strong><em>&quot;The best place to hide a dead body is page 2 of Google&quot;.</em></strong></p>
<blockquote>
<p>Are there really any &quot;tricks&quot; that work?</p>
</blockquote>
<p>I&#39;m no SEO expert and so I don&#39;t care for meta tags, keywords. Title and page description are still important I think. I believe the most relevant things are the <strong>time</strong> user a spends on your page and <strong>social signals</strong> (shares, etc) and unfortunately backlinks from high authority pages (this is the worst part of SEO).</p>
<p>The good news is that you don&#39;t have to do anything sneaky to do SEO anymore. Make an excellent page on which a user spends a lot of time (so good that he actually bookmarks or shares it) and it <strong>starts ranking</strong>. For all its evilness Google is still doing something right here.</p>
<p><strong><em>jchook</em></strong>
Keyword <strong>density</strong> (just the right amount) and total <strong>word count</strong> seem to have an effect and I�ve seen targeted <strong><em>landers</em></strong> work very well for specific search phrases.</p>
<p><strong>Backlinks</strong> will probably always be relevant to rankings as they were the original bedrock principle behind PageRank. If you get prominent <strong>blogs to link</strong> to you, that can help a lot. Inversely, use <strong><em>rel=nofollow</em></strong> on anchors to avoid seeping relevance to other pages.</p>
<p>Ever since Mobilegeddon your site MUST be <strong>mobile friendly</strong> or you will get penalized. Also other UI stuff matters (E.g. don�t put ads above the fold)</p>
<p><strong><em>aledalgrande</em></strong>
Also performance - make sure you use this <a href="https://developers.google.com/speed/pagespeed/insights/">tool</a> (pagespeed insights)</p>
<p><strong>_idm<em>guru</em></strong>
As a solo founder for 10+ years, what I can say is that all &quot;rules&quot; in business are &quot;rules of thumb&quot;... Not laws... I host a podcast called &quot;Open Source Underdogs&quot;. Lots of good advice there for all founders... Even if you&#39;re not working on open source. But there are plenty more. You need outside ideas... Just seek them out....
Also remember that VC&#39;s give tons of bad advice to founders.</p>
<p><strong><em>galacticdessert</em></strong>
I managed to find playable early episodes <a href="https://www.listennotes.com/podcasts/open-source-underdogs-open-source-underdogs-n0_Zq8s4LbE/">here</a></p>
<p><strong><em>sahillavingia</em></strong>
Solo founder of Gumroad here. Highly recommended. It forced me to learn a lot more about every aspect of building a business than I would have otherwise.
I&#39;m also a fan of investing in <a href="https://shl.vc/">solo founders</a></p>
<p><strong><em>xenospn</em></strong>
Another solo founder here - I copied the Notion fund memo you posted on Twitter and used it as a template to pitch VCs, so thank you for that!
<strong><em>eruci</em></strong></p>
<p>Just like you, I quit my day job in my early 30s, and have not looked back since. Have founded a dozen companies in the meantime and am currently having the best financial year of my 15 year solo-founder career.</p>
<p>My advice is, hang in there. If you like what you are doing persist and adapt. My best product thus far is an API I built to support my original business plan. The original product I tried to build is long dead.</p>
<p><strong><em>pknerd</em></strong>
Dozens of companies or sites? Even sites, why did you make so many Ventures? We&#39;re they affiliate sites?</p>
<p><strong><em>eruci</em></strong>
I originally started  <a href="https://foodpages.ca/">https://foodpages.ca</a>  and dinehere.us then built  <a href="https://geocode.ca/">https://geocode.ca</a>  to provide local search functionality, then expanded worldwide with geocode.xyz and 3geonames.org, also got into collaborative fiction writing with fictionpad.com and price comparison engines with comparify.xyz &amp; askvini.com (which I sold on <mark>flippa</mark>) and real estate aggregator sites (shitet.net and landhub.ca, landhub.us).</p>
<p>Currently geocode.xyz and geocoder.ca are my most profitable businesse</p>
<p><strong><em>bitcoinmoney</em></strong>
Was it worth it financially? Like are you earning loads now?</p>
<p><strong><em>eruci</em></strong>
Totally worth it. I&#39;m currently earning around four times a senior software engineer salary, and I&#39;ve got plenty of free time. Overall my average earnings over the whole 15 year period have been double what I&#39;d have been getting in a day job.</p>
<p><strong><em>tmilard</em></strong>
...I am always quite surprised that many people think &quot;yea, you always can build a software in a few weeks. If not bah, not good&#39;.</p>
<p>I think SOME softwares requires month if not years of building. Because there are difficult technically. Those complicated softwares can be a game changer in the field, because well, the technical entry is so hard. So let&#39;s see more those softwares like perhaps future BIG success...</p>
<p><strong><em>immy</em></strong>
Props on pushing your edge with the post. Building or tapping an existing community of early adopters is an enviable position to be in for a solo founder. Very unsticking. The feedback loop provides much desired certainty. Whether Twitter, Discord/Slack, a forum, whatever.</p>
<p><strong><em>hermitcrab</em></strong>
I&#39;ve been working as a solo indie developer since 2005...one of the keys, from my experience, is early feedback. Start showing your product to people as soon as you have something that might be useful to someone. No matter how imperfect it is. Do not wait until it is polished. I wrote about that <a href="https://successfulsoftware.net/2007/08/07/if-you-arent-embarrassed-by-v10-you-didnt-release-it-early-enough/">here</a></p>
<p><strong><em>earthtobishop</em></strong>
This is by far the best guide for solo <a href="https://blog.gettamboo.com/the-epic-guide-to-bootstrapping-a-saas-startup-from-scratch-by-yourself-part-1-4d834e1df8c1?gi=2c392f6628ff">founders</a></p>
<p><strong><em>mlacks</em></strong>
<a href="https://github.audio/">github.audio</a>  is a game changer. one thing I find hard about lo-fi channels is the sheer amount of visual/ mental noise to break through in order to get the video/ station up and running on various platforms.</p>
<p><strong><em>xivzgrev</em></strong>
Why do you need VC funding? Plenty of people have bootstrapped businesses with no outside funding. Don�t ask VCs to pay your paycheck - ask <mark>customers</mark> to. Make something that�s worth paying for.</p>
<p><strong><em>jv22222</em></strong>
If anyone is feeling lonely as an indie founder and looking for an indie founder Slack community where you can reach out and bounce ideas of other founders in real time you can join the Nugget Slack community <a href="https://nugget.one/join">here</a></p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Product Demos", [" notes saas product demo"], """Instead, <strong>set up a simple use case</strong>.  Say <strong><em>�here�s the problem I�m going to solve for you that I know you have�</em></strong> � BOOM � and then I�m totally captured for the next 30 minutes. 
Try it. The first five minutes is the most important with someone like me. Don�t waste it.</p>""", "");


          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "             UI/UX in Ent S/w", [" notes product ui b2b"], """<p>&#39;Real Ent Software Don�t Need No Stinkin� <a href="https://www.saastr.com/real-ent-software-dont-need-no-stinkin-uiux/">UI/UX</a>, Jason Lemkin
...Just because you�ve sold a few seats to F500 companies doesn�t mean you have any idea how they really use enterprise software....I have installed SAP myself...spent over 4 hours trying to understand how to manage documents with Documentum...you, the end user, <strong>aren�t the customer</strong> for most true enterprise software, or anything like the customer.  You are just a user, a data-enterer.  The customer is the VP in the enterprise consuming the data, and the only UI/UX that really matters is the VP�s report...(As VP) once we crossed $20m in ARR, it became about the <strong>Executive Dashboard</strong>.
So my learning is end-user UI/UX is critical for apps that need to be <strong>directly adopted</strong> by the end user � collaboration tools in particular. Our ease of use was critical to our adoption at EchoSign. But know thy enterprise market. State-of-the-art UI/UX is a great thing. But if end use is mandated � the end users have no choice � <strong>the only UI/UX that matters is the one the boss sees</strong>.</p>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Making LLMs work for you", [" notes ai llms"], """<li>LLaMA (Meta Rsch) released Feb 23: 1st openly avail model thats (i) actually good (ii) can be run locally</li>
<li>The LLaMA model is a 7.16GB bin file (just a giant matrix)</li>
<li>Contains a CLI version</li>
<li>You can train yr own models on top of Llama2</li>
<li>OpenAI Bing has ChatGPT 3.5-turbo &amp; GPT-4 (uses Claude 2 by Anthropic Bard)</li>
<li>Claude 2 came out 2 months ago - relatively gd - currently free, can support larger docs</li>
<li>GPT-4 is $20/mo or API, only free way 2 use is via Bing</li>
<li>Google has Bard &amp; Palm2 &#39;not in the top league&#39;</li>
<li>Cutoff dates: Sep 21 for OpenAI
However, Bing/Bard can look up via srch.  One reason for cutoffs is that &#39;there are potential adversarial attacks against these models, where you might actually lay traps for them on the public internet&#39;.  Claude, Palm2 poss trained on more recent data (plus Bing/Bard can run srchs so more curr)</li>
<li>Ctxt Len: 4k tokens ChatGPT, 8k (6k wds) for GPT4, 100k for Claude2</li>
<li>Lots of people are trying to figure out how to teach lang models to identify <strong>which qns are meant to be based on facts and not have stuff made up</strong>, but that&#39;s proving remarkably difficult.</li>
<li>All these models have been trained on partly copyrighted material coz &#39;pub domain data&#39;s not enuff to produce a gd enuff model&#39; <pre><code>  -<span class="ruby"> <span class="hljs-number">3.3</span>TB Common Crawl
</span>  -<span class="ruby"> <span class="hljs-number">328</span>GB GitHub
</span>  -<span class="ruby"> <span class="hljs-number">83</span>GB Wikip
</span>  -<span class="ruby"> <span class="hljs-number">85</span>GB Books (Gutenberg + Books3 from The Pile (<span class="hljs-number">190</span>k pirated <span class="hljs-symbol">eBks:</span> incl HarryPotter/Steven King/Sarah Silverman)
</span>  -<span class="ruby"> <span class="hljs-number">92</span>GB ArXiv
</span>  -<span class="ruby"> <span class="hljs-number">78</span>GB StackExch</span>
</code></pre></li>
<li>After Silverman sued the model owners stopped saying what the models have been trained on</li>
<li>Simon finds LLMs exc for Brainstorming (20 ideas in 5 sec)</li>
<li><p>Simon &quot;No DSL is intimidating to me any more coz the model knows the syntax&quot;</p>
<h3 id="react-pattern-for-llms">ReACT pattern for LLMs</h3>
<p>Based on <a href="https://react-lm.github.io/">paper</a>, simon&#39;s py <a href="https://til.simonwillison.net/llms/python-react-pattern">impl</a> based on the RAG pattern �Retrieval Augmented Generation� (ie using Wikip srch etc.)
Take the user�s qn, srch for relevant docs using a regular search engine or a fancy vector search engine, pull back as much relevant info as will fit into that 4k or 8k token limit, add the user�s qn at the bottom and ask the language model to reply </p>
<h3 id="embeddings">Embeddings</h3>
<p>This is a language model adjacent technology�a lot of the language models can do this as well.
It lets you take text�a word, a sentence, a paragraph or a whole blog entry�pass that into the model and get back an array of 1,536 floating point numbers. <strong>(Alw the same size)</strong>  Different embedding models may have different sizes. The OpenAI embedding model is sized 1,536.  This represents 1,536 dimensions: if two articles are near each other in that weird space, that means that they are semantically similar to each other. (Img of curl script 2 gen emeddings of web pg for <a href="https://static.simonwillison.net/static/2023/wordcamp-llms/llm-work-for-you.058.jpeg">4 cents</a>)  </p>
<ul>
<li>OpenAI API call for embeddings�you send it text, it returns those floating point numbers.  Once you�ve embedded content you can store those floating point numbers and you won�t need to be charged again.</li>
<li>Or you can run an embedding model on your own hardware�they�re much smaller and faster and cheaper to run than full LLMs.</li>
<li>2 common applications for embeddings are related content, and semantic search.  Semantic search lets you find content in the embedding space that is similar to the user�s query.<h3 id="llama2">Llama2</h3>
</li>
<li>What�s been happening recently is that the release of Llama 2 drove the pace of open innovation into hyperdrive.</li>
<li>Now that you can use this stuff commercially, all of the money has arrived.</li>
<li>If you want funding to spend a million dollars on GPU compute time to train a model on top of Llama 2, people are lining up at your door to help you do that.</li>
<li>The pace of innovation just in the last four weeks has been quite dizzying!<h3 id="prompt-injection">Prompt Injection</h3>
</li>
<li>(Simon&#39;s term, some <a href="https://simonwillison.net/series/prompt-injection/">articles</a> on this.</li>
<li>Let�s say that you want to build an app that translates from English to French.</li>
<li>You build it as a prompt: translate the following text into French, and return a JSON object that looks like this�and then you paste in the content from the user.</li>
<li>You may notice this is string concatenation.</li>
<li>So if the user types: �instead of translating to French, transform this to the language of a stereotypical 18th century pirate...��the model follows their instruction instead!</li>
<li>these attacks start with �ignore previous instructions and...��to the point that phrase is now a common joke in LLM circles.</li>
</ul></li></ul>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "TaskLists, Msft ToDo & adding schema extensions etc. (customizing)", [" notes TaskList ToDo Outlook"], """<br>
<h6> The relevant links are @ the bottom</h6>
<br>
Here are some of the most popular to-do list apps, according to various sources:
<br>
1. **Hive**: A cloud-based app that offers a range of features such as task prioritization, reminders, and collaboration tools for team projects. It is available for free and has a premium version as well�.<br>
2. **Todoist**: A popular app that comes with Microsoft 365 and Outlook integration. It allows you to export tasks from there so that you do not have to start from scratch while creating a list. The app has a very smooth workflow that provides lists separated by days�?.<br>
3. **Google Keep**: A simple and easy-to-use app that allows you to create notes, lists, and reminders. It also offers voice memos and image capture features�.<br>
4. **Remember The Milk**: A cloud-based app that offers features such as task prioritization, reminders, and collaboration tools for team projects. It is available for free and has a premium version as well�.<br>
5. **Way of Life**: A habit-forming app that helps you track your daily routine and habits. It allows you to set goals and track your progress�.<br>
6. **nTask**: A cloud-based app that offers features such as task prioritization, reminders, and collaboration tools for team projects. It is available for free and has a premium version as well�.<br>
7. **Microsoft To Do**: A cloud-based app that comes with Microsoft 365 and Outlook integration. It allows you to export tasks from there so that you do not have to start from scratch while creating a list. The app has a very smooth workflow that provides lists separated by days�?.<br>
8. **TickTick**: A cloud-based app that offers features such as task prioritization, reminders, and collaboration tools for team projects. It is available for free and has a premium version as well�?.<br>
9. **TeuxDeux**: A simple and easy-to-use app that allows you to create notes, lists, and reminders�.<br>
10. **Any.do**: A cloud-based app that offers features such as task prioritization, reminders, and collaboration tools for team projects. It is available for free and has a premium version as well�.
<br>
Please note that the popularity of these apps may vary depending on the source consulted.<br>

Source: Conversation with Bing, 10/18/2023<br>
(1) Top 16 To-Do List Apps To Stay On Track in 2023 | Hive. https://hive.com/blog/best-to-do-list-apps/.<br>
(2) undefined. https://clickup.com/blog/to-do-list-app/.<br>
(3) undefined. https://techengage.com/best-to-do-list-apps/.<br>
(4) 8 best to do list apps of 2023 | Zapier. https://zapier.com/blog/best-todo-list-apps/.<br>
(5) . https://bing.com/search?q=top+10+to-do+apps+by+popularity.<br>
(6) Best todo list app of 2023 | TechRadar. https://www.techradar.com/best/best-todo-list-apps.<br>
(7) The Best To-Do List Apps for 2023 | PCMag. https://www.pcmag.com/picks/the-best-to-do-list-apps.<br>
(8) undefined. https://collegeinfogeek.com/best-to-do-list-app/.<br>

<br><br>
Here are some articles that can help you build an Outlook add-in app:
<br>
4. **Outlook add-ins overview - Office Add-ins | Microsoft Learn**: This article provides an overview of Outlook add-ins and offers resources to get started building them, including a quick start guide and tutorial?.<br>
2. **Outlook add-in design - Office Add-ins | Microsoft Learn**: This article provides high-level guidelines for designing and building a compelling add-in that brings the best of your app right into Outlook�.<br>
3. **How To Create An Add-in In Outlook Using ASP.NET - C# Corner**: This article explains how to create a basic Outlook Addin using ASP.NET, and how to locate and run the add-ins in the web and desktop versions of Outlook�.<br>
1. **Build your first Outlook add-in - Office Add-ins | Microsoft Learn**: This article provides a step-by-step guide to building an Outlook task pane add-in that displays at least one property of a selected message. It also explains how to create the add-in using the Yeoman generator for Office Add-ins or Visual Studio�.<br>
I hope you find these resources helpful!



Source: Conversation with Bing, 10/18/2023<br>
(1) Build your first Outlook add-in - Office Add-ins | Microsoft Learn. https://learn.microsoft.com/en-us/office/dev/add-ins/quickstarts/outlook-quickstart.<br>
(2) Outlook add-in design - Office Add-ins | Microsoft Learn. https://learn.microsoft.com/en-us/office/dev/add-ins/outlook/outlook-addin-design.<br>
(3) How To Create An Add-in In Outlook Using ASP.NET - C# Corner. https://www.c-sharpcorner.com/article/how-to-create-an-add-in-in-outlook-using-asp-net/.<br>
(4) Outlook add-ins overview - Office Add-ins | Microsoft Learn. https://learn.microsoft.com/en-us/office/dev/add-ins/outlook/outlook-add-ins-overview.
<br>

How To Use Tasks in Microsoft Outlook More <a href='https://web.archive.org/web/20130805212604/http://blogs.msdn.com/b/jmeier/archive/2013/05/14/how-to-use-tasks-in-microsoft-outlook-more-effectively.aspx
'>Effectively</a> (adds a new col + groupsBy that col)
<br>
<a href='https://www.outlook-tips.net/tips/custom-priority-field-in-outlook-tasks/'>Custom</a> Priority field in Microsoft Outlook Tasks: another resource for above but incomplete (gives up)
<br>
2023: To Do API <a href='https://learn.microsoft.com/en-us/graph/todo-concept-overview'>overview</a>
<br>
2020: To Do Graph <a href='https://devblogs.microsoft.com/microsoft365dev/introducing-the-new-microsoft-graph-to-do-api/'>api</a>
<br>
todoTask <a href='https://learn.microsoft.com/en-us/graph/api/resources/todotask?view=graph-rest-1.0&source=recommendations'>
resource</a> type
<br>
For more information about Microsoft Graph extensibility including limits for open extensions, see Add custom <a href='https://learn.microsoft.com/en-us/graph/extensibility-overview'>properties</a> to resources using extensions and Add custom <a href='https://learn.microsoft.com/en-us/graph/extensibility-open-users'>data</a> to users using open extensions.
<br>
todoTask + todoTaskList nd Open Exts, see <a href='https://learn.microsoft.com/en-us/graph/extensibility-overview?tabs=csharp#comparison-of-extension-types'>this</a> table
<br>""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "Webhooks SaaS options", [" notes webhooks Agents"], """* Build a serverless workflow
	Create an event-driven workflow from a series of functions using Durable Functions.
  e.g. trigger -> fn -> update CosmosDb

Related: MailHog
MailHog is an email testing tool that makes it super easy to install and configure a local email server. MailHog sets up a fake SMTP server. 

**_Note: All of the below have HN threads for ref._**

[SVIX](https://www.svix.com/) OSS Webhooks as a Service
SVIX REST API (or libs) <- api call:
```
var svix = new SvixClient("AUTH_TOKEN", new SvixOptions("https://api.svix.com"));
await svix.Message.CreateAsync("app_Xzx8bQeOB1D1XEYmAJaRGoj0", new MessageIn(
    eventType: "invoice.paid",
    payload: new {
        type: "invoice.paid",
        id = "invoice_WF7WtCLFFtd8ubcTgboSFNql",
        status = "paid",
        attempt = 2
    },
    eventId: "evt_Wqb1k73rXprtTm7Qdlr38G"
));
);
```
In order to send to a specific URL, we need to add endpoints
```
endpointOut = await svix.Endpoint.CreateAsync(new EndpointIn(
    url: "https://api.example.com/svix-webhooks/",
    version: 1,
    description: "My main endpoint"
));
```
Svix comes with an application portal for your users that you can use out of the box. Your users can then use it to add endpoints, debug delivery, as well as inspect and replay past webhooks.

[Zapier](https://help.zapier.com/hc/en-us/articles/8496288188429-Set-up-your-Zap-trigger)
Basically wrkflw is triggered on popular WWW apps
You can set up a Zap to send a direct message in Slack to yourself every time you receive a new email in Gmail. In this Zap, the trigger is the new email in Gmail.

[Trigger](https://trigger.dev/) OSS Background Jobs framework for TypeScript

[Automatisch](https://automatisch.io/docs) OSS Zapier alternative. Build workflow automation without spending time and money.  Allows you to store your data on your own servers.
Custom request -> Makes a custom HTTP request by providing raw details.
SMTP -> Send an email
Catch raw webhook -> Triggers when the webhook receives a request.
""", "");

          TreeDataItm((gfxGetUNID "gfxItm"), "devNotes", "MongoDB to keep its hands off application building", [" notes mongo SaaS ISVs"], """"But our fundamental kind of organic development still is, by and large, horizontal, and <mark>we use specialists, ISPs and partners and domain experts</mark>," he said.

The strategy of MongoDB and other more modern database vendors � both NoSQL and so-called NewSQL, the group of RDBMS with distributed back ends � could not be more different from the one that defines the world's largest database vendor: Oracle. From its foundation in the late 1970s until the early 2000s, Oracle had been primarily a database company, with a number of software vendors building on its RDBMS. But from the turn of the century, it went on an application acquisition spree, splashing out billions of dollars on <mark>CRM vendor Siebel Systems<mark> and HR system <mark>PeopleSoft</mark>, through which it acquired ERP technology from <mark>JD Edwards</mark>. The strategy extended to the recent $28.3 billion acquisition of electronic health records vendor <mark>Cerner</mark>, which Oracle says will benefit from using its database and cloud technologies.

While Oracle's strategy with its bag full of business applications has been to integrate them with its databases, and more recently, its cloud services, arch-rival in the application market, SAP, has gone in the opposite direction.

Legacy SAP applications, including R/3 and Business Warehouse, were developed to run on third-party databases, including the Oracle Database, IBM Db2 and Microsoft SQL Server [PDF].

But the strategy shifted when SAP created its own in-memory database, HANA, around 2010, and <mark>built the most recent generation of its ERP application, S/4HANA, on the platform</mark>.

More recent market entrants, such as HR and finance SaaS vendor Workday, have built their applications on their own database. But they will be in the minority, reckons MongoDB CPO Azam.

"The software industry is orders of magnitude larger than it was back when that was the case. That's not to say there aren't going to be verticalized packaged apps � Oracle has the cloud versions of their apps. But if you look at where the spend is, the vast majority of software being created is not just going to be packaged software. It is customers creating their own software to run their own business better," he said.

For <mark>packaged applications</mark>, MongoDB works with <mark>ISVs building SaaS</mark>, rather than build its own. To that end, a banking-as-a-service platform has built <mark>Temenos Transact</mark> on MongoDB, while Salesforce Marketing Cloud's analytics solution is powered by MongoDB. Icon Solutions' <mark>Icon Payments Blueprint</mark> platform and Inovaare's <mark>compliance automation solutions for healthcare</mark> are both also built on MongoDB, for example.

James Governor, co-founder of developer-focused analyst **Redmonk**, said it was true that more businesses were likely to build applications in-house, where there might be some competitive advantage. "People say enterprises want to become software companies. I don't think they do, but they do need to be able to take advantage of software. It doesn't look like buying packaged applications, certainly in the traditional sense, is the preferred model," he said.

<mark>Where customers need packaged software, they might be better served by SaaS vendors rather than a database company, he said.</mark>

But the temptation would always be there to get a slice of the action in the remainder of the software stack, Governor said.

"There was a time when <mark>Oracle only had one product</mark>, so who knows what will happen? The pendulum swinging back a bit. If you've got nine out of the 10 top automotive companies building telemetry-based applications on your platform, then there is a tendency to say, let's lock that in a bit and do a better job of serving them,� he said.

MongoDB's total revenue was $1.28 billion for the full year fiscal 2023, up 47 percent on the previous year. Its losses from operations were $346.7 million for the same period. Financially, it is tiny compared to Oracle, which boasts nearly $50 billion in annual revenue. But MongoDB's claim to be the developer database of choice is not without justification: this year's Stack Overflow survey pegged it as fourth choice � and the highest NoSQL vendor � among professional developers, 26 percent of whom said they used the platform.

"They've clearly got enough on their plate with continuing to build that horizontal functionality," Governor said.

However, it was is the nature of the tech industry to see companies appoint a new CEO to instigate a sudden change in strategy, he said.
""", "")]

    let appendAble1 = 
        [ TreeDataItm((gfxGetUNID "gfxItm"), "recM2S", "TimeLine", [], """
                <section>
        		<div id="recM2S">
                    <img style="-webkit-user-select: none;margin: auto;cursor: zoom-in;" src="img/m2s_Snapshot.png" width="500">
                </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "recOther", "Rec", [], """
                <section>
        		<div id="recOther">

<p>
<span class='mTitle'>Anil Agarval Venture Finance</span> -><br>
<img style="-webkit-user-select: none;margin: auto;cursor: zoom-in;" src="https://assets.amuniversal.com/7dbf84506d5101301d7a001dd8b71c47" width="500">
<p>
<hr>
<p>
<span id="zero">
    <img width="600" src="data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAA60AAAE7CAMAAAAB25eaAAADAFBMVEX///8AAADm5ubk5OQsLCww
MDA0NDQ4ODhCQkIpKSkkJCQ/Pz88PDwdHR0hISFRUVEMDAxGRkbOzs5YWFjb29smJibY2NjV1dVO
Tk7h4eEQEBDf399cXFzS0tIUFBNVVVUaGhrLy8tISEjd3d1LS0vIyMgXFxfFxcVgYGBjY2P2063A
wMBqamqTqVR2dnZtbW1wcHAJCQi0tLT9/f5zc3OxsbFlZWWsrKxKSkpnZ2fCwsKRkZGUlJShoaGn
p6eOjo6kpKR6enqJiYm9vb27u7u5ubm2trZ9fX2CgoKurq6pqamenp6WlpaampqLi4ucnJw6AACY
mJj/25CAf3+EhITq6uq2//+Ghob8/PwAAGa4uLjb//+SqFL///0AADr306v00an3+Un//7aUqlSQ
2/+TqlKWrFf//9uYrVkAOpBmtv+UqFju7u74+Pe2ZgBmAADbkDr40646kNsXGgny8vKQOgD/tmYA
Zrb/3Lb6/FAdIAr09kf117H82rKWrVOcsVwQEgWMn1Lmy6eRpVRDTCU7RCD+/vnu0q361q1xgEIh
JxApLhA0PBz+37h3h0b517Ffajbew6KbsVeDlE0vNhc6OgSHmk/b3kb6/Uk2LSL21awmHxZmOgAu
JhzXvZy7pYismHxMViqQfmf527aah27t70xXYzKjj3VANipqeT5kcD3RuJhxYk/l502QoldmkLZR
Rjg6ZrZ8jEtYSzxISA60nISKcmPErY5RXC9xcSCAcFvAwT05MylUUxTLs5NNQTOamy/buJDO0EO0
tjqoqTUAOma2Zjo6ZZBdUUIAOjpGPTAsMR13aVZkYxu22/9mtNu2kGZmOjppW0qQZjqMjStjVULb
2//b2rd+kEdldDfv0KB/gCQ6OmaQttuQkLa1to308mHs3oL5+Ojbtmb/29vr6Wa229uQtra2ttv0
88vd2G46Zmb18H7Jv22vrkzo5MPt7a/u6p1mZpCPhljz9JZmkJDL2Y+xk0Dv7uE6kLbbkGZnZVSa
k2TBwpT/tpCQ29v+ESbLAAFarUlEQVR42uzTf2ubQBgH8Kz1fqjniXNu2UiNlcS0GNogdWmrqTUa
jUmTElIQ8v5fyM6NwaBQ+kcHEZ4Phzw+93jnP98OAAAAAAAAAAAAAAAf5BMA4IhBWgFoC0grAG0B
aQWgLSCtALTFq7R2AABHB9IKQFtAWgFoC0grAG0BaQWgLd5Kq38/POSHvMgDP188LPwsy8IwyEd5
cAhXQRUEwbRYVdPHKgyq1Wr9uI7jaFvO61m8SdZR8vQcRS+75OlpualfojKt0yhZ75J6f3WzXKbX
5WZWJvFLWt7cXY/HptkbX5rmoOfqxqDLGFUpoaqhMmYwojJVQkTFCCGMuy4mA100uxirOpPIcjRK
mCJjhAkmBmUSQkSUSEaSZLHwfLijiHWJYejj/f5u0FVVgzDKXNYMEeL2emafUYQlGTOV6jqlBsGY
UMNQbykhqDlPlhFSZNmyFG5Z3HYcx9Y0R1O4wx3NcTyxROFxT3Q9R2FnX798+7ySbPuH7fBmhEuS
JEuKpnExqilEFfcgrjXfep7Nzs63lu1pnqNpni0KRzS95hqL9LHMuai43WxzTZG5otiOmBFvXPG0
89NhrYlpcbZoiKdiWRImxB0YffPiZnyJkFQqHeHk45z+8bt8v+9/ieofr9un7/H6F07+i87ReDOt
w2FQhMUiKw555me+n90vfH80WizCJK0eiuJQHIIgrIIiy4OH2XodzpJ9Ga+ravM8jVfhNI6et9tt
lG7rpJ7vZpNJEsXzsoyS+Gp7nYp0L5N5nU5EUCcXk15/cmHqpu7q/YGruvotZawJKhaLUYwIwhiL
5GCXEINRnRAithgiySj/iX5xb+bNaVtRFO+iXQJVCGzVkQ0mAsPAAFWRxSIJsYkdDwMdOnyG9vv/
23OfkqZtajdt03aaBxJClt5zMvnp3HvujcwBVp7XVJzkBZkTeK4gczi9rQxGWlkCgmWrhUUMOtTK
eBgwpkWtZ9tWR3JUgRMEyXH0fk/VJBHsS5ZlqKJIaxYI1EIGezCnZMBKFeQQGyUFfADGjJLBoGMi
177KX13dt3EZruML2Wy2oMicLNNFdJusWvjTKUQ24Z3lHm4DHk8AIhXMgktcBgJL1YIBWmlWnMS1
jEXQmKVlwCseBEL+tiKxiTIEM94FTgasqlG09Hqz+djhcIL/iLSmYKRovDn8I0RfpvQldPHxIqvv
iMXrowH7f6R1Nmgks2TamDNSG4PpbDCoPEBix0XnFHuzpOG6l1lj5rsNLw6jTTxedLrD7XZ7PB12
YeTHwSgMlqfJcTRpBcPd8TgKDns/2k2C0b7ZOh/iYXcyHC9aC9zXbDZtu1a0dUu3jJ6qSo7EA1LQ
B2ZFjQeMInjEMWRXUokoKCEANt3BpigKED9cJWiCQBRyhKtMoC0GjUkZiFqq9djqFjVRM8AuUY4J
odyGpdt6TxBVVQDoTrFp6j0dwGPgHFHLy4oiKwBVBv8YhWyV1A8vRifjNJtugFYhfDdX+fzVVChV
cQan8CFDojFBepUiaxBtWWFwlsChPMvNy2C+mj4IoNN0GlsWt8kZ0A6mGZ9ZDCWrAGVCEyeU+Drn
F0iI8TV9gPCyyNOfBc++Iv5au1iYK34UWt8n9XlQnyHz1QeMZ+h9ZryjFEcfQWL/p7Qm7mx2SYAs
UH2ApA4aD40BwB3Mgo49Ws1dN1n50FWEx+4m3g/3Y8S0tdaxuzyetqPxcDM8BetoE4xOo2A0GYLX
YThZbEfx+TTaL87dfbzZHaLWorVcLBbtbr1uF03T1GvQNEsydEskVAWiVEAwhzBV41TorUqoAmf6
KQS3O23sexqoosCW9jz2HI9jhtbkYb5XRfBtGPVFC7QKuJOeAuwOqK5uFSVoqQQ2Sc0dXTIIZoCP
VQTCXiYxA7DARJYNDoEwKVuqdiCL6SoOiUughC/Vdf711ZVHWqcwjiGI+G2I1hLDmkMEzuFKFu9C
Fgve9VzPFBSm2WzuNwcKnjcZQE9blfBkMq1gOszDaDWu8g+LKkXcClsMl+KhQnFCz6zrtt3u9wFr
4aNo63ua+sz4YED/DLpfvii0H01i/7e0zrxLkkynswYGaG0gGq5MG54799aHbeh7K2+a+L47W8fI
WTf77mQ0WZ5a9XpreDgsl8Nl4HfrT2EU7sat5TaYjE777ai1eNo+Lcb7RdBaBpOt64bb436y7HTG
XfuxbZsIg2tly5GAl9YzVCllMBVMlos5oFVUJQMiKUo8zu8eLk2CC0qMPbsWA3QLFLVq0UPSEcuY
TTX7rb7pgExDBJWknjyg0R3DEkCmCp6R9YJlnY4EUnHE4bwCxhQZfMikcUhceVABfFgUyzhlCDEN
JVplbKUZaG10BNyAQbDK0DdZ5rIlXIedzGEBhTJP0lDM9HTrOiWFpbEQXLar3mAVQeMJYWguBi5n
Kyps2jQuluN8zhNLJfw4ozCVp6cHIEdUb9dM267XmzUOsfDfpvWNiv0BqilYv4fp6/TFRv72/mGa
eH4Ux0+7XRxHPvyQwX3uKv3xK7a9ILd/HBT/JWD/17Qmnu8miIJpEKpzN0kQ/Xr+ar5auwSqN3fh
MA1PWx+R8HA03A8P56Ufxf5qMxnuDrvdZOVv4uh8HEdxMBm3glFrEgxP7XGn2xofJ5sgjhetcXc0
OXbr53azb5plw9SdslWGrmFA8AhWcAO2iB7SVqAn9UTwZUBROX1WccuIefFTzYDvhIt5IhGySLT2
B4NIh7RCNO3HblFHII3cllc1pKnEv9orWhLTaaDZ6+kgGaG4hUuIVZGTGYOEKZNNiom5AokoAAEv
zGNieqmUCoAlhahUyeevYx4kZlJ8cQ+F05BFuoeo5w2Ry1YZrTd3X1UPuUgt3TBI8b0K+G5uvrrJ
cJzGZ+lkKVVcgMjupx2Ds9S8zk/ruBzKW0q1lz1LCjx8LLP2aJqPtccORfF/j9YPCH+fU1NQxxC8
9btaofrN5388vrlTxHpceUvue9C+lM9+8deB/b/TOmeG8IxQnc0aUzdpzIAvbCWkrODU9y6ANQqG
B3+18tfbyXKxHx0Df7UO1+vtOfLDwznYLuAKj85+FISTU+u8HAfx4rjonpfhbo/3btlujs8nBMIT
mEy14mOvWAQsRUc0jR4UES8QS/atxhs4BIfMXBIBKySQ58aDSshsYBUsI99ksGLgSsr5QphMEmiF
ZCKFq6sCU1V6wzalaRx4vw7zpnitKJbJYqK8VmVyLoBRFseCTgWMZWEJZwr0lWSQWE3lEJ8pP29i
4tyrfK5PlGUpKuUBNzwm3IzZaOCAkxBgs7shrl/dtSsXC/JI6GIwYm9u7hQ8VWQFLFLOmlrCoJvJ
OUSaZa3e63xFwI34JhOuWKQEKVZ40bBMu16zkVu0lQL3t7Q1peB5USUxfYvrbzDN53Od6otoYrz0
Y3t+lf8ttC+J7DtM/1RI/P+ndZ4gRZ3P5iSv8/nMdenI9VfubOUlrpesPIw4GvorYLuJNtunp+3m
sNmNup3heHQO1sO1F24mo9D348kkiA8IlE/nyS5otY/j8RaYo7DTss1zp98at7qtftPuI2nVHRi3
0EDyTYlMgKdKOMSbswQJoyxi1ytL5BgPK/dngQGqlUEfwQxkSY8pdzXcSqMjqbjQMB/7NQNySS4v
bgCumEsQi3Usw7SVLCrmHZdJWnlOwlXgCu80+CRqGbmprwTOSElTWEup6UQWE53P5fMDI6OAcE4g
ec4qZFGRq5xlOkx2dYFj1wLOr25uuo2dyDglUb1jyvrVXVURVK5QIvkFgCxZ5pjEpjkrneCuXt1v
q1W6kxDG+dSi5kQV3nqxaBbtut1R/o62pgS8hfYlSX2HKYt2k7Hya/LueKvl33732cvjh+vLqSiU
fn1rqb6+TpX2g4mlX/gDef0kaG0A0hn0tJGgWHOZTkEsDGCI6jy5oKwzX4Hci+dvGpen9W6zA5T+
3A+j7aJrdpswmSKExHOobujP6cPfjA6b03m5QdA8nAT7PQLn4fnUtU/LbhfZ7qhv6hBW3S7DZbLI
CoL0SYwvi1RQU2mD92MAUkNyiDBOdO8rTUEm24YiXAFQpyyKpJ+6P5huy6KKWcr1dvsRdRrgj00k
XQXaHFxhlWwlXpQo2i5rWLtsaOTgUgxeQFBZwE5+7Jv4t9+09Xr9ZNg2JKvWfmzChlIIorSYksKC
78r9VW6Nu0A6vCSkq8h2EY0qxCpdw3GiwrhXIKKMtU7lDAeZUlMSVgB7A7mUOUnXsjhNMXKW5qdB
8guCad277Orr6woHfvHGDrqbKm5WFlVoq2WbtVqxtkDO/BdpfRlVpqm/VVQC9ZT5pV6K2/x333/2
58e3P7xypV9OVLVzzyD7vML+IbCfCq0VMpYG8wHC3gdwCnahqLOp5+LYvUzns4vnJaG7hjMcjZZx
tIlQng2C7WHYGo/Gi2jqRa6/263jw+WCuk2w2/i70dhut/bh8vwEi3hxiifLdmuy67YXE9Rx6ijh
oIBStiSYTQYYgoYytQSkEiAVQRmPSBUfpLZEW29w37AEKBhg7akCXU04gkawZgwHA68mgW/LeRy3
H2tlgziFmAJnjNRLMrAI5ifnSSyXyyomVgWZfihzaSSMpHDUqLiDh8H00nioMOcNbxSzLquykipf
mkwCKfDGX1/lugwthL8YXEEQAAy8WVzBpJXmRXiqsDC4epMZN5ryHeSUSfVXN5DWakbGAwvSCr8X
tMrVAmgkWJn+UliMS9X8q1ySGl532NgvwYRXhmtm9awiKmJFu2lzyl+glQh9yVb6raa+ppE7v8Pr
K9n/9rOPMh6Mm3fM1u5pofeI/R2F/QBePx1aoaxojBg0pknygIh4QLg2GrOVv0rcELUdJLCRv4s2
63Xkzv0oikLfvUTeNkzCTXxe7HwI7yryV8EyxA3beDsa7bbD4/CwHEVhtHuCSbzaLVuPbSrTQmCX
TWiWDY+Wmhmcoo66DBVZgB6ziJmyirzlOAALsEJ8ea5WyXm4DIAZQBEXUFrLfGQI2LBR8dsqK9Da
h92pY6J/CQNxL6QTtNLMMK50g1WEJABuOI6u4RP3qyqmp7INM3Y6jftc7vr2+pbGfQ5fKve56+vb
+51EThFjlV535Pi00Rphs4qsAh2FOGM5DhusJploxVOAboDaUucSqevYNbM3oJSO0zA4K0tNyyhk
qimtBGeJBeAsh02LSNnL1/mcidNpIM62tKLLUxBSBqm2jSqOycl/IW99WVbfjF/Gvp70M1FS/MNn
H3v8OLO/eju/HLxm42WJZeNFy+lTovVhkLjzWeMCYxhjNkjmyXwO/QSFo8u8MQ/9yAvX0Tp6Wofb
cI/wFiTPGv56PUPfhLuOn7aR76+hq1ES4yPYHJvHbnvZ6pwDCPH+FCbBqG7WFstWG+2IfXgilt4z
ipIGh0k3VCasBiLhtBcCcDEptDQkssCSDKNz5SHgCGqHBBJkiiwxBWdNYzl4cHWEy7hHN4ebgw1Y
NREvPo2CVXxzVMfQHHzXwCsF2VB0ur9AJSGNmqGULMOAE/XuIY7Wfrxp9evItu3FIQLCwCzlUgEm
FJCC1qdX+YqELwQmslYBkOKA5qLKLTwqmXnHsJ5Q04FQ3ij+RgOVOEIWS2lrVaGOSE3OMJyxMfLJ
YAamqZJipW7+9XUop4XX1HwiVDF3gUcogieeZRfRIaGXOf7P0coIfb6w+ts8FePys5Wkvv7xs39u
fP9d7e1CN9v3JRaB+YcD+4nR2mCeMDVBoKEJGSxSVRjByQXp6XruIhxexdF6E3pzfxUGqMYMDxvI
rOuv49UcnK/Wh138FIbrcOVF6y0yXD88wlbqjgHndgMTOfQXh8da/QhfalyvNS3T1A3dceDSkt0D
fEgJwRUFqpTEUlEV9R3ARSUWgnRVabSpxqMZIBHX4DSvCjgj17zBw7zO8UhSgX19P1paKjOTACYh
nBZygastWFK5bJSLBgwmCDMzkxUOS0mAn2ctDcxY4mSRp1+DI37vMlmOt89BnVMIEnAJD6qUtiZd
rq4qIikeQl4FuoYBT0kmcmE28dSEyAwpGSuxRFTwRhpZyExeWcuvqPe7akGhuJdcJ5aREvxYgqko
UZytfPn6tgZdfWtR0y/KCsM8hNUx4HbrsAIsQ8r+uc7DlNCXVfUXpA7EN/xkhp/9O2OmvF1xnn9P
Yl8o6rzj9dOjdQA/GLgi4vVccDvHjtidTd3LyoXoPjTIFV6tvNlsDnITd30IJuha2oRREPhkHg/3
8TpaRXGI5v9dGO8hxqPRJAgmnea2E6+gVE9P/XbrjPLrYtRpPppIWx0DpFqOZBokkiKMH5EGi4I5
LS3giAZ0kYxge5q7mNRvBL8HLGpUNuXxwfHG6j43WIgc61dSjWZ30TYEyoN5Sn6FMl1JrYqWYxUJ
VsnRe45EtjLBxVqnJMOhYFimHFMuUU9DijBXJSkDbgWeKrLM2MElCtNWbFYlf1/hSHB50CqAH6r8
AtbUGy4UAHDaQCgIuB+pq5HsBMS/AJW2DHUm1us6ngM4AcGtEsBcppDBDNUq1krVXEB9xFNQhKUX
QUuFXIXKTJQ7OBJwRSxsFg1RfsETfjkCfgHVtM9hcZdyo7gwkv7Nca+9qfEU056KlxT2i99axJ8g
rQ0SyMscXhKEdDafzi/YXxDk+p6LJqfB7OKufALa36zdabJ2Z158QGPwYrnbPXlz3BDF6FQahu6D
50ebYdMcu6votNj64aQbt/qIlSPvqY1gzbQfj4vj6VSr2bquW6jRFC0KfmHt0jAgq2mmqoowa8Cq
pjH9FIJcZUvdwEwoYUoBVYEIk7aNXO7B5vBVFtSe5LQW7RqVhUBq2hpl0Q04lCDW0NAybGgcIVkF
S4CLRzux7ogia8XHi9JMAFx2ij1VJJ+X3Cz6FTJp2grbiAkeOcIbBKgznu4gUSVikbGyMFiRM4xb
4AWpBVv0MEFT02E64UEky1uzKJU6RcsmO5i5vDfYKPrNsvuoDYJVce6yo6+v7h2sDewJ3gJrSaSg
W2D1ZeTxKIZR2ipqH97L9Mt/27/f+PuLTNV4I3ExSP0PxrfXbyytav69LPa5vkQcfJq0DqZzlG7c
OZR1nkzd6SzBp+e6tLnoGgbJ/iUBc2HkJdMk2h6W3U4Y7o/j1mEL4wkdxOt4NDlsNuj7j9Zxx16i
NBv6wzA6D1f+ZDWb+p63RGkEEVv3vGg1zaLl1PRi2SCflvXxsxZfR0VqKVFgJwmQMbKJGJ68tMrN
+rzAlJDTgCYruHKC7lfubzdNjqMk1sAUxVrTNA0gzxp/NcgqyCVsUXQ17Z6IJUCrIRJ/8IKhzZKE
KFIgWEGqAiKQSjqO3enqqob7NK2nsraHt6pGH9A8uEzc9Pr1bQMsQiN5IggAAaUCj1YJGhwmBWLk
YMkCSlEIzt3pTqQGJmKSd+q1ulU0VS5TxWxUsAGirDpEc2XeNimXpOtXV9NsFWdZkZU0FZtMK1o1
CCvcbezR0WQ7nMQi4T/D6vuwsvEu/q2oKSkSCqj/4fj2MSU2k/xaYUlgn+X1k6QVbjC1QSCknbMO
xJlLjYbYed6sMWgkQJQam8L6Af5LtG8tO4/tU6u9C0fbYAuCZ/NVvN1uh/4sieLIX09aB9/f7lun
p8UkWgcrL3Yjb6GbbTJDWsN+xwK5DsXCDoSBSqIUj8IAZp+SZBYlMVPNciyWFQBNvXGfFBmSPO0k
Fh2X9dOqkqt0RcpZDepW7EmPtm7ANBYINAqF2bMAUwgqCXKZJu8ZdHuBQl/yi8mHhrQWCIW0+VAW
EajX0cHxyBtlCZMwWJHQyiCIJY6MoqpYucpfz+UMEQky6Wae6bVIO7woxVXYoNAaiXR75kYqx5ET
xeEpUX80EW0IWLLK2v4xNwQ1S4sBVFavId9pnL/KjYA3zpeYtYSHShpvFzjUmHsOtLWIvLVWryFT
/yBan9XV9wJgMUU1+PGz/35820i9YuXhQwQ25fXTo/WB2iES2MCXaeMyHUxZQ9OFiPUSSCtrFPZW
l4bf6nTH7c5kcqy1u3XEtcfJcbldPQUHH1Wd+CnxKYSO4VANd2s3mCxqrWYNjmri+f5l3tEtPP11
vbWom6ZUtnQTYIlaT2RFU5EGM4d4QlaAPUN5aeoFicP7+4BkVmbesYa9ZY93SSXXGJmkvZqhUm0W
ppVjW6zjmGbBm00nEM9ENDUe68hSVQEniCdgA/YFpoSozwIiYCzp7UW/3+73+5BDDf0NkDFS07e1
E/a/37Bb3F5dXfuMVrhMgIc+ZaxU4Ao0NZgiWnmwShNzovQTd2e22zpURuEW4iFxGuM4gwEHnwT7
xFYiJ4TM8zynoSRQVCQuEBICMQkxvQh3vAQPAa/AFe/CWtuFA5QyiEH07LZJmrE9p1/WP6x/e7Ro
HRH+22HPxs/JlFNva/E7TqMDS+G+oHhCWCGlbNiwIhwrfDKzlKDrdDBGfZs4wm7WnhMIsCmsrDJV
e7V62HWT/wStr9aWPqAamQnrUcI4vvn/WZkIWDn3oer0LLAvE1hx9tHRWkHaCk8Eot7GAtKKiXSe
UGz3jVZlidbqEwRzvW5dm/WNHcwHZ8Sy9bqV1E1bd/G1ne6no1Nn3V/3y16l/7SboiS1eZzUZ4/z
7QB14zG8Tr7RTSL4bc/rOph1u6bl+CBPYwgLlmhsx/Q5bUsSThH0aipkVNwkd9Leo4bIlimo8PkH
U7Sd0t66KmukVQgo+kGWmkDDls9FJz+rxzJhhXaSXVWJDIcuq1NEGEwpmuUq9B5Jg8HhEj7ON4Pz
CP0p+LGmJ8uxnS6fBe4JsENKiS3QIlzzdCGfnmbfMTyOR3WfOGVWBqwkFJBTsCGwLGcp2VRpWZmG
ScOut+uBoydlTu85UoxPHE2nE9bIpiFWFAiHuUx6IyZe/+T0T7CAtZkEiayioYfM9N9u1sJ6Pelo
gtZ/jlVefF1W958SqE5u/t9WP3IrXqMc9hWBjXRVnH1ktGJwdcJqL1JTDKSXK/DvLMr9PhLXNbyH
qCtVVp0DOjSn5uMB2WrzehyGQXPmAAxVwOBPG6MpKlFozWKcp1ws9zEKe98cBvbkfDyicoWMeKyX
uko30MPTo226OsQVf2Mu26JcMYBJ8wM9TdGHpCC6VSIjk7ZIe4EsEzbL0lTzelj0C2D1keUlUXai
0cFIIidNoIqsCg5UHWRHSyPzpBfmCEqriLgh2yALtHYVsIaaUaW8qOBnL3rFctnD719eTnd7zAHO
HwfbnqWo2Xg0Kc7G6d2nsp8b5fN5bypM/NBWJr1ZWiTiAlOoHy6TVkCM6whve7k6txGgWw5Nl2xM
cbOZBHutkS2Co63RJJAwS+Eq3FD55GfT5vsEQ+GIZHwgGJbL+Y4WZ+2axXXLbIZhvSaVhLb+67oK
afrLCFi+5er9PwTAL9cXG1HNKZ/J/EVE/LJAHPH6UdFaXnb2yyVMhmjWwGiHCdcnTqX3+31MqXc6
6wYC3eFwh12apuikVs1qEyM21batyjTO41PRYeXfjRpPjHhbS69YXADQAZi+HrajfQPtoadhFa0G
Ew2cag1tfCga/mBdWhQkenkjahGrRlGxKvM72u+FLb+HkNfFi7lD6PSogwgYheCHapIE4gEIbnHK
ITvD1UW3lvZEowuLP+NgTdOieXd6JXg/AJtULSMJtuKya2mSyAil5rjsFeFfKqTxWaCBCTYmLl6D
m65x2gHZvvnUF2Ax/NQO0loeSGyDUnrZVxWFYEAqdqCBdlN2OX8Xx/VZueE1RklWvxADoI+MsB7R
ceIuqjDRHfGsrlFuTA2H2VHNfDbzAIBZIabDSdDKItPnP5EZIJhX8Nu4sEegkx1WZfkf0Pr3dPWD
/bcfOey/dvN/vKK+zilDhX2FV4FrxOtHRGs/vSCia7BaWcA0jCowWIXLH1e1dvsOGrAIi2kPRu1o
2Hxs2oHvKDJtfACG25mVtvD2P6wRTU9b2CWm4nnQ0/Mem6vBKcGi8ahxcgLL6E0HVRcBK6xEBiCC
PwIElaB3hqyxv+qqrAdpAirFAoIQRZA7yadbNB4FT/lcXsBTeayVaJpg6UiP5u2SqAnDJGXQX8GP
rng4J+eItMF6Mj+6yZLBH9yQY4BUUnQ1CaqQnII3o1efDw4sti0aS4Ta+EIZK10ogNx0uq8wZRWW
w5SdVN6vcrAlnlTWpQhrlqYGqiuyXBCpgFY5hstZCCH5TdjL1oOdFW0oraTAPYFklkPod+izfgFZ
sdgwLQp48R3I5Xrf/uRn8zZEN87bwTHbOCRaw1/hUoklRF3O1W0MJNaatiSqTP/At8Szv8mqQDXT
vOU63vy/r6IoEmt/N4H9wOtHQ6u3ZPT7tBA7veCDeSvDYZqYUNwdt9BRbe2mZziEmaCO5v62qtEp
rxE6xUBwZ89HD6P9uuz1G3g0nqZYGT3sz3M0cNYrr7zETmsmikvhdFJnesnsEYhiGo5WB/ZBZe7p
AHFUmc9RBlVcBouiBDwueHvuSag3SCv8u6s5dZJMG8xTDXKJi1ZgByqtifjUOBQQ1Zs1qqpG8nGD
YcH0wxdVJJoYNN2gjQkfJIXXKE7PdmgMcmzXHPaqm8G0g3jBq3QkhKugCGy9n9c/d1cuFIuYkCfp
oqCEdqvwMNElwSIWeIzfKVl8C1pxuis/zZNwWlD6WXVi7qyk3lFWsSKDMEVUzNelREkLlO4+n0vL
MEz8sXcE9Cm0sc4nPvHpioSnK6GH7Njtaoi8tfn3aI22hHhdVwWqmZjIVn9y8xbW9zUxVJDL/EWJ
+LXy8EdCK3JWr4K1XDcW3gLEeSJ3A8LwAmMaB13UKT5Hw4fdej8awVNYw/xqG1Vd12CHhLKVtOfH
w6hSzEGbPa9fTnv7SWt33e7A7oIN2d1lMq464aVd93Wzq1uW5WpIudjbN9B6IXUat5IoQV9BoZBc
TRM14aCcL28ZWhozWBvnl1Z5ebA19m1ogjBRzFWIuoEuaU+vw3cMcjUO9ggPP8UHQbTCxfIpsmbb
gJ5KIrvkzABnUhm0pkRnREE7RNUIHoJW3C8OMaNuMrnlXiyMUbsxOHzxuzaKixpApc9JKCv9+3gu
SCpoxCkficXJ9rhd9hoOi8+soUX9I7wy4IeN6T2RBZvstPKqO/iFBZ3vpM9+urB4Li69ixAmt/Hy
Jz75+Ux4h2eR4dDSg2qtCVrr8qtVpj/+4b6mq6IIXEjdYhk3b2cdxJtL/x/xKn7rj4PWPmoqHnZO
W3KvQ2SsXpG1FnwPP9OqhYR2Mhwezodx5/ww6tUu1fomCMPQUdTmY80kZwj7ZP/Sw/aI5RxiRqSV
YL01aM179cNTn6FxeTXahofAsUO/butdXe+aYgKHGRyFT6VBgh6mLiTRYNGI4zdmtPPLYzG99hUV
f96abruapreK/UEgxTiJI7RXtjTLALC9ZtWv+oawHgNT9HM0vYT8VQW7oiLGerIOj56rxVKENUag
EWODmjigwgK/kH3oe5yufFmDySkqB9OvG8kbqz+Ep1xIn8qVBxmAkVb0arJAG+QTVa7E84Q7b0xZ
rfJ61I0xpQWrSgwiLlPekbQiQyWtNDS9pxS/j4JiQa2e+WR6muJzEGbgywHb94nWpz/xaXSPUmzk
yiXDtP12rdb0g6TQ1tcT1r8bA+fuhF/p5m2twhfIK3zEXMRVrL+dvn4MtKY9SGt5ya1J+x5W30uj
NoricIO7CC8W0+EFA+VDjJgPNtXhcFa7qhYUUnNnfs9p+74JUFDfsczNqFzMFfLFQt4rQ/8643A7
QjLch26fhk0b83KX+6bvo+9qlHxLJZCOQU8vu6ViIt2IvlEN2vapj5BUd5ROH1RJ4SS6waQ26YyK
q5PF+5UAoUz7navDQdgO6/hpdAt2YKOEu7oW90Ep4X2BwDIo7qqarsNUKIuCbUKGY09XqHFMMBPs
wMolejMk9mxYNiJRgFTwCvWlsPESaMqW88XjunxUIL9ZmhaBNz6woM98/ixENyGMFRTDOYZkQ/ol
GCdLMi6xu5TguwBn5zAtB2KZloqXoLSmAOZ78/OZdFP8ANFmi7yUuLsA1lzZ4vsLwmpV120zqNVn
9UCVBa2vVIJ59oquQlhFGli4eXvri7dc+b8sOP1tef0YaAWbwNUre16RstrHiQfeYJcArevx/DGY
1cLr8f56Gl1nIbY5DC+b2qYmdx1kmroV+PD8uo5p2Q8UV2SWrL8stuvGZdICq41dZVo/bmqP7XAy
b/oIgrslN7Rd8GoQT4v7MCnRPiyqis+kGJERxgU0KWyvUB4IywMqT6ZiwFfsdLzFlSVk7h/OPSZs
W1d0e4Nd2xzoDKvNuotJWJcFGFgR3a6BANkFskhHTRM9WvZVsilJ9+2uJmHFaQFmAGvYvqpx8JX0
McZXJbZnIgsvqzyfo5sB38Qr+eLgvjHUaC3E03EmgGBGWzRJWVIadXForjBbldYlFieIDIFlKYUz
haM2pFUsUXDOQpzR/IWORm8MYT5X9PniNEqAflES9vOf+OSn1zKC9zgNyOzg2EGteqkGsqD1dWF9
VVfzd1So9M3bXD95x5++LHh9rZ8Tyevbp1V0F4mr50WgpgtR3kpHYee8DWH8PVweHzfbzeBSD8Ka
79cnx/uLo9rbwXEWWFVMxnFm1R+tvAJGuTnCvWxhNH1yXqPaPOpUzsPxw2XWq/fa8AX4pk1fE9QQ
VSaKKZ2/lFQsKiX1EwAxVOQEzraYX8x4B+g3CltuEjAZxWJl07Uwyc5p1a5r6kDSDoNqAGm1SgiY
Hb4PlDicEjiIt3ElgDW6Bi6ZYrBV7Eaa9B0Vwoo+FDfoJ0CIqY0kq0BRdSgmNrSAEhJYoW/CbM+j
ZuQz+XvNNyVQz4iUmKWE+jImBnJgGAuEZd+lpLW3CGMMvqNJN3iUsfg2gGEcxMLvxQRdVGbClTh7
tmHAA1Au4QWjKVpZ4iaMp8xnP5lby1BcvOPI3GsOZia7Wp/Vaobo4LwqrK/lqxnpFit383bX9+jl
+FzuBa8v5fWt0wq2QKiH3FVAiovMO4HZYvVwHN4P7x/rQTA5noaTMTbhH80C0w16YT08Pow6S0jn
tWnb9WpJ71YvO3YnC9xvob8aNdbHYQN3GGEr4tNwc92GV5s+dNdpi6qwAVDBgmi1yvhkMVic8xPA
8gZAO02nG7aMmLbkloCgrvJep3Rx3HMQAbr0FePcspzerKr3TAS7Gmq6vgOQXatrBnXTKLESo+qY
be2WwHUsLkz8pNWBhwJxaoQqY20ZyspMNivkkpZeztjiu8hnFAGb4lk5X4Drl9xFpWAWqggaLoin
T0Xfxnj1sFxpyaSXiss9U1EvjnYaFmOtn0IsTG1F9vynQlJ0AI7tZ3NlFZcjB5McQwo7y3320+m1
LPqurFlpCv9VfOyiU7/6WkTrS0/wS2H9EANvbrHKN297fY2RfCrzJ8PEq/L6xmkFmjBHCHFlhSmN
T89jJ2exn9cn09a85m/uz9PtddL07XBwCYLmBvujXcYYSz8e+17juKlWm81eEExhZCpCW/E8lcoO
G8SM+6vF/n7aWe+Gx8l2u732MHDKIXQOsYq6j3AukEsImoaEzhJzblhgR+K8nNxIpwcIuUuWU/N1
A64GTsS1F8XG1oaSIg4OOC5r6UGISXffhU/K4lwcN3yykaWWnFIJUTBKz5abJLFJxK5C5bA0V2HM
CroAGStaIFzhdA/xBVio8iqsKUsEjcQw3k0IoBKVXH6hJ3AL6kmCJVFWpisw2lb4HWHFit2lNtj1
NURdmDKM+9BdyW1VwSZT1s9xOJ3aikIXC88EFd8Jta19PlOWqbkiDZZQVxrmPp0rjLOigpzCVbII
B7oIhTdhaL3Q1r8nrFF/dX2LNb95+yt9izUjrhGwr8nr26a1iIIw8FowIkYUjGAYzKFGDI8+d4yw
m5v6JbwOtrO6aVUfZ5frvGbbhnU9H4fjp346jXuuZ5vBw+WwKIN1ZK2L1pqiu96N1mXs+H+C0Xh8
Pjxs7S6tFDpwE7vtcyMIWpBwORqNiwwPdB4KqRXX+uV0uScroDK09Y1KawOt7Peed6jasEWpjg+B
NXtBuLk06Za3kKQCUKS0JiTcgWeqW7I4QQCrI2BX2F8FdYI/5pcs05LWGAd1NPZ+6fin9tK+kGRH
2FFlkZ0KWhM8gz34IV3o25KwBRNOYTgEbsx+saixkbxm766okF/iEcxRm0iWhPc/2vlQ7M+ES4x1
hZGfJ1FC+6l47vOeCacE3YvAXdnmP4sd8MfgN56KaJUkjb+WadfD2aYqasIvMtYXleAPrOa4b5n2
xZuPYk1vsby/U256bmW9ZVqRrxZA7BLaSq9dkWUm9F0XnUa/NR3udaOHHRlO7OJg68L5MAwnNZRu
7lcIllED8eAoXncmrc5pMPbg12MPh5OyFchqY9jxnrATDAyMx/lpcqmbsPjYZon+Qm7oINhjlhgN
mhNSccAq4gt0mb1mm8V0RTiG4VSydBR2scBQe9mfolmDZSG0dhy7tt3OApa7XJaELbgjVFSXHLeE
TFUF1FrSSnJ6m94lhMLRdFyM0IBJiBZUlCmwyhcHGeQSsbHqKMiqXRXWJ17FL3L+DncICznvgp9Q
9GuJYEyExDRGxPA9V7TnfoCCexCjQAJnLMTcfI0sW6uklNLKjSM4P0t6CS52mMEplPec8cK79xRw
xOp+o/D5z+bSYwW6nRXos2KFmpprOX4tDB9Noa0vYP3z9ZdmiBo3PvpIWOWSOAKbi/T1FXnlW9cb
phVimi56dAaXy4SVaaz31MLOwav9uNOYtcPm4Nw5DUcdbgLROk2mp2lnUcx/9rOZAqRzt5y2OvfT
p+N+1Ec5OJPOe/sHDPR43gLVJQbUGJDddWajQ9NPIko0LLgihA84LmlaidkqaOV4nCb23mfRCUtM
zgGGB+5ghmlWDcGujqRUofkB6I29dYiSE7TUsTEpWp2dMSKkm45lqwh/da1rQSbdEiSWJeESQe2y
vwvrlZgejz+HroQSrwbnUcxwTdvggI5EcwSmZ9DQMTXuqphEITkZo0Ei8v2y1quihTM24oqER+Ku
iKRjuDHONxpIK3hFqYlS7LT6y6nAVLgK8aKQVnoTMdcqjnojgmGASVX91Humr2LaBzdBcpP59FhK
AXEMs14LXubThXQbwp4SUk5YEZ6whWUFtdm2WrL+nNYPGevL6pJgtfAxJKx/VW5i+nrA7/ZaOPwc
abxZWtm38fpUVrra87TMP+02VfiVDof5/Dw9Pa3Ho8Hk0pvVw+slHMNZ2Pfymc/mihXMp4xGjRX2
8z/Ve9V5o18o5GCqrZw7/ad+EfQ/LZkKY3u2zrm1PrWVZFwyDfRWZKPK7X4jKzB1laVXkMImqwF9
JJV0+0p2peDNLU1WYTHqipaPYlS5A8y9t3gAg8luYPrVIJht5/Mq91J0UFkqGTTP0kMMQEvEvITv
+ayaBphSjF3jIg8lpNT0JJA07CAIEFUzY44zHKafiRqYVRBuqzpMkfE7LugwK8qdQr4c4qIsaMVi
qxVn/D4mA1bCGR+uFq16jKjyaBhxqi0ewrkjfAtamZ7iBEvYGqmsuDO+ocsJ8XBpvTNLavUyOizx
gvniVKFDItrOjQMEEpNtDUVhNFybf1Fl+pCpvSKsKidFbz62tWc3J4P1irw+v429VVrTEFfmqjiP
Jk6K5VVjBKkcBI8Y9zyvy2uMpNfsql/DxHN1sz+hz+jlPvnZwrJzHS7G23IfI6wbyw3HFbCOHg6T
4OWSDdzFmIOoxUq/j8n2U9PSYkkdKHWTiqHDxa8JXKOdDQ2VhkPcBpuuSueDcCqFXqHRBE8IaA1c
a3HHYRE917zy3qQ5GA1U2/aDx3DTtnXThjvKAJ2090NyupYb+Gi6UlRpx6BNilSxbMsWSDyZFVUt
hLNAMnBgsaL+I6qVCCqxTBHFpIN2rm1IZPyOoCAwruE33cnAk+zHORuAS9RdIJsAqmyOKhvk71uU
ctlGzUbI4i78hbIJauungGcK5kNBqzi6Bs1NEFhBMjdWi4fza/PcWfVZAVx2Kc8JfuL1xGSeKAAY
uo8q2ywQ2vpqyvoXwprmX/X3bj7Cxe7r+B/K6xulldqaZhAspsXILIZvzqPT9mKGx+Z8j9ZOYzSc
hJN27WH4gJJT4E/WRWSo3q5ehWu3hfrUYnmompw566fLBWxhD15bDR5gElb/JTz+rcoYz7lhsYd2
XeargMR1ORJgiKk7mcZDLMMMdN9Quk6X2a169Ipnk0JpAzdF5i5rmGRFF8fue/vANKGkll4K4L6f
hLaqglaXT2+ZLlg3NIBq6RjXRinZ4tiPmF6/Ez58fKWiwBV7nrH4q9m+Hf9Ugl3MFDU3cvOSRFag
dPu+1k6ScVGc5XaLDWQCFspMoJlKnBUM30miGZTljGpCm2NSeBcnpaw6gTGRb6oQxGR09Ax8Pour
2D5YRL+cQhdeR1SL34FY976D7SgXrdVFj4ljWnHFuXMbXhiLtkrHrD0+bkMnovVDLfg1VjMB/v/b
Nx/n6jN7jeT1Ja5/mm14m7SmgasHWovcoT5fILve8dA63t/Xw565Pawbh2PVnxy3kmZfJpPBbrxK
ZzLFXTPcHk6rRjGNkZ2it36ohiu0aPvIgjO5PAS60mph+G7awQDLeLnYr9AQqobVtoUirgmPhSMO
4JKMKcI4S1Wll8lFAoZOjY4MFHQl9XGxPHEMA59UVPBG2tn7KcElX4NzqVdt12ynHc7DWeiUHMtx
uyU0amD35QSepncZeWMpahePBtBkMBpug9yJzUO5I3AilrTqNYclYyghgIVkRiYlgk02pG470Lgz
IrVT7Pxkp/PFuRGnUEsU4ej+SHqJO9o8UlhBU+wq4WUErgmBLTQV9wfP7wgpslVSiS+0XoEuN31h
B4c5LG4VxOKQrUlU0xGA81nYPaLo44M7IlOmUa5Dy/u6nc96gtZXU9Y/BcG5W6z/z1nz/8hi9pp+
XV6j97E3SSsKwUgxAVyxwLSTTZh0pbHAFi8z36wOz6P5rN2sVv22xi3CNL92bfW95cSVZbWzLFa8
HMJoRL+tYItmzmKFR+dzmQIMF4sptkTcYZ69fD8ZwXQMY9R0fA7D2ra+qddMp2oHFuJiScyO0e8K
ZF27XYOTF71SEzlnsrZIj9m2wWg5gmAdwPKOOFHccnHV1M12YNdqVd8PNk14rkx4hKGmXY1bFfMN
gHksp3lKhjhWrEFLRuQHZE2YTmBFIl7gM2nqgYt2MLkDqxIyzKiMixN84p4YiqUes04kafyZd4Vc
pZZk/MuUNaoDQ4xJJF5AmZQL5WVVxhNEjR/cSVxga4guRMonYl0uYipyVrAYHRQymkeH4qJkDF7v
QHBC0xJMfmmzYuFaEtV0/lyq1fbr98fNZRbRGv0tvi6sTx9lxvrna4DfsJl7TV6fg+G3SGsfWtqH
ugLWPBasSLD599F4ua/XNuvODDZ5wDAL0W+lNcGwH1uLNXJEjLC08hnstoBPpKmN+0OlyKJSTmy8
gFy1vBueRuvWw6A1HHTgYjyB3uM9WkD39V6zifgWqVatZMk0GWpwLbDn4gcQOBG7WoBOCSvFDto2
uqnC5kuyWegVO7XoK2+xscww8G1oa485dR2aDBzhvhCuJ00GnoisQSopLekQV14NUkSJhi0WqCRn
/jiBo1gObgQF9OI/H7yVpOILjLDZKct8CK5BgsoYFCUwTAbqdO9SN6mgjKHpRMQzW51iLr2c4UYC
dkcTBW5jLIy+Ed8igKY4TKQYwOEXmaXxgic8+4zAmbHx51IcUc8mNeAuatIJHsGLqLKFpCIS8cPL
5GEwCQWt1NRXYCWrORf/98Wbj3t9X1gRI3l9Fdc3SCvgLNPRL47WxDITptFXy9ZM1+xqD6WmrqlW
T9hR4dCGv7Crzw6VVaWFzb/xN7f8/Ccz5Z3HDSfopsBzgPp0rsjnAsHYig1bvoSXYasznZwn2DN8
fB4Pw8dRWHVNzsvVt5eZI6PlqbEWDL9vYFbpIAZWsAgCnpNX3BhJqCI7PFZSEzmvSg9FsCiuLigf
+34PkCKybtd6epeC7CYVkyYH2gijvZyquoV7GnAuGXBMMRclkpRAWoNxV+4ailxXd1xkneRLmJ3+
aAPkZXzhXngEIudo721a85VVPr3QxQ4R4EmUrRKCc6nXgKmrMDJgEmYFF8DTHiWxiktfMvrO5BE4
RtqaErRG4hq9LCdw3gujE0Zf4VfO0mgYubCIuyg9y8yuMVnfttG+GUyGx2PzButlMVjAGglrZIj4
ws3HvzioUPgLeX1ZGn6DtEIaPQhsGqJYIK7rRn/RGTYD2wlql+vG0v1as7m9HIe1+ujcqkCKK41T
T3cV1ftkptholGkMzuHhUUUYWTCfSMzNeUuI9Plh12kd5rPJ/fW+ud0025u6a7oGDEj3Fwy8BhwH
FXmr4dgOkOmqooOIVqm16i/bGFFnugqCDfxlQt5lHi9HWxSXW8P0Ldc0HcefNWvkXNe470sJUbNw
GatYrq7bNpBN0kthKNSj6I8eUPKVEShLQFdKGrAwQrDAW2Q6inZIAj3gC2QLQwUj3RhhiceTxNbB
29KpxOsFYTQPsoNrbvvYGrx4klNkkhJNReWEOoNwMYjHMTgiCn2N/BBRrekugj666T2TVkjsXVLK
3rEALBzOgJ09Xc7niwP5qIbf3gT1I47l99iOaH2prB8y1vz/eRT8s9vbH/9nnumI33QHXMnra8nr
m6MVkSxoRdbqPavrcr9u3W9D+E6vw9NuYFdnw0cInBP2LjuAzDLUojG9zJtBP1NYLvpANJf7fObz
uVwOvBZps0jTL9wvICFutPb79bjVWI/as+asCWd91dfZNA2C7RWFLNuulUQ8irKQ6zerZtclWSXY
kiyj7aUbXdIqvMQQXwNlXhrZESujSXRFUcqwzQATKBuMoARmCX0fXdFQZNKY3LIibDiO5pgGHuia
Jd3V6Wbg+Kno5CAiFZtLAd9kt2vCZRWlnxCzBJjBFwFM0HqE4JciC1EV0HA71Tg0c45K04MtA1aS
HUmxOyjT01XeqPQMknds2Z1lzJpAAIzflYXpRPQA0ap53u6FnohoxAdRMKddaWYSOS1xpzTjB6XX
Ufw8IpaX+Cuo7bBt1uqwhD5uIlo/8WrfJlfB//vo5j+8fnUbrd//sw/4we3td1+56cu86T+zvoIf
qfoarhRWnLw5Wjnh5rF9A1Hk6WpwPtSqPcc+D3bDyX0TFojxQ80MB4PxHnt5s/60bz3MRo1dv4gH
5D7Pf4bPf/rzuQysEbRaeH0YjlmzomivTqMONj5Ey3Y6D+toytT0UtLy/WqIVo2pWbajof/BPUOD
6rZuuparOw501dFdc5gu7LtGkpCCKuito4vDWiWtrlXxVvcOjBSW6duBHVSbkFYb93RL4Bt3FvtP
dNHT1bqGabHBy4oxJ3DYImVNGOSIQ7EDIZSNrMBUoWGsEEFIyWaKn0IW8RgJJ4xjRfoZB3qWxFg5
rnfQXj7ULElkt7JmbjHagJH8Rh1DNwLfzwBBRrESj0GpsIqLUIEaK4SXCgocWSEmpnwATU38ou5G
h7JiCo2kl44rsQ+kJqYeFNEVikvI422zXds+3k+ugta/BWvkCs7RSvvpm//s+unth/X1v3mPb//1
DT+lgD7f8N+jVdSGpdzfiYZx8tZojQ4rLMrBwnk4DS+HZuDXw+HDeLKtHdfLFXo4ur9bYja9gwO9
4tbTlIdmbXgF7GH1yU9+5SvYJigP0DnXLrLgPjjlzsJPy91hesYhJDuN8RRmKB1WJUS4FoJTqiX8
9o7vlxSgk9T9ap02X8d0TSir7Tt2K108u5pFr30SgTAqTzoTXGSjetUrLua6D4uT49tmtVat0+Rv
lRg2c7KdnVxF1kuugvzYNjSlq1vcd7wU9UejA2vgLjyYXFZLyJrlmyoUj2zSdy8TV8IKOEmo9BzI
0liMW9m45T3ev5PG2E9tedi2oW/3p/1qVUYaUJ7JKUotMIsQjPMZGL1ClWO0VLLEBQRxI11LqRiY
JZhiOI5nRPc9FlQWIs+7sfnLod9olhCG5CwHgqDVKirpTnM2OT0MtzdYL2EVrBLW4L/QuPkSnvPX
Ar1f3t7+/G/e5Zu3t9/66ys+3PBfpJVOiXfAFetv4kp1fVu0QgLFAm3iUn90nM4u1cDvPY5aD83Z
uHG6+O3J5FxePwyu2zFEbYc9+Lf7Tmu1KuY+y1+afxDYNWLFzRK9Cvo/fbiDO0+N6b6z301H51EH
G4JPB4Mty0tov7R1bvVrsK6KgmaXtCoOirrQR8Cq2zAgGTjdF8ob8OfqnHgTOyXqOOHIXakNz8Wj
WTNN0/Ud2ITDemB2deS14ojKHHGXFYANYvFMuiF8xg7c74ocpzQypOXxAPDJ6TVcdG0ktSnSSpIV
0ZhJERJqqYhDhWsJrEt0P1mgJiW8v5J9Zr8a9TS0V5FNoPd8MFPvo8Ov8hlEUJ1i3sq5d6ii6oI0
CR8p0Eo7/2dSCRL6vOA7JKbQ3cjfFO0yzMoWxwlFYUmTGQezdsW3Od11zWp1OBqf5oLWFykraBWw
8mBx/2kP/w9vb7/xIST+52jl+h/QypVCSe0Vdf3Es7q+KVrT3PZT7M7CmBimg/N8u8WYDTp402lY
u9edZmc09dZPld2l9hiaARo42B9xVeC96ePP5/jPgXNq6wJeiX6n8QS7f2t/wKDcaDpG+Nwa8XDM
w8fBY1tV6WKSYRHk5KisB4HYOtEyayEE3ITVoQRkUcU17/tw9Jvo3dDwKzqphg6LkwZWuqZXboQW
TIcgGYaLei0IfNwR0Sa0hqxGhkZNYg6Mmhbg1x1E2ZKYnGU4G1Wipeg4rnBTOPZWg5zGafMlF1lR
nEVkjCUOp6wAV9E1Qf9ItVCSovQKT5RsXmEAKSOhqLTmvkxU30UWwRQW892o6yMMjVB7hMSizMVF
SsEsAOWrsQ1Ext+RdnIqxBcSLnilvUtMzhlaNqkiFE9JMrIKpK2mXh+MplPRb30BK1klrDE0NW7+
w+tnhPXF+jdo/SZp/Q8uH7jmc3/aVuKvc1cy+6ZozacBLFDjBVSInh4mA1/370fH7XRwuT/MBiuv
3yh+dnC6nqfr9ek690bzRrmQIeX5Yh6cFzLosJJe0czpr7B/9mK1bkFe92PI6xjgjs7nw/RwejzO
2rYmQyeTSMEMC7b8MDTVGGhFQ7cZVNu2H/J4aY7jmINyeWBwJyYex5G7oqmSymYrD1xqzpe7mqGi
JMWNiW1Umky9a8DmT0yT9BjrTUcDjzJi6BJaraBVRy6sUp04Co5TNI267L4iqqTfKWkpCQopseIC
ipQvwErPMFs2QJXEwOhn+11Li9995nMJSQAJvLUu7MqqEh1D/blLG8GqSdk/sppVIK9MPlloJswi
a+V6R/bjYihPHAf9eb+KCFoeih3DQqxD003FiJptYs7pGc7mGOiqXp/MRydB6yvF4FwcUeHNf3r9
7Vz1F7di/ea5pBQtgvkBya+/vOEDwP/JdY8XgJ68UmsSuL4hWovADMAVcc7Oa3ExOtbhYX9qjMxZ
fbJeLtHhaXRGc8vfHtfFxa61a3Ra64ooIKNrk8kx2/XE0SfK/KrAyL5ao6yEQ9a1HvbYMLzReZqe
Hh4eRg/D4TFsbnRuz4KGaELWYfQ17NDEvI29ad7P0IYxHbw6aIUSDrz+VUVJWBKHchUFIUMMo7Px
WvEaAW13tEBg+BzRoKsZeFLeU02CiIfxI2RMFeBqmJ1TfQv9XMg4gJYJj6QgRlbADS+5qspclTOq
7Gti0eCE7++iOjDupApaOQgrO66DaJThK+u0qT+2ZrOUUxZzU7inGG+l+krcOob7LcUAsBiyR9E7
lowTTConoWQMHkW27B1xRBZfiJIJ/jvOz8Xf8weWRWmLDgwkzUAXFmbVCVwH7361yWQ4n0S0vlRW
/LkmsBPKzX94ka3vvLz2tx+qTlGsHK3v/nm4+9UXN/yXaBVD6vm/wPXFfhJviFavQBcTiStCWr3W
9NpsX8eV9chR5e24s1+s9vuJ09at0xPAREm4TypzCJ4xxp7J5Fn8Jeqc5KngtmWljI/lEshir/51
azzqTMfT8X4wH4ynk8F8W6+ahlPqSpJTrdVmphHMTdcNNpt2ENR7fi+o9tB39YPZqNyoqlg8+GoS
tCYVwMmZco6/VryWw0KV2JgfJkV8yYYOjBVqbzLmNvp7SyPmGsTQRZVJt+q+beCh4DcmQuWum5Ro
2scLuF1FJiQxdkwTvJIbqeESa8JkV9hyRZAsGa5IjJG3gkpWm4gqrRHiTASv4Bu4U1uzktqVmd9G
x3Sls0NBm0pVWWHmIBBKSHRe3EX3EYorYclZRtS8UnRyIbcMB8R7AOMBPHNUnk6qcEIjNq+ProOj
qDL9bVhlHPn05j++fvS32PoZMX2Glt9nfofmDn6Km7+i9cMN/z1auQ7PwfBzNPwS17dFK6JZwgrE
yv3xaHg/uB722C3CtNq2HY73ncP2CmfbdnJYwmqHilEuj0owjcU57hWBJ/A4EgA/PzAWFWHPQzu0
gb1eFqvletEHt6tGa7QdjqHLg+GkCSJ9tFPa9brdHNbMKg8WXA30thnUAttuw/DrlMxaozwyoaUl
oKHJPHIkuYQ4Us9ilXLLhkwaUErNcKG5mDvf3lcpvhKukMwVhnRU3aXcWnZJdfGp2xjtAfT8osfC
UuNkiH5GR0sCR7LJ1DFBQGnpBRNyNoaPbFKUkSGtaNHSdawwnsYj6f4nowxko5oS8ANw7EsJ21JS
V2Hnj2xOnF9AIymoVU2dUS1eg0Ezcuko7BXto4Q47paEJi6PuRNnsExsaYeki5E/nHgUTtkwVjnu
YOjhbI7/t4jWl7Dmrf9GGMxWDLl8+df2J5Z//DcJJK0vbvjv0Mr1B/bO5beNtQzjTeu5pONkGI+T
TMmkU0/G9Vj2sV3ja+6O7cS5EzVVqtCzISIE2iKkFpC6KK16kXpRhU6PzgY2bCrRRZFYsWCPEBtY
ARJig8R/wJ7neScllHBJgXJTv6TJxE7s5Jz88ryX53u/qT/D9Wgw/D9DazSnUEyDE9BGnp7Ruzg9
3cSWFIhcc6ODwBcGh9XljoxvSncnMHUPXZuxFMNgiHI6NcFHiFYKrzidDiNPMe8QvR8MjsBXdXi2
Dk5Yn8YpddOTGLsWwsRQwyChWmFxc7Jlg86sKxWmYq3mZbPcp9Ncb6dXHUS3PqTV0YAbVBSvjEah
M8HEUg0CSaHVAA2nnS3m2pPUzhi9Edn2xIwFE6IPbz/MTQHeWbbtwo0sIxWRz2qeiYxSA0LMRPFA
McAJBuRcGzZhhR3oKRUPbMoWOtgRDGSJvhOX8hQ441eBVqkaMd4dBFCSY6rkWY2bgQpaaSNm+wdR
ve+yQ2wFymDsHFAHs0xBz52TYpaMWtIRKceAqfRz2IkFwriSJBZxML9IUmMm04YM1LCwrelia3s7
ovUorNvvoMB00L456KhygcE3q7ooQb0trV98B7SeKOFv1d9W1/8ZWtG5ScpOOYTBiYlcfbW+sroG
j2Cvt35xcaPNLeWpNk6DTI+MZKrYADcyfuoSz2FB+CwRNEUWPdtorBOdAQyGc+k2z+nAfCfoKuSW
97Z5/NXS9OT6VMvjcH23VYRymi3XRkHW9VDhDc1sM4t5p2HTDUsrGWxIoy84oJ9Q5wt1BP1RRp2t
THlepgdKAwYSphc6GK3mUzQ1vV/zlhZauko3v2n7jdAKEAkjnLd0lLdYg6aemtK+kTHCXqADXTEd
MndVsAApUQI2zEBjFnRUJu0bnqu7diCDo4yAnVORumiTOBY/hqZKswetXQNDFqVShDsQIDt2HhHL
xaxpxPBkHAjDM7WQ7oJWhN54EzdtU+XXMG3F10FaETdDvaNNBvzzIdct67RCCwhP1dN9t1hYb0Ve
pqOwVt/43/8OaAV+sr4RVZX+pL3z1rTyrn/5wpwM62/j+j9Ca5rOwRQVMo1TqjYuzkJLq6tbLfRc
VmZhTt9YrKba3W40xYVlqKS0qpgL4QtHGEPTYszZpmITpsMCb9jM6UzAI9Hhsc3luaUuw2MeYVdd
W5vv5VHI9ZUhw/M1NEJdAGCYtgfVqTTDrGmGteZWLpUp+ig2wUlIhy+pJbbY6ck9nkYnN+1F1aIY
NbaFLUCYsa0TRMfqt/Cw+Bpw6BPYmu9j/2ozazo0GUOKaZAirTx0GZVloBwHiwAV+gfJYg8Tg0lx
yRvxdDHuKlCHhA80ULIeHkKBVOoqhU6qSYCRe+/EfgiUY2y64LvDA4OtiOJ+xc9XEAWHvaYRh0bS
/6sFnqOehh4DcWnp8g8JnhMAs6sjvdfqhi99HnmeaMo43kKIpYGrQo0DRCm9dem3HoU18a5gFVpl
LXAJrYLoocPwc/8VtJ7AePD1v4qrFIZP/Nesv02rMJdmt7Qz3atMcQrTIqxK81uzC5mRXGE6Rw8h
GjyjYtwfTp45eenUaDJJM+wwEJXpMEQed9FnzKuRBM+XzLR54hw35+QQE3dRftpZ7u7AKDG9MV/x
XR0lm0rTQ9bleY5mZG07tJtwPEBlbRyblkm0Q0NHEAtKNbr5GwFbqDQGUO8KmU4PKSE7Iqo9v7mA
p+rO63LiohM2LBWhrt9wQKqOjrGJFm7W90ClBVp5VqRpcayExq3wPtQM+S19EzLqCLBWamGzociu
1UgBNd2HtqImq8g50HbR4PMiiWWyy41wMnJCYlWCCVrxgWyUpYi+3h8AN8j8VsvX8z3X0VDJYuhr
eQVLkZHECovSitSeIfCc2EZaeWJsddrDBR9mUFjlq2TXioJyFvNnM1vcXu8JrUdgHTvqYHo3eSto
JcGHHdivAr3/DlppQpz4K5Vhiuv/Cq1jCYik6CGmCC/N1NdWpleWVtc69e3ZXn0sVV7ppjBqLwVe
R8ZHIa9JBsJnxBTMbJWgjgFcUMo1jBuBMHpB4rXosFDMNmwXWW9mLD3R4UTT8szGas+14kOG08rn
YSX0Ye9RqIFm2GSvFd3+prmSWzJVnuLogC85rVXDUoGHVFPV2dzSet5rOLWwtdSGsGbqpUBh1moh
lLQM4ApEkapSswMxRxhxp2jjHiuEi1GGgss81KgMFQe4LC4BNN2rhcWSDWb6KZmovarxEN9vjMvn
CAvf1DQ5/CNQY6AUuMrmV0bCPOsGEMeAG75YVV0wSMWl1KpGYXLqouvl847GWd4c5mSZWUuh/UI2
0klojrtYThY9FqcEBnszYx1kDiCyKhktnxffMCiHybpZWmxNrgutfwbryKfe2bEZxPHLR2nt++Pd
/zXaeuIyN9D9VVz/Z7SVsKH/wgEv1e4CxpBubtRXa+7qbKtQQAa6kB7DyC3sfOtwXxwbNiPjMPEP
j2BBVLlAKK+prHJrWvwSgJnU8oHJNMWbEKd5ziT6OuUK3EDhZmu7SS8i/AyM6hpeECdatOrb9Nkr
GhyHAds0cY1CyAiTUIHKeMyEqxEnzPI7y2SWZl16k1RA6rgwGsfZyLEdm3vps7aJOrPrG1q40TT9
bHV6vtaA3d82iX8cngs8lcZUFehyY10Au2LT1PqxJI9VLQ4tZ8gNpDwTlasG0BKuTZqepMIU4cqG
Sz/EG1mp+BX1ptqPpDSqCinBxY3ZeZgk2eYllTHwXuH5z/24gWINXpkuE3A+XDTbn4fPcefcAIvL
Ua8osjCTdgDuxwvlCdSZJg86OG/AynJw4cQ7Wp9/w8p0JBL+2lvmrVwE/F2sa2y7/hVc/3ci4RTb
rQmxMnV2uuX2dH1+cj5052eLxZny8nQ5MTqSWVheRscUPkP8jMkE5HV0fJROQ37VMBFOIipOAl68
kH6aERNjNFuQV2njYu4aPbQjJGuivbQ8vVJTNZSTcESOmHtVunORcjooBjVM5Jh2w1D9yPRLQ5Pu
y4gXC1gr7H1S6OCjr8KMgd7uDKY3OWjiAFGD+2RNFI3YsWk6cZiD3SbNFnYjbs2WVyenkBBPtwCq
6/txNohoe3QdvAMucZ/T/hu6hRnnCvLQaIqT6nt4cplBypNgOfXYYKmK9WGWoiiuVDpoq1iSNJ8n
TCGuBt82klKxKxE8tzS5trgdMvumitLkb/oBzVf4efrjtEyw1ETqATtD67On4zHOUoPnX7bpgFkW
ndjNkQFvQ4E7U0bZPWPbpYpQeSCtr2Ht9vWdP/HO1mdFXA9pPUxW5d7j14Tf/cJ5P+bfwPX4R1Bi
/d1P4XpH2po4mHbIFk55c2b94nxhcXVzfrq3ubEAujq5haXe1vJ0NZXmzwlL8Oip0VHGwXgBpiN4
w18Mcsrb8AGasGJxmhBtFYVl7fj1M6GeVV1HswXVpF7PUAKXZneZToYiLos+sCBC7RqsBcfZMSWu
PJlZ+qQUtUhgVcMuVtYv9go2VNUHr9FeneJiXofPOKAlyoe/sJYNXd/xYDOuTrR3Mumx3HqNfwcc
0/CRyarxWt4LtBgfD+4qcWBYtbwOWqOTbXiwB/fNkFu6M8QsFdPImqEAVrDF5qdUhYmtyj4TmGNF
2bc1WppoBQbq2Cu8uTlfAPrSEMLwREenq5Lsi6yKWz+SaYnC5YA5jDAFpgT2HNZZCaqhqmz5wAqJ
OGO73N5ueNmoJny464awjr0DJ/+b4ko2D2klinwnd/Lq0Pt7lFa549+2zvf15V7jOop1SOvbdXCO
Sevh+lfSCuIIGswRdDJVl+fquSnMDdleN91ShjMgdpZWVjdg+213MO0Qvwinzpw6A2kVbwTApDYn
GSJj4Q1UFdUlIDHCZDgHajmsGDUgUkpsxfuUa68WapoS2NlKgfGqRW3FK2nII5WDX99nlMriji5l
Xg0kG2JoUjTiyqgUkoSbkXVacd9CGZdMm2ap2q3m9YDdIMdq2IFdcG3PswwzO5XDt5iaWMgGhqdr
4Np0AGJcDVyPSXEcFqqa4ygxXXfzLtUOCxUmH8JrKGAJeKoW3MZQcZVRazTASbz44jBmqQmXisri
sjj3VV129kjVOOZktzfWF5tZW42zQoWlwejsoKyE1S8LIn0epMoM0oODIaOZiHxPYKmv4imWg52B
tBxDnXMNz6wVK0LrobIiR0HS+k6nBtPs+/3XKWcEpzh/5eKwG/ulv0gr73iXeetRDCTu+0viehxa
P/xQ3ly+fv0yrnh99DPIKl4+lHU5Wg8fPvzwX0TrAWR0NcDLlOvOwMnUsp181naay+mEZJ/tmXJn
dmmCZ1JBPE+dwg/Kv0zD3IBDfR2XNBUgQnmlrJQhqdzt2s7hcfGFMDlJb0cmLNLjWC7PFFT0NxrN
gq+bOtVKJQ6KDkeDbdo8zIJdVEAIjmSTq0bXjgpU8U+ItSyD/Rm4KlD9BbSWj6+0skuYg7Htmdx2
U0OMiwYRbJNOPB6stiHtEwvbNsPlhqH7PiyAgB+e+JrOJyvC8gh4DAOaHWoAUBnCikN+DfRrQIZG
n6PDMjaS2sgHiNIPrYpAR9qz4IwYR8MSERObcaStzDYh0Va4tYLCGP8+EFCE0gy8Ub46rfSLH2NA
1JQazebPwIDoKeeBU1oFWbDKzJgPThlmh0lRpPhmmdlFoZWwvlZWdlqNE+90Rd78Wg27W/8opVi/
WfjOoV8fV79e+Oyf+4SP3sGHI8DvaGHKTVxw/Ut9nGPTen2kmzp1/cPP8OO/XNC6/OFnAPTl1yor
7/5VtL62MoGtnVyuO7VdKeRlF8zidCc9xr/PmaXOxExrOs0fE8yNjw8DWPCaBKykFcdsyOcN40wl
xsC0S+ACC4VggBq9phkGR2ksQuFcdXrdi53W7PymCbsSfUJUJLZOLdMDrYFP/6/PXTd4MXQLqIrT
ME6vPvExxNGP2NWzPSSbYdbzgoaTn8lxgJkNSN2m7ZkEH+EuAC21OXWq4JF+jZG1HwTwEfvxBpG2
kDIXi80AIMPqlM3qMfRdFSChmq6Dp8albNzB/ZauAHKAAjYPQlZ6FdnCIbwxuBQppjQSankPGnkO
n8F4urS4fdHhgT90XigIC+BVhrdZ5lKgGcNUVSDn+ArG1EIr35B2MItwWkLjQcE18nLQagWdZohR
EVr/tHfzzuLgoxtuuH785i0Ca0TnUVf/kTvePa2MhRN/rTB8vCAYLJ6ZdVrlS5cvfwbi+ReZfvjw
+rXRM5cu3bxOVi+TWK5/mZdphO0WIrRQ7+E8mRrcurrmzSx0E4hrJ5Zt37T0AgpO46PwMA3jx8RZ
+ngdh7JCmIfHRxLUVihtKsVElnUmacf+0fEPWxOS4pQobkJKT7BFrdo2JMXvrVYsldWVGKuriELR
bvUCxKh+gEjVQDSsaOy4GlHcq0NfDZ0HWSka7kerFFYGkMZKsGObPTmgPT3FU13DEh5JujgNZpJT
uCM3l4+DOJ1RdYN6rtLJC9ejZRZt+IgNoqyi4WobNOEzPlVCR2+Y6mkZ+CJfCmmnm5/r9XS1yEiB
0Fd2zmoyMZGaC3+Wyv4wz0W2XTuP74RFbfqcNNmq4EC3pQxMI/AAJ8BIpSo67TUa+CL75ThKQk56
JrnRsOMDZmNRbZln4US0HpaDx7D/PHni3a+faX19P/n9n9zwC9yg/e5P4tufM14+uo7eIcNf3tX6
DAzD7FscBsNvSSsIvbZsfnqo2QGul4/CGkXKoxjFHeJQ4+21hRQbntfB9QGy/yytIyKDZDbdbpfr
c+uLvbXtZr5QWZvcmMa80i2PKqbFC+2lbgZF4XH8nPgZz6CMlkxK8wbV4ATglKAYuRLulyCMuGIl
sNjKBa9MXUlsmq2ccneGqaFi96a2bUOVZgm96tDW0HOQHFqWy4NX45KtqoxAQQrYojLGVbz1fR2q
mTV9rMC0KyRzqsPx44lMC0VgtG5C18y6LuQXjFlLI5wYt3CRs08twK9RtSlLHtBuEGovCORGzYcC
k1QZC9Pw2WCiGQESj6XRUAibhBDLxFYGKFIPo9mnPK1ZAmFgaqFLxBlQUsBiJxi2CQqrTLBgrO8x
rlBopeAXAL7IU0zZZIYqaiq5qvwb4DvZn0dOWTeW74DDyX2v2SwKrYcVJkjrp0+8X29sx5kdO1RX
iuvb0Xr5w/GWduGOtp6+HKF3VFmvn5qxBz/1KdTxUVWcX5lbLo+dvHbzOuh+Dexn/olIGMCBoSSS
PfiPyr1mD4MOF+E73HJq2+2JOXh2G5xJdjGRWa7nqKEjENZoX+Ao5JS3jI2z4sS0lr8mhBWPijdR
kZjtIfZwUinktnyXhtCmuwtLRRO42rA71nghVp1BuuZBWqAjELYdUGbHxbkPHTK0BjiFu0Hnjm4t
gPqaXt72OC4YbFbyrj1fTY2kmZyWXAcSnS8iGkbrhodEWsbF4U4HCXVupuBywJMcL6mBfj20HTPg
rgI/YMSNRzezAZurCus4+IZkKwGbsQjH8T2wwjQU75dKESiWRWaAJ+Nh3C7w4WPVdW1WlOj/Z0Xb
8WUjHmJmCrMqmauGB7OGAOdpSVijAhKBFaehdH8kHMY13mNFBn8CLWfasdgF7Q7CYqEmtB7CihLT
iffrzyxNiSOVpuPTCpFMmEO3bv00WL1+NBnFLYD15LIzcIFngl248Gn4YXT0KObnMsOXiDdgBbT/
VE0YcsdeqFC0ms/PVTfzrfnlvOe2SsvV9ex2SYWK6L0cWzHIORMIfeE9PPlH/+HwyChoTUK5kvg9
OYkyMYPrpHR1knxF5zVHPQW8ZDctuOI857ViA4XdxZkNRLHoNUYbOQcho+jiWHhnWoHvQwOhrYq4
EeIqomKSikvUiQMni+iyZKMejCJuoVZbR1UshwggPWPCDcE9RKbHoRJegBZqON2dMYNp5NSZ8kYL
WStBtcBosVkLnZDzEw2Hu9fRq/U8w8DzDcqWVFHTIY3uKDxQHJ4ozaTuKlhkBXUl2Zw6KBQySObk
fuqs4jt5TwGrkZ2X/4B5TGHdmNcSieNiMBZ5lyLHMRu1r/e1kt6D7BUaS6f/eQ6HoZSztkUZl4mp
qmbmW5XSCaxDWNt9feGJ9+tP182+Pk8MAck/j4WPFwhfvlkdevzguw9ueSM3qZJHpPfhqWp44c7j
pw8e3H/w9OMnj2/duHPh7JAeFmaXUuOXgHiUxv7j2ppISVFYZkQs9lrzMzgCyvUalhMuzk+uza+H
VkyHBGYgkClJTEdPXgKr2IiD1HWcwCL2xcI1X4flPwZOeE3SnSjBMWwRdDTxnihDbu90uu3cSsWE
t91ebm8FBizz+CVElwIZHdQ08DmiRW/YUFOpefK0dPxSylQlXOJj7jxBpsoTcxA2I0EMpznnYmM5
NZbZhn0J5mMXPgluxwsDaGsrl1uzYlYpw7y2vVHh4Tq11vbazMoUZp0jinZkCy3/GGhOoHGoi1Rw
VNSd8aRMlnWg77rcdMutrsAEJEZhLfNWvLIDOgTpBbg8AcNw8xVLwUMY+M7xj7Z99kgHRRKjXXhU
We4HAH8yrAms4lq0WczFQihOisQ1X2WJvBJXBgBCq2JlK6WW0PrHpDXxXlr/or3/wL/zZ7Hw8ZT1
+ujmuScvHr24pc0lJbZ9k1a0blKL2p2nL5794AfPn//g2aPvvbj/9PGdOyg2xILWRm4ctWKoK3D9
x90RXCM0H+3MTbaylclKzVQVx64tzhdXq3MFV+/HVBa/nhZUTyFvhqySVsbD48xPxwVMljdGeZEE
xckzyXE6GrH3FSrLKai4IKtcKUTCODqnujHv9582p6vLRdA3xN1hHMhJ959Dl5GMflAZbzJkjEDF
YpEniiwNCJ0J+YUQo9DUaqO/u5ntJMa6JceD2xCJrAeNxRtotbmR2pkyAHk4O4GwPdWtl2xvaqba
WVhaqk7biJwDNolcS8XygRYlsZ+bb3RwTSOE0zBxol1YajoaUgOZwS0eLDnAleYOIod3itCLmF4N
8GdPZzitkGuZIY4CcjQDVQHXrA6BOA5wksIyw1/KKjs+Yjo+H8FKWmk/HIgSV2YMsqUHD4UN9Xwg
I8CM1lJFaH0NK6S1dOL9OmJAtI7Ewsel9fKHN9OLZz/+3t1HT3/qLp+6/ufU4eOHO/bArRfPd/f3
P9rf371395ePfvUCKvv4/J3zqpOfrWaSNxEvf+bwD8BbamuS2SVJSnemOqstd7ZUtH2j0Zyqluvz
GxP1XoUKolmFeg6jc2E7xB4cFJkuYZ26BE9TAvSylTPOzR9JsIr/AEQ2lUus2minrrZTLECxXgyP
Exu4jIcZDeNc2Fr/YKO+vAa5iiEQ5IkSjBJjgFQzWJ0lMwKnBnEFClyKvKj0DlNVdaQGhuZZ3jRm
NdWsItyNc+zcOK6brbm0+IdxG6HycrrTgjyCcn1+giWw9tQcbIs4LHoZe4JspLm1phfYQROq7mga
MlUVUPHoCl0VMTedbK9UDD0XZS84mWRTu6GJWoI9mXpKbGOQZLlN621OuwZu561QYsbJ/dJJpQaz
NtVvMxoGqAROTBaxyB189tOSnAJMHrrBA3HkQ2SwhFXSW3k6NSbxtIKWU2g3XakyiS2CwdKF99L6
17o4Y0frwseqMT08OePeePDLj64+evBtd+4kVfLPaa0bn/740Tdv7+5+8IUv3N7f3//m/t6ru88f
vXiAmPjTg5q7tXPmGgT2hJSb3p7WhHgj2AvNzSxNVVprkzUWZYLWJkyIS5npkotcztyuI5YFrLQd
SomJtALbpLj8mQVwXAakFQXj8WQCmWp9uaDBcd4sLJbxFNTZRBJPJPoaOfy79U0Xsxsmu9WaKke9
nINrh3VhhryEEQa9qJAiSof3DD6pXRIOw2cYkFYdvBpmw5/aqdbi+jr+LiyXwpqJZRelLUMSPXtl
Z9W1AJqGCLu2hb31uXJmmElAaqJTnoEvuDi/NreyVfMh2ag1KcBO5W40g0G4NFz0rJuFoZFeZebR
CsVXolaEw6wei6bGIN9gkdVar7duc4QEU0tOpoBs4nP4MZBUotH/HE4hTigKK4ikOwJhNKSU17K/
9WDUi+SxEaxgntMROXpGvhW4kcOwls8Lra+lNfE+a/0r521sE9fhN2Lh4+ato7PWjfuf7O/dffnk
p2b70uU3MldBt6p/+glo/cIHH3xhd3d3b39vD8hevfv82bd++ODxjU8PKN5kLnnz8ocQajD7jzgP
h0kPjjhfXukZ4er6Rdspub47vzG90k7NzcNN6y4nhkeTYhEe5qAX1piE1/FxaClCYPE2caJEErbE
4bFcp7227uAX3phf2ZypTiSizJiNXQE22rCeK89U9MEhc3K552kKA0Dx60j5JCZ1YIk2CSkXXXb9
cq0qXHHOafJ1g/tUDRMmphJUz5rE35T6fBZgedDBlm05oDbEKKjwouvANYVpC47vmxfr3XJ6BJF7
dMpAJlffqFfLO7nyZN5C8Ct1X1UFDXgeVQVT3CZArwUKUVHmTFZ4sjJpxQVQlVPgFEOlkYIsm7Mb
rsr5LvI3hyjS+s9Nr6CUvic52ZFuQyauDIIPPIpRtQmoyqvUgVl2whL3BD6gsNKRwVCDOUFom9hq
1BRaD2AdoDHi/fpLMPB3/tAw/Da0JhfVGz98BQKf//DxtxeJ6+GdtDFdvzZtfOrWy7t7e1eufOEL
H1y5d+8eLnb3Prq9/+qTR999+vjGnbM+ws3EmZsPQetn3pbWyMLAxDLdnZzMm04rW/Ia8bgXNleX
Nqo4HrLUXJ5IoKAbdVEhr6MY0C9ZK/AcHj41Ok5eqbhsxp48M5Jb2dhZqzmW4YTbc9wkk8vIf59I
w+VVzFPpnWovwO+dUYL93jAwN0xOXhOLjkLJEDRl3ykJlTATcsebeRv32fkcd2ghtQzcwJdTrdbx
0J3NYkiHE0pCoe/zrZvNo4qEwJXjJ3zcZxeWM4jq+cIiNhUfe4Oq9XJ3pRlYTlyT4RCaJgXo01RH
BBgBRxaDXe4C5+AmAscWKS4UYMs5aRE/gFDVg8J0lacxxyiAUE5QyWiXChydEQnKFVSrhECuwU4L
0gpqmcgOCbuQUjZcKaik9aD1SnZpEY7+w8B5oaPIlnXt8DWtYyKtQyfer6MLB3fh1/FIoel4Vqax
cODxi6tAcf/uiycD9tIlBL+H0nr9TGYme7rvztOXV795BeoqCxHxF65cuUKZffXJs2/df3LjxrmY
Vdlh2guHxdtHwgksVG2XZtd6CIXnt2B5b273trcrxa3lTKo+157IIek8MIHwx4OuIhaW0BeYckMl
jdHC7anhiamV+lx+EZparrYJahovhHRMrId4JjmguZ3r7FRna3EM6MybkFEDYzpFXKUdwmyVhLKE
asSGRFsjVZI53Lyf8mvpcgCz4Xvw6IsHojcxNlHfgv0KtAbgFbd7Xq2ZRUzsW5ywZuisObXqaUQF
YBUBg+R5nIuc7s7MzKxsOb7JmrOBZFQGFCsWn82AXQjAi9mfpl6hD0ixtiQ7YqivvBXTRSXxNlvV
dtGKEUkZEh4jl3AQ9qsAnPTGFDmLXUxPeIFGR2VgObqdQL4eJyyVJRFbrMh3gZ7seRSvJMzWLNWx
swgn3BNYB9KK48H/i2YN/Tetvr5P8ZfxUFwF12Owite08+knv9q/feWD/f1f/vBGfy13U26PwuBr
icmip5y9cOHG/edX93YJqtAaQbu399FH+/eYwT6+c+HTSnOqe+Y6+rP8+uPTKpqHgi3aqe2FpeVy
pTTZC4Jwa3vW1f1sqzKXancw7wG7WhED4x+TVAS9Z65dA60QU8TFxPUMtZUup1FMMa0u8JzXxAQB
YOCbppk/2pOewXGvPDCmO7GyvjW1OVWzMImokJUtOJKWAVgoCX+Ryas0JKVwSl5xK1sfGuNUjerL
c2Bp3GWE6jiQPqSqM52ZLTcwPSxubbWdwPVK+aYd2jbZjjuBD8Dn0mOM4SUUjjxXLDylZ6a2Cln2
YdnWBVWoTyNx5W46nmsc+PBmRKVdDnahAka7xvkBGcMbwglhVWJWsFivLuoSEwPlc/0RrdGcGhIZ
hdpDTH1JvsS/MhZCpi8JqfwCcMqPsHgJbuUpaYqUKW2co4hIyHSz2HMktEoQ877G9FdXDEfDH+3i
HM8k3NYvPP3e/u17V6/ufvCDBzcGthPX2D6Vey+PTMbPn72Bdeenv/pkD0hTVgnq1atXP8DrF65A
X6++evbiwY07nzqnZZdHbl5+ePktnYcjcuxqF//am9Pl/NRWUTeR9XloEyLnm88AsRxrwTihij/W
KDo00m8FrqeGcZOo6ympCONkyCRMhZjnRAsxFJU5ocxVA7ZYY7T5w2KBkyJzU7YSR5BKBZvMx0+L
sHC3yaeoJIx8obd4JyWmqDaj0E1wUGPSWMGyHOgl0tDA5XB/s2HRPegUmjUOdrHlrYnOqxvkUTLF
Z9DH7znoplq19tgw/0cl5eRZbqfHgbOZZKINm7SvDCqOr0XdFZqo6G6CVjoNx0I1WAFmNA9KvBpp
IIE7YDY6PxL5sar7+flSGJ2eA4pxNyiNJj0RSx6bpUTNHpBO+g/vGqTQHjIqG14FXCk8SRzNPT+S
J7AApqt+1s5iJvMBrbSgYO/1iffrL60zfX0rFNdDj8QxaUVlqGt86sGjfQFx/+qj+3dOu8uX0EEV
+/6laePGk+++/N73Xn7rxfd+eeU2AI1gFYGF1F7BLbfB693nL7/7MZqwanMu+eHbaStKTAIVTEq5
9vRsu1bL22ahGdLPCt3SejtdzmQSDzCbM+PU2JPSwAGz6NWcGSWtrDwlUWViK5Oj1iJPIrJToVRk
VYrK6ch6iGFqBYuZGExCQ+eaF70YuxuDLKnIJhMIaFyj+Ucc9NKowOKxGJHe0tFlxR0TrRmHW2y4
08axLJRG6fAvlUKzFmZtD/dzhZzg60pbh6GxpefLicjOMSztDpZRUdwew16inUkTE8wU76JJR7AG
5vyAcqopeOHECGXIVBnzSnc0cvUKrkMKWBXXMGk14orl5B1dlUSbsOI/J2CLDmjFR8CTXSF8Ae6Q
YFqOCQCNZDayNkVPQaUV/R2IFp9maED+gCmKjDSOu1Yjm883a+I8FFhTU+9rTH8jFD6XOpK5HpPW
+AXQuoc09Mru/t3v/ejOQK1zLbI7XM8UBh5/99nVK1fu3v3lD55HtALRK1RYYAs53kUCi5T3o2++
evbywZM7F4bCzRFo81vQSlURBeSQ0tXeTN6FncDUVOKD032d9ZkFJK3iSYK/QeYSJJNSZWIMPJ4a
5jsslJiGx+lAHIMRMdpCx1GKuQk+tOBKHwa2pcPej2nD5WrPjg8hKeNvpFNxNHYgCStPBedAejVO
SMGqMBs1WbE450zGFhp6aOpWw4dNEKSGgNH2GmEWWEKwi3if90JkrK5pSp0pi/vhlDAb7PmYk5g2
xcW/LkkZVYOLcdqeJ2Y8nG+jTxY8l+b/BhJg8CBFalUBg4pKhwMiYZnqz4owE1fZjqMIVPQJI5A2
fDN0A10h5LQagq/TfxzhDbzFJyzNWr6wk4MFItXDiUwDUo0SaZUpFnKP6DkYJ6tsRcuA47AE42Wl
VHIPae17Hwj/zVD4iLgeLxIWbf1o7wrUcveD3U++9+RTp1vpKBi+tto4++DZq/3bkNGrr+5BSO/d
A6tYEgnvgthdvMcX7u3uXrmLetONOwPxXgrjKLn57ni0iiuf52Jg5ZbWNjxsboXLXonCLGjLYqcj
XicIEEHl8crEE8qKatN4YkSqTbwtSgKTaOZQs/CwrLN2qxMZqS+Jx58pbIari715TW0QOsoXPbQ0
9D9IK0/0535QMElEYRCmvmLFeCEA8yAbLeD2cstr+KYZIBJGZzVvMxy2i7bbrFVCT7TVDSm5vom0
Djw7vq6zJKW59QQ1VZaUUPkR2U0mx3KrsdNKaWV1iuMRzUK2oSus3gqtcZ31LXqI2GXiXnRRQSFH
g0pK2RpVMKS3igZXRoOtWnETA262UeUkDYEupp5GiA2C+YHU0kAew+rzoB+fS6YVhYU3ZrqkGqCK
6mJav9gr8NB8Xlg5vFbea4aVMCs1YYEVgbB64v36q7vSu0fE9Vi0UlufUls/YFy7u//q5YNbarHK
9un1YW/g1reu7u8Byr19vrv90Tc/+uib+/u3b+/e3rv6wT3GwyK2/Mr9/Vc/YH04Vixfh0fiuLQO
R0P3Exgb0e2UZxenm81Cy9Zkg4l0FsMNGCO4xwatG/xiJ6J+6xnxSIyfGacPEVdos7K8lgSysEeg
xJoi/xM8xxWOfpqXRujvTyREW9vlmfliqNAOwWlDqudq3L6CTWJY56TlSvMS9JUDjAiuxj047KsQ
WvAKm76vA0PfsWBjspslBPC1vJsNa7VKa7G16KJtA3tPnn2cwK3VajYqvY0AaKOHs55JHATASQb2
yQhWwRUpwczazFJuojPTRF+k4upgRijUIOkoKmOBUxKDdwCXBLG/KgTxVOUhpOMa43PN0w14OJhh
o8g0SBajk5PZYsUdKu7h6XMgFV/Pa9neLkLKiBkUc88rA14d9/L2aOMrbpWsV1J7TJWqbOWbns2/
TFI2JK2Zvr7/oil+/22rr89Npd4oCx+T1us7xoWPf7UX0bqLotEnj+5/u7+Yunb54aWF2J2Pn+3v
g0V2WL8AWgEtsL3NBUohsKSVokxkASzqTR/f6S9dgqXp2LSOcDe6DGBJVzMzc0u10F4MEWiKkgGO
YK2eGj6THManAUwQh58O0kp9Ba0ncRtldhS0ToDV4XEEy+MoMOWwJa66gIEumOhEdwTVWepZaMDu
7GBDXjavqTzlBWvI8aCzLIFyUFh0RiJAFXNhJKWIKOVwDYDLafkgzvTpc/BC8oq5NKiyuKViDz7e
IkLCSguD+bNhsYg7imZg4xJhcOBz5DeCVGzEoaQKo1GKzY+E2rEErE0LXRwLsjCpB034uEiLCjjo
IhZbBmWVtA5KLZcLMJMsqKBkk4bu8/xZ3XEsVIBiMYvGD5kLMSBDlSCP0dmQjJLJaAywWmJhBIqy
W1aJNszyLwCemB4uBtKi5JBa+qCkqSuibue38sjQnYJrCq2s6rnv09a/bZBIvyGux6a1a1x48q2r
pFWIu71799GDc0pr4tr1VO/8je/C5RRJKHi9eheu/mc/eP7JJ6ggs3uzd5DDglcCffv2/tXnL5+e
88duwoF8/Eg4wUiYFaBcub683CsiqGoVLFQ/xdTmb2PGy8nkWDc3durSNQS8YJUlYLIqniZiizXO
QHk0CZkdHRvbwWly9frsyuxavbxQX8iNJWggpjYD453y3OZWHu1QOX6NpvX+OMCNBgOeZx+HNlhN
oUUXsBri0rUMLnykk1Zf81Fa8vBiBqbvZWv5LDI3BITNpgt3e7hVKhXydqWYz9OEmC1hP52LFNTx
7aCh1zqweMhifM9qd5IX0S3wMyOBR6BR3fDirt0AD+SJfmF8vwa5IZlsuTKVBKgAScQVrAo+qC+h
0esYARhSORGGIay0YcShPzBADCmsDPTjMvhBA3TUSoopYR4irTHyjZDZ0bBizGXlbpqh6DtWXluZ
rLCYZQhR8uzXtKbP/h+mrYe/w1/H4XX/ZOIqtI4duoWPQSsrSWWj7zFppT4SWES7j+7fOF1aGJ/S
73z86Mpt3kFa90Didx88fXD/hz/84bdevnz07JN74HPv6i5dE/I5ABYm4l89VssnP3NsWseGEbWO
0M0zgbx1ZgXTDhen56aXSnFgQiOsX1mvJk6NddMjJ09eA67Yi46FMtPoyDiZlY9kCzQ4HU/iEub9
hTL2tmxMT8225sud6lxnIsWSclIizZ1yveDEFd8s4TiArDbEU4X7VXYxQC6ardEQTu5gBR6ayrMb
GYRyPyo9vhY8/OJ9cGz0hWlYyocgtYJp5SguFZuuXSkVIbAFbM9eLEFdbS/Mu8VaGMLk6zYc3dlq
JxgJMw4mqYRWFi+p/qyGdZc2N0MVzBlyOg1bqA0Hao5AVyeZLA2BKxqJ4dcXXGHpIIGqZfqQcLiT
w0Aj2YQai28Y9g+A8MGD2WdxjZNjTDmSVsXoVbwAbDAq8TH2yUpK4KsqQabNEciy1Spx8RAfHNmC
ZQYeogY8o3uwYZlpa/+Jf3z9FnOA3/n6CgYy/WOH7kTH2P0TKwFa/0Rcj0/rzboW0UreuCCvUNez
SqlcHIQnYm+XLBLF/Vffe/Dk1o0bt27d4r8nT3/47O7eN7+5vwtFlqQ3evvNRz/V6mdoGT5uJExx
ZTCcSeQwi3RrrYqDkVe6216DfYh+JWg268lkOjcyKvYlJKigk3Ym2CRGI1lFfRi6CWHl9FL8yqdh
NqxurK5vQKcLvTkcfZOjmjFJxNNUp+YxK8IKe5OTU6tbpZqvIBtT5SDUaGCY0Hqak1wcg7N2NRkm
7ENULcPyG6YFjBtorLpoziAYLtpIVkul7VKt1CzipVkrFStFoFsr9ir5fBia+UqlUgyhdxwi45Tq
3FIfEcrCEq8IrFzQ2gX78EhmaaqpndZdU7O0OGlhqsx+kox/kWmD0hxFTYlpJ2ACO1GbyUHUYPlZ
pMtmHPUlGVFIzERcZZ5StLEOYyjwE3F6MaN9ltE0pr/4LNlqrnL+C97pcTnPVY6DlZIwg2fZ+051
54Bl2w/pC3EjnzClFWnr4j8H0uFwpH/t1KTDR/gaBPI/ROv1vr6lN8T12LQuxQ8j4QONRKnp48da
Pn7242/d3Qe+EcV7rx599/79Bw+4JZ170m89uY8m7Cf39vZ3d0EpYcWb3f1HP413T7KmfMwOTjRd
FLhiP1y3utKr1qeXl8vtjYs1k7s3dVRWy0kxDia5Az3iE284UW2cF5E1YhTVp9GkaGyqu4ATq3q2
neepbo1id3mjnGbeiqIUJihO/oG9K42N4i/D/8LuzLSz7TCdHlM67XSns+xsdt1d1u12t6XHsr25
xBbBeiRoRBQ1RtEIJAgBTARijFwa/cIHTDTBK3yQYBMEvINHQjyixiPe8YxHTIyJz/NOS60VLWrj
EX902+nu0i7/f58+7/G8z1tBH1LNDu4YmdyzazKb0hpgwsmkLcIBV5m2hg8nffNN8Ch6NGjZIAg2
kQ5qmosw03M83w1QRjKcsmFx0s2ZymLu1EhVyaoVjGVPZtDUKJFyjQxi41w2my8FAJGLVs7UxEC8
nQe/bTilIEkrPuF7zvMByIgPavv1hiaNzk7cwxNaSqggxIhQGmtixBQoEIdRqTRlRXKFNFmDbsO3
Naa57EstLrXBjczKz6m70H1N0bn9ipQsji3iQwxujQLNHGhooq+poUllWaHKoiki/v+ULXM8AD2e
iI56G/f4uJpjWEtoncDqm3VA6z9vrr/8FXj1zL8JrSwz0Zb+zw0Q11YTTvubliNhwO0IguFDp993
7vjWute//9KzmLUyMUXD5oVnPnAEPZwPnL566W3ve/vZzx0/der4xY++79ILDx0Kn8OJujd/4O2f
M9peza+9Rm7tRcVFtsQl+oYLtUJ6rG+6f2bb6OCgJpNhpqYGkOnBm5+DrYtD6PsY/LL8yywVuO1A
N0ekQb34qW+Gw2F/BmIBP5HeEaBnOze9bTAp3EqT8AEHEW3gIFVTOFBu7A6aQnEwSVUaOE2sM0Xp
m0aZvrioaZ5NGbDn6woaNxaOajoum6g+bkEAcQDsRZGe5vMZRL/ZWcCzkqngGuUnbEzNo/SUCowA
WqbZ6aT8TpVUlY5jNJIiVPkmcOXHeHJ3pKfVzE3mU7pJODFdVjTmoVIWwuF7Wf64pGAOe6sxWqOW
0deN0Xufk4CCVPFs6RH3s7BDK/qomPhTsIQU0vXiMliRSVMRwfUFuBQ5I9VL1CDzTaE8it9W4YyR
7zOphthS0Apq3YX/u//paMX5N6J1S3I5FF4jWmm71JxqfP3102iYottKzOHgGpXhrVsvfARqxOXD
aTm0b1BbOnPmNAD7Xsr5j1++/r5Lh4BX/FVi/er7zyl5cWxaI1qlEIoDtM6M7C+MJQamd2zfn925
N+vEDMAEtgnGtgnIfzFuLnJDHpEIs7dKbpXgmNiFX0Qnx+XiiXmFP3RK88aNXXYkkhsZ2T7WRecX
vDUPeIpp6/Amq6Crgq++fbIe49YgHXAqpq674RXXTQoCXF3CE2oGWgmjUWPotulrTSYkv6VyVAvg
vGRYkEi6YEAwatEtZvZPotaEfWuIjBEJYxNAACtECx9TDqCMXDdm7BgnzwtEGQ3IEbTiyNi8XDTH
Rxp6/KH+PVPIVmnhBpdSxqyUIhKZLPWA53oacY8At5UMq3JuKIW1VHQn9oBsrnZk3rpFA2ZF4yuj
cDRUYkU3bLmyJsy4mi0gvBN3NL2scyW7wl14GkUhwsHcW4CYmQdgjbJaZeF7eZxTQHfqMVqL/4to
XV6H9ZJ/Hq2bkn8RCq/NRa1lVj117m1HEPEKWsOoF9HtW8+fP3v6zYdWoPWlIWYPAbWALeXBmJc7
fu7tV591kk8AEV96/7nPWXuOPrN2tMIsia5K9Czsn8yNDsTnuQYtv6t/yvZcU7fx0+jOzbf0NmMM
XeDKm3RYKbIFWsmv+JRci4SvtyU50NynhEtG92NafY8diTo7qxPCWIw10xkGgMFI1cNPt6622nPK
ZkC0Ua2Xfg58EsRFFzGejnqNZWvI7EwTPRHPA3jLdr0SBFARIqi1yK2BBVbNZCbz1QpKS5VqvgSe
RcWpkrEcJwNrFoC5koGa0qEKcc51+pIEJBAqA3PhFgqSK468Rr7nQM5gqzKRjKd32zEFoNJB7z54
Hi1OIFJnnelxFZgFIcBXrBwAWNeyOBfgIGoGoASeoUafF4wgiEuGv1w3ICvSqeyXyRuJrulxClUl
M/mY7XpGk3ArO88YEjSpWmazVaxhaOhqg1O5Qd4vu9LBobAz9q9B63uALFp581PevdLV+z0rHb9f
zJwU71c9xPt5Pr/yK7xk9TdZ5Sf+/JVoffEaIL9WAwkI1pfJdc3cumEmOHX87KU3PwstmhCVkoS+
4/T73/61M+8gfFcecjAOMct5ufdfP3/q9dc/cubQETR1Tl796PnjzsS+p1EegllDILV0De2AXcpw
sermdlSndk8i+YpqPl0crH6IGro6CNawv0otv4y1glh7N3bhPVtWwlTxsfR21USIiC6jjTy1ud/X
nMlJ7FYXHGD1hh01jZ1TEPaU5iz+kJacLfSMiGiu39SIK7wBsNx2CnyVff4kgj6QB7q2D3JtihqG
4zouBBFFJ2Vh9iQLi4hMKletFjN5CPAc1wKNOhnZtV6xDBeoruQcTtCU/WAkLf7PwvN0fSNYxXiM
txCqPF1dhUwV5sQDw34rFA4mv7sr/VaEoVJrksXMxCipkVlrKCYGHZrh4isx4a+XSBh4JMGypcyZ
N7o90RpD5hSiItBnYCtveK6io2CgApRKOWeUFXonoonLGhSIlfZR0kVqEpijcA6zOU1jrTxEKz10
Gv8VaGXs+bpPLuImhIucRWJ7DKml4FRA+eLVD71kCXorv4IY9q/+Jnxg+awTWpW6OnrmPj1ajzbv
7jl14a1HqFh61nJhGDT51a++8NDLVkE1fFzkSyff8Y4jGEi/fPxz19965tAhCBBPv/d8U77rqWZw
WjrbSS3g1/ikoygGEGFnsrnB6V1AikIHXUe392LnRhvEwZK1claOeSuKRjxgVXRtljabtaeThUym
oCFN62kodsI/rS9rFAsD/C+DnJbqw4wSGyxGWrf0zPa27Wno7lFSW8CtPU16NV/PqrCgFXKmKObC
NcPHKwKpchzOsmkd3KTbBoQ7pWKmGhCrqDKVYJuQKubwJzOZrWYt3I9MFvmjAQWt45k2Lm2wo+WZ
1eGENFsFnWwRyxHsyo1A5jsU3bBMZKArMW02RgAfvgjLjxGodF8U1+/o/iJ1E2BGiY1BsIgWiCh2
hIFc3MOMIFQPglP5RwyCoyrtx8XIUWwkItJNXbImjdDuSWTEZYg6TKkpiThD4bN1oBX4BRuLhirm
ehotb0zkrr69iNaBTf8itBJ+uAKaZN1Fy1fq6r6J/268JheSB+Uhgdhz6r7wzDM/Wv0Q90Ly01es
/ApE66pvwvMY8h9uecE6odVdQuuynmlNfw8OpYXo1lNvv3rk5DIyBZMsBvPP8iFKlwkWThInoW4C
Xs+eP3790hFong4dfuvZj+WaUQ9eO1opGGwLF2HM6BFVR8tem91THa3SdhssiOxR9fPbpvu62jbI
AWYRDnMYR9TQuJKiMGtNsrRqYHRuND4SBWn66Y1A7/5saTDNQVdIMLiEvWs/+ADrhTGKMt3REYBx
tB5yaatS2Q5OpvJQPm+KaB6ACXo1yqBdVIEDGwVQA9GjuAU7QTabClB25sF1tro/n0XndRJyfifj
2LbDVRYyK+cjDqZ7i25W9nBEIWzY8Egg/HgWR6bSAVfRTifG904VoJ30AEtdMX1krtAMizwiVOgC
OaMB2JRXKmeFxNpXrI49VWFBGGDi4A3tf6XIJFAleULmzK4U2FP+Npek015NDGEaoP1QeK9mBlW0
qPjrQafcEnxLE7iUIX4UotHAk2yT67y4MAjNrSW0wnv6X4NWEmJ4sRImsvZ8+SIkxNf99YfCv7MK
aCFaV3+TN/Jv8SM/XSe0ZrAcMsmWK9ljrWiFPhBuhe2V+q3n3gdvCEJx+UBdCGXhEw8lTGfAryfB
wh+9iNz1pS87c+TNV7920RzqCP3A19pvFQcXjsQNZBVVg5C/uG3b4K68C0267Tg69ERecXLbULyt
hVoIJq9iegisdoo+mLJhlocllW1JTAwPzcyjaWNNJuD7PTFSqRR3D9E+gm173sYqsZQSydT3NLpt
7dVIdzcs/qhfgjzdwGebebhOrUHx0WVFump7yBnRKPWhy0d4a/ugUhfzq9nJYoqALKZypRRIdS5b
ShVn80hqYQlu2y4XN/slJ5AVOWEXZhcshxeJFSCVLSGYyV3anyi1YRzxSomnd+3fW6j161t66HFs
cyFd2HDBG2NgvDHyDWPjmMK7qFoQQykxgBMjF8ngm0KNkuSvjKBV01RFAh0DqGUER1xKBa/1vqHT
YQZcPpktayJ8jIrteYSYtR0oSwhwMiti47JX1nUatOp+WSLhBMaR/3VoXQbgSpg853FOybCW2BMs
rX5I3j8Zrau/yWuW90iuhOQb+B2WH/pnThFoXRkK964JrYDVhj325vMfvXRYMPhncAR4//ahTljk
wV99+/X3XnrWy46AX992saE68GrMx64VrRupumNFGMSX3GV4qDtmxmuQMNiYxcpUM76jw/9yatsw
9j0yc6UWQoLeDm7VW9osjQvcz5GzdGF+YnoAvdvk2MRY354KotPs9qmZWoLqRhx8l1ErHcgatmpb
QqsHjXYTsVuiOpoTWwStjIbBNQZWJdOw0OeqVdzg8w0QZgOM35ZSbmlqsgihYS5fAmCzmdlsNZ/J
YUE49LIo/rIqy8VXls042vA1pHtatdAs/VRpJglcOYbAaxxiWHBKwHJDZmGof75vSMVGE25c1g3E
m4rs1WAsXC/FXM6m83imKnJEmTjVWF/Cx3qitfHxXKpcIeSgepIZsMjyda6PDO0PF13RFM/yGPXC
0HnKMPH1FYUg1cjnCLJt+mWEcJX9NzEN6YHJXyRaiFZQ678Orc9/0jJzYdKVO5blGasfksD4CWhd
9U3+Nlqf/69a8ppfidY1cyulwl2TkVOwFIYieNl66aUrPjz5UCh88oVXP/KR0wT3yZd+5NwWa+jo
U6FVrLuhjEjCm2gWwZlu9PcPGiZah+WR4aLLkA67DAvpeAvV/B29Gzb0bsS6OTJTC7mVemGpDNMK
PDGBJbAT+C+Rxr6ekSLalblMLuMMFcCtCUbD+DC2fedQBnMpXqJtKEqdereQaROyty3d2PeDs2lz
N8gJ0afFXcxgNbCjhggTobAN0QUsyaEAnpzNB1DtW6UcVBD52Smo+SsBBv4QBzuabzkovnAfFZsb
ru9Bk6/tSrQ3L/0yFXrlm0TDnUKv4YIQ4JUhexJjCeP9c/WbN21qbI2aKElToIGIGqdeNPjhnJuM
n6ut9CEUkCoK76TFN8tQlCeKYwtNYaBlwjN0uoeLK9MiR0bo400Nv9C2GRh0mCoH2cCnJwDZm3vt
eNWAYMOO0TUilC+jul5GsoBEweSvpiW0bl1ntPJi+bxiBVpXPfRGSUzXjFZGwEsR8XqhNVhEK0Ph
tXIr4SrK/oFsz6mLXzt8WDo44RFBBD//W4ePErB0LOWkzkuhJT67SZl6mg5OS6+EwhzDAf0NG2os
FbiaCiaKWXNVx0WxEUipVEcTyS50aqiLwEH8yEFWXLPOxI9Sd+pKjqEiCWuIgb7xCfDSrj2DU9ks
DQYHanBjGkjEZRNOX250PD1S2VkYLlEtpQKjoFdmdSwyAa+8dTe2goV8A4GwbXt0ykfCanCoPANm
zWanIA2eqmTzVgoNm0o+Ozeby0LBxE6rxYVWhgy/WpofQ3nIZudD256m87gUmcKqkpCrwJbXS7r+
Lhk6Y0Q5NpFVejbhbKnXylRT6UAYhcOL5kyhip/r4qIyAyuN0Vj9EvGxzyOGEZRE4AC1DXRA1DQR
Jyk0F5X2D1Ee1paRi+Qzge35NN/3o6EEAjN4YPTwmyGsV/i968ObApEIXc413/OMx2iFqH8d0bqy
bruCW1c9tHzP59eEVhzksUQkQ+v1QqtWV1eTxHVZzrS2KtNboGTYMKZuhanwyZNS6+V5EkpXw5do
lV4sLuCrBrTWZ58GreQTUkoXb4lphHuujeopNADW1Cw8ebMjY71dAxioqSXaQK1tZFH6RLR1SJGG
fof0EA6TVjowIaqG8VIa2sPa6J69u/rn8nPbh/pkbRUXpNM8MbEd9ZudedfjxqYGq16S1W4IDkXO
FFJrD+RNUAnbgJwNvJYR11powIAnHYNeEdVZWKNBApELnFwmYOemSCGTUUTD1XF84BMxsIeCqRkz
aR8BSgzQam1mpCt4DdNXajp6GdbjM0BWsngaLBOu8cRYv9Eovzq2NNjQC6G6rDKAZbpKJhWDFs6G
A63hFinyn8oBWOocQg0DZR9N4rSEI0sjORwQVcTUkVOtsstKrJKBPShHUN+2UF3CeL0ZgbqJQI55
iJiJa0qltOgidfO7o1hsIJfPW77vp8RFjePDreuM1tX6BD7jydKFj9fhfHhtaF1u87xg3dDaCrQu
h8Jr5lZY8SMYPrAxVw/94SVIl57Mo7QlfQLXAuMhWuFKfHZrffZVT4FWrkkWcu1sQ4A7n9Wz2y0l
ytlSSApMzUHnBjXgzq6xmXT7ho59hGWHEFOor0S7FUExd6Vz+TKwyklW6PY4fbdj2+hM/96pqZn+
cRqVxnHIrHjGRH4uXdhVUSOcJfMiW0il2KcGbt0keSvYDE0cFkNt20Sb1QpMmixBKoAImD4QpVSA
BDWLBk7RCqq5UjGfmnSCDNdC5vJctAyAQ1xh6xAAajaTXigod6bDzHlxtyzRKnkrVRKM7ENmJViF
XBFsTOwBtRKtmxpVF2Um21dVGbklWBELs3pEaKoGy7pEIiEnpSWZWF+yU6I+mG5MNFrDE2T2hnDV
zHBcnX+rlSSqwr4O/1q37GACUBf9BYNjX4Z0VCLWNJtUDuSIdyLDadVxDdMYdQ3PySyh1V5ntBIv
r3sCWuWhVedNRN9aI+HnSOd21ata3pr+zw4XIFOo/UXiuhasPpt7z/d1xqe01289/9GPHDl85Ilo
pW2aIHMlYqmBegxoDLOf3RR5Km6lqp+H5Lqxdz6jb0tmREVupAwNnYt0l8B1YwsUQNAqcWlrPCk/
6YLYDoqDWXPi8mVZISeWpAPQCo+PpdOFmf7peeas8T8zPkR3ZEcw0jczs7fiYm2VWi/ZKrQDdM4F
VAlWJotNKlUE7OIEIBtA0DSNTN7miFwuqCAAnsugg2Pk8hAzTRbRubEcyJeqKRd/I4VWbbkMfBng
RNfkbKrdn+CrILsubVaAF9NiLNxBYuV9RLIsL+CgQ6HSE74YiDdsg+PsMeYInA3H1JvQaSvVhaoq
s+lMYQXJ/IQGh/J+cdMj3mQ/spiu6hoEEFCJ4cVxhasibnF8b0GCVfHQH55LeQqrT7wz5rCwpHDD
juq6jag3t+Izsjp9NZAqmG4AK1ZHZnAQCNfm1hWtPEhJn4DWVQ8tU+6a0PocPG+9D7ZQ/yNoZb+1
d2Z/Sbt4AS6kHz39DnRNCcfV5wj9g6Hqx8OE7eoDnyb6sF3fXF98Gm6l81l7GABClWRFldlxhy4k
MWgMTCU2mdxVyoy2d7IODPJBS5UDcaDIcPt5KCkAq4Jd2bdlGSnOZcpcB5Ue4PKMXbUkGzei85Ib
Z99r24uDO2amh+FWBj5q7CaldpN+gFZgg/DY1O0yjdPRygClAnKURjj5lG0EkxlWl2azmSzgCXXE
CCbiskz3IG3CsI2mldAs5pJl6iJAsDHWh2xrIoEjO3nkhBEQU1Z+lIAhbOOQWqUAkRyMdQOqDNO3
RMsGhAgAGcwjWBYSlyRxfMF0OdlONIOiagpVhJyhk2c0ShxMw2AujSRcVUoZiVYwJpGqii2GouDL
c0LBLZvOYMbyxC6YVK47thnuj4zqgdsoi6okeY4KWk2jTJs4NKuW0Iod4EfXCa2vXCHaXY3W1Q+t
aOfwK/xttDLZXd/D7xEZW0Jr19rQSg/Sox2Jwq7cp88uPLy9cPz1F953FQPmJ5fj3UVlMG7EKlfg
nMTA65L2fxX9osz0geubI8WnzFubadZJz78BC2mQ7XIvk+aVZotBVBvbU9ZSg4XmTpEGh+TTRY7q
WuxLEq40LWXq1y6LbgCJ+ACoKZ7oouchNmsQrGLXL8Ub2h8mJyrFqanBPTsGSxFYJYBbwWAsNPFK
MkUAWKOeB3p6z3NySFZBMB5+JgE/sGk1X53CAHrJyQUZDLPOVovZHH5igwBJLVqQUCuCaQ2PKkAT
wkEdYwRVoDXJWF2iccr3BaeUR8gbDgNh3vDa8frHJoLGTYJVvDVR2U+BP+EYDpmLaz7RGImJyahU
fpjSijchNQ884To5oBXPILjpdQWCjjH6RYkZHVeuiEU1TVP1soYgwlUNNzsy5XhURDREY1QxKmq4
qhXANWJS2CJ6xS0qZmhamSmC6yyhdaxQVzexHmh9OXlz6Z5PLD77eyvQuuqhN34wLPHKE+Qr/G20
vkHCYFUt/WDFa6LY6VP/orz1ADZXCVoTa0brs7k3o7bd/9jFhdt371y7eefhhVP0I8Xax5XkKlPm
sCf9wNVLV8+cROVY6FfuXo1WcKv6VDVhWS0BazRkoDvqW/WSFUVvUcUu/7ndw5ZSaZ6ZSMMyGNvl
OhnsEoKyi4MZIKPnRb/AXnGPoJswEAFICo/GSbOC1jgOwUrHQ9xQHa7tzm8fnKvYOYeL/clgm0Rz
uGXT5q2bid2tnMuBLAHMomlG6O5dtl0IDQ2/UkIIDHwWq5Au5YNKNoWtVFkY6hq0/7ZIgijWOLYB
EADsHAqAzDYLyucGFL4RshIZLEmFpeIkmkOm8fIPxDRSBC+sO+wAQz0oZKiKjD8cb2UtiampgsFU
XHEklZGwGPHjkG+p+5Xn0B6xHqcx7LvIWlp8RKiPT33VL2OKtmx43B4d061MddbxkSKTg3XE9AoO
7WEUzWE3lyfK7XcRzgcB8roPmaXxGK3jdXXWeqCVPzjfmHgO2ZG1oN+2tHwLOeaKZ6x66LWQ97e0
fAkIXPEVnohWGQmQQyXj0lnRt30NIP9PbkifGKuhEPpnXmp/fxK9azD40NmHX39w/96Jdx67cf/2
5VPnz73/I6ePvPnNL13SAssF3g699NLXrp+9/t63XsWjcGSCY8TqYtPL2MHZUt559JkDTxMJt9Ey
CckbCpilVAyWP3ArgNfCjp26MtqSxA8vtIZt6TjS147eZmAP3IqAkkaI7QJZmrgA80JSggWaPCHM
SLIEjHi4BqYioxKt1JyL6+FoNtc/05/SOL4d69m0FRxGZNRt7e7eunnr1m6iFxABF+nIOr0Yh1sN
p0SHlyCftzAAB3LNu7Bw4fxqBYpaRIM+hYq+h/YsJwGAUQN14ZRpazb6pHPye4KvTo6MGQhEQ2UE
IwXecBEO/A6MBY2LSg3E57SPQhQbI8rYRhVrboAPGGyFPp9blHWFhSIAGWwqbiytks2yDIVr/AGz
Cr9GTZ9EKZb+Kkdi9RTauQhpbCgcHHCpjWKTJuvfVR09mhRk/oBmPWBsxAwdf7dV7GMtE9TMGX1V
MUsp27UFrena2DwSs/VAKy9Eky8cGJ5VaF35EIlwtWb/b6D1JRQIT0x8i6B93rqglcLD+bGVLZze
v0ut+4btd1/5+v1rJ47h3Lhx7cHtC6dOXcZ8ufhBrCgkIcR9+2WMn58/+7Wvnjl8GFGx4FgexFl6
2uEzbzvXmOp/9dOglUWWNkJtniEdvZioiINFyuheMzbWRuHsBky1tsQ7qWRqThfAnVJZBVrFfYxF
ZaiaQl9wQJe8xXXKRHUcLFqbh2BC/rtwfxUbr4Tw9Eguv2e4b9bR7azWI6HvZszikFWJVgEvKk8I
NVUyDJIzKgmRpQKSqRRG4VKp6mQWJOsYTo7+hiWyi809GuJRZFtlIBQ1Zc3yDYTGur4bvyWk1CtH
AgPCMzy8FHmEXPOVxodHot14UYArb7iApolopUKJG5KZkzIi5iSutFoo8RdTB7AwTtgSjcokXBTB
My5k6Q1XV2syMQdCjOlcjGWbuseXa+g+snNDx/Q8ilkKFYexsu/kwK06TjS2uyIlaX5pLomHxpGj
fKhU2akK9JWP0dq0Xi5qLwdJMrTl+eKVujr1h6uesuqhN30JfPrllV/hyYdIXHm1OhL+J2vCdYvc
ulRmWkMkTMlh5q0Prt04ePCdx27eeXT70R3g9TIGVi9ef98HDr+ZnoawQDyC0Bgmwi9838XjVxZu
XTi+aPDyQgzgvOMQrfrPHIG9BEwQqY948wfed7lhcuDVb3nLi9aKViJNmo29uxvqtcCKRMSZFEWc
oaFS0NXCydYNHGiNN7Ov2pXonxigSlHIsl1CR8AWO3JYqaFXP3Egw+0kUrTqa2PpWlKckNqBlHh6
LJlohtXwfP+wkZkZ3bEd+XGskbEvqBToQCxMxOIGfDT1ABFR/jxadsqxNZe9VAuQzeRKKATPZnK7
S2i4VlLVoII+q+sGFiJllJFBwxB2eAiFy7YXs7nIUduWwMvgqwrr0lA1iYgfCTuplRNCglTepFa2
d7IJQCVcpe7Fi8aILop6CW2BVrmsNzU/ig/hLmhZciCOhqITFrFSPe8lHdeTWwEzoAxPMQOOrKPD
pIMjgVNd5t5sXzdTMKyQtfDszZrQ8ctaD0TM+UCLhtbDaPEylEYgbPgc1ncoj36M1t0sM/1Xnucu
I5Gsuy6nrq5xYvxp0fqq8aE/fufbxw4eBK1+/eHC1+8du3Hn67cucMD8/W/9yNXT3Pn4Dladzlz9
yNfOXrhy+8Gj28Dr+cvnrr/3/W/7yNUzNAVn5QkHq9ORzb756tsvRLb1wkONqsY19ltJh4hjWybM
udKMgRhLfmUb1dJ0/3wH9EmJto30OuzsSst6jcLe8XgSpBmuyhC1Ab4AeZV7oNoLAyyqtpNckzX8
5IyzPlwbSDQDBZT012oClyR2a8y6+b2DU9tG90ThzMSVwpT3M2sltQpcuR+cO9R03bNRZ7LdIOV7
TNDcXCqoZLbDcgm6RtgZwogU8zguWrO+4xlgKV+jM5LH9XOIow0T9LO/JkE4Kk0JMcuQWvjSdG9Y
dFry7sc/rzbjRMH2+CXSg1QaSOVprIfZAw5FwqRVJcprLzDDLT2yWpYsyt6oipqtwJUYFo84Bgrs
z7Jny4qwU+HaO93DSICv4d/oI8em+sMHACm9IhpdxbSqjom01gSISwG6PTZHfWQNNCNlTTHZvzVc
F4M4IVqxahNlpv5n/ivPkuBw/arDLDLtIVoHngqtB/Zt+P0vv//tEwevPbh1BZWmmwePEbcLNFy6
fPbt73vb6TNcA3ladj6+/tbX79y8ee3+o4UL2Dl3nE9421VQMM5hwSzM+0+++asfPR+beRWKzQDr
2tBKbsQfDKO3JQvZQdnfG0PJ0i1O1goJrlOOt20EuW5sHh1BZNueKIym00gAJeiXmJdEBGLiovHQ
lIzzPKQn/tyMJWtjYyA0RphYYpeuobWTFAPj9PzOYjCyd3B4uN+qF8uIhlZ2NyUS3tQtpWEiuIHk
qlFXZ/mgD9+ndseGA1POySIehkDPNVAMZoGJ0+uuAYR6kBNzGBbH3+OZvumjabJ9HA78aATHJZQP
/ciXejYsBzOmD9f3MLku7Fcawak8Egrz4CXGNBmuIepIk1TsqpbjhyValo6oclBUloxUolcIV0YA
xGkfR6nnemgGwIaLhBoVMTxdU3lwP0reeV+jcxrtWMUC3UrN2gaeZTjZagrTA4A6aVWGC0jH+BxQ
N000gJa4daJAXf9/5XmJlKOEWonbdThUCRdWorVtbcrDt3z3l7/5/s27C7du379249jBa/fv3n1w
/+7thSsXzr/73Z87d+4szrmLFy9eufXw7r0bSG9PXLtz99HX8QSYHn7uIspOX3vbpUuncc4cOfyy
k4ffeu64UXsLVRdrRmvYzJD+49i2FIz28FsfM6UlK79nOg5fwy6idd+G3qGYPQHwJQt980CtcCuI
VTa0gqwWf+jJsLxqlrYru65pKBAJa86goVxZGE/jL8u0d23X/ky2f3qi0D8Skwn0elDsJp4tjIQl
lcWkK6ezNRaauPvcSoEqLQjsU1DwlyqVDHLWSYzjIBgG7wLLZQ8E68VAWSYgjhtU+Cg7xRB4bptI
19BQ4q8OxsJsQjGseNw4DsWIMn8DCp7INTEuZ+mL7/iellFAa4TrM+p5ZJhNNY0UW6O8JsE2AEo6
iRLwCx26wcKENy3SZGOkWtbgo8gxA13nvo6IEgqQ0Xc1nHy+EsB7AoeP+q6qOSkKn9GpyWQrji+r
vMKVmPWAt+f6uIjonmcCuMtobfivtf9eLlGtl0xi6z+EVm4yf8t3f/yrnzy69fX7NwHFm3dvC4Pe
Q2B8C7bB4YEX6QKT2oMHT5xA7fjgjZvX8ATg9TgfOgcr8Pe99a3w8Of56IUet79j476jBw7Q9vDZ
a0Ar7a5D+WFLYdADbZBc/ZyLMqpTgyY4mYbtd0t8R2W6PT3eNz8wPz2OWFLmF8JZlTAXDPVBnYuV
1S4Kl2TzKxo4eJBBcDI9P14YH6s1M8vtbIflUf9grFgYLwztsSiK6ImSW4nRrRIMAyr1iphlq+QN
W4DoIiWlyC5locGagte3gZoTZf4IlIOKa4vzdhlRo2vh0vWIAA/YRR5Z7CuMpfnCw9ECIlZSV1xL
sWl5ZK45XusbUohPptJMXgWriNbZRCFf4jAdJUZjHiRUWjR0exGBYEwFE9rsn4bAopSiPsx0wccy
k+q70PWylKsL+HQvpvArcISilA8cT9W4lF0D6XqVfH6uarpesH0y67CILDsU+BaNmUzpzUijGDah
U7WM1pm6upZn/jsPRcU8n1kfZmUgbPwj3ErXX8D1l9/69c9+8n0y68KVhQcoEd+4ee/+AzLoLRwI
Jx7dv3Pv5gmi9eAxlKQAWDzh7qPbDxeuXLl4+TLeLoN/eTt/6vhn/5CfHY0fJVrXwq3UATKaZe9i
etKOClpV+uRHlfIoRPzJQhvC4IHtiY5OrF2tDYyPIxKmB4TsE5eh1XRC4uEwtOQNAOADxPFAkggB
RsCxWItDbm1uw4xdW3N6sL9PjQ5OzE/vyEgkDNd+ETKxJNwdloXhkCLbIdncSCEWBsWaJjRNKTRs
MHiTykgdmGMolk1tYgrJqg8qlrqUZ0MloXk+JPIgsEgwPCFDUnLS8rFdpuN4lnzUwhJTstC/v4F8
ytuidBlXJHoVWSIYlIr9EK+2NWhq7HvJkhyFaGVYys6MGqN/krj1Ly9SZgdZtx2XLRoCH3EtXZqi
PDGQKRrGjIDZ29WJ66ASTFYh2ioNzmEVtKXHQnNThREwRxZ8HWoN+aaauZy39sGE85n/n792BuH9
XXj6vFXOi6A9/P0vfvHLX/30+z9/ePzWXVAooHj/2k0g8s79Bw8eAKkIgQFRwDU8x975TkAWOe4d
QPbrDx8+XACmF25duUJs30a96l1mrr/9KOC6BrRSg0+K7ELqWstrCN2kgqnZXMySa97QW5vu2NfZ
XJiAQURyYiweT9eQtPLp7N+IBh5/e6l9KeyEC+JA+qtg11oCkia2L8dr42PjAxQowIUC3Lp3uF9t
1If7duxyGinjb+oBKPgm5LpJWq5IXFmVAVuC6zGarjMeRqsjD6w6FUylUw2BfDVAIxbvg8B1Haas
vlk2IZGIeR4gbgC/Uezew8uWGIDLah+rJNraBbXiTsWiE1PxgenRFHQa9IdiW4lwxY1oBaAUE5Va
IVgpAJuGVda5CFK2QvO9iioX0RchD6NyHK5d5QXxTa2hZmIG11Rl8IZMaYIkVWiQEQTgIUPjnci5
bRTN0LLKjRTztMqaQoZumJ7YhUdUMbiDcAT1M660xVfQlyLhcaA18l8bCq/z4Q9/X+HpOziEqsD1
wKtf/d0f//h3b7t84fY1cOf92wsPH1wjg+LcuHEDMF0+Jx6jFk/AM67duwdU4zxAyktoX7t399aF
dxuoDK+NW6kX7BU1YVvSUFht5E+ZY1ETp+zt3ZgudELSPz6wYUNbfCwJr/1CjbQEAqUQiISEfzET
vnBqdFEdLwJ/cmoNmWK6bywZr9XSlCeIciIuwfJY367I5sb88Mxuo5GRcJggQh4hXdcwWQRY8cOp
lRHy0QPCxDtwp1+GMjawadRv4gZ2BaeiYGPhA9nW8Knkg5sCm7Q2bQHBVoMiVWbUT0DKBY6gNgwM
FlWHeOEDfbkGgjTkemFXXLPhWl8Fa1LZL2ClRwSUmlTyI0XFZ4yHwyxUQS+WmSwgSnsX2c3aSEvR
UNtbgtkbF72Lozi4WANSyyJ18DX0l6PM1E3NNGxm4zBztHJz2QyRyTqw9MRjusrxfJX2anK9jFZy
61Bd3egz/z+rz7Pr6oohWgf+EbSiN4oM9tXf/cofXn/u0bdRR/r6lSu3798Ed95Hsnos5NXHIGVA
zAO08gjLnriBc+3etWsA97F3nrj26NbxRmtm3wFZuvx3a8LtdCcNxbtWlN1BWhukqhq9u4LmjYk0
0tbmWhfGcNqh/MfeDHRy+FfYpJXAd1ENIhM5ONwERZYiDuLgVmxcHk4k5yn0Ep8V6JsGiNl4sn8K
Ji/K7h1TfiO1ETKaxne4SZ2JeSNNxxAJa2ZYMtI0NheplbBcqBGDwIcY0QWpWhxABzghoTBdjMNy
4xVQTfEhezpKNKgRigJRfuR7firpK4/0c/C5ZNy7I/RhZLIqLdcQuZgRqp8lNkCcMI7g2nZWhF1D
Q75K9BKrhKtoKBY/FQFF0+KuV4AaB5Dzncp2y9eR2dKGjfCnmUuIWl2lFKLsmQ6ieEhBuH02AwsO
RBC6inqZpLToD0EzQn8XfMqWW8y0PT9UHgpap/+/Hf2vn80IhPsKi1qmVcrDtRm+YClcs9Xzh2/9
9Ns3H9y6cPveiWMn7jy6tfDg3rWbRGZ4wovlT+Xg4p08xC4+HDwBrcWDh8eb3NpR7pn7e2gF8pbY
ZmCHxZ8uCGhgiDRlRFQ4285AvbQPkXCyfR+kwIhhuZIqHv6kcyqH+a78c6k7hNgYg664EpE86syc
nRsrDI/0dyXHAVb+NVHMExGoOo0aPWBPv1q1m9jSXEwPmSCKJAEH3MrCDjDKpeYsxqgGi5/cf4M3
sCvgiZwVYHU9wDVwHHZw7LLrG2aMZMwVbsB51NzJbw9fN2ndSIdJTF0IVZE04x52ivnCEjWrZzMp
FTgVuDIaFlfyViXKxJWcKep8hRIH3yRhypCMGIAzexXuZWBMjDYIXnFwL6Nlw4T0Kp+jWxp36EWZ
f2LWyGclG8p+RaPVuGO7rmlyp3sGeEXmGtiaiQS3rKuskUdYQg4IcMiECVwQcfmxThhoLf7XCiTW
99TVNS2hNbk2tL6IZ3mzFK4PvOXofLlp8Cs//g0qxLfu3njnO8GQV27feXCX1eITi6GvHODxMVqX
7lqCLO/FJepV5xsGO14t3+FFf5tbkbImkGCODu4enXXr63UFAV6uqLoIu8ANZkdnYuO+DvyD4EqK
mLcX+WY6CcUSQBo6e7aHkvhOwSstYADXdsEuy03YXbwjNZpsTxbIrNMZ1Gas6TgZbGB8l9EobVbI
HhqFxBbbJcQIgCrkyj2mVBNoZlmjvl+0dqDWlI+Ck0ZHFOSpDjqwaMZydMy1oBO2NYbHrB+XDVAO
cl1dr8qQbfPYcByolKJYOPYnVoyMARgTEawDkDwNyqvolkowPwCoUgdrIghF+qCSPEGiLGFBR6gQ
qIJU/IZrrZdKMD5w7SoVxLK0hjYvHKuBPLiYmq1UUBnjEh1QI0XAIEy6TpkmIgP+bvIhzfLsEoQg
vm2Uqk42N2k7vq+DWxWF/x1Iq9RWWLhD10mzjvsYrROF6f7/k+tfOxYyBKB1HGhd48QcA1TB62PA
Aq0bhvTI+Ku++/Lf/frtj+4Ad/ceHl+4e+3RAjuxi2hdQuNfJLISJy+dsM9zA8FwrrZPbJ/e8jfR
Gu8qoBa0PShxmiUlGlhkUxXdSrnislnbmOjd1wE+Qs+1kwWpRK1GPhaHGDlyIS4M4mHagdMMUwla
MjDq7ZucHMMMwARm0/c3kUtbW40ktEIT25wGqdy0xiydVCZjpKGvylagRf5shvQwKktOfZ1iYY/l
YQqbUo4LEYHhQfnj0jgKVIuMFhc28ao7JQvHYChpozKDMw07qN1wF3b275yRXe0M/inkwBvbOggY
2sj7KKKN7dLRQRJZhLwBqWzk9FCdT9qEzWBJREpR1UtVPA3lIVzzHctGOAAqLkOfJmar4j8q3MrW
S9muZIoBku2cpcbEE1YKySb/nfzlYhmAH8IH24KOMp8PIPTIzOaLTh4b+8r0+KeBMOXCeC5uhsrD
dZm+vTTfCrT29cN86MAz/z+rB9H7p9GaWOt8K7NUgpRIFbyGd7XPxrR2oPb3X/nj737ybYzkLFx4
cPPbqBghiSWHvhNVpxu8OHFT2jnCpkSnsOzyRz4DYsYHCx+aasY3+nvcilpQe9c2NTMRT4/mDTqY
UCpnQOpm6SYIIoOa6YZORI29+xALg4iSLOtKzwPcuuiagms490N/CGYVW3CyLKxjWJMatabJYem+
wnAKSWewbYepBOn0YMZr7Rb3tAZTV3qETRl9smWylLxuBXDpngCuofs9CIRXLt1C3QBxIq0MORDq
upbFRmsAhjVyga/Rq0hm5+AWzsds06n17bYBK5RsPdvOzSSESdsXTV2YQw804ySxcbpvr7eFLyYk
1h50WQlVvJSmHgW0qugYI9hpxqKMfNEehayRFmcx8WtSJArmAZxxzaG5RZkir4BCNoCDPMJ4z7cc
lKMEsYrKopGJqpHlsk6mQQDiBRaihlwRPWYLzqvZHBIGy4sxWGY0rGsmN+YhV1fwCa1j4ESzAq1o
ufY88/+zavxmqL9vVQPniWglOPnh6NFXHSWYFhF7IJExg44XveWZA+zn/Ib9nIU7B4/dXXj9hdv3
DxKtN+5jDPYYQHvn0f2bAO8JiJ+AVzwm+SpbPFKPusEPx+49OmuNP/stb/l7aO3qQhw7ZRfQ10gO
+vTbjDKgs/WIq2ncnLS3PQkLGCjyW+Aa3DZdSE+kk1JDlU0ZzYz8ya0If5HIAqi0OEKgjAkAfEhO
DFW3ifigfWLP1LYC6zjzpQxMvyINpC2mpmoQg/uRiBDIrgSplJhCP4kGyf4Y9wmjxDSK7HQfNRgX
d4BzWQJO+bRWqwQOGjpuYPgELtjLKPmuuCT6RtHWVNHAAxVs7TjFYakFS8pOe/v5MTAswTo6GRPn
GaksdUsTh82lHvSX8HtFyrKT+exutmpi2BiLMjSrxBxiU8VKOLoolJC2NfLbcMJONtfgSgFY3VTK
zRumEeRcZK4AG1f5oQdraWUTQmHXVfRiSrPsYmCU4OnoT2KD3lxxLlOpWIDrn9i7Etim/jrORt/R
vW6P8hg84Mnb6ht7D5r2Mbqupdu6lm0t7HJ2OINRpjExGqZO0XiMxCzqUIPL4gk4IAOFBIxERMIh
eAeJRqOiiUe8YozGW+MRjfr5/N7cGJsHXvH6beu6ttt/+9NPP9/j8/18EThAeUFNpWtCVJl1yLL4
ftwUcOtCUXhfG3ZXHVjz//No+2b/PqL1r3R6oYJp/MjhzRhSgSPD4fGnLqB1r2FXql/72t1rXvtU
9HOe9ZOzP3vj297+TNSL3vL5DwOaL3/lh2+87/MfBlrf/cH3ff5tr3z721kFXiwUM0bmByrCb2Pk
/PZ33/rAlf1A6+6/NIODeHVDTklyhjwr9kbUIyyTVAW8YVI0pyNQ3IhBdKxkg13RUFdPN7hVrPsX
G4qFSELYquGSSmEcuJcK2OJPbEmM9jQG5mQYtoOlxEaYf2uZUA0RIfhLSiUkWPQHyGW7hFfEIVZq
QzUKwKqINa6kkCjplfmdzvXHiIpBUy4CYRcCJwvFYd2yGBY7uOIaLm7xsmlksNTlyiEtAiCzMUno
ju7F785YmIza3NsGUtrZ2le0QkiicQhWft4u+qx4316L4pCrh8DOkYJJq1LVLnCSANwWEqVevFPg
CzWHcAqOcNSGapMoh1lFysvU20YOil8MNTGom/G7MBNlo9WGlgMyLNsw6w3fA8laSaOSwJJ3GGVk
U4nhArRMMfhhIBUwaPmdibu2jsIxsY4PBen8crR2/vtnrk+CJvhfeULIWtuWofXP+gkLYG7YX7FM
1ERQaUi0VPMmOB+2xJL7j5B5RXw8/s3Nm774k+9//Yc3XvG+j7yTDErp/wffBhJ925dfcePD73w7
bvgUlE8E69tugXRfzhD5w+9+960v3/ggpttf+c6PvnXn+FOB1j/PrdA4oNHqKIWW1gI0NJTohNRE
HBEb+FVBfUTuxkbWzdWi2PuExs59Ld2YmANI2WTFAVjZPRVz3TQ3CjYYg2RBrZua9rYlWvFoPBzh
MmAPrPcn+wtWvQh9UWvdVZNvG43UiWyVEBHpKo8IhMGt0MCKjoUKxKJpAaggEBa9SAA45iDmdcys
YcFYApGlR32/pTMIxoiOa0A3b3g+2DUqaRkNqgnUkvGNpomUV7P1DkwjgFs5v9e6r3Vvd2tnezJa
w9eNgFzJ9g1i9oaBQEOD4acVU9RxI+RTzcnCdhEMG4yo8/UAYarYoayIUhROoOoNLVSnQOyO4ZWy
upHwYhnDjVuQBPNWrps0Ed/zN3OcMAeJQMF+oTgyAnpN+IWEP5IqJ3ybDnGAK9kVUUMMWTm32y4I
omPCTzgoCjMUNv7t5Yf/4peTI0gOOtsWGziNf8lPGDg80NifVZXbF+9f/eQ9ORLvgEoQHHikS7bz
G3GVX0CXj4/x7/745z943Rved+udKAojtH0LcItGDdGKm6AqfguuPJNR70c/D80/UPvBz3/0w7du
vA/VKSS4b/vBF8d3P/0vVZnQGaWcKQf1jcP+IJMsOdFqw/pHlXUVKVkBPsE0SoPVSzVmchq7u3ci
egw0ERuCpgcZlp1Xrolk2orOK7C9EWbg/fv2NAHZra3Nm5o60gmVbvrlvrxSw/iSECg3761w2oWH
vRJeNAhBU90uYeAvcx0bAMDNqYyEVRIsHcFt0AzEBPjkZblzOQoFMbJYesGkQU62QWMJ8K1neDp7
tNyiDmoF0Dn6YkZdRTJ2ChUi/Bnb2vZ3DkBSVF/LgjTkwYJWuZ8H1+C7FN6OG8MUIdgo1SrUC6K1
5PmeDrNiTZMUuPlLEdwt65quctVXYJGWUaKAdtD3UUjqhuulEy7khI4WYxsKTRngnuu4dBAsK8JW
2lVckK/pWOVSyU8nR8rxkot9l4Mjvmt6GVtFYKGxc5XlTiDKKmP4EiP35hJaReL6d5Lrs1aZL/3P
Rit6rTDNFbrDv8KrfzekEAcOFuQT9z85f+HsmTtnL98NR/zGw0DmEwe31Wp9G8cRJz8VkgZWjJ8+
/s1v7hw98Zoffhu8+fJbN97yqQ+//JlA6edf8SkB4Fufev37Poh2DlkWcwHA8afe9+oP4os3fOCj
70TE/I3vPhVo/ct56xNo9tKjhGUzJIshkpDXlUXpMw75IfeG9tAFEDFuYPK9vqW1h1omsCpYORAa
AM7URJBXgxyWjVfuQW/raGrqRoQZTfc0t3UiE06MGCoQ5IRqEeRi+1oBYMlJEPIHY99BOIz3RWqt
l9QIoQp6FXymmkjxdBMpHtXAKp7xSAM9VGYs38jalB5mgVLXwzU4iyUt10ulsqgyWaioGqRZ8JcW
Q+sH9kdSWO1E1orQce++4WIxFarhhO26QMUf/DqigQN6ZE4AAYImRwALCjQgDVT0eDluaQ7boFII
M3IRYBK8b0YsG+F2BrGyRpBqdL/AA+So42R8I1+qeFbcs1BGyqY9MY4TpbW44ahoEtuoBeNPi9Bk
FS9sRawMGS0gUXaz2HhpeDoZNaYCsRb2FZRKmGvgdjn+TRlvcQ8OtYcMhSGJdf4t0fpCztf8abSK
+//xpxF6/s79y4tMC2jdujpaqzHlfOLBhUuzUzsmz03duXD5/kU31zSOm3dVbUn2BitsdgcqJ5As
BtVO/OwH3//611/+ESDybQyJ3/nBt3zqo+9++Svfjkm7V3z53VQgfhjyJ4gW3/359734Ux9+20ff
8oYPQLj47Z98l1DF+5/fjY5fFf4JzegDSoYk1HJKxHXlkFryWNisrzXAnZQnbqgmua7HIIuYWhES
KOA40OxtJlSFDwODYJLrka2N3X37Grv2t5SQmVodyNJQPkmkFbgtSHW1KAZrfqEZHaFcBLM3Aq1C
0i8gW7tLBMfc+a+Se5ibMdQUW8o1B1kEHZoyNtCqQ/Fu25xG9y1Tz1pZq+jH07Zn64VCBWsiSwUL
YWVWj8QYIcMhxlLY9uCBWhDK5+bm7r2dwwlDwQ6MQJ7BC34OhBoNNFHCoxmEZqB3lE0KFJSYns5X
4hDoo3ekAJSOimOqnPhJ65oBZQatH6BV5ihNhPG8wZV4yUT7aDxOnTCUHPiFUhHVMlSBVGTgMVyi
RuYgCQcBJ0axQcTLDxb5ULomW2mG+TFVh1rai7d7pUHPjIUgAaEgxAq4dTFxBbliCfjh/6P1oad9
12IgvLwkvHXV+tLhndmaU588M33u3MyhY4dOTk5emr86Fxt94hNGtKqqbfHWI7vHx1F4EmilNXj1
Pm3u5vWffOPbX//IjU99EBhFXekjH/gUElj0WG99+RWf+vAzwbLvvHXj9QyYP3zjFchtP3zjLW+5
9cpnfv/H31yzmzXhvxQJc7RzczuLmGHu3eYEl0qxTiKONFYJ14a6KOtl/QjkuhHqCGHyIqZB8dEI
it2wnlcDSQTPZrLrkSNP2Dd0sLu92Klj6bDfDgYIhTVYyTTUalLtNjZGIrkuzOYMRZgqCm7FrQG5
gt9ERZhFVDAZIsUYBbLBjDYbr0j8AVMuaY1zICeJbctJpK+2m8TGuXg6nvYTsO7X46XSqKHpoB9V
M/wkqDWbNOBMJlomnHyJ723CCG4r99WGMUQQwBT9miAUXqg3RUP0KTQcjgcYsgnqs7WI7RUGU/GM
DoyxZ6rqlOSbigmEpi2dLqksNEElCTDFqOaNmR5I388jvHVBiQaPbcK7vMvSTVauQduBEIuJuOfq
iZFUKlks5gdHbdtLJkupZIF+w5ajITBQvVQuXi4bCLvpSq5SEi0I5OFQuAv/zv9H68JpqKoaALUK
bcRSICxUwquidfeR9WXp1NUzU+eOzhybmDg0cfRl06fPPlC0rt5yFDNOxfXjTz38xK0HxqGfCKj4
QKt66vKZc1/6xjd+8Nvf/uDbX//2t4FJ1JHeRn3Tuz/6hk995J28Br4FTBEkv+EVN96GVi2++PrP
vwu0Pv0v+jKBCrkqzgZ/0Nk6hiem41oRSOa0JIJPbtXX9je2oD+zWezUaGzphvYpUBESo2KChQZH
KDIhayXNbgazkmOb+D/Gjqp1dUqkMy7HZMjbg0UTWLa8jSlhJNW592BfbLsYjyORBePfbHPiwFcb
UGWqSpAiPaRvGKCbMfWkxRoSQJpGLAgdrQ8YIFSki78H6YRveX664pWSlULcVHRHaN4RuSazthdT
AAqo4mkIgxKzPQQq6ko4YRAraZ1wxQkCYXGFZaZtXJGMNBg9GuSWOuFnlEa6isko7SxUmqFx5Q5m
9GJYA+clIK9S2IXV2JWJoM1KykQcEE+P5osFNw7VFXfSAqA2IG7GGKnbINeoZSItTcNs1a6MtPe1
++URLP6CqB9BSaWUNvA6BI2EysS9MjyayKVtVYtQygRll7eEVnZcGQp3FauqpH8IWj++sJpm4crH
AleWp/xSLKR6FGVPFh4t31p6mnFXBk3Qli22epFA65PET1syR3z2Q/f/Qw+GCJWuIBBepo34k9z6
9PVFZdvVC5NHD42NHTq0Y8eOsbFjL5u8c/OikcxG0SHYc+SpG3rzg/s3Ea0C3odb1FOfvXZ8Zmxs
anb2S1968je+8Y3vf+8HP/zh94Dbr3/91gc+8HnEvFAgorb0qVvPfOVH3/eK991CrPyBGz/8xne/
Oc6Rgb/keYizGdPhERaD8QZdnJweTgRGXWgoKI5WEza7mzZsFMtu0PHoOUj/heDvJFiZvIrl6hQK
b2D+yosnMm0dyOXgVo2t4GElMaJA7SM8s2uwTE7COrktDWCxkJ71nS1CvCSam0vjaXAErUfNhodh
pGo6SGCJ1hhqRJiV8w0ueEokANUURsriKJ2mvEQ2nrUsP4nFG6illjFoxrJSRgUJw7FXd1GJl2Uv
6dOHF0RpgrLNtp6WnC/DeTyoSeOXaWCzlxks3hq2k+ohWJZRATJ08KqDKXeA1E2O5PJZO17Qolx3
zAFyO4MoOcLyVgnsKEsSEmQN3wEulBHc2mjepEr9oz5HhqBCAmBV/EQF5Ag4ltI+CDWmZxHsxoBs
u31oMFHKD3eWR+En4btGKpkyqOKCshL1qXQhnx8Z1LmOi81W1N/SlQCtTQ+Fwl0glPV/P1ppCvrT
3rcAhMDUdzbM0jKJaH1L1Sdwa9VqaKVnyxfWfPEt/Jorq57zjiULww2/rPq0kOZW4bznM/xpNI34
yoYNn6uqWrr/H3p2Mw5eLRBenVtJlZ2ZbXPzl47OHDo0tiM4hw4dm75z/uIcpGtGcetTx9vicljv
ZKFJtHIO90bBrS+b2bFjYsehk2NjX/rSl/DxoQ8BtcDtDy4/uPG9738duP0eCk0f/PbXb914w5s/
+O6v//B17/rtj775WuGl9te4f2/cvFVRKJALQYyA1W5mDAksdBIWYz+I58I5LG+l3GEjNLawgOAf
yq4MCBU92IVhlsCXl+9CIoF7mvoMuSaihcGmISOLfcS4Vk+dARaf1wiVECCJck2GuAgiYWKV/ipk
NQjnI+zViNEUVFEQ7tEdLatzzw0mPj3f8ONooriVVGKEbckUuDOO4BE6iRTWbsAfvGLENBlCeR15
oscEEyGlZakgR02iUYPJRpCe6yw5NcHEDX+NgFKDDg5thEXvtSFMSjVxZLRZbA4Q+MX+YgFkB1Ek
fgwnDjLQ4aMprFumX8hyV0bGcQIGZzE5wbZSoR1l3qjFv8XOgCV1hz/VxlL3BOrYVsqJpS03w0Ug
xjBarMVc175i2Uhj+6WfKFWS9IujNMQxUvn2oQIM1ijXMEHrsD3UBVqXh8IdVRAg/r1oJUbF56ct
K+a+lExImL1oJVp5nXcKqPNWuoI/ZWUk/IzFn7742H9KJMznfJ+g1lZQ67IBnFXRikbrgXLNrrvX
pmcmiNXggGSPTp6+fGJbKDXUfGTNeF7bUhXOj3MP8+6AW5G3Hj22Y+LYsWMTALf4ppNALM5PZi/M
/+x75FsEyj/7wC+/9/0fvPfEG970vZ//4mujbb9CD/evQKugQ1jta0pgQyIpHPPSJdrzSVhk7Dlh
DGeWWYvaEKx02tnWA2qFPIJopTZicWdbMN/KBJaQxbROb1JCSmfI3OgEjXttLXfK4Z2bibFamYmh
UCs1MG1l0hiwKq5zDj0EPoVyH8ylRhyVQzYx6AvxjooSjEkThUQpkRhtL5VylXKpMpi0kkCu78d9
7MlBVFxKFIYNCZM4oukC+oGTZ8oG94G3vLitmch8qYWKRN2SWb+dMMUHD66xwRREwzxUMyMxZTka
4KYOw7TTiUp7hflx0lBVAhImowA/DljXiNtOREL4DhWzIiRYdLOwUAWulFN0wFA0aA9ZLcuozLZt
P5mOQxfFLquLvg6FElaqWC7kcu0dRT9dLowWynm/5CfLccPlAK9VSA0Psi8eCgW9IcQcGSElXQiF
A3Lt6hjAP/XfjdYXEn48j6CVMCU2V6KV9z734QeLh/+JvPVJ4tPig/4ZaJWqqhIdQGsgjVgRCK9A
61PXHG62tzV88vS5sUMTglZ5JibGxiYnT8+fUDvhLLpmPFGza5eUG2fYLHZFdmq3508jcsajgdKT
E/g8gWuHZiaOTcxMTM2engbgQbhj189f+9DJD/3s/txo4ze/CUtRIWr8y2hdu6F6czU6Mx7RSlfc
iKPQ8cuOSFA1Zcu+JtU01Lk7MXGDpiuD32YI9MWa1gVrTyEaDnbA4jE0v8fZCtFFU8vOshThemHO
ociuEWxHBExrFblOtDLZpMGtDQsY2b5YiYUWAUE5WzUqVEsRLqBC+wOoQ4PEcNNc3ZryE8jmBnOl
ZGGwkkiVQafxUtz3Emm0bFKlkWIip2sZ3fd1MKmtiFYJ2h8yEkgHsabqRGjXoIIUDd+pQ4uVrxh/
3HAnmJYF6iB9hSMT8lX+PpwwEHKpQiKRS2TtRNL3MqA3jcUw3RTWShaQyDVUVE4xraSLN2b4XAPK
/Hx7AT0XoJWJK/6shANwWl7K9QppS0URDIJ/jyUx3e0cTZRHRtuH2ss5BPWJ0cFUqZLKF/wEBMa6
nsyPgNeRjYfZ2+ILW0YL0NrIUBjk2hqQK6Sx4b8XrS8BTy7y7PuRai5H63NXQSsxuJCqLi1f/pNo
FaT9IQWP+eegFeW2OoJ1URqxLBDeugpad6/tVLfMzc8eX2RWgVbw5cy565evJpoA0CPxbVUNRhvk
iEAapBIb++WLF2aJVjyM7/weXpvAmZzYMfalMZxpgHkKTaFzp8/frx9pFE3bNcH5S2jdDLACrYe7
NBCgmB2JWsJ5vl6yYtFUwZIl5p2DjYtLT5t6W3aiyhQcYBLAFQI+4aUt4LoJHxiWQ2O2qKBwhZga
O5skuyLXBAvCsTAjCmYlDmjHr4TE6A02auCz8Hoht2E1OtqKRpQjqqQuNiRNGxkbysAp8GoqmUuB
XfvLpeFcvFBIohbju0k/DV5N+nGvUo6jSQKhRArgieppWJdKkioECTbzSOCLb5oYPXPsMDPWwL4i
qDRt/+NUEEkXRE8HQjcGRDIPdaNpkPdIPp20kDLrjITxC1LwC4yaLjQZYuFqlCb8coi3R4RZFNZt
5TsKSDJxTNe3VYgdEPkirk/BYyrpAqJpGwd/sGOAPP1UudQ+mCjkUrl8fnS0nBjJl4uDiCCiTjpf
SMfjSOUljTvrTIUGOMGYxvI6U1cf/A9L/zi0Eqp/HVrph8a7WD5arCD9abSytvTPQus442CgtS2o
MT0ijVgdrVvb5S23z08dHwP2Hj5jO45PXfissx/j44dT4YZMfv1uIUEEWptL4fvXpo4Cn4+eMd42
MTNzEoRLyB+bmZwkWsPlRm7W2P1XevVXb918ACXh6p4I1xxKFApr1AIIXbpRKiC4o7tQONfMvip7
qljzuBdiPaoPgdGAWxc4lqwKagVqYX7f3NRTSKVkmcUriSAF6mvxvG8AQLEFnXGmiHgbZEUgQkyQ
AivACbkNfkyME2MIhjl4krFNOi85NsDqepVEueyX0I7s7+sfGYFMANI8mpYicfVThWLKy6L56qV1
0BgwO6LbSDCzqgztIqCl1Ic0OQPQxUCuEjJER3WNsMiVgwF0UuyuoD69FAgDpTHA29Q4VIp6kV0p
FRGRZ+MJN5NRkZ86nDpgok33KMzlBJsfZTqUIu61kClrSKwHS3GTDmkRx+cwPRovcd1FwTfrcS+t
7aJFI7ziTCueQySc7xtAVXiov7+znM/nBorDlfbRlBU37HginkqzLxSqCcbiM1pMW0Trw3Wmjj5Y
cjb+vWh93iLOxI1/FVqD1csr+zSroxW15X9OJLwE1v1/qsa0dfPKSPiJeWnL7Qsr0coQd+rsZ/NN
42vGW0eKLWvHAdVgC12HfurqncljQOaKw7rysZcdxzl6FCkteHby3KX526HBTU99jB1zUDxsBWI3
b2hjFSjMIBhgxTMApChbFZ9DJTRAkNrIosHytYPNwV5HYjSwSuEdOMAzsBoks42weJH1sq5HaqFZ
QmEJaBUODFzsv4WxbxDzAsEhQWcLb7gW+H7Xc6sjev4xkJLGnoWwikhbBjagg1UhmxU6n9xgheWk
YjleALFCVZss5f1CAaL4dBLV2biTHSkVCjm8cGhRKj+QQ9JRkEYMOs3OZEdD/Oqlgp03vBCA5edF
gQSCgQgSUwTOOhJEVYHGdyRulfGKQA8Wg20mh+IIiq5opoQqnRwW5kkQ/POTGtRubVB+wcR2DqBM
t7KODSdVoNXIFhIF33LKMFut5EdMDC0YtuEXBwdyff05+KPnhgfLxZH2kbzfPjxcRCMH4/ipcjyj
cPOz8KPAUQJupWnsUp2pDWjtGMK/9ta/C60vXbj6BbLsn0QrbxEw/Tg/BT8D9xGMK9D6okfR+hwU
nJbQyst/aDk4J6h13xK1/lVoPbGSW0mUx85dunCtGSHshubGtUEUS8iNj8pzn5xdjVongM9jR3dM
nb506fTs1NjMDPLfk0SrNLz5cdB6YDNHUWlCqNRrYZw6kCr8b6lBjA4WXKrpfUOua5CKMBJu3lM0
uYMKYb9ouRKz7Ljy4EseYXiIs37PziHMo0CuU4sUFWCtxed1aNFwCTogAFTysOZaS3/+dYLDArRS
QFQjaWy42Oh0RNmSxIdtCeFSKj/KpLVS8pGujqIgXIonC6VC0s8m/XJcZ0iZViUTPtowHe5HIye1
f19/HsUhNl1t0CBQColDSIJLOMZjNM4cGYUogm/ya2Ax87A3KSphNHLjSh1TExUjG8QaT9PF2EZ8
rlOaj1ZQBkiFoRnXqcqQbOJG+pzReAllaSPKASAUwgwTGCN+sx5S5xjiBSNlJf2RbNqx4pA8FDdi
ZihjZLPlYv9A+0B/vpjv6uoaruSKgwgiygMD6NY6upcoVwq6ArFyYAClUIocoPVhcm0NyJWVpiN/
VwdHcORzAMLnB92WVdHKbyEw3yEy1Bd8IYAdL6oE0T5pzTL0r+BWbrjif2jp/gWC/tgjl49fDi4v
UesK1SHBuhKtu5+Yk9bNvR956yPoYzI6Mz07+8VxsOmRIwhjF4vI6dqLF6aR6E6sgteZc9Onz5y/
eXP+wplL0zNHQbUvu/T+23Lb4d2PtW0ZSTYXsHagNhutr2f2qtE2V5L1YmHAh76pvX1QrqnXpDrU
itCD2dlIR29SKvT8eAc2hVBCNHXEe2CksqeIbw4rugkyxSyZPujFtBo0cfAlWjckskAtFOCjilFw
MDEXMG2dhHxSVHYoeuc6YtNGXmdhm0YStifFcjJRKlYSBXwGPP0CAOxXECJ7XtqNatAWJMq26xfz
8XJ750DHoOXYcej3XJvCBtuRVctEwmrFGKYLO17brgs8ZvjBCdsgNhfsH5IclKOZPVcUGxEn9Y6G
BQ0j+7gOSriceGMcTNMXLq/ECIIt4BrMpwPhMfAu+7smujn0DI8gsndB15Zt4W9KJIYrWBvt22nL
y9AEw0r7ZVS6B/Jt/X0Yn+4r4OUo15koQNmUz7oGVMOFhGvJDBZCnC+gRjQSCdC6RK4icyVc2/Hv
Pf73oPXJi4lncOUdq6KVMOb5vUBr8MjFW5c9B0WCuhytzw9kF7h56X4egn3Z5eOedVVV6aG+riVl
xLIa059C65rNHdq6bZcvnTu0Aq0T4MqJabRIl+wkeKW6JbL9s5cmj65EK5qvM1Nn5q9cPIFz+/7V
91+bnZw4du7Mg1OZvU9l1vvXopX7qtZueuLataUwPBq4mbQ+LJaice12NjeqhFzfsLKGktNr2Fap
UfZsWt+9F2Nw9PhGRMwri0aCmxgqk3Dpd+8rNbWKq0p1Ic0FFXR0thfzrqEgOw6J7W2BSQTNyYiO
xV4rbwRm6+iSSx80RpiQuhMWdtaKeYBJAXqIYiJVKZayPnQQJhZEFrxkGoOgo0nLljXTSbTlS34Z
5eK41Z9NFcCEcPbHk9yhpkm2dMXJjjqIh7UwV0mBOh0jYfGVg68UXMTDwyaw8F3EvF1QlLJpRKiZ
UD6mfAMaQRf4T0I9DDgCqTI5TkZPOAaIxjGdzkMDJ5ArMmUN/xEVyiYOCagW+zRIhl0HO31S8XKh
kIaIGbosO5NBh8hPJIq5QqUrv39fR1tbz3DBT2JferbcnyqNDiSTJoZdPdsJ1nfSZkbi9qIArQ+R
a+8fyXUo9/hwFVHs0vkcdAyLVwAtXPsd9yHzcb9+yGn/SSgEPwe34Opbqp7x1QV6XLYUkjco9OIP
WjcEttgc+ZYq5QvP4c9cuH/x9/jYssvHH7xxhlZkrUvU+qfQeuCgvm7dveurpKETIg+d/tEBFJaE
rD9A6/pK+MT81AQe/yhax06enL12+eKpUycuXrw9d+rFFy9fmJ2emYbMIh6UqP5qbqWUCetX1+5j
dCgWtwCueJP0jKIaJla56tHy/n35XlNCMBtOdEMm3AMHcBH/opODawyIRebKxJZLloUvWUtcqg3l
u/vjTjJXGC0VB7sGcwNxqFwjGVlqCIBJfuViuV2i/MoOjgAra011ikJpBEhVZdWFO1nTaNvgB2QT
QdpKS+wkxEtGsoQmK0QFaUyXJVF+NSp+cSSV1KFzdyzACpPacEEC66ZSloKDbRgUR3H5JZYBQAWC
ByiIUmsCMZM4xGswcguLF5nSR2bwuFDMmG3p6WTFN03Ipmw1pfMnqqocmPUDNvSD4XhfOCx8nHgZ
ZY9FR4TBsXEZD9dsw6Z3o2fB3hvqjrSdsgyUtW1g37RTo6XRxCj25w0ODXR2t+0fqFgW2jlWAihG
vp7w3LxLxxuSKxNXGZd6gFbhOLWs5ypi4WLV/6gHIv5ueSAA61JBeAW1rhIJj29Kb6m6D3XESqYU
aJ1taxpfhBrA+tSWzNyDM+fQXyUbL89zZ6bO3j116urN89fOXJv/7NyrTl05P3vu0idPaR1r8Z2P
gVZmmhvQcN3Q1FNWRE2pht7yYclBv0JH/8XRyt293U15STaMePveJ7TCwbOnp1n8tYAl3nEQCnNn
a+AhHJyevFbjNsMTtBnX9+xp6cLux844+hU60Cqx2cpDgQS9XXiN1wV8GYbWKzoKrSBW2zHMSEY3
Pdu13CT7rClAJYH2KoQ9vp9ys6kSgIjYEA4Lrhbx0nYlp1MLETEdF0JaIElBF9nwswXXc4AfoEgJ
sZZKPIFZ4c2LW2MZieLDP8I1eCXBJVaikw0XzM4irlgQZcSzMT3oBiNZBUa5HINj53TSxxv5lDCV
ZLGLLvDoFtaEqowrSMYBLh06YfxVEHtA4GxwBsezkfUiQc/lUtkS6mXxQr4V24O68uU00nEL1hUo
E+/bXyx0lJMOnSAJV2H/L/bvBCs+l8h1KRYeEnCtXvM/d8CsysACtbY+Qq2blqh17SojOIfLdVUn
zp8+eixQCR/i4TWKCk8em7r+2dFN40+nyRrqRFjC+oRC3cX50y8Tzdbl2J44eun81bm7nzxzeuzo
0aOz199/8VWvunJ2dv5ufeqJ4wvGbH8dWrfit8ZAavWBzZuru03hglDPFRD1Cn03XbUGlaJoqlho
M2Up29Hb27O+E5ur9oI/RebKrhXfOXIu7MjEKmWsawVEBy0tR/hycysf3NTTu69QwcCMEw1hm+mC
qQswurAAsoH4IF7FW0hzMg4kEagFY72cWFiFIlMWAW05GUdLtVBEDyfpo0BseBgAzUL8m0+oSHMT
kO4mVESHcpTBZsTJGAjHXbiMZWxXVRiYkvQUcpJE49B6YXlG1+KaRbDyNKxjBxheh5LYRkXuRA8I
SkaX7V+qIRQcJ0rPQ1kVcS8gCdiQYRVhJYyLMErtIFax2oZlLfooxWJZh9M6UXq8IB9H2Yr+37pO
awg8yPQMpOcIICyv2N7b29lXHk0UkyaUWolsOVkaxcidY2k0D+AbB6XE/tiAWx8i126idSEWHmAw
vHHN/9hB8yoyvADWQMa0OrWuRCsQOKzsmrt5ZzlaA8BCgDh97YTZehiLNnhgIXFg2Gy4d3b23KPM
egg5644Ld088ODu7Y2YHCsyT06fff3vXqZsXrl50hsZZpPrruZVRMJWHmMR5YhNkbWi314ilEKoE
osAUjh0LgRvoaqTE+/bt3Llzf0f3zu69e4hM4JOoFYtuNgVL0fGi3rOziUXjg12JVDdbsAvNWLiV
9vR0Dre3F0o2mrANAZECD4Hib9dCWBz0UFhlQtsDojzwDevCluUBsK4PYQQ6qvECGTYFtMYxMmqA
6bxsKl5RJfifUEFB+xPWYDXEsHHbMBwNzoTMTu1MJLbgcUaXDOGi3xBSiEYcJVgpJ34dIQ5GVg0w
i00ZIYkPUPhYVcPMGsAtMzymDxr6uBn2hcTIkgiJ67UIqnIhQa0SiDeKO/gDWHgK0R0ZvxoQilI3
pQ0ZpNNUU5hoBiH/oN7fiMfxF2LkfKCnZV9uZMQvxBPpQnx0FFqoeCHpckouEizSYb9VkZgyi2Bp
kVxZaHoUrr1r/pfOU/EXq8MDi2BlHPyo6DCg1rWrzbe2WrXb7509fhRsOYH3pYgYrdNj02duy4WN
f1y+untrq3n7/vnT05Mr0TqxY/r8lQcXZl/2suMvexnIdWby2r2GV128etvOLWatf22/9cDaaky6
4X0r8NSSR4DGukjUVvFsZpCngSMobqoL2+XWbuxk7ajkqIlu5gpX5qc4AXLJn/ySW86aG5t7hwdb
1wfu/LyHXmWt7eW0RfcGRQFIapEyojVEoIo6LMmW2augVmiJFRu6I3RMTcOE6MezoTcELOHUGYfE
MJmCJ0QBXZSUR70ERrWRTKoKxBh0clIMFwg34lYkA5h7KciXFJNtSUrvpfo6smC4Plh7wWxcVmjv
CHEI+zVImvm7BFl1bUjV0UbSJLHR3AiYE10a0+HKZFAjS8qqBJ2F2LVBo19AiB4SgXs/2yv10DwC
xbiH8SruV2LAJPWC9FDLEK06vlXWHYqKHZXJrW2nTJ2C5uLQvmIB/dgUCk1xH/KKoVIinzKj7K8K
dlXEf4fLNRbRSrgG5HowaLoKuA6zMmyt+d85R/D3esOrxMErqXUlWkF6m4YyW+Yuz05OTggELqL1
JHwkrt+5/sn7ct+G6gMHDmDeZX2/NXf3/OzMDKj3UVkEBMJnzp+ZBEd/aXpqanps7Pjp91+sqnqx
OYCk9THRevjAgWoE79XwSYPnScGCEkeEdBK85SXhUYriLHcZYmZkoGfPE5o6sgkstcHe5CYBTgAX
PAs0Co7FLvQ9zXtwI6pMfX09YreMWOgGZm3a0zuUQx3FAr4MiqXqaqJJV2oIwMo3Yd3LwRcMv9bI
queCW7Np24So1zOiLnyI/FQJT1lEwgmMZ1tuyk/6FruwhfJolDQXAewcHUojrspJG6pnY4LOt+gU
LimOAt1SVIN5BVUFeKupr+W2RkzDhQjbmlCkDiglWgN+F6MFpmarwbYaSW0F3jhrR0BRYgVvNjZk
lCgE/GKZFAUScj1v0fCfkOn4ipcCHI0VKuKKBSGFykSaIwpOp6+bkDlkhPWUqplcAmAKhylMBHYM
+RbchN0E5PyQTBShTPYtDA8Ik0VZo6kb3/GLRYOWHNG6WGhabLqi0jTcXwXLgzX/K+cA/trSIlj3
rV5iWqDWtatOoz+hUr8Nwt9zRzEzhxh2LDgTR49PX3tw8+y1T9Y5hb7Wffs7chUvFrl84fQY5m1W
NHzwNcZdpzH1eunM2fMXzsyOHZ89fwXi7YEniDn2x0Er955vRgOn+vDatdAh7c1B/B7Y9NGuWoHr
IZ/I3AqhyjVmsXVPY0+utP9g8156H67fA2gi7iWtNhKTEDAhBsaBl3ZPW0vzE4TYX4yuE9i9rR35
EpCVGrFYZQ3XKKMDEQ7g8AR1YUCX4IXtNzT4CHNpB4w5NJqseLbhelayXCqn0gSpZ2aiqayBR9lQ
GbJ6g4EWh9MrJQ96I06vydgaSe9vE8a7EBnKKOPaMZaDFPxRYewqj9bhNDSEaumnD6oPi0CYFzjb
QP4h7jOmLRStNaKuRkjSJxXEGhWztirv0dCEDdYg08IJwFuoMVHNiZ6zzBIxM0xSLTujLA8JAxsB
V0bUvNOMEtaIKIJXAt1GaJFM5JKu6yZcqDFcVJDLiUS2Egc1xwB3MHmU0z/Av8S8V7TkANfFLs7y
WBhw3S46Of8Tp0gF03KwLuveLKPWtasuwDnSa9WfQjIKXS8PmjP8NPOl09cuz3322uzZK7djHrgj
bZlXruDryWOAMtC64hDfl85ceP8nf3PvwSfPnp6cOntv17ro+iNr4B/+WGg9AOkhxEzV1bTirwZi
PcyMy4wR8fyVNMTBElI7ho2Eb42ZOtjYVmonWvdiEgf7WPH3443BcMCgXJwO+QT49eAeepNyYF3I
npDc9u5r6+rD0OZIHhyOTLKuJjEoCZcXvPGddmrsnnD3spKxXD/uWvTdtenrYjh8+qbBuF42G6cM
WI8ZWRoYoefJeMDl81zW8CjEkyj/wOoI8EyD/zQ89zXoIjKmaUQkxLygvNp6aCHx3kD9MncU8O+W
WGgCt+JAzbyljoyIdwGzEOMMCUfQIuJb/NyYWOSMtFVX2PLEXXgQfxhxypcEoFUKPPxJs6y44y62
ZyXhai6RFcVWjnpKMGSNvWWday85y2NkMeuTH8p6FhpQOnXSlssRHA8wB8WzvWtj3ifAPAAcoHVZ
LPwoXGP4l3/imv+BEyZY+x8C65+Ig0mtq6MVm+QO7HNDp+CiNjV57rhIOqn0nb4+f3cO5d/J2bOX
r1y5f/v23aufnT97afrkyUM8K6CKt6OwnLg7d2ru9sUTpz57dmr62r11dd7m3U/f/fhopUy4ei1D
YVxsaLHksMJnlli7pEmi92pD4CYaO1D6wxdlpOvg3p1AZOPe5j2tWJWOq7hsYhYL4DbtRJ2Jy9Cb
uGWGWSuFiCReBGUdQ/nB9o6+wRLU65GaGrdUsyUsVAgCowttHXJrWPJoJIbeJhs33KLs6BxU1bNG
2jCSnp0VIyuuRfPguMpAEOMsFgDnaAguHdPmEACU/LYc0g3TUY1c3gbAHArhCVMCdTsFzDW4AisL
cG0drFm2CZ7fVseNWpgDYnwrLyKV/CibDLiVMGrOtHXjvRE4MbLzCZ6tB1QFSCW+4z+CCCXMLqzo
Y/NVTxTtgn4QYSxTiCLxVklPmoYUidoaonUcU0fOkMh6Prz6Ee47ppnJIBpGqGHJqsatkzSLMtLc
fYlWMDSPAq0CrkTrYuq6KGkiXMv4pzfW/Lcf1pd2tQdgDURMi5LD5XOtglpx/sS6qsN7yqG5i/cu
37xw5s4sDoLZ+ZtXTsxdOX9p+tjJ6etnL5yfp33p6WmI9YnUQGV49KEm7cTYBIRMn5ybu/3Zm/Pn
b1757IUpcOu6sH/g6ZRWPG4kTKSCVTcDrUAsvYX53GSfkIZCEsklKqnh2ho+Vetqza69I8mBPXv3
7u+oxNH9LJWL+Y6DKCsxxGC8S8fPZlBsc7B8vImkyw8scm0Z6Mj159v2dQx5poFhlIaIGXgJB3il
lEgwLdEKX5Y4B7jTFo4XbI0z6MzvoekK0widUbKLG2wwK+J3zTaT6QhfWrjCOANwZ9hmVcSeU855
J1OIiCOkSVaW6hD8Akq4Juxntq8Dx4aRmoYoWgZW8TvUBg1TjiSxBBWWg23KMk28JS67A+QYfBC2
JFUCrwYHk8ICsvjpnGUICBl8znmJetwhgxqDDi4SXHwQ8DgSfC5UGsZIEs0dQbUG9BxQ+huOi5QV
doqcoLUsFLfi0C2jWqVlVcy7o4UrvFFjSoDWDYvk+lDqugTXdnQ11v2X77NqwvNba+8XvRtBrcsl
h4+WmFZHKxehj8MYrXbL9lNzVy4DlGcvzN+8d3+uYe7q+aljx8ag7j93bhLn3HHAk5ltcDjH+hC3
ItG9fvPiqbvvvzOFSfYLF84ArVfXhVIHuLfu8dBaXX0YdSYgFodo3YxtU41tnhbiky0CD4So0V9K
O54O70O6V9eALYz9PnR+fkQTqgEuW1Khn8u1NOP1HEUmqCd2dncHubyoCOOaaMZiD3Bb63680HV1
9rupnK6E8AogFqEDIeuW0MryMNoqZpzKAZtINR3D8SzTMmExCLGhD+MlDLL66axrmYYOab5fyqiQ
+2RoOhq1vbgjo6xjhhQXcM2oLK4aoKcIoUEAEk/c/kaLKNSmYemG+SAAlxUg3L4rmEivwd8r9hcA
b2EhkSBcFQ0FJHZimMMyFaXmOMLYF2AL1xGoSPNZl6vlYfYPbJJ1AVWRzcKdReJuH7wQoHYtOkBS
CFBW+ToQsLlKIQYC33QlbSExisPj3I75tqFyn5gkO/hOBcOtJsTLNj6C3RoBWgVcH05dFyVNf4Rr
bRVH6P6Lj0IdP8A6MNSxImldjIP/IlppEby51a8Dt967e/vi3atXr969e/fqvQeX56+dnjwG0dIx
hMY4R88BrEhYF0wmJqYvAZG4BV/wZnAwNIZ3588goD5+bvbS7CS5VUocQEv3Mbn1wGGg9TDjYSJ2
swDtxvxghFQQkrmSPJM1Mh6eHnU1csyV4EMYUpOWplksSuJpRkaQFY6hZvyuFqomANcWgLZJLMuh
cEJEZbhobgIjd/fCtCyXNxPFrCU11Nc9rEcQjRxqEjAYjhKuh6DXszlNrhq2alIiwbYMvEhRcwGt
FwoGEjnPqA85+bzuJjxTVjgXHh+1dDkZ4n4Z9F8zaO8IH3zDUEJqSNTQBJqIJZG4sgwdJlq5GkCS
GkQzidbj4Cx2ZEKEosBqDVNFhp1idSY3ZnJhpQ41JXeQ4OsamNmQstHKbaip5XAgUuRgcXo94Uq8
kgnRBZL4i2DqT1dk0T4CzzIbVYhUdmaFvbmRSutp2y27FhL3iAFqJYuj06pIjqVqRgSxcBrsqogT
2OItj4UXK01tC3Dt728v4Z+/Zs1/6xkXUfDqYA04ZHkc/KfROr4hl6m/ffnCnetnbz548ODe1av3
Lp8/e2YWoKPOAXS6dAhNIZw4Nnb9/XfnZ1FHXujg0Mlpy7ar70fMfP7M7PS5meOzZ69uUQcPo+78
mGgVWCW78mJzsNx8Y19J4hMurGUyuhxBUZWFUNGlhA1hFN1B00QbVNVUA5laRmd3EaGoBCNAv4Vi
JgiJewMl8cb1kBLzRX4vLpDK9iKBaOnt7OyzVK/gKcgbWVpaQiveWWcCWmWHTVSaebvIVh1TtZmI
srHhZrOeKDVV8CTGbGgELx8uHkVvNESI2CMeh4PSaDgE8xMQM6jZd2Ji66JhaSpn0KXa4IhIOOjw
oqS0DrIlwEYLBXZq22up9iWkgs3KIEUkneQ9NHRZ5MUdFAYDLpaKu0VuKxgVF9zLDOImdqmqkojU
OoFJmSVhsUeHzJweSptyhJG2EBDSe0L0ZEHT4NmMgx6V53vZvAUlF8jWcrNRQb98gaRrK4pqvm/Y
KE/LpraI1sW68FKlaTm75hANVz1hzX/lqeBPizwK1oUK06px8Opo5cKq6j5t+4n561OT07BUOn3p
zp07l05PTU9P4uxY/QDER6fm7554/5RAKz7Gxs5NX7+3bhcV/SdOPJi/M30SHZy72+yOI4+PVqA0
YFdyKyVNXCXXazPriti249DYmmshYIpLD9MQFbuW61ilQRcdzTgdrmOyaNDKuC+qGX77HigjWnro
YiocYBZ2jwuN4s4eOJC04YWuNUv7sIgQBfPwksOl3LDBD1RjoyafpzbgSkGe7eq6B7jajpe22HlE
68angilhhLVUwdVdnUJcWU1j0NWA3miYoaaSThgJLqQzMuyU6lAcQ/6na0CVACs+OHAL+WMDMFpP
o+MQY/NgLTu0D0LrIAkoscZE/MJ4gumsBXyCKREQZ6nuBZ7JvaTsOi5XRixC6CIuxrcwX62hLx1B
GeIQAbNpfoPakTWZtTLcRlFAFIghyKaaEcmxqrtwTIaxf0U3NBsiraSH9FW4PLMuDcM2xPlWHCus
AHRcBOI0kutiG+dPwdWq+i9d78rXoWJ7P8Dat1QOFhWmR5LWv4jWp1f3erUnPntn+rioBb8MIiSW
hpGjzqzsqi6pnGbuPJi7eH4aE6xCdki0Xrv64lP3rz747NX7F6+8/87k8dPz97e7rQKtf1PeKoJg
CJq4w2ZTc0FBaVOyfRNdD0cMgrP3B4zY2WwSiWTBtgED7GuyHZaN0UuoldjgkSjhURVvCGsjOUwn
+jpEafN6HpAr8vye3r3NB3vbkx4KLAuNzQUtU3ibGiZmWRKujWh6Mp5CyZPLbaB/gp7W4JKYjG57
tPqk7yEKUEkDwS78DaHtYR1GUiFyMiw0SfOaqXJ4zVAINLQ2hYTKNNAi0Tm4QPtF2kRBAhGqXVeb
DTXgv4qadwNngwIxPys+EcqKGQeTY4kqXlPoDSeIlbM8Xtzi3mQ2ZQBXBrtAJq7iMPCFIplpBbGK
K/iQkGRysq6Go7UoU4coomKkLJbT4dB4DY8w9ZFYEaOvfjaO2rhjGLbl6dFgLboiGrTBMp6sx+6s
CfwHJpYLsfAyuB58FK4Bve5c8192GOM35MCs1BsuA2tQYVo1aeVZxaH0D9yd7W9T9xXHCY3vvcl1
cnu5zXqB29zUNeF6uLaT+iHGzy7Eju04smxkVG3SpGkV0uDFBC+qCtaWtoNuaxnbNClFPLRFKxto
QqtaJoTgbcX6qlKlbX/Nvt9zQ0xI0gF77H4hjuMk4LT34+/5nfP9nXMkFRlZ/uz2R8f9UBf70tN4
l3ubwYrEE6R1eermjY98WvkDJ05dvHbn2sULJ0+evXj93PLlU+9evXlrKr7/yBaMvHrEnPATh49R
WHciHfwcF86V700PQwrsRJRpJWipjWmKBtKz2EM52WQ/htlthocmLGhxQH8qE03UkzEIiq6BQdW0
qkg5YYBzZnbb0/xP5DsTcQM/xf7yS9i/Nkos7PqmYBIKQOSW96VZf8C00BPNF1LDxeBkRsJhqKzN
8TEGRz6lIzUrojlsCIhRsyg8qqoZS0ojfMvN2Q5VLWhT/lgwMWEkYP8Icy44jEQwW1nImp4aHpma
GGX1iCdtkfDCO50R0FOBR2SPqEIDmS9SfG4Vkdhk2rPiLvbuIVdXKMOAMkBiJasOohhK05DMohhb
VPEhlXl2OfiKG3IKCeYd36ys0/nE7HBozvC8ShJ9kx0OQWcxy9BpOOZMIDEd6o70S9Skn7AqFRyZ
n7u6dWVUs5G6EldvCMnh/yurxIEhrIrAujSAdd6HdeMM0+a0HtleC5z/8gYKNeCTjLLlofRD25RW
NoT46OL1V5fh7j/NnhPIOzHLdPbGpRsncXTno7PuuXOg9ca1c1OxXWxs+oi0+oEwzMKstT6BNmk4
W/5iVIHIIAeLjZHjSj9f1Y0mMeqh7llOPFuJckwczsN4AE6sdMo4Yj6pVai8OIOBiWBhF17bX1xA
mmkvqjdYnJT6LEa6zhf3708tzFcjClNMkzJUA+/kRG5Xum7D1O84Bgi1DPaNsLBntVz2ZvIcVnIi
VtxKY7YiaI3MJQwIUhgOhQk9EgmjJhtz3VbE9i33Om9MeIQcG6kwlEYgZlJhlfYztEaMBjhSWRrN
+KjyOY2P0MFEhEgS9VUPkD1FgCWsdCM6mUIs6thh7DTD3LyKURPE4juxiYV4EkCwyuMDgJaA0sGo
30teSf+rEbzhLseF6UFuhxUV9IU8aaVaSabT0G729o8AWlNnsKwhjczkse65GN1s4nAj+1as0iri
Osg0DXBlIWeAa24IS93yf7PG8euM53IMg5fWKCtbkg4qrYMU0+a0Qlm3p4xzdy6d/Eg8/Vy8lRtg
uyGspBMHbM6f/+rCcflG8k20WeQ5cfr0+++e/Pz88sfHP/r0+uRE9SketHtUWlfXVo5elf/Fuxuw
8RoOTOZOBKc95nTTReWklltq4pCOnjWMRLLa78Vz1dow0im+moxyC4irDmDo0jlFs+Pzz+xuMPxA
bpiv8nIOB3aKVjOzsGdfKW2OTK+AyjUNTgRWqi1gUd0sShdwSJBT3Y643EXT0uSxN4qHliiw6yds
DZ8EIE3aXBD8GDZ2gWGjG41U+pi2yOluKIxYwTDqH9hV0/mOtLAOTLBdxcJLDGikPZmh7/g0OcU7
XzJGhyHJJtCRJUcARProWZIiC0XXyOxN5WOwIQdRYdFUKavCJgy0oYAogonxaYTSShPjBLDXgSrP
A5B7wRU6OiIKy+oQQ1oFS0eUAHcEZzBHopGEYehhN2ujqTjsyeI45Dweeg8R8+jxoI5lQ3yl5ezX
49ogrrT4C6/dIazClv+LtTiE1SOsncX7YOUpubW2CG5aH4R16zpat5fN8TuXT70vldMH6fRLNYNP
/a/DBnH84rXzaNf//mkhmhKMhuFoHnwGsJ746Oyl5XNf3f7o1IfnnwzPHpHm/I/qZRJU5SQB355j
0WV3LGjHYbD14lk4c2F7y6LRSLVRSls1+N6SlXgsUeomev06W41OofBBIQGuKFfwWma1A9cPqp3t
+d1SbF1pjAhYMYA5WS0UkWvq6SOTMgCHeIrZD0LLuz4sISebTlSQETagiUYo7iDwtkNwRDAd7LFp
f6QStRQzEjeoWRJZwieoaDbUFRNqYgkn2w0HTNop2C0GwqtqoltwGaHSMolIGEngEdnAAlbQOkZp
3UFpFW1lWhZJNpKq3Nu9glGwqoMTCZATu/ftKbnwXHDIjUZ5ZCyMN+l4SBYVdUIMExPjRBNPU4RZ
fpxZZtiRNAPfyTceWgerJJyeRtgPkRhwYQ7G6xS24FBYUxq26cCdoTQ8VRwFaSG9ZGoRpN+iQut2
n9ZBpmmA66pNYiCv7hDWti3f+LVzCMsrrYMVYfC6dPAgDt6c1he2FvUdtz48dfwEmomuSOpaYO8L
h1funXnle7evnT/31cVThBUIIwg+fub0325f/vgsmn6fvHH5cxzUQdfva9NTiWdxbOAxaPVxxUfA
ineU1nHOxsILuhWGJxcTFI12IlbKFNCmAZ6iWM3yulDcSsS0YnGMjIMocSgy7Xs0yCs4WjOGnCg8
CdzHRXDEjn39Wc3hGHJUb0qx6sLs/peKWY2zNWYYCgNTnxG++3mmUS0U8dAgDc/AX4aBRDBNwQiP
nbSHnaxXiYVw4EYOHgAFeO/Dfh9uK5uLx/p4rm1Hd9roTcq9ImuUJrsbAx++xOzAwtOXkotM+Zga
9x3LWDPsc8gGMHBCUS6FU4S3JIkY+pIJJON79tcdnoNwXSus41E524PFf09F3Ual2DPHRHH1T8EP
i65KvoqBsB6ywK8ct2OTGKaQVQ34A1AjbXFsDxJrIWzFMfgSOWoZ3GW7JvSUNWTDQXoJGa6wE84m
Sj6t2wdb1w1xHWxeW8C1ND2EdWDLN3odG8KaLg1gLQ/C4DXKukGlVWBdT+vBXfGxVzEO8l2YGyCQ
WA/sVe+nVfas7584fvWz5aOInk/4UTELsidPnf7bp598funqhauf3rx77vqHF949dfGTSWXpKZnU
/Ig54WPbhFVxMx3ArDn8Kk89t62RTNZqiCcRidbbyX4vm00sotdgFIOT6osxdMpvRSyTYyPGcLwM
LUcnWLYQFx+uO+7DxmkDYsZJy+3Zy1e2vWAVl8xLs2XMTcN/xT2F/NwUHfw0Q4iisjkTaVmZsxwy
IijGWI4056fr13Itey6dRYJJssQGXBJOkM3w6QqGyiTSOKge8TQUVyocvOw4USfRqTqc1QpHIN1D
VhBMoK0b80tPTqHWy6F2vkViDGrrR+J8SjRTIfD1a6K+8xC/F5VZUAuKigLGbGkhETaxQXYsnfQB
bfBKFRWyR8aDIX7OTT0FHdmngCnZJOiofDuU0nIANn+Qm2GN/6jOsT2GG3IhnKhfwcdlxeDesixh
lD2gbI4GYMoNP2xyTJCdzZaKDUkbElcmDDfGdU2uyZfX9iTtBNu3fHMXYX2yvxms65V1Pa0bdHo5
vKuiLd+5iZ3ru7AAMys84FT8+wNaTyH3xGM2n10/v/zFpZM/Qo8IInzm+IVPP7t06szta1eu3Pn8
80/uXL+GAzjHb187N559Ck2yHp3W1V2rFFx34rfB0dr5er1Xb+Z6rWqp28+hX3zCwzioHKZEIf7t
1HEApurAEQBn+yivdNQreChER4jJtCe7Ok2g9oEHVFyRcw3oK47qzIPV/bMFHMFpFUFrphnksXMA
I7DODCwSXJOjMBImKhFktWwDmFpuWHaw0FVkuLy0hZt4AuUisINr19HQXS3txmqwP8U1LWjFMVLD
8bqZTlqzWVwx8UR0nYVjCNk4E8HjkE//JC1pncYfFHqlW7/I/AzOwyPtQ8apl0wDyWKkL+Ze2Wgi
7LYVE9JqGia/iNcpLGCMNzIbZL0aKV/KOZDHH5X6y95QEgyr+Oupj/IXAl0KJ97R/H8OL4e2hSb+
RshyrXoCU7jinguKZbqyZZumzYqa6yGYMHSjm6wtZVJ+kt9X141xfcnHdW00XOoP8XI/vOUbul44
iGff3gjW+YeFdaNOL0f21EOjt768dPXk+7IwgMrnU+o4A3ox4uZ9uIZP3vjwyjkMhDx5QobSIYA+
c/z2h3dunsV29fPl5St3rn/12UWgf/Xylcm5xZV+TI9cb6WXSWqupHXnU9u3zS5WkVEqt4qpcr5V
q8U6mWKiUq8merE2ZoZ6WYwXNqkGiCHRX4nN/TUxr2pBURQ2EKcusRgJ6x8wrsyizrpv394X5xuz
Vex765lGqpFPTE1JuXXVHCzESn9QNlhRbQgKzl1bITTYtSS3xBk2Hnay0aznRXEa3VVVNAnVUBWl
WQIegWrBRW9eWCU0lHI8N5lfrMfwc4A8yOQQ95Qi/cCTTSL8ibF+Q3I0nsG/K8N5BFYeLEBmV8CC
LnNr7HuXKIEByf4KbaZOpYW8+zCP+ZnfCXwYZak1KA1laEbkB2yBg36hhjtWgs8Z7eyFiE+YETZx
T1PwfE2mwB2nj7HL8H1mMYw2n+QmIGtocCWDVRXGsWjc8qIWhl9ZiVahWdy37wFa1+C6635cB5vX
FV6rM0PS0P8buF7wj8dtAOv8wyrrRrTCJXz4mbw2du4ujpmfepfuCErsuoURdLALnzh5+8PPl8/f
vXnj5PsrTHMa3Y2b5z+/ffz42YuXL+Ogzu0LJ0+/+9HH1yeV0raDDIQfS1vFzMQPOJi+rRRDH/gW
TstAU/MFhBfNVrWfrLS6acMtlfIlTx0hoZSnadxMD8+lXdqcxgMoEMI9wW0ccyC8TLFVUy0XF3N1
Yd+eTGrffLmAad5GEhNe0joysFLdpLbO+EuY9TnCYCu0OUkyK2zAAMkxqyFc0boNJ3/a89jVEwDq
2F+nrZCiaW5QGUV/moQW8nIYPm6CB71Tr8SjQZvqFKLKY8uKk2vIheF14t6h9yn+FhRXmagMVOXJ
+MnpKamXSo+JyATVUs7KiNRyoMEE7yEQh1FCQ8UFXweUNEiNUkTBpuR88ShgZazNYHgc8BN6/sX8
yE/TDtNfNE1AN5nttcCjjZM3kNZk1qu4VoxnndLw+PcrhheJegabK3N8j23hRQpRRn2p3Eyt0Loh
ris2CZzIoU9iNRq+J6/gtSu8Nrd8w9YL96zB0xvBymM398P6rc1gXU8r3o4901fx/+nWlS8/uwzW
zmJn+gp8TXDyA93BOvO9s7cvffbVleW7X3x8AZUa7GB9XI9DW1+9e/H4K69ghOup908A+e9d/fju
ObX0zKC36SP6hEVXKbBYT+zNV+qxdn+pvKtVbbcaZXTtrRXymFjRyONePRkcGcelPoarfWoSC7rq
Rjx1AmpjcuoFLiWTr/ymhlwocznjAcshKEo4Wmtmyu06fDdzXewr9dFJgZNckNMZufUxYcl1SlHs
LHp6ox+2wYMmrsKNMaeqax5s/bVqUmEux2B+OB62zfAc2AiaMUgRyjeVWLaiaoYW5kE7B1f/HAsw
YvSFvRBPnVjyVgZ+IAymI2OMSj+FZ0Fi+bSAKxQVi0Evc0RCGRstIXygYsKNFAzQmsiMmpwAJpQS
NfswK3Q3YU2MiclpVDRXXFB45y2LT1k2G/Xzx9w8zKG0ymqVZWTr3ayHA64eTjI4GDmbtbpRL40x
WZ4LcnGQIovtKn67WLVanE/tmfUj4X+Aq9ia7o+G74XDK/pqb/nmrMEFH4S4bqCsDwEraOX7Rl3U
nmmFRpxYLDx67vyVT659dumGbxLmITmuM7wDCzFYxYb13PLnOPN6XFLB37tH69mPz135+OQrP/oe
Wk7Ak/gRQ+Nzav3pY4yDH4fWY8coqyvh8Iu1WjWB9hjQ03qhtdTZ22q3+vXOYrzbaXUyixV9Wi50
zp/ihR4IZWFAVBQjZgAqp4q8bQiAcLDTMC5EwIrdYpBXLGQKpkDHY/evkIOaIbaJKzlgBL+Dftv+
fR4EDyi2F/WSHpJM8CiH9GH6GGSg5IRmpWNsh6Rrc1AWN1axLJh5JsCHGnWrdhIRYqm8K+GobCll
wBwcMdRxIAS6cKgVtPrzlDnfjvzjA/9JeqiA6bT/pHxa0cvNPz4jeirn7aCHoo+EUQxNWHDU46N4
DZkPZy+miRUZvnd0jsgOQ12pt/IuQMvx9nozHWJim8lgvJuaa7FNBPS0W4k5MHh6toNVi0ZcO4uG
53GYyvpxNiTm8CoDwX+11Jjdsz/lZ5k2x5UH6Aa5pvvldYXX0tgQ1o5vRsLphYNrB1NNbgDr2mzw
enewwIo/G9F6ZGfOUK3y3j2FShiCs3zlky+v3fwQEe2nn3568eINJHlvXLz46aXLn9388vqtc8vX
P0P7iFdOg1TgutJH+MzfPl1e/uLCis/4zMmrl67dXXZLu45BWR+b1sPCK273JhOl3GymnF8sFDOl
6mK7mWsslHGn1y7N4qCbwit7ehIXPQocOsU0EjbEax6BAmBjqUlDXFvRJQ2DIJGTOri55Zy5kQCS
olBbVZ1AhZN0SA9hJncYFK82eyE5U9M4I8CphwmWV3GGfFyEi619FR4JUqGRw2LpU4IuImbLTocV
DK40dcyzaidwGjZRTttmOtOCotFvBcq5w0ZkwNOsfLGZxmhW8M/bHfwXqekyJYBPg1LPJzZGMy8D
W58w0gWBBvi4RYXGVMX3r0VM0CrOfdhFxidC7I8zwW+SdDAFnElhvjG9vAIspJ7b4ECylNSGodbA
VWPHpyDzRiZ2rbEKRxDMGWkbkoqcMHwpcwkMgsxi3mUl4eKIUTiLKAO9YJqN1EsvNppC60a4iglR
ck1ygm6dvA54dYe4Klv+19eDuz5zaCj/eLBulZv1sv1EQ5syXjp88CdHDrzEI96jM0M7zt+6e/2T
T65fh0P/i5tffIm7d28to4MLWL146t2PZHQcyz2SfGLb7wtfXrn74cXbV69evX3j4sdfXF9W0/so
rJzH8Vi0+s5DSutzLS+aK883MI07M5sq1+ulfLfQa3e72cX52caegg5dwuWLNBK2lRoupzSAjdtW
wradMDz+SPfYYdhwg2yC7dNKXPFDUtkZCWDPyLtAD8jIlFbiIRorqMhxOaIjM+ZsJ8nhTHFUZQh9
ABOz8GCkFnfBJVWWqjU+YiQiCjIyCU1aMTj9XC9W0YK1emT3bF3T60sByQ/xBCDVVbyG0zTzSzwM
iHcMDgL5vK4amvxCDn+ahPHNl0wJeuVvZQoX+SIzzIYvE7JHBa8TIriC9gg+HZP4mCLrSzQIJdoM
q6UmZNcdlRpMV6KOTnBsBaGbtoMGrLABo3oVpu85HpX5mG5ymxfHrp3njxwXrrJuoZQr55vF2RdT
i0LrelwfSA2vVF5X5XUQDguvPVwb/+tjOI5teJHTFPEwsK7dtPIdtK5bT1dGhusYdYO3Azuf3pZy
pmcCEYY6weFRxkxcSHrcuo4+MJcvXvjb6dPr/Ygn/nbp2vLydUH7q0/u3lKji7sPDFwRj07rSucI
pob3oCtDq1cvlqv1cmo2ly+0apXMUiVSKpVxxq1QVcELrih2t9fcNGay2JDSsJW2Nc2TEf9wMOF6
0+j4k9GIuFghRSBc5E0yLyP8HamBKveh0z4j/mAN2bYKMKAEUqwhAZyoteMRWAspcaP8QT0dTcQj
NsNsBNoIH1Fr1AMeFFVX5LR4OAvbhK3aiJEdOxR383kHJJHrYTBDwqdAK9a0fAC3pJagEk5+4M1q
NQmef/EF0i6FfwzAiiwiOCZpAY0lJN0w1RFZoqXMiE9IZphrHIvCKmlhJoKxVOnvIq5j+JiNmKUr
fClCiM3zTprB170QJm65jkmvMBiNeHXaRSzPy6KRcqWX6PXirgfnRK1XWmi2Fwvl2YVOTmh9ANfn
1uLqb17XyOua7DB5bQeGuLT/UcsE5/6vX4WhoeT9HdP2PSysgusG2vpMYnyku1Ua8TOP9Ux2RE00
Cq1qN+E5ztzozIw6Z05MTt268/nNj69+9C5Gaqwb9IqK61m4DKevXL97ZfkWEinJ1E4M4xjEwY/s
jmAmGAuR8FOdaKvYqMfzmVyltJjPFBbm89V8NdYtFgq1uqPpExO0wAcVM1SrwQEYM9ykC9NwDcii
cGKGTECqB5nsZB8T2G5kZLPMWGPUCrgm8Pg4G5dBjzRd5YMsnBBXcspWvhPDMvCZKkV1CmHGBGGF
KBGtaczlSUsXCY0H5mVokwqXf7KXdIESFC+IeBJ1H68WNqp5PM9KPJAPoJzCpy452yliCnXlWFmB
1UcVrGJJzot7WN/eT5GHNFIzAal4pqDgVEzJP02oYl7SVGabaX7g92GHDGzxid8uYpy906m6QFlc
FtLiVJf+EDrPyOMuz7+h1wQ7jMNVCEBDqKZG8EKeRuNGnFZA13POUbfpELG6+VisjTQ9mipbiX67
Wmm3S9VyY7ZRSgita3EdeIYHm1e/lOPvXlfD4bW8VmaGuMwXtvyvrcNfE0EOYF1nN9wUVt5uSOvO
RW1cyz1z4NgRjr94JhcI5rcdOYZ1GGtvdnT4peee7aNYeGsZI+PQcWkdrIyGj5+8fH5yxAzxNd1Z
3LPz8JGf/GRg5X/snDCk9SUvnppd6sVa5Wq/U+gstpr789Vut7M4m4ob+ihnJE+zK6BtB42IjQwH
tqymE016sS46bMdNljlVUw8BUpVZF2mNMobyhhbCV4JUPvarZjiNS1jOdWJHC3iFi5l7LXylIDkC
DQag40i8ipuB41wJ6zTSVeGg5sGRx3Nl1KzhALZzhhvzdEgetT+gRyv5atWLlaq9nBNCe4sSU17i
WJrA/Fgsupn4CAVWwuB72S3+EU5nhFtGyaBcSjbkD4Iq6sjPeOvPOlb5KTFlsRVU8hZ/AnISDqBK
EYcwi2uCbdhMsiqxMu6AdUX6qwVQbNXDCls76kYYsYEFz4dmcs9hhWwb+aSYhfOuOdhWOAveS2PU
ZTOf6PZyi+VGqhCvCK0P4romGJZo+AF5RTg84JXACq9tzwfW/V8JiQ828Wz2bf71J4aGhjH+fDBB
4+FghbhuSOsLx7a1suZcopTa9dSxFw5mnDFr17HVWa1PdRX16YPHnp3PdOoR/cr1D2+cOnN6Pa4n
vn315rmZ6WH157egIm6l+ewTR777k+++8Li0ElO8IxI+UHL7swC1W62WS4XWYrFUa+daeRQH5mMj
4zyzAlhRU9U1ywhaNmcDs9lIOunGaxEria4sWQM+G9sAl6pGNaWyQE8VGur8E6GI+AgJcy0qoGR0
yK6A4h+ivI0hWqWQmrjOxyBEkDDGkTwkM4ZjeNDFSfBohDg8MW+Y/vZ1Qgk5thVPhpHFIuO6jcuN
G+5EJN+uwmbrqDQ0U1pBDBUaf6YkzcQ5sWPcpvLPPdshZZa3pJVDtdgITZoBj6y4I3CX2HGfKV5/
Kjy+Lj0j8AFUklYxYZLeAD9IagoiyxVQxCyM5RdyQKs8ysN0dkg15uZUUwecSbZL1gGqZVimHnFc
J+7Eot12p9ru5vulcj2fypQL1Xx5tjFbbC067lpaBdf1m9dVeV1JDj/Ia35VYNuhIVn6U1v+2+tY
fMhfmc2/Z2poqDxowvQIsHJtlHPevj+pBu1ku/zszudigbHYdlR1uLCTfa4dDD598LtHjhw58HQm
qpy78tntU2egrutovXHt6MzRX7/11p9++9bPjo6atdS3jh0Bri88Lq1cZPaZRKaDmW3RaCzfyVWb
7dRCqVJvpmYLe/KBSRZZR3X0Kahk1RAcgKqbReJSQT8+VjRDSAMHPRMeQDsS11TpwEk54ggd/MH1
yM9I7Pg0azAsgqwc9A4gv4wtqLQTRloKMEgXY2Z1gkBBpUAxdmYFFroIq+CEgn8oDjmNuMFRlmCh
06z2ulZoRJRPCeGXUKwqnFf1Mn4HVw+EFfA2zkBYLIewRNAhzEwXZBaQirBzVOs9XKdXo3N6lmlL
whOhFZ+KKP4If4wV0dX1AAJt9vxm6KvGJSmF8Fn2u1gkm0Gy/DfgO6iUwcwUaRFY/saSI4uy66F4
JBACoxJmeHMaIhjXRhWbrmAvEanUC4XqYqnU6ZXK5YXF2Uwzk5l9cd+eQrObFHPaWlzpGR6khtfJ
6yAc3pjXquFDsqOx5b+3ngaHXCMV3LS+9jr34+CHgpWcEtdNaCWux7bvLdcNuPFC9uh0qHhsCzjF
QmT8REsd3g33IA2Kh781Gxs//wnU9cw6Wt+/cW3y1bfee+ONN978zTsf/OzoVMBa2HoEk+kek1Y/
Et56eGujtthO8JANysyZYiaPVqK5WG//nkxCHZtinigc5YbJC1sRFOirtTDb6EPR0O4FhUKORsQ+
zDQsRMmGyaPWgqcQqfLDKC9VGnTZUkFhYYcTYsQ/gEdpJfIfIghM6hBY8CsiDSihrtRlfAhgS4d/
Mp02IpDxaZobVMMlrgEdD5DxSCudbeR7+X61269XsJXuok8SfpipaAQJnBQ7DnFlmDsmuWhxUDHB
5EfAIrP3buBxktPl2H0HUeSVAqyYEKGQ5BEbcBCpyFB5SRmzHosAQaEBEcyyjuNbEQOEFUqqiNc4
SKewIu9BPEUO2AkBW01B+TYYortZxloFOW16zgWsGhomZ5OlRr1VQJEtv5gpzC4U8bZvL6YgLJbS
FaF1Ha5r1PV+eb3nRFzD66CeA2BJbDXypA9L4Ln/wi52qzUkayZY58K92qbfOzs0ZIBW38K08YHW
9bWbzWkVFHe+WE06yGPO7DDm2eyBC9vYA+XgROow0WWMfuAld+LcF5+eXRcJv0Jaf/rBb1577Ze/
fO3Nd3779k+PjkfKTx/BQfTHj4TZO2JXtV7tVj2rEot1kbXYXyg1y81WOdPJBiCGQbjPa50q4uSY
5yQiloctE5p7JWoJ2wvLIJZgqI1UcBho4uBpkOYcmbAvWiTNiejbGUdmZ5zXPno4jbEcieuekjdB
LyNMQKLFY/iA+6N+sYTY4/4YwuFx1GHoE9Rs+hBDkJ5kEIkvqOuE5nling2RG30uUi54TqfaWGjU
8xgUOTpl4vsm2ZcUyur7DRkuSKMXiiqx5AcxLou8+gVXfkqkoasyY8rfjDOhJBopEku85JnKWHl1
VARe8lGC64rCEluxS6gqINRkyrrOghCxF7FlPwkzaDKwCMN8DGJNaayqI/U0B/MknFnwTWTrsIPm
C7lKoVUs7y/CIbqwsH9hdqmci2X9nPCGuG4ur/vnN+NVBFYUth2bGPKXtmvLf25t59aZa9Lr3Vv4
zNj0B3CYqLEuDt5cWXnzdbRiQTmfeG5bqm9NT4YzB45wUVsPHl4wx5s7jwDc71JstzacsXNfXUIT
4QdoPQ5aj771l9ee/8EPfvD8D//wq9/+/OiY3XniyGN6mZ7YDlph7X9qyckm6vAi1HLJfDVXKJYX
iouZ2fmSC5lQUaiIZoqLdXDqVCKxbC1WXcp3u0mYjZysEc/aTsIxlSAuQiR6TVeDGxeefjDKgiQH
nYIkXsNIVYm0BsdEMbFkM4l3qJD0t4cGgTeojiRi6Zwn5LQHocUDM048oDeKy1bT4M0LR9wAcs3S
WNCUA7WsnowoRq6d7peX8g0UeywdBE3FxqZBGPEEkfiDG4gs5BWiSm319ZTSynf8kZtVZ9UoSAWf
hBWoiopSa4d5C4YVPm9mjYExBdQPKEgqfgXwK7HFKCs2ZE8L8rmqRJQ7V8oqz+KgHaPJYZABaYqs
G4h8QzBrGSA27NmoZ4Udzq5tpXqVpcZiKd9plFPzs+V5+B0ymVwXrhB/37oW1ycGuaaBsWmtvD7I
q9RfHwS2Gh1aWTP/iWYT22irkmXW+70+F1jFLSPiTe1N+KJMVN6zuZN/vbLK2tTZyA+Hn9qXMNVw
OtmtlwopTlFciAVGFg4c5PQN4Ap1bXg7jt759NRpnGp9f9AIBq2EPzs387N3DmG9/OMfHzr0xu/e
ProjmP/WANdH7h0BM//2vYl0Mh5zuu2lVqmUrJQbnc5SsZtfiAcnRnU3WemWMsUc3LndyFK1hsZl
sTragtaqeIPr0DSttBMy4DgMY6hoKBiEasoQYEDEDDGP0+FTUMhhdVAdPIhvGKV1AI/4BRFmaCbk
Hse5AUB4gZgyDbJYSrGFFkJKuc3FF5ApxYVsJeteGGjArwvlGWavMimFhryY48Cph2xUrmrSqmGN
jfv7Vka9siQjTG5nxB4h0PppJl9eRWwFWwnSVUFVwBsdZWgrCIrVwbf7TlBR/SZr5NU/wMrAF4rL
PS35DvqNonQlhP9IOmnld1G0kQ4OwbVpmCENdLLzd9iOW66Nz7SQDXI9iz08YrX8Uqrcg+W63CjP
76/O7yvvB2eZUr6dWM0J+7hulmt6CF4HAjsAlpvYqgv18pfy4r/rgN2Rbe7QynpSrff71bWrj6ew
42tiYX0wnEpoHcC6qbJybcY/F3ew+3sWr0UNHZ7rPbQ50gLhFQMhU0/HnltITA0dvXn7e6eF1kEL
mJOXl2de/e0ff/Wr37z5/Hee/+Gh3/zuzzNPGsXthPUxad3+xNN9d7EG44HTa2LWT6xSXOzEagvl
RldHcGdFeqmF4lKv3a+4yVqrEE/DEhfLJno52wHk3WgokradaNzVjKgoC/eOUjxUSeuwxm7X1CGF
J18ZUhqQXzqdyCv9RaO8tnHD/Zxp60xT6UQ9wMW4c2JqlHCNCLOInFEqstgf2MGBgxBTzYoyR48J
d8dilwqi4pHsxvJLrbyucjirgdQzflh4nKS+Al5+YG11mhpKub13Kn4VWfmcXg0yKJtxxrSgVaqn
fm5bgXoquE9Z1dmCXJEMsHyvv0Cy3waR3QrDkNeg5rKZkrJS6lJY0TEdBZ4wD84IRCPBsGk6lg2C
DSNshE3bnHOyYexBcNpmfyNTyC3M5lvFDDwAcISWl0rJajuS6AitG+Eq0fD63Su9Eut5LQqvg4rO
6h62TYntx8eH7q3xyLf+paAeqAZWYl8Q6XWrG69RyPvX5YX3bdKNdL2yPiStvN36zD6Elp5jsQUo
W2JZpSdk90nzxJGn8l7g9ZmZO5cvnJB5GoNz65iDPvn6z9566+0P3vvDj7//w+//8DcfvDozkV7A
T8nf/6i0crLcM10nWYjD5lePo+qO3Ewpv9TLLc3uy41M6HjRzizMou7cXKzbcKj2k716Hcdc+rWK
Fa2gAUzIi1hhs99KRB0DmzWqplytfhaJlyg+k0AQ4S2TswwCR6TLpuRkIJy4WilOPBCLr3EUuQCO
kaxBVpbFLcE2bf5J8jG0plDxZtpISicN23PZ0IFUiw+Dd1S0YKtU6ktFz4C1Cv6pELPHrBlzAPsk
E70ymmq1yjqY7UFOsQir3CPGY9JoSZO0GYRSTq/6NR3mwZjxJaFwIKU9DeljP9W7esCO6k+6A6oE
ufRAhE0NuQA5f46MNtt5u2EDSV/LBpvQ0zkd74aKJAAKZjxpZMeTHNdV6uzb3Sx16ANoNVL7Fvan
5hvNdqueb8ejEgnfM+dsgOvm8rqGVxFY8fuviYgHMTGWBapWlzmLtMnjLzrov+UM3be0e2C2N1wa
vuXg5srkj1Ren2JaCyveHoLWAbKoIu18dj5VhgUBqZ1EpfGtg/I4WZ3tqlNH3/750ek7l06hccSg
qQRaSlz48PzM0Suf3P3ZW3994+Xnv/Pj19774Kcz44mdjIUfY9/63NYDu6Om1a9Ea/1kLGbNpbvl
1FK7NL+EUoGrBSOl+VRmqdVvLqZasXh/qV5K5pIJnGWL2xqqrmhnO4eAEzkeL+rYQY2dV8IglIlP
A1csOOL0QtrdaUeio2ACX+KpUOkKI/lf1aTS+hP5kZvCZFdADC6kRhvALTGElwJ/BTaesEgAaBhq
2Q7c8JILOdfi+BiE1cgKYyQNRczWEskkbBJevJ22A4Qd/w5hBa2AFZmsyekVWrEE05VME7JLq7Ri
8Ya0ciq60Eer0j0fMF1J+Ayaz6lTcDZHHJ04MyIWUJFuE6cxbplBVmDZD6E1RAiOMFP2qyoP7QPg
kGG7Hoz7cAOHg1YI36bbim5FOfwnHE3WEdhblcpiuZDKgM58MYVeEQv7XpwtFheXOu12vZeMVf2c
8GqgN1gruG7G6977eSWwPq8+sA8qrBArzKaHn7yfsTF3aTf05lG0dFsxOjJ035oZdeurlJbapU1W
ZPMhtM8hft5s8ONaZX1oWunAlwUnkzj/JB1w+IivumhlWnBGjv70rT/+/tcz5764+iO0jnh/oK0n
Tl68i4cvfXjlpz9/7w/E9Y133h56MvziAYjyI9O6HZHwtrphZXl+FSb6WtiNtZYWe7VifjHVdOwY
GrMstOZxUSwU8ol0IpHHIzAdolNTMmpH4w7niXqcAmfAG2EyuiNxEJCwOxdWmEwJuZo8zO0oZ++L
l52WAMWPHieQRg4qYmtnAE1JEiR844HmqtgTIlaWfisQXNZ7gKUCf2E0COGJVvGE0u6cpuK1gE1K
VbKDmeZWrFtBGjsf1ecUjtJg3spPATOYpuNiZvLeQVasMamuTpLnaWF1xyqtOPs6EZDxMwEiCuyx
8IJDWjWVZmgmmXQ77Fm6b9rCZiAoukt7peJXsCQ1DgOzznnmZkBmuEqLSAVKa2fj2SC2qKiKma4q
rf91zw4FHctlV6pkCy+QyXaz3SwXm+1OM1MoNpD+nF+YT6X6zWZ/KdeL9qWLmi+ra3DdvrG8bqqv
qwJbGAA7IHaArKhsPabtGHpgPYlBB0Z3Yfe3DjwA7+Gdz86WPBjLdlCb13A6nKitcrqKae7BtfI4
O6umNmYLFZ/oCq0bz9Dga5ncPCStA31d/xBfcXbnjdGjv/7gnR/+8YPXX4e4vvJt0Lq6Th8/+9Wr
U19cvfrZlVf/9N7LL3/nBy//5oPXZwIddlF75EgYT3tXwgxF6/DKZ61EPWtE26VWuY8Wyov5fjIb
ye/H+Tmcy6/OLrWr+dliLlHpVvMVFOo7i7lKDYMsoAgR4AbbR7qeRd9ebLKCroUqIRANagYqhmAT
DmFQjGolloY7FEvWJRlD4jCAJKZU1nxcje2IFTaSGVU0DowhtrQh0oyo6EhJQVuRFjadCALJORej
5LP1SsKmpxHeRttgewglFInX0tV0BeXjui1HxkcZ/DIJDDbBLjashHMl/hU4ZYmuUmgHB+eAK4/i
cB6Q5HoBnsIYGIsMM0ogv0GDw7EUZLMJqzYCkaVoBnw15gkdRZWpfSZSSIbq961SsJgh4/aUg9Y1
zTVD+CYFL3K2q3Nal+Nadr1q1ZLxarWEjh6ZfrvcyC20Z2eR/SwWC/lCJ4eDOPVof4VWIVVu16jr
INk02L1iyfb1vv3rQGDvB3YgsWuwEWRl9TxMvh161AX7mkFKuTbkNH/fuh9bWqw2HYQzu25MK2hd
Fwc/Eq1Cp/iY1qwjW4vpkZlX337njUO/fOOdX79+9IsLp3FgbrAwYe7y9aPXLx4/+8XyT39LcX3t
h3/92cxYfBeE+TH6MmUisIqjoUolm3Zi3TjSwovNerNYb85nSq1Eq1nIFVP93FIJVYKlfi2ardXw
WAv/96q1Uq2fhUGihral5pwWdE0OM0YQqtuOjQcgI5rrxuGiMPFFHfnO0HBI9522koViU0QsXcJg
FHVBdzYNGzBqP7p8ScOlrUsqhrE01FfDuVY5gjcGVQoZpu1WoslSbQk7Zl2FfKquHdbH6eWYi6fj
1aVGqQRLraaOUjxRX5VGUPQ7rpj5V6c7z0hHKCGUb1xyX3qnTk5LFUaRBLAqJ9vpRZIbRc6yyi52
pYGL1G9W+o9qdPzjrlRpwSX2p4BV1R2LaDLioC0Tmjpn2gb/e2lMsIXZIlgPsz+TpplG2MrSZGYY
9dxSp9hslnKtzGx5sZTaj4ajuUK7s1DOd0q9SmKVVsFUbjfndSCva3gdCKwfEa+GxH5MDGIHGjtA
dkBtFVsqSwug3etmgGJCmG6kYxLybianA0RbqyvfWsUW/z6gnNq0jPN1tBJVrMeg1Q+I+UEW6d3Z
CY++/tMP3nnz5e//+OU/fHB05pMbTAsPFjpGYOe6fPPqKUD71q++f+jNQ8//5a3XnzT2Pxatz3qY
pFLFMaxe1KuhkVG/U+xXm+VyvrzQXNhfKi3Wo8l+rbfYSnVgburj6HSsFs/Va71KtNoolNteJOR0
4zTJQQ90dj7SNHYppP+Q2qPN8WpVVdzC9aS50BUFVEpdx5TxiOwAwcs2hEhahZXRdhBBG3qAX9Lh
v6P7AHElxzcOizV4XNoUjoQMCxmkaKXXjtUMQ8OuGEMcNWhRAI6LQMhw2o1yJ1ODg1gfYb8kcA73
ElyFuMMwGJ35Vxrz35NQPIDHhVXBVbiVbSulVcEz8vsJy1FXhrAAcLWFMEmVkg3JxjdL9Yo2EUDO
NzzCs+sINUwzbFgaoghu7rmtJcIc+2EDTgTKDIOJLas4YTYltV0rbtUSVq+dKXQKBVjNUoVGuZVK
ze5PgaTWQqnTL0Wr0QGtcknydnNcB7wS2AGvA4ElrysKu1ZiW2u0bg2zxPZhVpuUruE0twZU4tlZ
v+Tf9hcLshuf0sErwqa0DqT1USPh9Q9998jTBWPy9Vevv/fDX7785puHXvvFz2bufPq3+8T1fUzP
OX389pfnr3986uIXR99+7weH3nz5x78B1drC43RRe7aE0gt6aEXRsCu2FHMimMabK5UXMJu3mM/M
FnLlxUK71q1ly7vL8cVqPVdKdIuVfD5ZRRIHs4LjmO/W6yVNK8sgUKHNHRcj8two7Jsy5tQIMtiT
KiSolctQDzMnakFaeD6V52ODMlnRiuDQbCQRSxga231jorIZsaxk1AHIARn6hCiXxwB43g2uIMuK
1rJZvJp0PctAw0G4GILB8JwCAUarKN1IZOOYItNJ2CPSjhAxNO2FHIMs527kQKt/qFaolSX+CKzV
5jNcYxOSFxM/BH8PiqXfwNsvTUnXJ5oJhyUdBk7ZPkMqUlJ1FlSRbsNh8xDR1Iy0MQd1FV8l88QG
wmCL05R1bF7xpqvwIUJu9RDuopLNMdOWlUi08uiO0CwsplLFTnEhVdy/D/+PGqlyuQ75zQqta3Hd
TF7X6euA14HAisL6wD5ArGCzEbNcTBB9/SoJo2vlFIK5ltNFWUv31qK/hFlZ1mYzaKsoB69v9r0m
x/TwtG5O70+OPR1TJyf//NtfvXkITqU3Dx165+2jVz4+e4LTOAbiiomQFz85d+3shctHf/2753/5
nZdffuNPR4eUslRrH5HWUsJ1ou16NBvLeV4uEYm0u3A85PEqPt+rlQv5pUYGF0crW0HH/RwGsdgh
w/OMWLu7mIh369FK1NA4TRVzIGQOG9upOaoWiWh0RczhatRDQTbRl3rOMHemc1QkfKZDjGnoCXPq
Iq18ShCxIUSZ8R8vc9ONxCCt4TkOhAT6o9j7GmGekoO9H+bgoOYgFkdZNWaB2KSmwIQ4YnpxS4XN
nmdps/F4Dru6rhU3FBnYOjnNFt9TPAXPiFhg5DvviJLKm9wBxXIHH9ktTsSS+kgaJcaV8ZAUUN5j
TknA44OUVpWbdZlRx0MK9/qZAkXV1hQdvg64fhng03GI1zLAikydDs9EgCVZHVwrVFwbbzobCjtG
yI6kvWi1WM40ms18J4VdK4rgs3tTGcC0hD6PyUroflr9TMpm8jrQV6wBr5JwosDSkTgAFiHxKrFN
IXYF2XXMEtuHW5TSBzenA0x9SJuyClxyb5Xajiz6mqyNUEJFtrp5lsmPhf8JWjm/hu3BX+wpk0ff
/sUfn8du9Ds/+M7LKM68ihGSr5xZQytmVp388PrNC6D15+9857UfgNbfHh0a7hx4DFqrCdtKlCpe
vFCDo9+1IvkcutdiXG1uttNBxrGIPVExlY+X9u1JlStOKxZL4tBlMo7qXyTRc7yKZ1q2HXE0hUqp
s1VJDSYtePxllloIV6P0yoeznbZAxojsAxOnJxFyq4VUle4CPzUM3XEMyGlaZ0gZMC1XAsMw6tFU
G9U2nSDtCZRRdxoybfQdU8MYV0TzXVXB4YMApdi1dbLkuV59obBU7qYdE17nEXZkGkPmd5xlV7/M
OrnS/5Ab1BWFFUxFXAVXWp0AOVDTVBI3ysy2OEBkFyv2QeFz5UiRyhs+V8KrBOmDBLvEehhUcoZ8
CBCGbNdVVTCtDWPclgrpNB1w6eqKPBpCJIy0MfuWuyEXX4vi7I1joW/EYqHVbCx26t1qcWG+2YK9
H/tXhD/NZD0d09fQSkofQl4H+rpWYCUiXs05DSRWiB0gu4ZZLNHIdYtsbrDWbk4FU+F0AGmhXCjL
wt1VagdCy/zzJtHk7k3NERIK/7O0IsG0qxuYef3nqKL++Ptv/vB50HrovQ+Onr928d0HaP02+gpf
vnThxk1Ewt8/tELrSGvrwUentZa2jIQXT/aqDpwympbu1xJJuIAXcs12o7Pw4mwmVy+XsTXCUcpW
P9HuJZeqsUqtEndwMNoww04cIStOFMGniwsVzJpwz6UnptSoK06doGLjtCYY87d2zJD6p05EWuCx
w12kfP9O29n/RpHXcVw82h2YhXEcq6OODDfO9Wa8YWbA6XTn9qmzdzBLH3az2TVLLhhNmmuaVH4w
3A+GKLQHePIgIhCS0/jAeUFBczEYlRijvxrxJxOTu7/FX3y/v1063VuKLuqn9GlbWs/si8/T+/P5
TEzwCU1RrJDRTtD7FnV4caStKDXJTORQnNEixJk8TsNYGEVi3VU5mNLEzbsQtEJ+X1RCKE5UFKgm
9DhpzPcWFrtdtzgBZYVYF4F+auHgXvpW2GD5EreA7wO5g9utMKE5zMfS8bsKPKu6WUYavIj/xUVC
ORAk4j8E75isU6UPtsks/wbjXdGrsXXdN2yVy1tsWy1ITGSLWKjH4++GasiIMpjrahxbwCeAVbUY
DztGM0ibnuZEHvbadZC4NBY7R47PLZU7cLXVY7W5tu+6gZPTulPySlxz/7oDr0MRMT1sDmxO7MDL
5tBuLwXl8PIl/zC3POgd9qc5psJqueGz4d9M288bPk+uNL2wLXEd3c3/39HKifLPB7sPn7lw6fzr
ZxEGg9az7z24ePowtP0/+xCtX/36F978/lvff+fPZx5urCwjEj5//cyu3UvP4lsDV+uFYYKsR7Oz
JNaQiKZpkvj99uyR9pEjs0iJGnVIho9gUdfSXCNuzLegru62IzOsYEhLi3quqlgsA8m8J4oGI4Zf
7T37C5bowxToS1E8orqdzVNp8+nN1iVe0c2QwDh1QDwtI0FDCFEeUKB7muDtiJIRQvmgF1X8NOp9
XI6FF40CpBJcHzol8fay5lV6/W6o7cEdyajd7IQBL8boqhK5jUa5VQ0UrkHmchfOvR+YwBzOQK1P
FPnRJqSPY2IRCFMjgfql2NOEgQBJQaxLQtknFRGCYBa9XSGeApGs7oqv7BF5uoyYGSJCip0JLXhG
vGEogYKCHCvCegFOVS3IoBIZNr4Cx1vE1QOq/tUS2KV7lSwW2L0wqSPm7yHYXZqfW0BnPER1uHqk
PFeee3VuCUva2+UUVXFf0DqK607F4SFec2AZEG9FxLmHJbGjyFbz+JTQCgOBAxNA5mzyjbC8hLTU
IabbOd1O6fx222I2j4wXFiLO0D357vJOJ+UGUq9nppX1pW+feO745MfWL36wcW4ZUfAyaF2+efcM
xJh//+2HaQWv3/vud//0jx9d/WBlFd+7cgi07nkmWj3N444fs6kZvdQHpk6QZV0Ue3p+o3XstdrL
R5YqFb9Xn+kstLNa9dVatdnvLviLPexraiy5WVqPYnOSuNmmHmqam3jofxqWprt4SpZsRrySjbUP
+BbR/mCMW4RAiZmdVETkyPlPcI3ntkZPqRR1yvFU9HG8NIMXcnVOn6ioplp4AnPsW3aQ+wJXxKdy
jMpU7PfSXhZoxQMH92j1vk9BkIIQ28SwSqUP/bJWhPYCKuOpA3Cb+ycODhYsMgKmlp+MElDaYMIV
b7fKwsh08Z9XoKtkqMtyEaUdoLQoTrZSy0+SWVmi6gNcFgblI9FRpoqS8URRN6AkMQGqYYpFaeoE
E1Tq9lXT0TXoowk4GtUcwEFlWJEMRYJrDftZvbvUN5rdtD7bme2hHO9zbcRC1sCk1FylMt+rcxWV
JmgdxjV3r6O85v51WC+Rt3QA7CCHHSV22NvBhopBpLDzRONXaDmlQ/50C9PZx3Z885fmv3j7r622
dz1RNvwCHh6n4zqua/3a8WR6/cq9jeWVtbVDy4cOLa+8d//W+uFde/72k599Z4TWr3/rzZ//4szd
m6srJ08u07ciEoZyZHzf6jlu6ClaZJhpGOlOs4nuadhs+d1q1KnVcAunhqzWbx9b9JsuNhbU2416
ZbZ2vF2rV5ouhDYInIuUzcooJ1m2LKEirKLaa/Z8BTmaopimaejsfCDA5dOdzpH9VZZTqP/d3L0k
yTwIY7qsiioS5YOSUlISU1JlwzELTPf4KOZtsLsQv6M0sbkWH6t8+a9GX0NP0pk8ML1bT9LIsVRl
Eh0gJTD8CL2mQC8AbRy1mCZ6YHYQ4BLJbeee4WnZweFjAzU/XLHgGkqqIrw13P6UGLLZFCfhhX6T
GalY4w/UwDSNvVi8yOAa4gnEtlQnTnKsvCTjrW7qWqnIPKHAFFdM3RgKdCWSOA4rZP0W/iMpM1FL
illvVOoYkOs1mtnibGWh1S6HjXYVtOJu9cx8NfPLfhYbZpRHwk9xr6PlpmFec2BfHAKWLnZA7ADZ
UWaJT85tboLM3IYLSIJSYUOcHofN5Jb/3jyBHtjBJ17wSSGFzGkdjYVhz0Yrp+ROfO2Yu/c0ctbV
108eOnRy7eTrN9YuXTj99l+n3/7Dn5C35qw+lkj89teXr76/jECYkTDy1kLtjWfo4BiOq2iQk6Ma
XOkbRpZ63XatPHf8yKvH2hhgmVtaKgdGEgWthb6fVRdxHw4r0RPD7YU+DjpgBloxZeZyRdMswosy
7eShib0ICkXPo6DLFO4KdY9Vki0F+lcK2bk0F7kaImU+jTnhlmWJFqSmKeka/Inimi7kPfBGJTMV
o9g8ClCanILcV4J8AIc2MGuDBVAK0r1u7Bi90CuAVjUKvQp8TxEJoFFRCkm733IktGK53olY7tt7
kLCSUcGmoBUf4M3molQ+TCX/Zg5LpCGOAHpFHp8EmnSgyC/pTFWiC05hVA7jM8o8aCx7kzsm6wji
KYZEZm+xPcNJeg1fYsOHATX0WDq6NAVLx9/Gj4VDLrA6zg1XFvILW4vQJQuaZcwotKp4ji41GguN
+hxIPQLV8MxSr46Gmok+s5HTOsLr09LX3L8OZ7BDwA6IPZYTS9seoebU5ujyNbcc0JzSEX96fIvT
I8OW/97cxQpjNGyOPOuLmA4ArblzfWqhaawjAV8+8Tl/Yv3W9Y1VcPo64mDS+vDK6b/86kdvv/PL
b3yIVhyb+8L3//DDRw/P3zi5duikqDIdto+deIaJOR2hWeKHUSAZZa/EgyuJt4AhrFePHZtZaFdn
4Lfcbpaiz9pv9mqVCuoajSBOuxm6oJoLha4G4uB2ZMOAJ+CzTBX1GNZJENQBT64u4pJPNidFQbhU
UmIDX6QogvXVCSZ0nm6WUNlVJPgqWXUTRUdOi2aRLPPLuus6kVFEQMyhbjtR8JO5IngK0aiFcpIJ
9+J2NVzL2A0WFETPEFtMmkWMukkmj2rBC7MQDFwx4ZrLDdlvHWyLoE5YCIUHK5rwIIzvQDBkyUXI
koSvlMRWlqLIyJljM/rlNM7gCBXA5R98E6X7e8XI62BLlcqTIywAaxonjUC7GAuUuM2VWauKb2Xl
uMCHFIqZdJVq/9jDXGCt4WdpeYGH/8q9rNs5OoubCkfm0XMtY+dd5GqG6z6R1gGn4t0or7QdeRUe
dtjFktgBOqPMDnE7yu/csNW2Z6dbQe8WpseEvfbaUf7S1/Brc98+Aiyj4VNP2CSRAdenCPvHp5WC
JuD6tXn0bu7eXIGvRInp0OuHlldvXz3zxz/87m30W7+BSDjH9QfYrfbdH7/75zN3UBCmI15ZRb/1
Y+YrTFvHpRWxqpLEcZioehBoBtLYwEva2Px+dGahN/fa7OJSY6HXrsx2fK8XdHrlJho4fqW1mKLP
40ZhhGE1pJ08J1qSbLYZVQoCWHGxbIWT1IXNEzJQ5bNeCnB5/IXFJAuRsOiIFJgTGpZaNMwit4jR
tSj8B4AtRhv+VS/IphY7kCFrRWqlTE+BfhbxN0LhCXQ7HA8BQYCEldsloJZyPC01C5FWmizZExOl
UhF7UqcEhfSd5A82aNcMCk6boTDJFJjyPV3toI/D+VuxAoP3Ypm1isRUyJWmBndy2KMS8+pkdjCJ
z1uxfAAPURDN8i8rbXasaaIdzQXpBdAqi7I3na045SxPUj+hlyTFLhUhINbdxNT8Zt3vN3rt6txM
c6FebRw5QvVnrTY7f7zSqixkgZP71qe616fzOgwsic1dbO5jj+bskB7YIK0ERAT3P7H5HNI87N0E
dQvSV7cZPx8ueG3/RROU+T9BMdwZiYVHvOv4vvXbXzoa7zp94fbqyiHgBwDpLy+hefPu797+9U/e
+h7ut+YGjf8333r3rz+8eG0FUTPs7MrNO+sHnJdPPAOttqYq3Yh7Fpxy6qALnwR6jPx09hUs0qsd
6cV+JXKXFuabc0udKivEC0a00PB0IwrjRNE8eQpPSvgKVUPCuZutf3hNjSvCzJmMETJGwbnBvgBQ
hSxe6GkxmMNQEqTCBYHRAlhFxYXPXUSO8Cp4vtKNyaaJj+BsTBm0hAsKhIeTRQNuhOesilNwr/xb
Rd2FZDnTDhxAeVVBeavUq+A/yXUN0w1Upsv7Ho++cWZukLQKYgWtDHyBKrzuwNPChF8F2iSXi7m5
nUVmsRqxO6L9TVaJKl5YRBJ6Jn4Od8+PkTjLcLVst+JF6LhU0d1RkXfYKsClD0VV2LItU6UfLohe
a5FDeEVJD5HCKzqolTQ4YyOt9JrdertWewnhb1bBMGO1jDOQGJtbmputtiIU2RJ9J1oHnIoPduL1
qcCOEMuwmMjmfpYIbXGbs4vXIcOjAxuNenNOBZ+v4PjqY3tl8Gv5WwfA5qkz2e/gGT39hD7Oa5/K
10c8zbuOU2M69YI/uX7x3toqGjdrm7SevXl9/RfvvvurP/79x9/amm4Vl6uQtL71+3+cuXVv4wbc
ML55dQU64enkZeiMx6ZVLalKP/AbvutX/cT33CB04UH75aVWHU+DpDvXKPfn0jAEqxiB7jdRiFxA
kcntRWhEJFD66pGmIcX0FPCE+FfzNK2EmpIsoWjlQgvLMirFCsLt0A9RnSdzdoXk4mNL5dOzNMln
M5eood7Eo6u2imRawnMXsXSxhPBaTX0dg3UTUuR6kbhwiqkbHOAwdM0Nu5WyYWJF25SaeKmmxzFA
NVRuYkS2u2ffgcGYzcHNEJdAsjkj3okyMEkmyuBW9FsFsIJjURPmaRrmmQx1xUgq3SZHe9ic4aVJ
oezfnzDi5X8qEUWggMs/qKrhb3EKH/EGQUS0AEkwO63iHxq5pEFYyP8PWHSisHqC6kPFiU20sy1L
4Q4JZCjNpWbWxjGxI/OVNvY887pue24Jvhb9kkozcBXI/nNanxoOP51XApuXnIZcbE4sLPd3ZJa2
vSCU2xCbfBWEktEhTGFHaUOYvpyb+LXsAQ+rrPJ/DT7DodcnqCSGYuEdvesYisNTn1qULl+8x97p
obW1NQAI7e+1h+t//u07v/7F79787le3pa08NPfW7//wR+w9XMO0HL775I3VaxfX9/vPf/EZ5ltN
x4wwHtr1HOoiIG6D9lfLvEa1Mr/kN6Nk8WjVXTrarvdrZdSc5ivdDm45LMxXMGHne0VohtBzUdGv
sWC6Am5i/ClBU49uoStp5uRgkwKWAJNacWwcT0fmsLyRwz4Hei08gigjdZMRWk4VwBlCcsOEVynC
pzmapMUQt1tZOsm7FaoXmbzFDiU/Blm570XXu91m11L2YDe4Uvd9H1UnSQ2VInJeNynJvMwqjMfs
hEd97Gr5hhEwvv640ETfu4n2QH1IWkXPlNsKGcFubu9myplPuw427wsVBL+MUptd5MlpTqEPpo64
6BAdGwNiKzzEQFimRwW9piV2qYluLnNj7hA2bdWEjsJW8MYIoC7rRv3O/EsztWYj8Hs4VFVfKleQ
FtZbS43I89EpN0doHW3m8IOdeR12sCR2xMXCtsPzmFlASxsqCe1kR3LLc9MhTgWfLw4Zf+2oKnLL
h+O9z3VRH9rvT5XEyOHWIe86Lq1Y4t9WDly5dP7GWeSsiG1h51dW7l1c/81P/vb2bzDfui0OxuX0
b77121/96Mrd98+tnEd+u8aJuWtX1ycWP4ERnrHnW3UviBc9rWlYYaPup0YCjb7rJI6HAw6zmD9P
jy52sbK0jqdLbeH4sVfmqrMLc4sLzSAMygpIc7NuFIXdjgEH67Viw9CwTwciAAhv/EDTRYbHYLGI
OLGAZWN8qmtKkYdKeUBjUlHVAPI66J3MIiV6cD+mkRgmCFTi0CsibTNiVKDQ6NCQhXL5RMlBFCyr
MVI1qB5QrjVLkwjgA/B/AMcEYtS/vDT1LSTHRtoNZPZXSR7pFLASST7GlitXpIm7lHSreADvBakA
lSzTsGgCAbDKfFIieWRUqH7xe/GRIFboszZzWnZ1mKyzcC1oRW5dFF0dVUYEoaqmBqdPGaK8qdGS
bN2CtJKKRi5Ug77L0g2tl0UQURiJq3iaHwHLmaU6anzHXptD1Xtp7tjsUq0/02lUykvHWp20Fzqx
leetT+P1yf6VwNKI6w7AkliB7DZ4cmgJ0aAetEVuDm+O5+PqERglpXnUO/CnOaYvDJt4bFDuGvAK
G/Ldu2DDxaY3qPwHriOVpty7jk/rkv6x03evbayeu3EWHZlDcLCr5+9emf77L9/5zd9+/4NvDeWs
33rz9/94+9bd90+eFW5Y0Hrvynpx/jnM243vW1M8MQItdHS35nstj8fIYziqetTNMr/VW2g3+v1W
ddFpLPKW1Xw9XaxWK4utWi3UJvYULbNsRC0nMQCQW3RRmgT+qA25UQxgNQmxnrg7Z2ECjkGjUEE4
yG4pJ6CDKhV0SClcU9exIoUpsBN4LvJhtHIDNzLQnkSX1XId6HoMCYdfoS3kxKsyUWDYrUrcn2p6
shH4KXauHNiPEDMwAwXdR7RgXV2xuZdULArObzoL7f70QYJIRIVPJaX8IqndOtPOzxkI7wGaIk8V
GkKxppASrRIbqvSbNOEXBccFfgeVS3CcYj6ngAia8S2WexsII1C+tUXnBuECl5Ui3lUtq4CHYCyu
SZYRRF6UJKapAdVu2A+W5jBa4Tfq1WNHjzeStNWuzVehOVzARsCl8mKn3E8jIx6awRkjfYUN8ZoD
C8uBzYndRg8sh5bY5uDSiO/oR2R0AGlOKW0bpc9vt6HkeYTX41s5MMdyisM7ifHIU9aU8s24tJ6a
CSenLj68/2DjvbXVFeaiaysbUAj/4fu/fefnP/7Bd5iuPrZvvvmTP7x9+c7NZXwfcV07efLce9fP
fKz0Eg5DPkMkHJkOVA5LmaXNZT7aBIYVc5tatQOVWNZ1o1YHl4AqEYCtOBHy2dDDUtXAa/ZLCGMl
LSwnYaK7aSy2+yJlVDyZDVNb95wi5q5ZNFHRnFDgM1VVRkpb1E2Zud4EZ1tZ/EwSMK4HhoLs1fSD
Vj1BahdocJeuwqc8XBplUYolS3tRnRUBJSXzEi8xQiWxG0jriobYGF1VdUJyS0oJ0YGvIVSW0EPZ
3HS4aZsk0kRblY1VESHzFdziq3w/jS8M2N6kdXN0XmaRSBSGVXwEOmGTFH4wh8V7NmEFz+zpADw8
LKpPJcTPdKU83lWSzQDZ/ISQ/qtA2lIhtLYAPnJ5/nju5oc+K418I7bxNQ39smaAqkGt3G326kde
m+sGvXIV9RUkseiG459OLGkvNzRN6Y/QuiOvfL+TgyWvT3CxnxpGNvd4tBzaAbhb7PJNbuRTEEpG
c0zB6QioHx+yofp0zusWsDR8NL/rw1KJTxLXT+6M69b91jGc6yePNew9p69cvHtz7dyN1eWTy8sP
Lq7/4p0333rzra9+5Qdf/zppZRj8vW+8+e5vfnjx/u0br0OaiKz19eXXX1+9fWH9M86zbVHTUi+r
lP2ludDodLNy3de6/UDTGjiOv7hQyZyo40dBHEXleQx8VCqQpDbKlVYaJgogciCsCJMILkOTbAsz
Mk6mQ88DuaAjWa4ppO1FW6R4kE6oeE6zHhq6aCyK7EwzNDmBAzU9ifQhtoSkx/ddPHuhEYY0AvoI
GaBYoDH1Y0XF1jV86hpwR9zD4Oiloti9xuQVT/X9mHrdi5KxA+WkE+qoXykAe9+AyUFdaeuF463T
eKE3HWSye8VsDj/fKhxzi9MeCfljkS1XNlhBLRtPgx5NUcUjzFjFJ8zkJwSzkqKSPpbUCnCudkFW
DFdVEdennikVKEfk3mAJGYRlogIuM3MVM3Wq6fV8bxH/9SbAdbhlMgyXOr1uD9WE46/V2riqUJnv
VJGvNRrtDgBeqDaaiWLnWqZx/Ouog6WNAktiaTk9tJxZYXlJ6OmWMzpM6TCnn4N28MO/M+c1LxBv
syNcnrh3+5P9qMB1p9G5Aa5j9FvFKY0XKhDIPbp14fq9mxsrN26sIBX9zc/f/O73eB0dnIq1h1/5
3ld//PM//+jW9dvnbiAEPgsvvAzx/6EHF3cd8KgSHp9W6AlbtUbSaypKrVPpGQhLMdzacLr1VtZf
LCeZ1mylhmOEPdf0O92mX3Z9bI4IFQZysYMUMgjR8TTgKXRL19hJxKY+R1fwxIOzAUpC9CPBEbHM
oml2rFqD0RT4PrVoeknJ1OGw8HQ3Gp5vmPh1umxrupOYngrpol4yXM8GrIrNEJQ72ywJkicvjTVD
h8RC123bMXXcxKJkabcW9C2E0w7iaSAjwbMOFi0JZIXbHIzDIRgWqOarSffzI3440AjDcLlnEq5d
tzSNG37hQFktg4myEjpLogQM/AoqaJOApqyjzKQbOvBllov/MN6L1xPTkYyIOXUILT97NUjKS6qt
I7a3kdTyXzU6a4ttbNePNNUu6rqJ7L3ZhHgJyuw6po1fqaIa7HfKiPzQbz1S6cwd5+WpNHQUM6d1
fP86msHmwJLYPI3FnyGHBxvOLnN2hy3ncyQz/TCnjzH9VP5udKovHznIDZ9wO9TLQ3eYgStpzXEd
vTM33rzcCZyqerWn7F0/c/U6E9iVe7fWf/WTt7751dze+uoPfoC5m9O37t8+e5bFKGGY2Nm492jX
tId5uWfY9BI3vc58amZNxVucm3MUJU4qSRYoc+2FRr8exqHuQdXveX7WD3GzzfO0pBk4qNVKkMrF
shmGIbAIXHZdwgRFJkr1da5CkMUeBXFoAk1YQe5u3WHPX2KfUga6sSpDOZio8mZGa3v9RNwuxRPb
DeFTXFPVWFNyDc0MkxJ/CjJhNGdM0GwGvmIFoUWxglLitPoenl3fbTn9eR0ieQ1yXEsp7j1ID7m1
I03ASBb5Oi0+3RrE4aNU/Isvbo3l4P6zJJUkKKTgHHUdx0NEAi4mWbkTmbsPxYOTrmShj8pNSgoW
I6PQKxJdTrHanPtj8QwleK/fFTd7OHrPKRtdRe2JxWH84fdqbhBACBFEyMvRitWNJEuTqNYql10s
9XjteLvXK9ewPfbY3NLs/AzP4czOLFZDZPq5qn98XkeBpQ0DmzvZHJ8PeVpyO2yjdI4wChuGlP8k
jNjWLxzllbZNW+HzdM5HcqtjCvZpFzb4dtzNEVjf/4kXa6khP7p18e61m/cfrUPO/93t9i3cwHl7
+gK0xIfOI109eZ6GTPfBw8u7PibNfvpZ+q1ulkadKDleT5rHZuY9XfMbC17oRZCKY7n03GLdQyuz
mXRTDEAvzJeXKmkUmJq6d9IuaWHDhpS87wemZU/acGVB1wskXZUVk09iLg4WBzTgXKjzoW7fsSW2
GXk7nWK7SVFBZfeV7kl1Ay+OYy9E0TTyzMCB746cbtjAReEgK4e2JU0oftqJHOS5Sai5mqS4OmNT
/ChpEvdyuD2iGLtNJ1RtA4JjpLXoz9AObBHLD8gjYcwfIq58YBfi5sFXBzM50EdZFDKgPOs4OkeH
Bt0aoQsu8A0hK9AxIjPnkQDbpHzSZrzLb0CZVy8WFWTnmm0aINHQbbrgoiQmFRSdP15nLM3KdxI2
ITWMwgDVJhN1pqgSRVm91avX+8oiot+lJq5W1WtHjkOqgmRt8Xht5ni1HiN9yWvC/z2vObAjxA7F
xbTh7JLgDtDl65Dx05xQMjoS9W5x+slhy4F97F+Ba95/zY0dIW5w23bDMhjgClp3KgyPByukwl/G
1Nyp59vG/sOHb12/Blr/8u7vf/zj73//zU176603//S7H6HTs4GVTcvLZ88uC1vDgokLp3ftmso+
h37r2LQ2Gl691k1nelG5vtTzXaOERiokEhqU5P1e2PD9Vpvbpl0t8Ruh2+35Td8PTVnzg9iptMpe
6vpF1nmSWDGamYa8zKEmYrA7ASGhjLcW0lbLcVEL4hdYBy2WGAfiA5lPZrsAs10DtDrQ8Wcm8tCo
HGWVKIsCN/Dd1PFcw7Lw9He9zDP4XEdDxwCp+CNJ8NGIu6GVwL3IIHUgiyyxCAWSpx7Xggf8CWc6
eOixKBhGBeLm1m/sDsbDHM8ZpLr7maFOFI0kjR2ZIzcS8JxiNsr9pCSV1TL0pGQqCeE1LRPiB5CL
VzpMqrtQXEIoUnJsTetm/b6rS7JKxCUSi78sw8kidcCPUJQo8BEIG9ASQvKkaGHYXeyC8EYHlGbY
P1n2/NZ8bbY9g3Ec6BDbaLm2ZyqGoplRTusYvOKjMYAdRla42VFoR3zukAflu2FMd+aUv27oNw54
3Z6+5kLIXA7VGFYOO7jUMRQLj3jXcWDlplKkneD1udfS3Yd3Xb4LWg//8I+//vuv/vaHd9559+ew
n/7257/64/rV6xtnz66snL2R2zksb4LrN14irOPSivpuc67ntpuOj20cvgcnlnQRkkYptvLrRug5
/cWmjzb8Av70QghqUg/6+oLm+0bSaGTNuRh+TC05jZbfLFejIAvQYJBEZocUjNp+uCbkqJIFbSJ8
ShGkQWmHxo0Ld6BRW1GEXykpk1qExosdJ46GUNHyk8ZiiJARRScrVhzDMg1JuFHD2i0xZ2TaW5Lw
M6EksCUIkMWZ1+k9bg+ynxSextZxkebgAFSBKl8fH8wgnGBxqMk6QHj/puPFN/Are/egTCtbTqKh
bg13yax0j9jsQlIZG8gaytWIfeEnJQWwgj8e8AJ8KEzR5TKOQAZtRYkRYJtVbHKklTsfLZ37lhCN
qLIutglrWlDSAydSDD+JJQUIukG33k1R2PNRZeq34VoDz2s0MCU6W2theK690OaUd4QkpDUWrYLX
EQe7E7BPQpa2PVDFa04uXncwfnHLxN8bxfQTo5ZLrEbSV/AqgOUrYWWD6MDQ7Ugb+0y3xcKwZ6SV
QTDvyn3k1EdfOLLQ9KxHl289vHYbtO5GAlQq/eYvf//n337XT//297/+EJslDp07t7J2fuM27eb7
tNsPr6yfvnx6ckHUmb48Hq1pFPY6/eZS6LU61YrvBJVW3eh2E4cbXYJ+N058X1H8wDCi2dlWpVYJ
NHZXm9WuEzeqvXorsg10bLw067lGN1JCBypA+KDNlA0eVcHkmiLBkTqhoTiKrCoIFgExT9hAaIzU
0mVpBuJFM4T74lRBSZVMI/WTTgzdsWmq0DECbxVK46mJPRTpyqpodKgyqjoQUYAISSww3YfNS3ut
qFHtNC1kmZI8iIPzHYbb3CwfGyBMccQAZBCK6tNmDkuSD0LHJMlIr1GIVlK0XorcCMExV8QIomNT
tGW7SO9Z5E5Rukt+IEuWRP7gY+lbgTX/PzBMRMKhY6tkGPNwKoreDpJdW0GsbFmqZsZoPLmIf3XF
Z8UdKu5waalerrWyRjPsQSTRCBwnbOKSNLSxM2W/0uWca62eGFHUHqX12QNiAjviYmlD/IxASxsp
Dw2zyZctREcwHQY1/42jW99e2M7rANhcaPzK7C7YJz4ysAIqxU9LXccpMp3AiY0vfepY10BR5PLV
h/c2zp2/fuUzcQXzo2EQhH63XGuYb69jDdN7q2vvbdx8cOnefdj1hw/v3HmIC66nH124tb/7uVPj
0xoFUbmSBq1+/UXshYg0vd8Is8irLDWg2weobqsRoiGTxVrYzNw4MRMdRR0ncFwlrkdxGMhIvAIX
5Emq0+8VDAMVIZ0rmcSYCQdZGemimBQGUEUge3NKnDG3UVySHA+/UDeNyCraseEmTNPgTzSzJMPv
yGyY2LbBWxTw0th0CqOfYtXUkRTOhssWertw3Tx0w73gsEmzXsWGi8RJMLL+MWE5lwRSmEB20E8l
o/nOQxiWmKJ2TL97cC96rRyqV11Njf0QQ+SET4gkhPKqIJM6XtBgSKtaCjvMfMH0DCrJcLncM4UX
OE9H0RHsV3wT9OtMUpHlllDPLjEzQD/WcIIgMRVbV+FiG5lpoYclK0kUoOvT89MEYu3js4tdw8Dn
Ub+Gpd/1fnnhSGsWu3jSbtqbzWl9dge7M7E5siQot+H0cgwbzk2HIB21/Hc9KRwmsCQ2F0ihp6vw
DN62PYi7Ba1PxnWcQPi552cWGoH511/88eKFhx9cu70KWi9P91/55MdfeQ1irddeefFoOomT6Peu
XboHRnFg7uLVq1dv3bpy5cqjR49OHz594f6Fg97RN8anFZ3JWqfvNY83EOlmjhXPz7X6md9eavR6
qDfpIbR7EbymD41TpkMRh3TKMhQrUZysG5uegvTQ1dwIJckojnoWGiuGJdFbwv3xhAR3gSuK5yhO
okP9ABQVRzcUNP4lR1MNaIxl5Ge64VtqyKETmbpf4CChN+mhKGU7qR+Z+JEqvBpQKMEbmyiYoiUi
YcLdUGRL5SJfwHpwHx3slN1sL8721KJS4D7SfDguF0YMmOXDbKjmRMMG2O7HowyDd3P0FP0hLTBs
p+fZsmyLOByhwwFOzgnxRgHeF7xxupfjvTpgVSXDlLE8WHALONUCNyS7TtCvNxQVjwgxFEJgKC4l
ijvglt0U8WxJzOKbBtqwPMula8hh46iHhACFtmPH56FfcQwnRN2vulRudCrQyR5bqHWycqM6Suuz
Z7A7E5uHxduRzRPMYXj5SoTzz0ds2JkOSMUv2W74fEDsaDicT9/ScskxHt0FK+fHIuUnxcK0/5xW
SJmeWwgV+Y+XL1+988H7589Cfnj2xsb1K/uqPJVO++KJz1f0fY/ub5z/4OLlM5cvX77ySMB6C2/x
/syZW/dv3j2gd742Pq1Lbjg7y9UuXqs2X/akuIq7SNBJsBPfQ/tzYSnzIoTLWqyYEboJug6NIqF1
XWSVmi1bJiSGdsHphV4wSbEdPmEzkumaoiPCCxDjSllQb1ViJ0hN8FvgrhPVhlspqFztwqOtJubm
9NDTVaTEiYU9CiiwpEtlp6ignYtKk+8p6NqCVwmFpmZkGtxnRFGCuO+K5g1WpE3DueKARjHgyQ8F
nRUQh8gWlvtNtldhW9AOSMajudSJb3Yd3I8NL/t2W5KKIm8YGyBI6xtc7yuz0Ivoe3ovNEpU/II9
sDrJMXyLo38crwGApVKJ6anM0RuRoaIg7HimV4auCxkvkeamqRK0lfy/03azCKJoR1HBqE59omSz
9u2FmdtPoGhy27WFWiOExWja+mVk5/02dgrXFspY91GuzR57FlppuQQP5O4I7CiyNPI1mmI+3Ug2
bIjSnNMhE79vZObgCeHwYCpoeD7g5fou2Ee3cDV3jIX/887Nc8f0qUcXH969fu32xqGVFQy5rtzY
uHt5/+yXToC+b+NQ+kfni/sf3d24scFNTZcv3v3g3qVr1y5dwptr7z+4dPfO3QfvXT9d6H6JP27M
mnCKezcLSdPTopnZRmxqcGVQiteqs/1mZ84NKqmBPqGXhR7C3sRxTEMzAhfPPSVxE6dIx6l1g1aY
JBrKuTbU+VyGi+aqLGmNhAfS7CBGQdf1Q87VkFREjYoFZ8I7V7rYoAs/iqzWUTCGF4VKnMETT0Lr
riRoYEqhWtAcFb/O80ILDhdqCBSabMMpygCcG8V5REfACt96cHpaSqPZtKXv3sOuzUGqCgeD6AMy
SSwApm1yDBsEwzw6t5XognxskrFLUhyjKq2iwRTaLPMOth3iPetCJb3IUhqwk2Su37coMUQeIFu6
XLJZG5bYfdZVIzAjWBq4CrxwQaS5OvJSHd1cXrqBODtSTCVi91oxYwi2VS71D+ooMYWRHza7ldqR
Kg/Te54bhWGUognebVXaNWzfWZijd3lWWmlPA/bTOxCbUzTgdnzjX6ONYprbE5dcENehcPgxsNtn
YyHG4MXJPVvT6Y74nZ8dxfU/Vwl/qrzv8JU7125unDt3bnX5EDqpyzduPzyzD7TCt546deJLM95n
Lj98cG71vUt3zuw6fecBmqz41lW8ga2+f+398ysfXJ5yP/qRb395XN8KFdvxltZvuzqeAmi/hA7E
bmmjihs31c5SbbaRGPhCojoVSIATtFign+8nLvJL2/VluAVDU1jDdFTTKHm2OGZIUY9S4nE0NYx6
nq57rJOahkqhk64XJAWdVyWOE1SI8AMUBMwu5Ovw2Yrfi7wUajxUm5Auq3BcmBZQ4FcdfFlD5QYx
tB1rFoRTu7mIkMJ6HmcVsE7xstVBc3ZxNkgKOFEl5t/ALNEUH9NEKXgALzSJgmDhXAWuWxVjQM05
XCtGgBBloSYXQBTG/kQ/h/dtVFwOsFAOshHxgz6JH0iargI+i4/opZINzzyJMnGJbR0k9NB9BR6U
JBTzW1iRjsCEEg5Ls3zPr/T8CGm753puE6hqiWfiJ5Uc7PpuhCjJZVmneqyaxq6mGEFoOGm3mfp+
tpgutedaC+2XXzw6MwatYwKbg/tkZgHAUI7JNzuaIDs3/NUdOH3uKbyO3gQRvOYmaAWuL1HbNPMY
1+6ocxX2n9P6fGMfRtHPncNCJi47BK7L525fOL2v+ulT9Kxf/NoRc9/lh7fRW107e/v+mfVHl9bO
YuXw8vLrMAzZnT179ty5a1dPy5868e1vf/vL413WgJBwtq+Ffd1GT0XOvHKEk5Cua6RB1MmOHD1+
vNxcSjV4Uw8MURnhQjynAC7TCLWSiZqmi79qpk1DcyRXm1Q1pKJIJfu+AiWimzVDZLZJYiAMBGuI
c1GlcQMDCvc0DLqK5ZhqSTcly7JcZHZFJ3b9DC2LLOWyExkY63CzioOGCFQ/3LZrxh4Cc65PnOL2
4qn9mALnRrV9B0WhCWsqFuuv1ku41Er66EiF5duCB2J9fGVw+1w8JB6c5juCS80/YmpLN33XAT4N
6J+V2OAs3CTnV7mkbbcFahLdFpemdE0CffC0EoUaHF1FKGxYaNCCXrDseOKYcuqnplkoMrAo4Nu5
4VGzUL+O/Wq3HnIpsIuSu++6PKZR4sKKqD0XzgS6FjfK5aVG0AggSHTiJI5arSAE5GlQx3miVu3l
F14asyY8fg6bO9kdoN0EbxuIfHnSJwKYp3vTJ7eTcl4H0XAeDg+ABbL5mKwQUKVsvr4xwLUsaM1x
HZvWz1enDl+5fu7cWYAKUuFdV87hDtW+2kdBK2bVX0j2n354bRnS4LUbN25ePHP6AmZhXz8JW1m5
IbzryurqzQund7/2JUTN4/nWlmHU25HnVxU9aHYzONjqQpChlEFdrKpjKalt9JutFmYrQyerY0km
1ooEaadZyXqVVh9T0eFcdTHtZ+XFalMLPMPBjEAGBx0kQeT7seYYzUbWS12kWRISMccChXoRZVwu
STOixa4CPVJqiw1jmmvbHGP3/bSOslaaaVqBvdyiaiDgVFQbe8YJuwcvVMSqJ96qg1/FQVcYU9ap
vSgzyZVZQ93Hku7jHS6wrX1pglg+jlc8nPPL7ya8AJyfYLAdwKFqjf5mLwhdSzZTDRkoaeWwOVcv
uVmz5GmmSZUSsvmiTC+qWLznyLNbdJslmf0dhPomQvwwbTZ9VM50qcQOFMrBulYyQgQncQ976tIo
4qphTuV4Qb0cu4ilteZsrd5MYtOoL5YzP3Yd0I2KHTywH/lI6EN3sYdJnBc//uJc9b+nNferT/Ww
T4N2fNuBUrjW4X8jdr7wnm9727KcVsghp3ehIjx45s8P1YXHpfUjJ772cuHw+oXba4dgyxAAk9aN
O4yET33kxBdPfaK15/StB2tnXz+JsZsbh+5fXb984doa9ghzDHZ17fx7Nx9cu/bgEpxx5XOnxs1b
FxQnaSVaUJtpoA/fV82gcsTRKjgwWOK2L40dUojjY03JfM9H9WbpeCUMmotx1kqR37aX5qB5ClzH
9r2yp6BYJHGyRo1NP8bUeayoRpoitg3Mbr1aVwpMbE0EtJA/ubIWwFFDhGxahs3ODIrEpseGjeHE
9aDc6fS8BMUd1ZHlxGPFSlb4jbKM57Q6CUUjhsDhVJGyAtbp/eIIHUAqNboTPNQ6ADRflAYW+ZBw
nISTn9Dj7iPB1C89PgBJbqf3FnnXLfN7Wb3cDTXVdL1A4UZCsU1YTLM6XsIlqm4oSwY6xwgeCKvC
NrCkUhpsq8xfpQJybRMdUS/qtvw4tlXLllkwl8Cljj8lHV9YxCXWBgIUPAJkJd2PupLiaTOdTjfx
jLjvV5oNr+m5DmIX0438uIefp2mJGWXVzuzHnz/aztUR/z2wBDVn90ms5sw+G7efHrH8J+f2tAu0
5HVkn+oA2HywXeiRRTj80uaqplfGo3W0zBTvO3z5/sY5+EuwSlrZwdm38NlTUDlhZROc6Rqw5Bam
5eX37l1E4/XS2jm41bWb9+7euXjl8hnYOuZwjr2Bczpj0XrUCeO6ZjYXqh+341YX6jg3Xpyr1hIz
hnqm0kANs2lAA8zmJwJbBVIIuBIzsi3Hb0bQEcHwhs8ythuMxGO/1aB7NUuqEiDHSn0vNozAcjPP
Q28UcTCAtBBJOygtGZA0QV4syXiCGp4TaEHgyCWQ4QYpjkmUs1BB/VeHNwq4v1SHe7X0xIKkcOrg
3v04EAmDUxXdmz17sbV3ajeU9/COHCuncYqG76GTEIoH/BFJKd+BSVFfEjAjhx3UgwXoWM8GEDUH
wr9q2w/1guX5BsX7Mg9/cEWEPmlqyEx1E2k778BZXEInabaO2L6IkF3WYShEWRQPG4mPxnnUne02
XSqIudeb28AVWQPhaoBz8+VqIzBUkwImDufrWqgEOs6cZlizDs0IhJ9BVokNTTVjfBEhiRsj7Q3i
IKhXX33hhVcXwjFoHaNMnBO7M7M5sDm9o7bTN438tH/La+5eh2dzCCwtn24nrRQ9prxw9YbY/fLx
J+A6znjrov2Z9QsPVrdoXT53/t6V6TLkDqc+0SicuXrvPcB6aJl7XZZXbt6/dQaiptvnNx5cv3OR
XdfLsCtX1g/o1a99+cR4tKZm0lxwjYVqKJXcDpDyu+KSWdhA9mQpSeY24A96fpcaV4UblBzVb6aR
H+sWGPXqvTDUwJMdNVNPaxhWXFlIofLPeJ8myrqR3zWhpFAdW2FZNdKQdBoliIEdw1MndRBtAlE9
Qz4naZTalVz+4wCxcOKh6tTs9LNmz+VzXpNNXTJ5bFzi7kQuFt4DHT+MYTC2H2LuG552au8UZ+Tw
Qp8qcD0gXgEvWMxlwyQ0PwjJLwiMuUKNY3IFOfZ8x/SyRr2fRZpplfzAlcR6Jp6W4nsoDU1ZYg8L
/znoEuObLNuwEAGjKcPb0URPtS0NpTc0ZBITlzAqrqvZ1Dch5If8XzItnSIInNjsNnBgyzXwtw00
e1BochCXBIFf70cJ4pogg344xKSraypUUDiG6TqKCWZ7lZmjz790dLaf/e9oHaI0d7f/BtpRdIc/
GSE0t/F5Ja7DvA5vtCCsOa34hgOsDgvv+sn/hlYel9t7+Mr991YEridB6+rJS7emmy++ceK5OXUa
jdZVPEzXynfLG/eRu+Ju5L07l0+fvnzrwsO7d6/fv3f96pmJ1pfG9a0NtG7qlQWIptQsnk0RWTX9
bliGNpiNGheKh3Krb4Tljq54VqGIVDPwwjqeVYZuG57lQvRq6wWeOcQyea+SosbroviR9AO1aEDA
GCYVy0aXB6TqYtATQz6RYSKoLRpagbOqYYSZFAf6C0+ZkMXhFyRnsaclfmhRBmA0Mu4apVpRVQwV
p9bRucH+f/RrACvcKibKDwJW8Qd2YGuH4eDuI/wqJ8xh9KCC0cGKfr4KWocN34tRHjVMfUdD7t3C
HAPiXDPzXAiquOhwcGFOZikYLRpNo6eLVRRyWRpDXRcdVRSNbRNdZBax5SI6WZofRrhLgtaMJYJg
G1+xoYWwOIgbLaZBWK+WXdMKTATTFr4Nj6dQG/ZaQdbtuT76Zx7aOKgy0WUrOnvWop/ml4+88vGX
jtSy+hi0jh8UP53Y0WxT2NM+wcuY9vQL7/k2mCEDrDDy/CLD4Ve/9ERcx5m/eeNVY//6xftrNwDr
MojEHaprV6e7L7zxfMv64dXr76EFyy/AwPPZlY1r12+duQxxxIU7Dz+49P7t2xsbG2sb128djD77
Zfy8sVT93bmjxysoK1pSnB3txip6nYuLgBUZUjep1qE+rRp2ozZreL5VVLzUcaESTgx4P62SxWjU
lySt5KmIjDO0CcGVbmtwlp4mmUnDx5OpGYcRei/I+FActrgawW9lBmZvoLvPPBXRZmayC2TUYzPx
bDR3EH1HDc9NIl2RbJPbnSwN2ZqhTlLYB1gZh+4lrAyC8ToNZuld9xFd4rbpLUnmvmmhSZpGvfdx
y5XkbtuoNqhCkdyBAJEaJkwk0KMZXoRarRYBrBjlWB4tFxuYWBvGZjUF/1M4rmDbGmL6REVbi3Gv
XeDGC10tGY6GNNRG8Rd9MATDfrMZxDznBZZNF1VjXYiBEfa3u2HWn51LIk1J6KWRFKD+7mURknfN
dQMoRCMuxAgyBDnw6EAWmkxEKEmUtdGmmKk0o/F86/hONud3TMDGInPLo+cvT+QVwD3xoCVtCFaB
6+bwbHMXZ+fwBrA+I63E9RMV/TNnLtxcXeaOUpzVWF1GR6b1/HMVa9+t6ze53XC7ra4CzfXD67e4
Z4KdV9i51UsXDsSIncejdfbo8+VU04NGHDa6s6i1BoljNJYqkeOFUBA3YgPa1yCt9t2oHikBNA5w
GLpsQvWLw1VLS71QnYC0IUosw5RcIOWmQeopgMzU4nozXUTtGDoGC/1H1QJ2sgq9kmKitkR/lARB
E6QavhJ7OppEqKWEmuNYstYMgwiqRroet2AhtFR1qJN0G5Srk1PY/I9aMLusYJZJK0dbgSrXBQvw
Hm9Ew6t44OAgheXXB/HwoATFDaVihbAgXOS2gFUtWU6luohWSgspuJbYiAGMgl2kZmkwtMrhGwlU
cpW3bZU0k4oRuD1Vgesr6rKKmpPi8DAGQl4nDg2YC+b8BOm/YnFaHX9D48UfNLrSxdDrYolz5MRB
xLvXrmKh/uSZvbqTNoFtokVpmCZRAomTqiBhNSSG0YiUZ2dwJb3lw/5ftJLRJyL7n3CbgzoGryO/
/D9wr8Mbo4jpFqsDWjFL8C/2zubXhSgM476V4qjjY8LRqRqcE2NmMEbH1zUVpoKKdJJr0Z0QiVhd
KwsfweIiIoi9JQsLK/+Df4D/xvOcNqqGUImPcB/MnTudlEh/9z3vvM953+3kFQWdL/2H8ybRtc3t
Vbfuv0Sz/j6S0/4F0to4u22nQqH16RX25P8kTqBDwebDw9WrHzy6Y6s3mMdx4cmlNy/q8gDMhxPR
evZAHE15lbwQQRYf8nUgwkh2gnOh0gfb7WK621GRqMUhap6Y6NAJ48jkbWUHpe07LQEa6hM6CkNV
E3Gka4lKXDDoOcJv91SqnENFcSYTrseC5Ar7LEm7CB1RnrVD9h5Ou0GYwrnkylQr5Kcqz3tKCFEo
PxOOB/d+TWJNWV3qCNvMvzocV4HJOnbKHDmFf6lhUQWMlIVyCKsdntGo45wE8zc0JJUHQLq4zvrN
qL1EvbF9sXHdpHdkH9rFoZakgZmn4mIZ6ke2AzgW4vgDGNndwaHhCimqwc8jAyMhl+uguMa2Sx4k
+Ng30YkyShs3M3kOgh3BKQRNblnAUdbyotBRkJ+bNplUhtZgV6JwK4wIc6TN3MDkGDfuJBnq0xLP
kuFwbDlKJdisfvLEif1HOJxIl2j9lchSY4Hwp7VgBOnonT/XlxdKtZxxXi2xI1lYKbs5b8d8q8YX
S+HJxree35Is3/0QCeoNknnp8q5HzxqnTgbrZhBwL7MGO9SgO3+fN9y9f/3F7O3+QLjl6eMZsWfB
3slojddo0RNeNJWnUWxg5UeOFgb5mUihG9C+kzgNeoFBNJV+WMsOdrK86OXI1JQwU/mZrAJjcCvM
i7Nx1G7CKpDIELuuXTiQHKNRvQ9RwkVVJ2ADU0kXBZa2FYE408tMNcKsKaX8tO2uMDo1qVGy0hJO
lvcwz65SQ0ATbJiml9AbVEOnsWEL0FXYGLOcjghbYsWhvhLeqd3bwSqZHHbyrtunwXUbVomura/y
hMvdAbp8BWrY43ZCPpi+sa4Sa1fF5zp5GmTtMFVNwfzaY58lug45EQTWyoqqcm4jE2pm255sCsG9
ttYdiZzWa1mXhCdwizBIUVtCSSGNaxH12IZft7DNyJG6V0wpFaftPHc9JQB4rOgykQk9TIXRPvvp
yFDpNE0ETCI1vAHWG64bd8/s2QOHdyiQZv9aWsuRrnSF+s5SuXQTv44oHb33eBTnSZnX8rxoaoxX
nI5Cq52KE8+nFm36WVr3so3afrHx1sPZ15fBI2mdfdbotiszD15evghUyagV/U6Ekyvfh6zk3LkM
UpnVXrr9asZju5fzk9CaHPCl72iVRUYWxbli+lCndxBLLuGFR/FJKAzawp9u46OlEiGSLM27p33P
9fMsN2jl5SytiWg6OJsl+b6jTYO3aR/RInWbWvuAs5KEGjWh1jJAGLhaOtxvoqJICk8ahbcJsRW1
HehAuVGP+8dpU84jrWK/0y06UiMkr5DekmqLY4nZXQXuPnxdtxzG4Pp2iKhuZ/BcBULrNiVtDEY8
ElgSi9LN0GiIl4ZGpYFsGIaWLR1+wyN3ozcW6yByEc8Q9lF2yZANsCilq+x4DE7tdHfOX62ioEpQ
mywCo+iKxL4imnAvSTaE8ZSsNBk4jQBgHObHJjiOjxjMmV4c56qNRoMmxPFsOg6Mm+SpkZIesZaQ
YNlVvjZYGWcCKayfSP5jogTfOC3Uf6r0RHbRnbRz5Cj6CSMp/j20ltLX8as/rvG5UaWLIw2vfbuW
U54FMtI4rXY3UH0+FJFWauLYCsSurj/YWj3D1BXBFd6H2Yd1I1fdf/EGriUsfofq40V2jsAu16eP
H+xGNL5zE1fRMhy0fpipntswIa2dU0IJodPgcCYOBQe7WX748P6p6UNKREHh+OY0hiK1UyNdEfoa
HxA/OqNkpJr+FJ5FHlXYHhac6hVhRWL1J6Pu4exwaHwl/UArw0lMizGnRqPTiyOVMnHiKizkBL7x
TQ0xvKUj/GzwOVwSBw1Dk8tKos3tpgptolZrscd5TxVsv2FU4640OyMKtNYbDeC6kphSxJHEWugs
twC1zjA7gHU4kcoeiCXPeSfHbViIcRgUcFZVdaqEoCMhjJLMGFRURIjqFHf8sH8wGzbS3d+s2O4u
cBMjePqeDbKyhXDrLrXTQuxOOK+qHDgSXWSqNVyj8xhhl71uuB5uCiS+xoNJJFNI1X0X1Voflz2n
6rnpdIrzNAk8N1E6Um4eHKJPBP+D/JtNqrDf8SAM/1On8gi+xd9Iaxlakja5xuH99m3l8FrOXke8
UqUWbUNYobXHCcCez4PrRD0P0Zbp2ppuY/4MGgrf6PctrauXr7x199HrS/07I1ovIG2FXj+ffXz3
AXbKvZ3tX6b9ibH1zuzMovjYj9M6p39RC367ythOHl+/L3vfZ6yO4TrGK/TV/jIjWnG3BAE/Sysb
vVw7FtTn70bfpZsX+lfwlOne7t23rj9+fQXLXM6xghBWue3mDgxMd5/dv/7u7uPZ97dh7re04rU3
95fLk+fnaP2vteDPa+EP/ZpURPub2et4fKXKsH5GK7S1smGM1r9Gc7T+R1rwzwqgfjW8lnklsNQ4
q4R1ROug4koH5Bytc/pRzdE6kXe5FF2hrw+LHmpA6hiso/ZMjK1ztH5k5w6NAABCGAj23/W/i8Bg
M+z2cIMirKl1L9v6MR/V5zx5Ys1p/dQKqBUuUCu0UCu0UCu0UCu0UCu0eOzZMU7DQBBG4ZmKG+UI
HIACCUWisJAiUhgUiZhj0ND5EmnoKRAdAlHQoDQpUuQE6RJvqsRx6Yn+7Psu4JV3n2yPqRVQQa2A
CmoFVFAroIJaARXUioxc1e6+NlXUioxMfet+aKKoFWej+HH32ZBa+7Dw427vLFJR7138YjX/Migq
vTGm1j6U3qGySI/e9kmwekZP3phQ605ArbG3s3sZ/6q9jn6lDyS1qtVaWZzuZUxMUvGw+5jIEG/C
PXp+Gxx6OVWtH8vL5Hvw6g3dXc241jSBmDETjlJ6/FErD3fwr1bONeNa+YMTahr9aG3XmrzXnlSm
h1qpNUQ6aH5zbRHatbYHFj42OdRKrRv2zliniigIoKU/wLf4CdQvdobkVSYvbkE2LxH4DBo6/uHF
wg+gQEMjEBNsQAuMmtDZGC2MLIsen+PkZKLI87nTsW9m7tyZe3bv3r27/BVZv2FCnFZwvTzanzn+
NRloHWgVucl58Juj41E3AE9naZbPd7rfz+Zw29u+07k7OJ2dlGhl0MeF4a2j453e6Sv0kUkf6Z0Q
qBm7K0uK0zp5cmVxcBFbr4f58kWI7vfc7XQqz95WNBDPZDc61qBVkik9qMjS0vrrefDWbti0wE/d
sGTaOn7AT5cPHZH9swKtnDs4js8kFn5H6I0YI+JKk7KebgubPJXWadjyTfPJPr+quz3c7Zc04pow
EcV+jw+hVUcYPVikXTMLRCvz4GSjUZ9x5N6ou/ixcxBaz0eYMKgKtHLr2lD2jASiidKoMeKu8qRw
votG0WPsrYVJvmk+uqq7a3otNJqSRswbZzX6zSiAVh9hsQe3fouxOLRez4Nt58Lhz6Nn8ihk8qls
j3JaCWhKUX3sRWnEGHFXkpSU1vhDvB3XMKGV7IaK1d01lK+o4bTGTD48n6u1jrD21jexLyitzIND
Ksezk6s7F7L14+hpr47e3R5d/0SOT2erq0fH4Kq0xoj6HwjlYPZ+ZWXl9QsG6pzy+PFJd8e8O1db
MUbMlSaFcR3b7z1292g7Ga15mDHfz1ZfvxiFdfO6u8M+5It3q0e74UwiGkIrJ6n9V6tPjsOZW5IZ
e3D7T/UWhtb2F5XfmJ/FboEPxbkYfZu9TN5/t8KM2czUaY0/UPz1rqadEqH0dSV8/m6vArgs8Zoa
I+7Kk3Kp97I7MD5buZITEkV7W7uhtx4mV6peicwGZzV3dGZvRKFEw2kFtvvP+/YfQauNMOlBSZaR
1r4wm+EiE87GEE0xm2A1d3dzzhnZaM2xaSkbbU/nG22458VSjBFxpUnJ14Rb2fbsYfI3zpOlhrq7
Q45QKNFwWqNyC62STOlBRZaR1m5MMgzILqkNRyjm1C7SLWoVWjfwlFhtZs/xNvhVjBFxpUnJaV3X
S4KHSb7vP5fhW3M3bkKhXENpRTcYkytLptfNZRlppQg/E0yyGYkUh9xixTHMOFan1aHi6kWLjBsx
RsSVJSX+iY3QKmGSbxz58HV35DcUyjSEVlK1GUqNdZ7MBd1csRi03huRhpD7kO4mHT3MZZI5rdIa
Xfl5nLgiIG6MuCtPCuMtKohImKRWLkU1d9NkqUA0rAHCTU/lnkyvm8vy0co8OIyEzeTCk9LUhmqi
uQS0SlKg1XtYxytGvZGwU3WHP4IXDWuAkRAvjprMgdbCPJgxNs0IJnd2a8FqwhLQqkmB1rgt6w/S
6h2pu+N66BreAHWNtGoyB1p9HpzetpLtnFasImHMgOq0NlI4udk0Y0RceVIirRzql1YXntY+0qlr
WAPctia0pskcaK3OgylLFLKdF7MRIpHiKtPWk+07o7AniBqHUaHGiLvypEBr9NkdTndgeph1Wuvu
QMw1nFawricz68F/Tyvz4DKtPlHy1RB/3squUWpG4QIiYaSIMWKu6rTGLXSn8S0WC9NpVXe3QCvn
7d+glR4MtIZ5sO+WlWKybSdZeyrvZcLX5xgQHtsfn0ROsFRjxFx5UiKt5EXeYpEwy7TibnFp9WT2
PRhoTZlwWvcf3DStjAuM2MweC8cOqhmbe7m0ijFirjwp0Bpf88SUyBAJs0Yr7v5JWi+TSQ8GWpM3
XeQOFLn5mTALyXjoN4ivrM03jjKCRzVGxJUlRWjlLdHku4AWptPq7haL1jkN68GwyhRevbkBWgOR
9Tfm8Ds+yxpfzwhzY8Rd1WmN71YHDx6m01p350v6ruG0Tuu0xh4Ma8L5vnAvS2GB30/I0JovVbPi
FBtnFFyMwjvNboyIK0mK08qbKKG7FqbTKu5u5QmO0CrJpAfDExz5JKkR5hMlKbHTSmgUNh8ZvYu9
7e7owTPOxmqMiCtJitOaroB5mE6ruLud3RH+vBWNvAfD81adB0OR0qpWrD3Vv6LWZJMmGueTJImI
MaKuCNZplWiKYdZprbtjNdA1fn/nIcmUTA206jyYHaFFWluspMT2hVIOg3uRVjV2Wj0pTqvv6PQw
nda6OwIJe85MwwYEqcqs0ZC6DbTaPDhOX51Wfa299vVvKimFk+1qparjypIiGo3Q2iwKrWMiCXiq
hr+Dk78xRzIHWuvzYH8S67TCWSOO/D9r5N+G4KsfXFvTz1e6MeKu6IvdbcnvTTlMp7Xujr6EhT3R
kAERdYGVWksyvW5fdnz39bLQ2sJVEIq1/9NYeCNDZYMK0w4nWad1crTDY8mwukPdwvpj3/CdS7l7
9xUb/MQYEVeSlHyuuDGerelLbh6m01p3N1+qFphUw2nl1SNubjgiyZQegLO9578stF739W6UD9+/
XMbzLkiaxuIgWB2u8YzRLuGE0X/gnytr3MzM17w6pxQyyOMTNQ4iriQp8ST45vrAwWF2pyB9LNFa
d9fLp/6jbB9B0zScVk58D5/zkW9olWRWetBgHWVZaP3a3hnrNA4FUXS7/MB+y35CamvbdNtEmwJF
KQKfQZOOn6BxTwOiAprQIFJEAiQ6JKgowDHWFb6yrkZY8rNzT/3eMG881884zzO4FsQCei64fH0q
ivltcmQaXxw+C/R8Px7nJ7g9q27LVAaaje46O9ze7DY+/HHkAlnQk4E2pYOCD27uHsd5tsukqqZo
UWbzpiEa0k2t1rg5LO+icBbXXo1QakUkatVNFwdQqwqmXsGS/WGGr9ZD7DME763aMBd4Z7WK6v7z
usE5qZWZicmEMKWDgi0F05bNo9Uao2qNm3vL+OCWGqHUCg9o3VCrCGbDCry3MoeceWAmUgX5Tse0
ZVKhYG7DMHzHMqcv5nZlf8efbHLUqVaTgTSlg8KBnWG8FCu7GVdr3BwuFt0kxQiCvTmvPaCQWkUw
aQV7+38rQknM6PVsQVVwnpoUEdNtxtpjYAaM7l6eaDia6yBjlln9VMwpd1BZyMlAmhJBoc/jkEnb
1fekI4SbjfH+V3h7MYmbg7ZqjaWAGEHAQfIAHafmCK4Mpr5uyz16J6xAv75V+Yr05RGBVNzmo6yc
9NCaJ2dlW0KInz7x4VfNcnLclA7K9KzsJ4lmmEfvVdPDdWCN7YeMtVh1+8ApSzEi6sFx6cE6mGG8
gu7pgVrTh2qmiXKAYVM9bfwMxHNromWQksNqbSvv/k9EqkVM7UPWWq1WawfQaUFR112bSqxEfIXV
GsZqTQ5Sk2g6oU2l1X6lwmoNY7Umx99MdPhox9TAsFqt1g7A725gi0qOPzc1yAdhq9Vq7QCqtjX9
fb0Sxx0jprpvoF9htYaxWtODDsSI445xU4N7DrZardYOII3p445xU8PbWa1Wq7UbcH4NXF5NEjCV
Mlar1dod082fr+ZGo+f7dSqm0qU61atGDPJWZbUaM2ysVmP6AqvVGJMwVqsxfcFqNaYvWK3G9AWr
1Zi+8MsYY4wxxhhjjDHGmJb4AMB7T/AsEkNoAAAAAElFTkSuQmCC" alt="zero" />
</span><!-- "zero"-->
<p>

<table style="border: 1px solid black;">
<tr>
<td style="width: 30%; border: 1px solid black;">
<img width = "100"src="https://frinkiac.com/img/S03E03/754118.jpg"><br>
"Smithers, the monkeys are messing with the compiler again"
</td>
<td style="width: 30%; border: 1px solid black;">
<img width ="100" src="https://tv-fanatic-res.cloudinary.com/iu/s--Q_B72iNX--/t_full/cs_srgb,f_auto,fl_strip_profile.lossy,q_auto:420/v1371141961/waylon-smithers-pic.png"><br>
"I'll take care of it, Sir."
</td>
<td style="width: 30%;border: 1px solid black;">
<img width = "100%" src="https://lans-soapbox.com/wp-content/uploads/2012/06/excellent-mr-burns.gif" alt="Mr. Burns">
</td>
<br>
</tr>
</table>
<p>
<hr><p>

	Quote from MB ('the terminal') -><br>
	<b><i>especially appropriate for the monkeyBastas</i></b><br>
"Make them feel like they're getting laid when they're actually getting f**ked"

<p>
<hr><p>

<b>Photochrome Prints from the Lib. of Cong. [ca. 1890-1910]<b>
<br>Bombay. <a href='https://www.loc.gov/pictures/resource/ppmsca.41429/?co=pgz'>Pydownee</a> Street
<br>Bombay. <a href='https://www.loc.gov/pictures/resource/ppmsca.41431/?co=pgz'>Girgaum</a>  Road
<br>(Rights Advisory: No known restrictions on publication.)
<hr>
                </div>
                </section>
""", "");
TreeDataItm((gfxGetUNID "gfxItm"), "sartorial", "Sartorial", [], """
                <section>
                    <div id="sartorial">
                        <section>
                            <br>
                            <a href="https://en.wikipedia.org/wiki/Frette#Select_hotels">Frette</a> is supposedly a good choice for linens and <a href="https://www.amazon.com/Frette-Solid-Shawl-Collar-Bathrobe/">robes</a>.<br>
                            <br>
                            - Tom Ford has belts with a "T" for a buckle Men's<br>
                              <a href='http://www.mohancustomtailors.com/'>Mohan</a>'s custom tailoring<br>
                              <br><br>
                            http://www.gentlemansgazette.com/<br>
                            http://putthison.com/<br>
                            http://dappered.com/<br>
                            http://offthecuffdc.com/<br>
                            <br>
                            Seward Trunk Co. Embossed Steel 31" Oversize wheeled locker<br>
                            http://www.distributorcentral.com/websites/MercuryLuggage/item_information.cfm? SupplierItemGUID=71851D65 -5A6C-43FD-834E- C62D9FB6B482&<br>
                            <br>
                            Rhino Trunk & Case<br>
                            http://www.rhinotrunkandcase.com/products-capabilities/rhino-travel-wardrobe-trunks/<br>
                            https://amishhandcrafted.com/content/maple-steamer-trunk
                        <p></p><br>
                        Men's Nike Free RN Distance<br>
                        Men's SAUCONY KINVARA 7
                        <p></p><br>

                        </section>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "planning", "Planning", [], """
                <section>
                <div id="planning">
                    <section class="mBox-container">

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1481768491/custom-uv-dtf-stickers-uv-transfer"><img alt="Xfer" src="https://i.etsystatic.com/30455340/r/il/be39fe/4905272874/il_1588xN.4905272874_r3i9.jpg" width=150px></a>
                            <div class="caption">
                                XFers 4 any hard surface (1)
                            </div>
                        </div>
                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1489348100/custom-uv-dtf-stickers-permanent"><img alt="Xfer" src="https://i.etsystatic.com/41202800/r/il/aef10f/5000625868/il_1588xN.5000625868_l8yu.jpg" width=150px></a>
                            <div class="caption">
                                XFers 4 any hard surface (2)
                            </div>
                        </div>


                        <div class="mBox planning">
                            <a href="https://www.amazon.com/dp/B096VKLF4S"><img alt="keybd" src="https://m.media-amazon.com/images/W/MEDIAX_792452-T2/images/I/61fz+rhh+nL._AC_SX679_.jpg" width=150px></a>
                            <div class="caption">
                                60% mech keybd
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.microsoft.com/en/accessories/products/mice/microsoft-bluetooth-ergonomic-mouse"><img alt="mouse" src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE4FRBx-Msft-Bluetooth-Ergonomic-Mouse-Pastel-Blue:VP5-1920x720" width=150px></a>
                            <div class="caption">
                                Bltooth Ergo mouse
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1307771747/epoxy-resin-artisan-keycap-custom"><img alt="Keycap" src="https://i.etsystatic.com/33318794/r/il/6b4441/4174276988/il_1588xN.4174276988_b1p4.jpg" width=150px></a>
                            <div class="caption">
                                Keycap green
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1259858081/mossflower-artisan-keycap-real-moss-and"><img alt="keycap" src="https://i.etsystatic.com/19105348/r/il/be8dec/3977007622/il_1588xN.3977007622_5izk.jpg" width=150px></a>
                            <div class="caption">
                                Keycap moss+flower
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1513448257/moss-artisan-keycap-custom-keycaps"><img alt="keycap" src="https://i.etsystatic.com/33318794/r/il/e79834/5089165041/il_1588xN.5089165041_i15u.jpg" width=150px></a>
                            <div class="caption">
                                Keycap moss
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1262096668/katana-space-bar-keycap-red-blue-keycap"><img alt="keycap" src="https://i.etsystatic.com/13281541/r/il/b43c7a/4089578455/il_1588xN.4089578455_hk7n.jpg" width=150px></a>
                            <div class="caption">
                                Keycap katana
                            </div>
                        </div>


                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1450930413/resin-elevated-artisan-keycap-for-mx"><img alt="keycap" src="https://i.etsystatic.com/42224353/r/il/dc3251/4821808617/il_1588xN.4821808617_qui6.jpg" width=150px></a>
                            <div class="caption">
                                Keycap Enter
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="https://www.etsy.com/listing/1005243836/interstellar-resin-keycap-interstellar"><img alt="keycap" src="https://i.etsystatic.com/26969480/r/il/e32078/5340487566/il_1588xN.5340487566_4z3g.jpg" width=150px></a>
                            <div class="caption">
                                Keycap astronaut
                            </div>
                        </div>


                        <div class="mBox planning">
                            <a href="http://www.levenger.com/Bomber-Jacket-Tyler-Folio-6134.aspx"><img alt="Folio" src="https://www.levenger.com/cdn/shop/files/AL7455_BOMBER-JACKET-TYLER-FOLIO_BK_s1_c9179d97-590f-4a48-8639-a387dcf86ef2_800x.jpg" width=150px></a>
                            <div class="caption">
                                Bomber Jacket Tyler Folio
                            </div>
                        </div>
                        
                        <div class="mBox planning">
                            <a href="https://www.levenger.com/cdn/shop/products/ADS11905_LUXE_3X5_RULED_NOTECARDS_SET_OF_100_s1_1600x.jpg"><img alt="Jotting Index cards" src="http://www.levenger.com/Catalog/CardImages/ZOOMS/ADS80_A1.JPG" width=150px></a>
                            <div class="caption">
                                Custom Index NoteCards
                            </div>
                        </div>
                        
                        <div class="mBox planning">
                            <a href="http://www.crane.com/product/lincoln-vintage-metalsmith-tornado-rollerball-pen/VRR1331"><img alt="pen" src="https://cdn.shopify.com/s/files/1/0600/3720/2069/products/AP21655_RETRO_51_TORNADO_VINTAGE_METALSMITH_LINCOLN_ROLLERBALL_PEN_s2_web_800x.jpg" width=150px></a>
                            <div class="caption">
                                Lincoln Vintage Metalsmith Tornado Rollerball Pen
                            </div>
                        </div>
                        
                        <div class="mBox planning">
                            <a href="http://www.levenger.com/PENS---REFILLS-8/SHOP-BY-BRAND-34/AURORA-39/Aurora-Gemstone-Rollerball-13675.aspx"><img alt="pen" src="https://cdn.shopify.com/s/files/1/0600/3720/2069/products/AP19295_AURORA_OPTIMA_VIOLA_ROLLERBALL_CSW_1_800x.jpg" width=150px></a>
                            <div class="caption">
                                Aurora Gemstone Rollerball Pen
                            </div>
                        </div>

                        <div class="mBox">
                            <a href="http://www.levenger.com/PENS---REFILLS-8/SHOP-BY-BRAND-34/PARKER-1070/Parker-Sonnet-Contort-Purple-Cisele-Rollerball-13551.aspx"><img alt="pen" src="https://www.levenger.com/cdn/shop/products/AP18825_PARKER_SONNET_PREMIUM_REFRESH_ROLLERBALL_PEN_CSW_RD_1600x.jpg" width=150px></a>
                            <div class="caption">
                                Parker Sonnet Refresh Rollerball Pen
                            </div>
                        </div>

                        <div class="mBox planning">
                            <a href="http://www.levenger.com/Pair-Of-Levenger-Single-Sheet-Cutters-421.aspx"><img alt="pen" src="https://cdn.shopify.com/s/files/1/0600/3720/2069/products/AD260_miSHEETCUTT_s1_800x.jpg" width=150px></a>
                            <div class="caption">
                                Single-Sheet Cutters
                            </div>
                        </div>

                    </section>
                </div>
                </section> 
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "audio", "Audio", [], """
                <section>
                          <div id="audio">
       
      <section>
                                  <br /><br />

                    <section class="mBox-container">
                        <div class="mBox audio">
                            <a href="https://www.soundandvision.com/content/monolith-mtm-100-powered-desktop-speaker-21-system-review"><img alt="bkshelf" src="https://www.soundandvision.com/images/styles/600_wide/public/SV_092623_monolith_02_sm.jpg" width=150px></a>
                            <div class="caption">
                                Monolith MTM-100 Powered Desktop Speaker Sys w/Subwoofers
                            </div>
                        </div>

                        <div class="mBox audio">
                            <a href="https://www.cnet.com/tech/home-entertainment/back-to-the-future-with-jbls-iconic-l100-classic-speaker/"><img alt="bkshelf" src="https://www.cnet.com/a/img/resize/39255a6144e7633b8998b9f5974a530bdc00b231/hub/2018/11/08/67208906-c8d8-4f68-8b6f-e7dd0998e077/harman-jbl-l100-ong-pair-stand-rt-f2cf4a84.jpg" width=150px></a>
                            <div class="caption">
                                JBL L100 Classic speakers see <a href='https://www.theabsolutesound.com/articles/jbl-introduces-l82-classic-bookshelf-loudspeakers-at-ces-2020/'>also</a>
                            </div>
                        </div>

                        <div class="mBox audio">
                            <a href="https://www.crutchfield.com/p_714500M2W/Klipsch-Reference-Premiere-RP-500M-II-Walnut.html?tp=186"><img alt="bkshelf" src="https://images.crutchfieldonline.com/ImageHandler/trim/350/265/products/2022/18/714/g714500M2W-F.jpg" width=150px></a>
                            <div class="caption">
                                Klipsch 600M '...in my view, already a <a href='https://www.stereophile.com/content/klipsch-reference-premiere-rp-600m-loudspeaker-rp-600m-ii-august-2023'>classic</a>.'
                            </div>
                        </div>
                    </section>


<p>
http://www.avsforum.com/<br />
                                  http://www.klipsch.com/<br />
                                  http://www.polkaudio.com/<br />
                                  http://definitivetechnology.com/<br />
                                  http://www.martinlogan.com/<br />
                                  https://www.cambridgeaudio.com/<br />
                                  http://www.bang- olufsen.com/da/collection/speakers/beolab-20<br />
                                  http://www.jbl.com/loudspeakers/STUDIO +L890.html?dwvar_STUDIO%20L890_color=Black#start=1<br />
                                  http://www.paradigm.com/products- current/type=tower/model=prestige-95f/page=overview<br />
                                  http://kef.com/html/us/index.html<br />
                                  http://www.bowers- wilkins.com/Speakers/Home_Audio/600_Series/683.html<br />
                                  http://www.bostonacoustics.com/<br />
                                  Sony Home Cinema Projector - VPL- HW40ES<br />
                                  http://www.amazon.com/Koss-PortaPro- Headphones-with-Case/dp/B00001P4ZH/ref=sr_1_1?s=electronics&amp;ie=UTF8&amp;qid=1464305449&amp;sr=1-1&amp;keywords=Koss+PortaPro+Headphones+with+Case<br />
                                  <a href="http://www.stereophile.com/search/node/tube%20amp%20vinyl%20entry-level%20setup%20type%3Aforum">Stereophile</a><br />
                                  http://www.theabsolutesound.com/<br />
                                  http://www.soundandvision.com/<br />
                                      <a href="http://www.bestbuy.com/site/searchpage.jsp?st=AMD+Radeon%20+R9&amp;id=pcat17071">Radeon</a><br />
                                      <a href="http://www.bestbuy.com/site/sennheiser-rs-175-over-the-ear-wireless-%20headphone-system-black/2822013.p?id=1219561396856&amp;skuId=2822013">Sennheiser over-the-ear wireless Headphones</a>
      <br />
                                  http://www.tomshardware.com/s/pc+4k/<br />
                                  ASUS Sound Card Essence STX II<br />
                                  Srch for &quot;Essence ASUS headphone movie 2016&quot; tinyurl.com/zrtpnn2<br />
                                  <br />
                                  http://www.dansdata.com/spkvshead.htm<br />
                                  (forum) http://www.head-fi.org/<br />
                                  https://www.headphone.com/collections/top-10-headphones/audiophile<br />
                                  (srch results for headphones) http://tinyurl.com/mpt-headphones<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
      
      
      
      <div id="Khayyal" class="article">
      
      <h2 style="font-family: &quot;Times New Roman&quot;;">Some words about Khyal</h2><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Perhaps the most popular of contemporary Hindustani vocal styles is the idiom known as &quot;khyal.&quot; The word literally means &quot;imagination,&quot; and the khyal form demands improvisational flexibility as well as careful attention to nuances of intonation, phrasing and rhythm. Paradoxically, it is less known to audiences in the West, who have learned to enjoy Indian instrumental music unhesitatingly -- and have even begun to absorb the intricacies of Dhrupad vocals. Music stores in India offer a wide selection of Khyal recordings, and performances are well attended.</p><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Khyal is several hundred years old. Originating in the courts of the Moghul emperors as a less rigid alternative to the Dhrupad style, it has evolved into a remarkably flexible form that allows an artist's individuality considerable rein -- while remaining within the steady, inexorable flow of Indian tradition. Even within the past five decades the form has undergone metamorphoses, and the tradition of innovation continues. An artist is expected to develop an individual style (albeit one that is demonstrably connected to the tradition), and those performers who restrict themselves to mere imitation of their preceptors or of other famous musical personalities are firmly criticized for a lack of imagination.</p><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Khyal texts draw freely from Hindu and Muslim poetic traditions, and are usually romantic or devotional -- or a combination of the two. Generally composed in the archaic Hindi dialect known as Brij Bhasha, khyal songs are also found in languages like Bhojpuri, Punjabi, Urdu, Rajasthani, Marathi and (occasionally) Sanskrit. Many songs have unclear wordings, and in some cases the texts have become completely garbled through multiple generations of oral transmission. However, the primary focus in a khyal performance is less on the textual or lyrical content of a song than on abstract musical values. Audiences respond with delight to nuances of ornamentation, to complex rhythmic improvisation, to intricate melodic patterns or to a vocalist's superb intonation.</p><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Performances of khyal often start with a song in a very slow rhythmic cycle, perhaps of 10, 12, 14 or 16 beats; often the pulse is so slow that each beat is further subdivided -- for instance, a 12-beat cycle becoming one of 48. Each beat of the rhythm is marked by a specific stroke or combination of strokes on the tabla drums; by listening to their sound a singer can keep his or her place in improvisation. The tonal material of the raga gradually moves from a restricted melodic range to an extensive gamut; from a slow and relaxed pace to a quicker one. Improvisation is punctuated by the first few words of the song, which become a familiar melody leading up to the first beat of the rhythmic cycle. All extemporized melodic or rhythmic variations aim for this beat, and the gradual building of tension as it approaches is one of Hindustani music's great delights. Eventually the singer switches to a faster song in the same raga, displaying his or her virtuosity and command over the material. Some of the time a &quot;tarana&quot; is used to conclude -- these pieces are rhythmic in focus, and make use of nonsense syllables; they are thus in a sense analogous to scat singing in Jazz.</p><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Fortunately, the music of great khyal singers (the proper generic noun is &quot;khyaliya&quot;) is widely available on cassette, CD and lp. The following are some of the most highly regarded singers of this century; most are dead, but their music is easily obtainable, and their voices ring out with extraordinary conviction and passion. Other artists, like Bhimsen Joshi and Kishori Amonkar, are still performing and recording actively.</p><ul style="font-family: &quot;Times New Roman&quot;; font-size: medium;"><li>Kesarbai Kerkar</li><li>Hirabai Barodekar</li><li>Faiyaaz Khan</li><li>Bade Ghulam Ali Khan</li><li>Mallikarjan Mansur</li><li>Abdul Karim Khan</li><li>Amir Khan</li><li>Mogubai Kurdikar</li><li>Nazakat and Salamat Ali</li><li>Bhimsen Joshi</li><li>Kishori Amonkar</li></ul><p style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Contemporary performers include many musicians of great skill; some are regarded as &quot;up-and-coming,&quot; while others are relatively senior performers who have only recently begun to attract critical attention. These include:</p><ul style="font-family: &quot;Times New Roman&quot;; font-size: medium;"><li>Rashid Khan</li><li>Padma Talwalkar</li><li>Malini Rajurkar</li><li>Ulhas Kashalkar</li><li>Dinkar Kaikini</li><li>Rajan and Sajan Mishra</li><li>Ashwini Bhide Deshpande</li><li>Arati Ankalikar-Tikekar</li><li>Veena Sahasrabuddhe</li></ul><address style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Warren Senders &lt;WARVIJ@AOL.COM&gt;</address><hr style="font-family: &quot;Times New Roman&quot;; font-size: medium;" /><span style="font-family: &quot;Times New Roman&quot;; font-size: medium;">To Todd McComb's</span><span style="font-family: &quot;Times New Roman&quot;; font-size: medium;"> </span><a href="http://www.medieval.org/music/world/india.html" style="font-family: &quot;Times New Roman&quot;; font-size: medium;">Indian Music menu</a><span style="font-family: &quot;Times New Roman&quot;; font-size: medium;">.</span>
      </div>  
      
      </section>
      
      
      </div>  
       </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "fin", "Fin", [], """
                <section>
                    <div id="fin">
                        <section>
                        20 years of free stock data on <a href='https://finnhub.io/'>Finnhub</a><br>
<hr>                        
                        [[legacy]]
                            blcked srch res: http://www.tinyurl.com/hvvf5lr http://www.ft.com/global-economy<br>
                            http://www.economist.com/<br>
                            https://www.bloomberg.com<br>
                            <br>
                            http://tulipsandbears.com/<br>
                            http://www.itulip.com/<br>
                            http://www.shadowstats.com/<br>
                            http://www.gold-eagle.com<br>
                            http://www.kitco.com<br>
                            https:\\www.forbes.com\2002\02\28\0228dynasties.html
                        </section>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "re", "RE", [], """
                <section>
                    <div id="re">
                        <section>
                            http://www.mansionglobal.com/newyork<br>
                            Rental <a href="http://streeteasy.com/for-rent/manhattan/status:open%7Cprice:-2000%7Csqft%20%3E=500%7Cbeds%3C1?view=map#pos=12/40.77547,-73.97747">studios</a> under 2k<br>
                            <br>
                            Studios for about $200/day - http://manhattan.marmaranyc.com/studio/<br>
                            <a href="http://www.bhsusa.com/for-sale/new-york-city">Brown harris</a> (also has rentals)<br>
                            <a href="http://www.zillow.com/homes/for_sale/hdfc_att/globalrelevanceex_sort/40.808547,-%2073.873014,40.7416,-%2074.019442_rect/12_zm/a752f575ecX1-CR187zxt422kzhp_17gt2i_crid/">HDFC</a> income-restr. apts on zillow.<br>
                            <a href="http://www.trulia.com/for_rent/New_York,NY/13_zm/40.73048088865914,40.82056720511156,-%2074.04242212280275,-73.88569528564454_xy/0-2000_price/map_v">trulia</a> has both for sale & for rent<br>
                            <br>
                            <a href="http://www.brickunderground.com/">Decent real-est site w/lots of articles</a><br>
                            <a href="http://www.curbed.com/">Curbed: nyc real estate</a><br>
                            <a href="http://www.apartmenttherapy.com/">Tips and things for living better in small spaces</a>
                        </section>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "furniture", "Furniture", [], """
                <section>
                    <div id="furniture">
                        <section>
                            <b>(site below has WishList saved under email id)</b><br>
                            http://www.furniturelandsouth.com/<br>
                            http://www.hickoryfurniture.com/Furniture-Jonathan-Charles-Tables/ItemBrowser.aspx?action=attributes&ItemType=Furniture&Brand=Jonathan%20Charles&Type=Tables&TrailIndex=1<br>
                            http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/513/images/217%20jessicamcclintock%20cover.pdf
                        </section><!--A SECTION with cols for thumbnails-->
                        <section class="mBox-container">
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Reflections-Furniture-%20Outlet-Leather-Barrel-Chair/02Chair-P67/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/p67/image384/02chair.jpg" width=150px></a>
                                    <div class="caption">
                                        Leather- Barrel-Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Miles-Talbott-Chair/THO-LX-9521-TC-1227/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/1227/image1024/3074-1-lg-tho-lx-9521-tc.jpg" width=150px></a>
                                    <div class="caption">
                                        Miles Talbott Living Room Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Whittemore-Sherrill-Leather-Gallery-by-Reflections-%20Classics-Tufted-%20Leather-Chair-by/1610-01-P67/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/p67/image1024/1610-01.jpg" width=150px></a>
                                    <div class="caption">
                                        Tufted Leather Chair by Reflections
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Lexington-Cardiff-Chair/7531-11-8/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/8/image384/7531-11.jpg" width=150px></a>
                                    <div class="caption">
                                        Lexington Living Room Cardiff Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Thomasville-Vienna-Chair/HS331%20013-%20976/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/976/image384/hs331013002_91206s.jpg" width=150px></a>
                                    <div class="caption">
                                        Thomasville Vienna Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Hancock-and-Moore-%20Lincoln-Tufted-Chair/1777-%20965/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/965/image384/1777_lincoln_oc_hr.jpg" width=150px></a>
                                    <div class="caption">
                                        Lincoln- Tufted-Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Hancock-and-%20Moore-%20Kenneth-Chair/5060-%20965/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/965/image384/5060_kenneth_st_hr.jpg" width=150px></a>
                                    <div class="caption">
                                        Kenneth Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Hancock-and-Moore-George-%20III-Wing-Chair/9752-%20965/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/965/image384/9752_george_wc_hr.jpg" width=150px></a>
                                    <div class="caption">
                                        George III Wing Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Hancock-and-Moore-George-%20III-Tufted-Wing-Chair/9751-%20965/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/965/image384/9751_george_wc_hr.jpg" width=150px></a>
                                    <div class="caption">
                                        George III Tufted Wing Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Marge-Carson-Chandler-Chair/CHD41A-%201155/ItemInformation.aspx"><img alt="chair" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/1155/image384/chd41a-p1.jpg" width=150px></a>
                                    <div class="caption">
                                        Chandler Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.furniturelandsouth.com/shop-furniture/michael-amini-knightsbridge-charterhse-leather-chair-fs-knght35-gll-43"><img alt="chair" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/AICO11107.jpg" width=150px></a>
                                    <div class="caption">
                                        Michael Amini Knightsbridge Charterhse Leather Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.furniturelandsouth.com/shop-furniture/michael-%20amini-chair-and-a-half-54838-chpgn-04"><img alt="chair" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/AICO10401.jpg" width=150px></a>
                                    <div class="caption">
                                        Michael Amini Chair and a Half
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.furniturelandsouth.com/shop-furniture/francesco-molon-leather-wing-chair-p82"><img alt="chair" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/FRANC10486.jpg" width=150px></a>
                                    <div class="caption">
                                        Francesco Molon Leather Wing Chair
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Habersham-Plantation-Corporation-Small-Marcelle-Chest/17-2601-%20605/ItemInformation.aspx"><img alt="chest" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/605/image384/500_17-%202601.jpg" width=150px></a>
                                    <div class="caption">
                                        Small Marcelle Chest
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Tall-Floral-Painted-Chest-On-Sta/493513-993/ItemInformation.aspx"><img alt="chest" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/493513.jpg" width=150px></a>
                                    <div class="caption">
                                        Floral painted chest
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Chaddock-Petite-Camille-Small-Chest/MM1489-06-1375/ItemInformation.aspx"><img alt="sm chest" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/1375/image1024/mm1489-06.jpg" width=150px></a>
                                    <div class="caption">
                                        Chaddock- Petite-Camille-Small-Chest
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Hooker-Furniture-Chatelet-Floor-Mirror-wJewelry-/5351-50003-5/ItemInformation.aspx"><img alt="mirror" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/5/image384/5351-50003silo.jpg" width=150px></a>
                                    <div class="caption">
                                        Chatelet Floor Mirror
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Hooker-Furniture-Rhapsody-Floor-Mirror-wJewelry-/5073-50001-5/ItemInformation.aspx"><img alt="mirror" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/5/image384/5073-50001.jpg" width=150px></a>
                                    <div class="caption">
                                        Furniture Rhapsody Floor
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Black-Gold-Drinks-Cabinet/492356-993/ItemInformation.aspx"><img alt="Cabinet" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492356.jpg" width=150px></a>
                                    <div class="caption">
                                        Black Gold Drinks Cabinet
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Black-Chinoiserie-Drinks-Cabinet/492705-993/ItemInformation.aspx"><img alt="Cabinet" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492705.jpg" width=150px></a>
                                    <div class="caption">
                                        Black Chinoiserie Drinks Cabinet
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Chaddock-Prince-Bar-TV-Cabinet/1285-49-1375/ItemInformation.aspx"><img alt="bar/cabinet" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/1375/image1024/1285-49.jpg" width=150px></a>
                                    <div class="caption">
                                        Chaddock- Prince-Bar-TV-Cabinet
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/guildmaster-provence-drink-cabinet-718532"><img alt="bar/cabinet" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/GUILD10877.jpg" width=150px></a>
                                    <div class="caption">
                                        Guildmaster Provence Drink Cabinet
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Mahogany-Drum-Table-Green/492611-993/ItemInformation.aspx"><img alt="Table" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492611.jpg" width=150px></a>
                                    <div class="caption">
                                        Mahogany Drum Table
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Walnut-Eglomise-Side-Table/492071-993/ItemInformation.aspx"><img alt="sm table" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492071.jpg" width=150px></a>
                                    <div class="caption">
                                        Walnut Eglomise Side Table
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Rope-Twist-Round-Side-Table/492512-993/ItemInformation.aspx"><img alt="side table" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492512.jpg" width=150px></a>
                                    <div class="caption">
                                        Rope Twist Round side table
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.hickoryfurniture.com/Jonathan-Charles-Lapis-Blue-Eglomise-With-Mahogan/492454-993/ItemInformation.aspx"><img alt="eglomise" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image384/492454.jpg" width=150px></a>
                                    <div class="caption">
                                        Lapis Blue Eglomise With Mahogan
                                    </div>
                                </div>
                                
                                <div class="mBox">
                                    <a href="http://www.hickoryfurniture.com/Furniture-Jonathan-Charles-Tables/ItemBrowser.aspx?action=attributes&ItemType=Furniture&Brand=Jonathan%20Charles&Type=Tables&TrailIndex=1"><img alt="tables" src="http://s3.amazonaws.com/images2.eprevue.net/p4dbimg/993/image200/492145.jpg" width=150px></a>
                                    <div class="caption">
                                        Jonathan Charles Tables
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/artitalia-group-armoire-dc367"><img alt="armoire" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/ARTIT10099.jpg" width=150px></a>
                                    <div class="caption">
                                        Artitalia Group Armoire
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/francesco-molon-armoire-with-two-doors-i6l"><img alt="armoire" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/FRANC10250.jpg" width=150px></a>
                                    <div class="caption">
                                        Francesco Molon 2 dr armoire
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/artitalia-group-credenza-cot-176-bp"><img alt="credenza" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/ARTIT10075.jpg" width=150px></a>
                                    <div class="caption">
                                        Artitalia Group Credenza
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/artitalia-group-credenza-in-oak-cot-160"><img alt="credenza" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/ARTIT10061.jpg" width=150px></a>
                                    <div class="caption"></div>Artitalia Group Credenza in Oak
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/hooker-furniture-true-vintage-king-upholstered-%20poster-bed-5701-90666c"><img alt="bed" src="https://s3.amazonaws.com/flswordpressmedia/media/product-%20catalog/base/HOOKE13342.jpg" width=150px></a>
                                    <div class="caption">
                                        Hooker furniture vintage king poster bed
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/guildmaster-heritage-caned-bench-652502"><img alt="bench" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/GUILD10540.jpg" width=150px></a>
                                    <div class="caption">
                                        Guildmaster Heritage Caned Bench
                                    </div><br>
                                    Note: This design can also be used for a bench swing (custom)
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/karges-%20furniture-georgian-chest-0703"><img alt="chest" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/KARGS10164.jpg" width=150px></a>
                                    <div class="caption">
                                        Karges Furniture Georgian Chest
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/four-%20hands-large-desk-vlls-01-11-fh"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/FOURH11268.jpg" width=150px></a>
                                    <div class="caption">
                                        Four Hands Large desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/hooker-%20furniture-kendrick-junior-executive-desk-1060-10562"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/HOOKE12450.jpg" width=150px></a>
                                    <div class="caption">
                                        Hooker Furniture Kendrick jr exec desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/hooker-%20furniture-la-maison-writing-desk-5437-10458"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/HOOKE13256.jpg" width=150px></a>
                                    <div class="caption">
                                        Hooker Furniture la maison Writing desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/hooker-%20furniture-sanctuary-60-writing-desk-dune-beach-3002-10458"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/HOOKE11028.jpg" width=150px></a>
                                    <div class="caption">
                                        Hooker Furniture Sanctuary 60" Writing Desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/lorts-%20three-drawer-writing-desk-1223"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/LORTS10106.jpg" width=150px></a>
                                    <div class="caption">
                                        Lorts Three Drawer Writing Desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href="http://www.furniturelandsouth.com/shop-furniture/theodore-alexander-chippendales-signature-writing-desk-7105-213"><img alt="desk" src="https://s3.amazonaws.com/flswordpressmedia/media/product-catalog/base/THALX12206.jpg" width=150px></a>
                                    <div class="caption">
                                        Theodore Alexander Chippendale's Signature Writing Desk
                                    </div>
                                </div>
                                
                                <div class="mBox">

                                    <a href=""><img alt="chest" src="" width=150px></a>
                                    <div class="caption"></div>
                                </div>
                                

                        </section>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "storage", "Storage", [], """
                <section>
                    <div id="NYCStorage">
                        <p>Manhattan Mini Storage www.manhattanministorage.com<br>
                        Makespace https://makespace.com/nyc/<br>
                        Box Butler http://www.yelp.com/biz/box-butler- new-york<br>
                        OR dump stuff in Edison/Philly (cheaper + less crowded + less hassles)</p>
                        <p>NOTE: MOST MANHATTAN SITES DON'T HAVE TRUE 24X7 ACCESS, ONLY DAYTIME ACCESS. ALSO, IF THEY DELIVER THERE MIGHT BE DELAYS etc.</p>
                        <p>JAN. 22, 2013 Gotham Mini Storage</p>
                        <p>Prices range from $39 a month for a 64- cubic-foot locker reached by a stepladder, to $2,000 for a garage- size space. In contrast, a similar 64-cubic-foot space at Manhattan Mini Storage this week was $57 a month, with a year lease, at most locations. Prices started at $70 a month, for a slightly larger space, at Tuck-It-Away, which is based in Upper Manhattan.</p>
                        <p>2016:Gotham Mini Storage Locker Promotion Rent a storage locker for $79/month at Gotham Mini Storage and save 50% for the first three months.</p>
                        <p>There are about 30 self-storage facilities in Manhattan. Manhattan Mini Storage, which has been in business since the 1970s, owns 17 of those properties. (NYT 08:) A 10-by-10-by-8-foot space runs about $300 a month. manhattanministorage.com. Spaces start at 4 by 4 by 5 feet, and one of the most popular is a closet that size with a hanging rod and shelves, "so people can store out-of-season clothing,"" he said. The monthly cost is $45. The company provides a key card for access to the building and elevator, and the customer provides a lock.</p>
                        <p>CubeSmart ... enjoy a range of new services, like a courier that can shuttle boxes to tenants' homes its employees can sign for packages, which is important for tenants who run their businesses out of their storage areas and who make up about 30 percent of CubeSmart's tenants</p>
                        <p>Tuck-It-Away, one of the oldest operators in the city, owns 14 facilities with a total of about one million square feet of space.</p>
                        <p>''Most people rent twice as much space as they really need,'' said Edward Troianello, the president of the Self-Service Storage Association of New York. So calculate carefully and conservatively. According to Mr, Troianello, a three-piece bedroom set, plus the boxed contents of a bedroom closet, can fit into a 5-by-5-by-8-foot storage room</p>
                        <p>(NYT 14:)start-ups like MakeSpace charge roughly $220 a month for 36 square feet of space at an offsite warehouse.</p>
                        <p><br>
                        https://www.publicstorage.com/storage-search- landing.aspx?location=edison+nj<br>
                        Storage Units Off Old Post Road in Edison, NJ --<br>
                        SMALL 5' x 5'<br>
                        *Climate Controlled<br>
                        *Inside unit/1st Floor 1 Left $69/mo.<br>
                        Online Special* $74 In-store<br></p>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "desi", "Desi", [], """
                <section>
                    <div id="NYCdesi">
                        <section>
                          <div id="NYCdesiStuff">
                              <br>
                              (Note: These work in lib browser)<br>
                              Some girl who moved from Minn to NYC - http://101baddesidates.blogspot.com/<br>
                              Amardeep Singh (dated site but lotsa links) = http://www.lehigh.edu/~amsp/2005/04/desi-weekend-indian-bloggers-bob- nyc.html<br>
                              SruTHI's decorating website - http://theeastcoastdesi.blogspot.com/<br>
                              SAJA Form desi spotting - http://www.sajaforum.org/desi_spotting/<br>
                              <a href="http://www.garamchai.com/desiassc.htm">Professional Indian Associations (net-ip, tie, etc.)</a><br>
                              <a href="https://siliconeer.com">Valley desi site</a><br>
<br>
                              Bhel, chaat, etc @ Murrah Hill & Village http://www.desi-galli.com/<br>
                              Nisha's Desi Street Food Site LOTS of info - http://indianstreetfoodie.com/<br>
                              <br>
                              punjabi forum (chk out jokes)- http://www.desicomments.com/desi/janmashtami/<br>
                              Daandiyaa TOO! host events all over, website only works in IE -&gt; www.desiparty.com<br>
                              <br>502 error?! "http://nycpunjabigal.blog.com/"
<br>
                        <a href="http://www.tinyurl.com/j2upuzn">Desi Blog srch Multipg results:</a><br>
                          </div>
                        </section>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "tv", "TV", [], """
                <section>
                    <div id="tv">
                        <br>

<details>
  <summary><span class='mHG'>The new stuff to watch</span></summary>

<h2>Brokenwood Mysteries: Series 4</h2><br>
Neill Rea (Actor)<br>
Filmed amid the beautiful landscape of New Zealand's North Island, <br>
these four feature-length mysteries show that murder can haunt even the most idyllic locations.<br>
<hr> <br>
from an AMZN review:<br>
<br>
The last three years have taken a dreadful toll on my favorite British policemen:<br>
&nbsp;&nbsp; "Foyle's War" ended in 2015 after eight seasons.<br>
&nbsp;&nbsp; "New Tricks" ended in 2015 after twelve seasons.<br>
&nbsp;&nbsp; "Inspector Lewis" ended in 2016 after nine seasons.<br>
&nbsp;&nbsp; "DCI Banks" ended in 2017 after five seasons.<br>
&nbsp;&nbsp; "George Gently" will end in 2017 after eight seasons.<br>
(we may come to look back on the last ten years as the Golden Age of British Police on Television.)<br>
<br>
The one bright spot is "Endeavour".<br>
This prequel to "Inspector Morse" is still going strong in it's fourth season.<br>
A fifth season has been announced for 2018.<br>
"Endeavour" debuted in 2013, but was set in 1965, when Constable Endeavour Morse joined the Oxford City Police.<br>
Promoted to Sergeant Morse in 1969.<br>
If it's still on the air ten years from now, we will see the return of "Inspector Morse".<br>
If it's still on the air eighteen years from now, we will see the return of Sergeant Robbie Lewis.<br>
<br>
WHY YOU SHOULD WATCH ENDEAVOUR ON BLU-RAY OR DVD, NOT PBS:<br>
I always knew Masterpiece Mystery broadcasts on PBS were edited, but was I was surprised to learn exactly how much was cut.<br>
<hr> <br>
<h2>Wallander</h2><br>
<br>
Kenneth Branagh returns to his remarkable Emmy and Golden Globe-nominated role <br>
as the soul-searching Swedish cop in Wallander III, with three gripping new Kurt Wallander <br>
cases based on the character created by bestselling novelist and father of the <br>
Nordic noir craze, Henning Mankell.<br>
<hr> <br>
<h2>Worricker</h2><br>
<br>
2013<br>
Page Eight, Turks & Caicos, and Salting the Battlefield form The Worricker Trilogy<br>
three gripping films that follow the exploits of Worricker<br>
from MI5 headquarters in London to exile on a Caribbean island to life on the run <br>
with his former lover and fellow agent Margot Tyrrell.<br>
The all-star cast includes Oscar winner Christopher Walken.<br>
<hr> <br>
<h2>Arthur & George</h2><br>
<br>
2015<br>
Martin Clunes (Doc Martin) stars as Sir Arthur Conan Doyle, the creator of <br>
Sherlock Holmes, in a real-life case that inspired the great author to put <br>
down his pen and turn detective.<br>
Co-starring  Art Malik<br>
Inspired by a true case, Arthur & George is adapted from Julian Barnes's <br>
acclaimed novel of the same name<br>
<hr> <br>
List of Masterpiece Mystery! <a href="https://en.wikipedia.org/wiki/List_of_Masterpiece_Mystery!_episodes">episodes</a><br>
List of Masterpiece Contemporary <a href="https://en.wikipedia.org/wiki/List_of_Masterpiece_Contemporary_episodes">episodes</a><br>
List of Masterpiece Theatre <a href="https://en.wikipedia.org/wiki/List_of_Masterpiece_Theatre_episodes">episodes</a><br>
&nbsp;&nbsp;&nbsp;&nbsp;Season 32 (2002-03)<br>
&nbsp;&nbsp;&nbsp;&nbsp;Almost a Woman<br>
&nbsp;&nbsp;&nbsp;&nbsp;Daniel Deronda<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Forsyte Saga<br>
&nbsp;&nbsp;&nbsp;&nbsp;Foyle's War<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Hound of the Baskervilles<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Jury<br>
&nbsp;&nbsp;&nbsp;&nbsp;Me & Mrs. Jones<br>
&nbsp;&nbsp;&nbsp;&nbsp;My Uncle Silas II<br>
&nbsp;&nbsp;&nbsp;&nbsp;White Teeth<br>
List of Masterpiece Classic <a href="https://en.wikipedia.org/wiki/List_of_Masterpiece_Classic_episodes">episodes</a><br>
(2008 onwards)<br>

</details>

<hr> <br>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "music", "Music", [], """
                <section>
                    <div id="music">

<div id="ThumriPane" data-dojo-props="title:'Thumris'" data-dojo-type="dijit/TitlePane"> 
<!--LINKS BEGIN-->
<table id="ThumriTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>
<a href='https://www.darbar.org/article/an-introduction-to-light-classical-thumri-dadra-and-other-styles/47'>An introduction to light classical thumri dadra and other styles</a>
<br><hr><br>
<i>Article</i>: Some words about <a href="#Khayyal">Khayaal</a><br /><a href="tinyurl.com\201609150500mpt"><br />some</a> Indian classical music on EP/LP<br /><br />LP+EP+Ghulam+Ali+ghazal+<a href="tinyurl.com\201609150505mpt">Akhtar</a><br />https://pediaview.com/openpedia/Indian_classical_music <br /><br />201608140319mpt Yahoo <a href="https://gist.github.com/anonymous/56f7867c06165e6904b32465367c364c/raw/d1c64c4c25af50cf3479d2fd84ab7881c57bc521/mike.html" target="_blank">Search result</a> for urdu+ghazal+ghulam+ali+ghalib <br />  <br /><br />
<br><hr><br>
The History and the Origin of the <a href='https://www.sahapedia.org/sites/default/files/The%20History%20and%20the%20Origin%20of%20the%20Thumri%20with%20Special%20Reference%20to%20Gharanas%20Styles.pdf'>Thumri</a>
with Special Reference to Gharanasand Styles.
<br><hr><br>
<a href='https://www.jatinverma.org/major-style-of-hindustani-music'>Thumri</a>
<ul><li>Originated in Eastern Uttar Pradesh, mainly in Lucknow & Benares, around the 18th century.</li>
<li>A romantic & erotic style of singing; also called “the lyric of Indian classical music”.</li>
<li>Compositions are mostly on love, separation, and devotion.</li>
<li>Distinct feature: Erotic subject matter portrayed picturesquely from the various episodes of the lives of Lord Krishna & Radha.</li>
<li>Lyrics are typically in Brij Bhasha and are usually romantic & religious.</li>
<li>A Thumri is usually performed as the last item of a Khayal concert.</li>
<li>Three main gharanas of thumri — Benaras, Lucknow, and Patiala.</li>
<li>Begum Akhtar is one of the most popular singers of the thumri style.</li></ul>
<br><hr><br>
Kathak uses ‘Thumris’ (expression-based numbers like ‘Padams’ and ‘Javalis’ of Bharatanatyam) to tell stories – stories of love, anger, separation, heroes and heroines. Thumri originated from the term ‘Thumakna’ which refers to rhythmic movement and stylized gait. These semi-classical compositions combined melody and rhythm with a couple of lines of text/ poetry, which was more colloquial. Some Thumris reflected Shringara rasa (the amorous flavour of love and romance) and some, ‘Bhakti’ (devotion).
<br><hr><br>
While the early Kathakars and forest dwellers told the stories of the divine (early Gupta period 4th century CE), the traditional compositions also explored love and beauty with Shyam/ Krishna as the hero of the story....
...ater, rulers like Nawab Wajid Ali Shah went on to write Thumris, set them to music, and also danced to various Thumris, where he played the role of Krishna. The others like Pia Rangeelay, explored the aspect of love through Thumris, where the subjects were the lover and his beloved, and not specifically Gods as heroes of the Thumris, as it used to be in the traditional compositions. Much later, during the British rule, when Indian classical dance was considered nautch, the presentation of the Nayika became more sensuous and enticing, the style of singing more provocative, and thus a lighter version of the Thumris emerged.
<br>(from <a href='https://namasteswitzerland.ch/2020/09/08/thumri-and-the-art-of-storytelling/'>namasteswitzerland</a>)
<br><hr><br>
<b>(from a film review: Girija- A Life Time in Music)</b><br>
Produced by Madhu Chandra and Sudha Datta and directed by Debapriya Adhikary, Samanwaya Sarkar and Sankalp Meshram; with a running time of over 2 hours, Girija- A Life time in Music is a labour of love that takes us into the world of Padma Bhushan , Girija Devi- one of the finest contemporary Hindustani vocalists of our times.

In the film, a student of Girija Devi recalls an incident- of how one day Appa ji, as Girija Devi is lovingly referred to by her students and younger members of the music fraternity, was sitting in the verandah and suddenly called out to her. It was drizzling outside, she recalls and Appaji asked her to extend her arm and feel the rain drops. “Feel it,” she told her-“this is the jhir jhir barse sawan ras bundiya that we sing about. Feel how softly the drops fall. Now if you take a big taan while singing of rain that would mean musladhaar baarish (heavy rain), so the taans need to be soft and delicate when you speak about jhir jhir rains.”

This one scene gave me goosebumps.  As did many other… The documentary is such a wonderful attempt to introduce music lovers to the living legend (who...) rose to become the epitome of grace in the world of Hindustani music and earned the title of <b><u>Queen of Thumris</u></b>.
<br><hr><br>
<b>(below snipped from good short essay <a href='https://aviman75.wordpress.com/2013/03/01/thumri-download-the-best-and-most-popular/#:~:text=%20%20%201%20Ka%20Karu%20Sajani%20Aaye,Kafi%20%29%20by%20Pt.%20Bhimsen%20Joshi%20More%20'>here</a>)</b><br>
The Banarasi style draws from poetry in Hindi, Braj and Avadhi to source suitable insertions, while Lucknowi thumri sources insertions from Urdu poetry alone.<br>While Lucknowi thumri shows marked influence of Kathak, ghazal and tappa, the Banarasi variety seems more inclined towards adapting melodies from the folk repertoire of kajri, chaiti and jhoomar. Lucknowi thumri illustrates the impact of the courtly culture of the Nawabs of Avadh, while Banarasi thumri uses with elements from folk culture...<br>
Some of the most famous thumri artists are – Badi Motibai, Rasoolan Bai, Siddheshwari Devi, Savita Devi, Girija Devi, Gauhar Jan, Shobha Gurtu, Begum Akhtar, Prabha Atre, Pandit Channulal Mishra, Naina Devi, Purnima Choudhuri, Shubha Mudgal, Abdul Karim Khan, Nazakat-Salamat Ali Khan, Barkat Ali Khan, Bade Ghulam Ali Khan. Among these stars Shobha Gurtu is the brightest and is called “the thumri queen”.
<br><hr><br>
https://www.quora.com/What-are-some-of-the-best-thumris
has links to YouTube incl SAIGAL Babul Mora
<br><hr><br>
The <b>Hori Thumris</b> are most often based on the romance of Krishna and Radha. They talk about their play and pranks with colors during Holi.
an excellent, in-depth <a href='https://www.inditales.com/hori-thumris-holi-songs/'>essay</a> on Hori Thumris w/links to many YouTube entries
<br><hr><br>
</tr>
</tbody>
</table>
</div>

<div id="PodcastPane" data-dojo-props="title:'Podcasts'" data-dojo-type="dijit/TitlePane"> 
<!--LINKS BEGIN-->
<table id="ThumriTable" style="background-color: ivory;" class="separate">
<tbody>
<tr>
All Episodes of <a href='https://www.bbc.co.uk/programmes/b006qykl/episodes/guide'>In our Time</a><br>
Episodes classified by the Dewey Dec. <a href='https://feelinglistless.blogspot.com/2022/02/cataloguing-bbc-radio-4s-in-our-time.html'>Sys</a><br>

A few selections (only chkd upto about #500)<br>
<ul><li><a href="https://www.bbc.co.uk/programmes/p003k9fs">Stoicism</a></li>
<li>Marcus <a href="https://www.bbc.co.uk/programmes/m000sjxt">Aurelius</a></li>
<li><a href="https://www.bbc.co.uk/programmes/b01s0qmj">Montaigne</a></li>
<li><a href="https://www.bbc.co.uk/programmes/p00548wx">Proust</a></li>
<li><a href="https://www.bbc.co.uk/programmes/b09smh59">Sun Tzu</a> and The Art of War</li>
<li><a href="https://www.bbc.co.uk/programmes/b01hl293">Clausewitz</a> and On War</li>
<li><a href="https://www.bbc.co.uk/programmes/m00094kn">Rousseau</a> on Education</li>
<li>The Grand <a href="https://www.bbc.co.uk/programmes/p00548fs">Tour</a></li>
<li><a href="https://www.bbc.co.uk/programmes/b0511tm1">Ashoka</a> the Great</li>
<li>Blaise <a href="https://www.bbc.co.uk/programmes/b03b2v6m">Pascal</a></li>
<li>The Cult of <a href="https://www.bbc.co.uk/programmes/b01pg5nt">Mithras</a></li>
<li>The <a href="https://www.bbc.co.uk/programmes/b01mqq94">Druids</a></li>
<li>The <a href="https://www.bbc.co.uk/programmes/p00548zx">Aristocracy</a></li>
<li>The <a href="https://www.bbc.co.uk/programmes/m0014xt4">Arthashastra</a></li>
<li>The South Sea <a href="https://www.bbc.co.uk/programmes/b01pcs5g">Bubble</a></li></ul>

</tr>
</tbody>
</table>
</div>




                        <br>
                        http://www.songlyrics.com/<br>
                        <a href="https://en.wikipedia.org/wiki/Great_American_Songbook">Great American Songbook</a><br>
                        <br>
                        
<p>
<details>
<summary>Billboard #1 hits over the years</summary>
<br>
Grammy-nominated or not, No. 1 hits over the years<br>(APnews:  By MESFIN FEKADU)<br>NEW YORK (AP)  The exclusion of The Weeknds Blinding Lights at the 2021 Grammy Awards shocked many, but hes in good company: Princes When Doves Cry never scored a nomination either.<br>Heres a look at every Billboard No. 1 hit of the year since 1958, Grammy-nominated or not.<br>NOTE: Songs with an asterisk represent tracks that earned a Grammy nomination; songs with two asterisks won a Grammy.<br>2020: The Weeknd, Blinding Lights<br>2019: Lil Nas X featuring Billy Ray Cyrus, Old Town Road (asterisk)(asterisk)<br>2018: Drake, Gods Plan (asterisk)(asterisk)<br>2017: Ed Sheeran, Shape of You (asterisk)(asterisk)<br>2016: Justin Bieber, Love Yourself (asterisk)<br>2015: Mark Ronson featuring Bruno Mars, Uptown Funk (asterisk)(asterisk)<br>2014: Pharrell Williams, Happy (asterisk)(asterisk)<br>2013: Macklemore & Ryan Lewis featuring Wanz, Thrift Shop (asterisk)(asterisk)<br>2012: Gotye featuring Kimbra, Somebody That I Used to Know (asterisk)(asterisk)<br>2011: Adele, Rolling In the Deep (asterisk)(asterisk)<br>2010: Kesha, Tik Tok<br>2009: Black Eyed Peas, Boom Boom Pow (asterisk)(asterisk)<br>2008: Flo Rida featuring T-Pain, Get Low (asterisk)<br>2007: Beyonc, Irreplaceable (asterisk)<br>2006: Daniel Powter, Bad Day (asterisk)<br>2005: Mariah Carey, We Belong Together (asterisk)(asterisk)<br>2004: Usher featuring Lil Jon and Ludacris, Yeah! (asterisk)(asterisk)<br>2003: 50 Cent, In Da Club (asterisk)<br>2002: Nickelback, How You Remind Me (asterisk)<br>2001: Lifehouse, Hanging by a Moment<br>2000: Faith Hill, Breathe (asterisk)(asterisk)<br>1999: Cher, Believe (asterisk)(asterisk)<br>1998: Next, Too Close<br>1997: Elton John Candle In the Wind 1997 (asterisk)(asterisk)<br>1996: Los del Ro, Macarena (Bayside Boys Mix)<br>1995: Coolio, Gangstas Paradise (asterisk)(asterisk)<br>1994: Ace of Base, The Sign (asterisk)<br>1993: Whitney Houston, I Will Always Love You(asterisk)(asterisk)<br>1992: Boyz II Men, End of the Road (asterisk)(asterisk)<br>1991: Bryan Adams, (Everything I Do) I Do It for You (asterisk)(asterisk)<br>1990: Wilson Phillips, Hold On (asterisk)<br>1989: Chicago, Look Away<br>1988: George Michael, Faith<br>1987: The Bangles, Walk Like an Egyptian<br>1986: Dionne Warwick & Friends, Thats What Friends Are For (asterisk)(asterisk)<br>1985: Wham!, Careless Whisper<br>1984: Prince, When Doves Cry<br>1983: The Police, Every Breath You Take (asterisk)(asterisk)<br>1982: Olivia Newton-John, Physical (asterisk)<br>1981: Kim Carnes, Bette Davis Eyes (asterisk)(asterisk)<br>1980: Blondie, Call Me (asterisk)<br>1979: The Knack, My Sharona (asterisk)<br>1978: Andy Gibb, Shadow Dancing<br>1977: Rod Stewart, Tonights the Night (Gonna Be Alright)<br>1976: Wings, Silly Love Songs<br>1975: Captain & Tennille, Love Will Keep Us Together (asterisk)(asterisk)<br>1974: Barbra Streisand, The Way We Were (asterisk)(asterisk)<br>1973: Tony Orlando and Dawn, Tie a Yellow Ribbon Round the Ole Oak Tree (asterisk)<br>1972: Roberta Flack, The First Time Ever I Saw Your Face (asterisk)(asterisk)<br>1971: Three Dog Night, Joy to the World (asterisk)<br>1970: Simon & Garfunkel, Bridge Over Troubled Water (asterisk)(asterisk)<br>1969: The Archies, Sugar, Sugar<br>1968: The Beatles, Hey Jude (asterisk)<br>1967: Lulu, To Sir with Love<br>1966: SSgt. Barry Sadler, Ballad of the Green Berets<br>1965: Sam the Sham & the Pharaohs, Wooly Bully (asterisk)<br>1964: The Beatles, I Want to Hold Your Hand (asterisk)<br>1963: Jimmy Gilmer and the Fireballs, Sugar Shack<br>1962: Acker Bilk, Stranger on the Shore (asterisk)<br>1961: Bobby Lewis, Tossin and Turnin<br>1960: Percy Faith, Theme from A Summer Place (asterisk)(asterisk)<br>1959: Johnny Horton, The Battle of New Orleans (asterisk)(asterisk)<br>1958: Domenico Modugno, Nel Blu Dipinto di Blu (Volare) (asterisk)(asterisk)<br>
<br>
</details>

                        
                        <br>
                        <hr>
                      Stephen Holden writes for the NYT covering the Cabaret/Standards Scene (Gershwin/Berlin/Porter/Broadway)
                        <hr><br>
<details>
  <summary><span class='mHG'>Show Calendars @ some NYC venues</span></summary>
<br>
                      http://metropolitanroom.com/enhancedCalendar.cfm  <br>https://54below.com/calendar/?month=December+2016  <br>https://www.rosewoodhotels.com/en/the-carlyle-new-york/location/things-to-do/events-at-the-carlyle  <br>http://www.birdlandjazz.com/calendar/  <br>http://www.jazz.org/calendar-full.php  <br>http://americansongbook.org/  <br>"NYC's 3 major cabaret supper clubs - Cafe Carlyle, the Oak Room (Algonquin) & Feinstein's @ Loews Regency - are attached to hotels.  <br>Other downtown Cabaret venues listed in a NYT "Cabaret for a steal" article by Erik Piepenburg:  <br>the 70-seat cabaret theater @ the Duplex in the West Village cover is $20 w 2 drink min.  <br>100-seat place @ Laurie Beechman Theater in Clinton  <br>Don't Tell Mama, W 46th St.  <br>the Metropolitan Rm  <br>Le Poisson RougeJoe's PubCast Party @ Birdland  <br>Kazuo Ishiguro "writes fanciful, mildly surreal lyrics to (Jim) Tomlinson's (saxophonist) music..."  <br>...latter-day answer to Gilberto & Stan Getz (!!)  <br>
</details>
<br>

<details>
  <summary><span class='mHG'>Harmonica stuff</span></summary>
<p>

<details>
  <summary><span class='mHG'>Harmonica Notes: Understanding the holes for playing songs</span></summary>
<p>
If you play any blow hole on a standard key of C 10-hole diatonic harmonica will the pitch be higher or lower?
<br>
If you dont know the answer to this trick question, you may have trouble playing songs forever.
<br>
Lets figure it out together.
<br>
First, blow into hole number 1 and follow that by drawing into hole number 1. Which is higher? The draw note is higher. Right? Check for yourself and youll see this is correct.
<br>
Now blow into hole number two, then draw. Again the draw note is higher.
<br>
So from these two examples you might conclude that the draw notes are higher than the blow notes, but, if so, you would only be partly correct.
<br>
Now try blowing into 10 and then drawing into 10. Hopefully your ear can tell you this is different. Which note is higher in pitch?
<br>
The blow note is the higher pitch than the draw note. Somewhere on the harp, the pattern goes from the draw notes being higher to the blow notes being higher. Where does that happen?
<br>
Blow draw into 3, then 4, then 5, then 6, then 7! The switch happens between holes 6 and 7. From holes 1 through 6 the blow notes are lower than the draw notes. From holes 7 through 10, it reverses. The blow notes are higher than the draw notes.
<br>
Because of this, most harmonica players call holes 1 through 6 the low end of the harp and holes 7 through 10 the high end of the harp. Many players get confused when exploring the high notes.
<br>
They know something is different, but they cannot put it into words. Because of this, many harmonica players do not continue exploring the high notes (and they feel intimidated to play songs on the higher notes).
<br>
Have the courage to explore the high notes and, the more you do it, the easier it will be for you to include all the notes on the harmonica to play the songs you love.
<br>
Playing the major scale is a great way to feel the shift.
<br>
Play these notes to go up the major scale:
<br>Do Re Mi Fa So La Ti Do
<br>4 -4 5 -5 6 -6 -7 7
<br>And play the same notes in reverse to go down the major scale.
<br>
<br>Practice this a bit and this initially confusing aspect of harmonica will soon become second nature to you.
<br>
(<a href='https://www.harmonica.com/harmonica-notes-understanding-the-holes-for-playing-songs-7328.html'>Article</a> by: Michael Rubin)
<hr>
<br>
</details><!--understanding...article-->
<br>
<details>
  <summary><span class='mHG'>Wild Thing (Hendrix)</span></summary>
<br>
<br>5     4         -5  -5   5   -4    4
<br>Wild Thing       you make my heart sing
<br>
<br>-5   -5     6   4   4   4  3
<br>You  make  everything  groovy
<br>
<br>  -4    4
 <br>Wild Thing (spoken)"Wild thing I think I love you"
 <br>
<br> 3   6  6 b6   6 -5   5    4
<br>But  I  wanna  know  for  sure
<br>
<br>(spoken)"come on and hold me tight I love you"
<br>
<br>(instamental break)
<br>6 6 5    6 5 6 5 6 5 6 5    5 6 -6 6 5 6 -6 
<br>-6 6 5 6 5 6 5   6 -6 -6 -7   -7 -6 6 -6 6 5 
<br>-7 -6 6 -6 6 5   -7 -6 6 -6 6 5   -7 -6 6 5 -7
<br>-6 6 5   5 6 6 5 6   5 5 5 6  -6 
<br>
<br>REPEAT THE FIRST PARTOF THE SONG
<br>
<br>AND END WITH THIS
 <br>-5 -5   -5 -5   5     4     
<br>C`m`on  c`m`on Wild Thing
<br>
</details>
<br>
<details>
  <summary><span class='mHG'>(harmonica riff) Billy joel's piano man</span></summary>
<br>
<br>456 456- 456 456- 456 345- 345 345- 345
<br>45 456- 45 456- 45
<br>
</details>

<br>
<details>
  <summary><span class='mHG'>Yeh shaam mastani (Kishore Kumar)</span></summary>
<br>
ye&nbsp;shaam&nbsp;mastaani,&nbsp;mada_hosh&nbsp;kiye&nbsp;jaaye</p> <br><p>6&nbsp;&nbsp;4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-4&nbsp;4-6&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;6&nbsp;6&nbsp;&nbsp;4&nbsp;&nbsp;<br>&nbsp;4&nbsp;-4&nbsp;&nbsp;-4&nbsp;&nbsp;5</p> <br><p>mujhe&nbsp;Dor&nbsp;koii&nbsp;khii.nche,&nbsp;terii&nbsp;ooor&nbsp;liye&nbsp;jaaye</p> <br><p>5&nbsp;5&nbsp;&nbsp;&nbsp;56&nbsp;-6&nbsp;&nbsp;6&nbsp;-9&nbsp;&nbsp;6&nbsp;&nbsp;-9-9&nbsp;5&nbsp;&nbsp;&nbsp;5-95-4<br>6</p> <br><p>&lt;ye&nbsp;shaam&nbsp;...&gt;</p> <br><p>duur&nbsp;rahatii&nbsp;hai&nbsp;tuu,&nbsp;mere&nbsp;paas&nbsp;aatii&nbsp;nahii.n</p> <br><p>-6&nbsp;&nbsp;-9&nbsp;&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;-6&nbsp;&nbsp;&nbsp;6&nbsp;&nbsp;&nbsp;&nbsp;4&nbsp;4&nbsp;&nbsp;-6<br>&nbsp;&nbsp;&nbsp;-9&nbsp;6&nbsp;&nbsp;&nbsp;-6&nbsp;6</p> <br><p>hoTho.n&nbsp;pe&nbsp;tere,&nbsp;kabhii&nbsp;pyaas&nbsp;aatii&nbsp;nahii.n</p> <br><p>4&nbsp;-6&nbsp;-96&nbsp;-6&nbsp;6&nbsp;&nbsp;&nbsp;4&nbsp;4&nbsp;&nbsp;&nbsp;&nbsp;-6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-9&nbsp;6&nbsp;&nbsp;<br>-6&nbsp;6</p> <br><p>aisaa&nbsp;lage,&nbsp;jaise&nbsp;ki&nbsp;tuu,&nbsp;ha.Nske&nbsp;zahar&nbsp;koii&nbsp;piye&nbsp;jaaye</p> <br><p>-7&nbsp;-6&nbsp;&nbsp;&nbsp;6&nbsp;-9&nbsp;&nbsp;&nbsp;-6&nbsp;&nbsp;6&nbsp;&nbsp;-9&nbsp;&nbsp;5&nbsp;-4&nbsp;&nbsp;-4<br>&nbsp;&nbsp;&nbsp;-4&nbsp;&nbsp;-4&nbsp;-9&nbsp;&nbsp;-9&nbsp;-44&nbsp;67&nbsp;-55</p>
<br>
</details>
<br>
<details>
  <summary><span class='mHG'>Chala jaata huun (Kishore Kumar)</span></summary>
<br>
<p>PLAY&nbsp;with&nbsp;a&nbsp;fast&nbsp;tempo</p> <br><p>chalaa&nbsp;jaataa&nbsp;huuN,&nbsp;kisii&nbsp;kii&nbsp;dhun&nbsp;mein</p> <br><p>555&nbsp;66&nbsp;55&nbsp;7&nbsp;-5-5</p> <br><p>dhaDakate&nbsp;dil&nbsp;ke,&nbsp;taraane&nbsp;liye</p> <br><p>555&nbsp;566&nbsp;5&nbsp;7&nbsp;-4&nbsp;-7&nbsp;7</p> <br><p>milan&nbsp;kii&nbsp;mastii,&nbsp;bharii&nbsp;aaNkhon&nbsp;mein</p> <br><p>77&nbsp;-7&nbsp;-6&nbsp;-6&nbsp;-7&nbsp;-7&nbsp;-6&nbsp;6&nbsp;66</p> <br><p>hazaaron&nbsp;sapane,&nbsp;suhaane&nbsp;liye&nbsp;ho..oo</p> <br><p>7&nbsp;7&nbsp;-7&nbsp;-6&nbsp;-6&nbsp;-6&nbsp;-7&nbsp;-7&nbsp;-6&nbsp;6&nbsp;6&nbsp;6&nbsp;-55</p> <br><p>ye&nbsp;mastii&nbsp;ke,&nbsp;nazaaren&nbsp;hain,&nbsp;to&nbsp;aise&nbsp;mein</p> <br><p>6&nbsp;6&nbsp;6&nbsp;65&nbsp;6&nbsp;6&nbsp;6&nbsp;6&nbsp;-55&nbsp;6&nbsp;6&nbsp;6&nbsp;6&nbsp;5-4</p> <br><p>sambhalanaa&nbsp;kaisaa&nbsp;merii&nbsp;qasam</p> <br><p>-7&nbsp;-7&nbsp;-7&nbsp;-7&nbsp;7&nbsp;7&nbsp;6&nbsp;-7&nbsp;-6&nbsp;6</p> <br><p>tuu&nbsp;laharaatii,&nbsp;Dagariyaa&nbsp;ho,&nbsp;to&nbsp;phir&nbsp;kyuN&nbsp;naa</p> <br><p>6&nbsp;6&nbsp;6&nbsp;6&nbsp;6&nbsp;5&nbsp;6&nbsp;6&nbsp;6&nbsp;6&nbsp;6-55&nbsp;6&nbsp;6&nbsp;6&nbsp;6&nbsp;5-4</p> <br><p>chaluuN&nbsp;mein&nbsp;bahakaa&nbsp;bahakaa&nbsp;re</p> <br><p>-7&nbsp;-7&nbsp;-7&nbsp;7&nbsp;7&nbsp;7&nbsp;-7&nbsp;-7&nbsp;-7&nbsp;7</p> <br><p>mere&nbsp;jeevan&nbsp;mein,&nbsp;ye&nbsp;shaam&nbsp;aaii&nbsp;hai</p> <br><p>7&nbsp;7&nbsp;-7&nbsp;-6&nbsp;-6&nbsp;-7&nbsp;-7&nbsp;-6&nbsp;6&nbsp;6</p> <br><p>muhabbat&nbsp;vaale,&nbsp;zamaane&nbsp;liye&nbsp;ho..oo</p> <br><p>7&nbsp;7&nbsp;-7&nbsp;-6&nbsp;-6&nbsp;-7&nbsp;-7&nbsp;-6&nbsp;6&nbsp;6&nbsp;6&nbsp;-55</p>
<br>
</details>
<br>
<details>
  <summary><span class='mHG'>Yeh dosti</span></summary>
<br>
<p>yeh&nbsp;dosti&nbsp;</p> <br><p>5~&nbsp;-4~44&nbsp;3~</p> <br><p>hum&nbsp;nahi&nbsp;todenge</p> <br><p>3&nbsp;-66~&nbsp;&nbsp;5-454~</p> <br><p>todenge&nbsp;dum&nbsp;magar</p> <br><p>55-5~&nbsp;6&nbsp;-5&nbsp;5&nbsp;-4~</p> <br><p>tera&nbsp;sath&nbsp;na&nbsp;chhodenge</p> <br><p>-4-4&nbsp;555~&nbsp;-444~</p> <br><p>&nbsp;</p> <br><p>teri&nbsp;jeet&nbsp;meri&nbsp;jeet</p> <br><p>666&nbsp;-6-6-6</p> <br><p>teri&nbsp;haar&nbsp;meri&nbsp;haar</p> <br><p>666&nbsp;-6-6-6</p> <br><p>sun&nbsp;aey&nbsp;mere&nbsp;yaar</p> <br><p>6~6~&nbsp;-56&nbsp;-55~</p> <br><p>tera&nbsp;gum&nbsp;mera&nbsp;gum</p> <br><p>666&nbsp;-6-6-6</p> <br><p>meri&nbsp;jaan&nbsp;teri&nbsp;jaan</p> <br><p>666&nbsp;-6-6-6</p> <br><p>aesa&nbsp;apna&nbsp;pyar</p> <br><p>6~6~&nbsp;-56&nbsp;-55~</p> <br><p>&nbsp;</p> <br><p>jaan&nbsp;pe&nbsp;bhi&nbsp;khelenge</p> <br><p>55&nbsp;-56&nbsp;-55&nbsp;-4</p> <br><p>tere&nbsp;liye&nbsp;le&nbsp;lenge</p> <br><p>-4-4&nbsp;5&nbsp;-5&nbsp;555~</p> <br><p>sab&nbsp;se&nbsp;dushmani</p> <br><p>555~&nbsp;-444~</p> <br><p>yeh&nbsp;dosti&nbsp;hum&nbsp;nahi&nbsp;todenge</p>
</details>

<br>
<details>
  <summary><span class='mHG'>Aane wala pal</span></summary>
<br>
<p>aane&nbsp;wala&nbsp;pal</p> <br><p>4&nbsp;-4&nbsp;5&nbsp;-6-6~&nbsp;-7</p> <br><p>jane&nbsp;wala&nbsp;hai</p> <br><p>-7&nbsp;-6&nbsp;5&nbsp;-4&nbsp;5~</p> <br><p>ho&nbsp;sake&nbsp;to&nbsp;isme</p> <br><p>5&nbsp;-5&nbsp;6&nbsp;-5&nbsp;5&nbsp;-4~</p> <br><p>zindagi&nbsp;bita&nbsp;do</p> <br><p>-4&nbsp;5&nbsp;-5&nbsp;5&nbsp;-4&nbsp;4</p> <br><p>pal&nbsp;jo&nbsp;ye&nbsp;jane&nbsp;wala&nbsp;hai</p> <br><p>-4&nbsp;4&nbsp;5&nbsp;-4&nbsp;-5&nbsp;5&nbsp;6&nbsp;-5&nbsp;5</p> <br><p>ik&nbsp;bar&nbsp;waqt&nbsp;se</p> <br><p>444&nbsp;-3&nbsp;-4&nbsp;-3&nbsp;4~</p> <br><p>lamha&nbsp;gira&nbsp;koi</p> <br><p>555&nbsp;-4&nbsp;6&nbsp;-4&nbsp;5</p> <br><p>wahan&nbsp;dastaan&nbsp;mili</p> <br><p>666&nbsp;6&nbsp;-6&nbsp;7&nbsp;-6&nbsp;-5</p> <br><p>lamha&nbsp;kahin&nbsp;nahi</p> <br><p>-6-6-6&nbsp;6-6-7-6&nbsp;6~</p> <br><p>thoda&nbsp;sa&nbsp;hansa&nbsp;ke</p> <br><p>5&nbsp;-5&nbsp;6&nbsp;-5&nbsp;5&nbsp;-4~</p> <br><p>thoda&nbsp;sa&nbsp;rula&nbsp;ke</p> <br><p>-4&nbsp;5&nbsp;-5&nbsp;5&nbsp;-4&nbsp;4~</p> <br><p>pal&nbsp;ye&nbsp;bhi&nbsp;jane&nbsp;wala&nbsp;hai</p> <br><p>-4&nbsp;4&nbsp;5&nbsp;-4&nbsp;-5&nbsp;5&nbsp;6&nbsp;-5&nbsp;5</p>
</details>

<br>
<details>
  <summary><span class='mHG'>Maniyaro</span></summary>
<br>
<br>..<abbr><a title="Tooltip test"></a></abbr>   ,
<br>     .
<br>    ,
<br> ,  ,
<br>  ,   .
<p>
<br>..    
<br>     ,
<br> ,  . .
<p>
<br>..    
<br>     ,
<br> ,   .
<p>
<br>..    
<br>      ,
<br> ,   .
<p>
<br>..     ,
<br>     ,
<br> ,  ,
<br> ,   .
<p>
<br>..    ,
<br>      ,
<br> ,  ,
<br>  ,   .
<p>
<br>..   
<br>  ,    ,
<br> ,  ,
<br> ,  . . 
<p>
</details>
</details><!--harmonica stuff-->
<br>

                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "elevateLinks", "ElevateLinks", [], """
                <section>
                    <div id="elevateLinks">
<span class='mTitle'>Links</span>
<br>
(Emersonian essays)
https://en.wikisource.org/wiki/Representative_Men
<hr>

                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "buddhism", "Buddhism", [], """
                <section>
                    <div id="buddhism">
<span class='mTitle'>Buddhism</span>
<br>
Ten Bulls or Ten Ox Herding Pictures:
<br>https://en.wikipedia.org/wiki/Ten_Bulls
<br>http://philosophy.lander.edu/oriental/reader/reader/x5038.html
<br>
<br><a href='https://en.wikipedia.org/wiki/Shikantaza'>Shikantaza</a>
<br><a href='https://en.wikipedia.org/wiki/Five_Ranks'>Five Ranks</a>
<br><a href='https://en.wikipedia.org/wiki/Subitism'>Subitism</a>
<br><a href='https://en.wikipedia.org/wiki/Kensh%C5%8D'>Kensh</a>
<br><a href='https://en.wikipedia.org/wiki/Satori'>Satori</a>
<br><a href='https://en.wikipedia.org/wiki/Linji_Yixuan#Three_Mysterious_Gates'>Three Mysterious Gates</a>
<br><a href='https://en.wikipedia.org/wiki/Hakuin_Ekaku#Four_ways_of_knowing'>Four ways of knowing</a>
<br><a href='https://en.wikipedia.org/wiki/Sesshin'>Sesshin</a>
<br><a href='https://en.wikipedia.org/wiki/Zazenkai'>Zazenkai</a>
<br><a href='https://en.wikipedia.org/wiki/Ango'>Ango</a>
<br><a href='https://en.wikipedia.org/wiki/Rinzai_school'>Rinzai</a> school
<hr>

                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "travelNYC", "Travel - NYC", [], """
                <section>
                    <div id="travelNYC">
                        https://blogs.baruch.cuny.edu/asianamericanhistorynyc/<br>

<p>
<b>Discounted stuff:</b><br>
<br><a href='nywatertaxi.com'>WallSt to RedHook ferry</a> free wkends
<br><a href='nycgo.com/free'>Free</a> (pay what you want) museums: Met, NatHist, Frick
<br><a href='21stires.com'>only</a> remaining disc store
<br><a href='premiumoutlets.com'>Woodbury</a> commons mall, 1 hr upstate
<br><a href='nycgovparks.com'>Public pools</a>
<br><a href='downtownboathouse.org'>free</a> kayak sess/Hudson
<br>free <a href='link.nyc'>wifi</a>
<br><a href='thepodhotel.com'>pod</a> (39th, 51st) $95+
<br><a href='thejanenyc.com'>theJane</a> (railway sleeperCar inspired) $85+
<br><a href='citizenm.com'>'stylish'</a> timesSq $150+, 230-rm
<br>Rooftop bars <a href='empirehotelnyc.com'>#1</a><a href='230-fifth.com'>#2</a><a href='standardhotels.com'>#3</a>

<br>
<p>

                        somewhat interesting:<br>
                        https://batteryrooftopgarden.org<br>
                        http://www.bikeblognyc.com/ & page/2/ etc.
                        <p></p><br>
                        <a href="http://nypost.com/">NY Post</a><br>
                        <br>
                        <a href="https://www.vice.com/read/dumpster-diving-on-the-upper-west-side-511">VICE</a><br>
                        <a href="www.nydailynews.com">NY Daily News</a><br>
                        <a href="http://www.thedailybeast.com/articles/2015/06/19/why-we-love-to-loathe-manhattan-s-upper-east-side-from-f-scott-fitzgerald-to-odd-mom-out.html">Why We Love to Loathe Manhattan's UES...</a><br>
                        <a href="http://www.amny.com/real-estate/city-living/manhattan/upper-west-side-1.7059835?image=2">AM NY</a><br>
                        <a href="http://abc7ny.com/">ABC7 NY</a><br>
                        <a href="http://newyork.cbslocal.com">CBS NY</a><br>
                        <a href="https://www.rottentomatoes.com/m/those_people_2016/">Those People (2016) - Rotten Tomatoes</a><br>
                        <a href="http://westsidewords.com/">westsidewords</a><br>
                        <a href="https://www.airbnb.com/locations/new-york/upper-west-side">Airbnb but lotsa gd photos</a><br>
                        <a href="http://untappedcities.com/">http://untappedcities.com/</a><br>
                        <a href="http://www.humansofnewyork.com/">(blocked)humansofnewyork</a><br>
                        <a href="http://www.westsiderag.com/">(blocked)WestSideRag (seems gd)</a><br>
                        <a href="http://therumpus.net/2016/07/the-upper-far-east/">(blocked)The Upper Far East - The Rumpus.net</a><br>
                        <a href="http://www.lifeintheapple.com/uptown.html">life in the apple (blocked)</a><br>
                        http://gothamist.com<br>
                        <a href="http://www.timeout.com/newyork/things-to-do/the-anglophiles-guide-to-nyc">Anglophile's guide to New York</a><br>
                        <a href="http://www.gothamgazette.com/localbeats/manhattan.php">Gotham Gazette Manhattan blogs, lists</a><br>
                        <a href="http://www.terryteachout.com/">Terry Teachout</a><br>
                        <a href="http://cityroom.blogs.nytimes.com/">NYT CITY ROOM rdr's stories</a><br>
                        <a href="http://newyork.craigslist.org/search/roo">NY rooms to let stories</a><br>
                        <br>
                        <p><br>

                        <br></p>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "NYCeat", "NYC eatingOut", [], """
                <section>
                    <div id="NYCeat">

                      <hr>
                        <br>
                        <br>
                        <a href="http://www.yelp.com/biz/europan-cafe-new-york-9">Europan Cafe - 11 Reviews - Cafes - Upper West Side - New ...</a><br>
                        <a href="http://www.toochicformeat.com/nyctour/">Vegan NYC Tour</a><br>
                        <a href="http://ny.eater.com/">ny.eater</a><br>

                        <a href="http://www.yelp.com/biz/one-riverside-park-new-york">Yelp rev</a>
                        <p><br>
                        srch results for manhattan veggie places: http://tinyurl.com/z9bh8qq<br>
                        <br>
                        - 252 Manhattan veggie restaurants at http://www.vegguide.org/region/5<br>
                        (but v. few rated well, lots of cafes & raw/vegan stuff) top choices have been listed below.<br>
                        Hummus Kitchen - 768 9th Avenue 212-333- 3009<br>
                        Gd rev from NYT, also has falafel<br>
                        Soy and Sake Village<br>
                        47 7th Avenue South 212-255-2848 http://www.soyandsake.com<br>
                        Japanese Vegetarian cafe West Village specializing in Japanese food, but also carrying Chinese, Malaysian, and American soul food. owned by the same people as Red Bamboo / VP2, so the menu includes many well-known Red Bamboo items like chicken Parmesan, soy chops, and other soul food dishes utilizing soy meats. Other menu items include: numerous mockmeat sandwiches, curries, salads, noodle dishes, bento boxes and sushi. Lunch specials are about $7-9 include both sushi and soul food options.<br>
                        Hangawi 12 E 32nd Street<br>
                        Vegan Korean dining in a tranquil space "posh". Zagat rated as top Korean and top vegetarian.<br>
                        Lunch specials are WAY cheaper than dinner ($10 vs. $25),<br>
                        <br>
                        Beyond Sushi 229 E 14th St betw 2nd & 3rd Ave Union Square vegetarian sushi shop<br>
                        Executive Chef Guy Vaknin is a Hell's Kitchen finalist. He serves all vegetarian sushi made from fruits and vegetables topped with customized sauces. Spicy Mango Roll - black rice, avocado, mango, cucumber and spicy veggie topping with toasted cayenne sauce.<br>
                        Kyotofu Upper West Side 705 Ninth Avenue<br>
                        Upscale, modern Japanese food with an emphasis on tofu<br>
                        Souen Organic Ramen East Village Betw 1st & 2nd Ave 326 E 6th St Small organic ramen noodle shop<br>
                        From the owners of Souen comes this tiny organic ramen noodle shop. The seitan dumplings are vegan but make sure to ask questions about the ingredients of the different broths available.<br>
                        Maoz Vegetarian Restaurant 38 Union Sq E International Falafel Chain<br>
                        falafel sandwiches, salads, and fries. After you get your sandwich, there's a large selection of self-serve toppings - pickles, cucumber salad, roasted cauliflower, dairy and vegan coleslaws, carrots, baby eggplants dyed in beet juice (really), olives, several fresh hot sauces, and much more. The trick is they don't leave very much spare room in your sandwich, so you can't really load up on the condiments. The first Maoz branch was opened in 1991 in Amsterdam, Holland<br>
                        KAJITSU it's Michelin-starred Midtown E 125 E39th St betw Park & Lex Aves<br>
                        A tasting menu here runs $95, with the option of an additional $59 sake pairing;<br>
                        you can also opt for the less extravagant $55 menu, with a $45 sake pairing.<br>
                        Shojin cuisine refers to a type of vegetarian cooking that originates in Zen Buddhism.<br>
                        Even though it does not use meat or fish, shojin is regarded as the foundation of all Japanese cuisine, especially kaiseki, the Japanese version of haute cuisine. In its present form kaiseki is a multi-course meal in which fresh, seasonal ingredients are prepared in ways that enhance the flavor of each component, with the finished dishes beautifully arranged on plates. All of these characteristics come from shojin cuisine, which is still prepared in Buddhist temples throughout Japan.<br>
                        <br>
                        Peacefood Cafe 460 Amsterdam Ave betw82nd and 83rd Streets on UWside<br>
                        The roasted Japanese pumpkin sandwiches ($9.75) are served on spelt bread and come stuffed with pumpkin pulp, cashew cheese, walnuts and onions; the Shangai-style dumplings ($8.50) are packed with chives, mushrooms, marinated tofu and vegetarian protein, and the chickpea fries ($8.50) are thick mashed legume slices fired up with piquant Indian spicethere are also vegan cheeseburgers on tap at Peacefood's downtown spot. Don't skip out on dessert here, since the raw key lime pie ($7.50) will blow your mind, almond brazil nut crust and all. (limes shortage coming up).<br>
                         In addition to expanding service to anyone and everyone (in Midtown East) Jul2016, David Chang's delivery-only Momofuku restaurant Ando also introduced a new vegetarian sandwich and a meat-less side: Veg Banh Mi s/w ($10), Kimchi salad $4<br>
                        Charrua 131 Essex Street, New York, NY 10002 (212) 677-5838 (S of Houston)<br>
                        the vegetarian chivito, called the el cheto, a "signature Uruguayan sandwich" filled with portobello mushrooms and mozzarella, plus carrots, caramelized onions, and chimichurri, and served with a handful of thick, hot fries.<br>
                        Renovations are now complete at Tribeca stalwart Pakistan Tea House. The inexpensive restaurant was purchased by the owners of Baluchi's last year, who decided to close the shop for some renovations in January. The space now has a few new details  including large wooden tables, and chrome panelling on part of the wall  but the overall layout remains the same. Tribeca Citizen notes that the restaurant is now serving a limited menu, which includes vegetarian and meat combo plates for $8 to $10. According to the specials board, samosas are two-for-a-dollar.<br>

                        Cinnamon Snail at The Pennsy<br>
                        World famous vegan food truck turned permanent vendor in this spacious food hall above Penn Station. Every vegan's dream<br>
                        <br>
                        Founded by renowned Chef, Guy Vaknin, and his wife, Tali, Beyond Sushi offers an assortment of distinctive sushi rolls and other nutritional staples at their three outposts in Manhattan.<br>
                        Chef Guy and his culinary team fuses unconventional pairings of fruit and vegetables with whole grains to create sushi rolls. Hand pressed juices; reason. prices, online ordering/deliv.<br>
                        UNION SQUARE 646-861-2889 229 E. 14th St. (Between 2nd & 3rd Ave)<br>
                        MIDTOWN WEST 646-964-5097 62 W 56th St. (Between 5th & 6th Ave)<br>
                        CHELSEA MARKET 212-929-2889 75 9th Avenue (Between 15th & 16th St)<br>
                        <br>
                        Cinnamon Snail Penn Plaza, Southwest corner of 33rd St. and 7th Ave<br>
                        "voted the top food truck in America", four- time Vendy Award winner the Cinnamon Snail finally shares the recipes for its beloved street-side meals. Here you'll find Fresh Fig Pancakes for breakfast, Chimichurri Tempeh Empanadas for a snack, Thai Barbecue Seitan Ribs for a meal, and, of course, Snail classics like Vanilla-Bourbon Creme Brulee Donuts for dessert.<br>
                        Blossom du Jour (212) 229-2595  Vegan, Juice Bars & Smoothies 5 locations:<br>
                        CHELSEA 259 West 23rd Street (between 7th & 8th Ave.)<br>
                        HELL'S KITCHEN 617 9th Avenue (between 43rd & 44th St.)<br>
                        UNION SQUARE 15 East 13th Street (between 5th & University)<br>
                        UWS 81ST 449 Amsterdam Avenue (between 81st & 82nd St.)<br>
                        COLUMBUS CIRCLE in the subway statione 1000S 8th Ave, #21<br>
                        For over a decade, Terry's Gourmet Deli on Chelsea's 6th Avenue has dispensed some of the city's best Trinidadian rotis. The vegetarian (potatoes and chickpeas only) weighed in at a whopping 1 pound, 10 ounces; was 6 inches long, and cost $8. I'm not sure how one person could finish it. You can ask the roti maker for any amount of pepper sauce to be put inside, and I usually go for three plastic teaspoonfuls. 575 6th Ave, (212) 206-0170.<br>
                        <br>
                        Nix (Michelin-starred chef John Fraser)<br>
                        Vegetables are finally getting their due in New York, as evidenced by new all-vegetarian restaurant Nix. The food is complemented by a strong drinks program at this NYU-area restaurant in a modern space.<br>
                        (Brdway & 11th, just north of the Village) 72 University Pl New York, NY 10003 (212) 498-9393<br>
                        presently open for dinner only. http://www.nixny.com/<br>
                        "When my vegetarian friends ask for dining advice I send them to American spots like Hearth, for hen of the woods mushrooms and gnocchi, or to to nouveau-Indian spots like Babu Ji for their bright yellow Punjabi curries. I send them to creative pizza spots like Roberta's and Pasquale Jones, to Semilla for vegetable-heavy tastings, to Del Posto for their vegan tasting menu. Some of the most celebrated vegetable dishes right now are served at "regular" restaurants: the grain bowls, the avocado toasts, the brown butter and squash carpaccios.<br>
                        Superiority Burger made the veggie burger just as much an object of desire among the city's culinary cognoscenti as a trendy lamb burger. Now, the menus at Momofuku restaurants read "vegetarian options available on request."<br>
                        <br>
                        famed Avenue B deli Sunny and Annie's - vegetarian sandwich - had not just pesto, grilled mozzarella, fresh goat cheese, spinach, seaweed, and avocado, but also ~three~ pieces of bread, making it the first non-meat double decker I've ever seen.<br>
                        new fast-casual Asian restaurant @ 122 Ludlow Street Zing's Awesome Rice: menu will include six types of "seared rice," Yes, the fried rice is awesome, and it comes attractively plated with two domed scoops on either end of a long plate, with sriracha squirted in the middle in the shape of a heart or a leaf. But is it worth $11.99 to $13.99 for a modest serving, so that a full meal with app and beverage will run you $20 or $25? That's for you to decide. The rice is loaded with umami, has diced vegetables in it, and offers as a main ingredient a choice of tofu. For an extra dollar or two you can pick a more exotic form of rice, including a black rice with a particularly nutty flavor. Beverages run to beer and infused sake.<br>
                        (5/16) Philadelphia-based chef Michael Solmonov and restaurateur Steve Cook officially kicked open the doors to the Chelsea Market outpost of their hit hummus restaurant, Dizengoff, this morning. A key member of the Dizengoff Philly team moved to New York for the opening of this new counter: executive chef Emily Seaman. Dizengoff will always serve fresh hummus, and pita baked in a taboon, but the toppings and combinations will change often. Solomonov tells Eater: "Emily really changes the menu all the time. She gets everything from the market, basically, and transforms it into Israeli-esque dishes." Solomonov notes that the avocado with peanut harissa on the opening menu is "not something that you'd ever find in Israel, but it really tastes fantastic." The hummus meals are $10 to $13, and the salatim are $3 each. for the moment, Dizengoff NYC is serving salads, hummus, pita, and drinks.<br>
                        &lt;&lt;resp to above, a reviewer sez:&gt;&gt;I thought that the hummus at Dizengoff was excellent - probably the best in Manhattan along with Baraca on 38th Street, and amongst the best in the entire City in league with places like Olympic Pita and Mabat in Brooklyn, or Grill Point in Queens. (they don't have falafel for some reason)<br>
                        <br>
                        Freud<br>
                        The brunch menu at chef Eduard Frauneder's new Greenwich Village Austrian restaurant has a vegetarian breakfast sandwich with cauliflower, egg, Tumbleweed cheese, and onions on a roll. Baked eggs are also on the menu. For sweet options, Frauneder is offering pancakes with rhubarb, and French toast served with walnuts and smoked maple syrup.<br>
                        506 Laguardia Pl New York, NY 10012 (212) 777- 0327 (just N of Houston below the Village)<br>
                        Stuff to eat @ the Columbus Circle's Turnstyle Food Court (access via an outdoor elevator at 59th Street and 8th Ave)<br>
                        2. Tex-Mex Slice at The Pizza * Uber-cheesy, with a slightly thicker than usual crust dotted with serious jalapenos and black-olive slices, and irrationally finished with squiggle of honey, the Tex-Mex slice verges on wonderful. But they should hand out wet-naps due to stickiness. $3.50<br>
                        3. Key Lime Tart at Georgia & Aliou's * Topped with a fresh raspberry and a few slivers of lemon zest, the yellow pastry looks like a beach scene if you squint your eyes. It's every bit as tart and rich as you hoped, made for nibbling rather than biting. $5.50<br>
                        5. Smoked Egg Salad Sandwich at Ellary's Greens * Vegetarians take note: The smoked egg salad sandwich at Ellary's Greens delivers much the same barbecue power as a slice of smoked brisket, with chopped kale adding to the textural terrain. $8<br>
                        6. Avellino Focaccia Sandwich at Casa Toscana * The house-baked focaccia (sometimes known as pizza bianca) is thin and slightly crisp, and on it is piled mozzarella, cherry tomatoes, and fresh basil, making for a simple and delicious sandwich, the way they do it in Italy. $9<br>
                        <br>
                        Agern<br>
                        Agern is the new restaurant from Noma co- founder Claus Meyer and chef Gunnar Gaslason. It is located within Grand Central Station, right next to the Nordic food court that Meyer recently opened. The focus is primarily on Nordic cooking using local American ingredients. There are two tasting menus available * the vegetarian "Field and Forest" ($120) and the meat and fish heavy "Land and Sea" ($145) * as well as a la carte options. Both tasting menus span seven courses, along with a selection of amuse-bouches. (Prices are inclusive of service.)<br>
                        89 E 42nd St New York, NY 10017 (646) 568- 4018<br>
                        <br>
                        Salvation Burger - rustic joint in the Pod 51 hotel<br>
                        Chefs across New York are fostering a vegetarian burger renaissance, and the version April Bloomfield serves at Salvation Burger, her newest restaurant, ranks near the top of the citywide hierarchy. Her kitchen mashes together golden beets, carrots, carrot juice, French lentils, mushrooms, sticky rice, and sweet potato vermicelli. This is all laced with enough warming garam masala to power a geothermal turbine, grilled over wood, and then anointed with cooling yogurt, shredded lettuce, and sweet tomato confit.&lt;&lt;writer goes on to pan this place bigtime, also v. exp (~30 burger) <strong>Desi spots:</strong><br>
                        <br>
                        Founded in 1975 with a name certain to popularize the cuisine to a wider audience, Curry in a Hurry was one of the original anchors of Curry Hill. The international food store Kalustyan's was another. 119 Lexington Ave, (212) 683-0900.<br>
                        Dating to 1996, the amazing Vatan still offers a single enormous vegetarian meal, reflecting an era when the westernmost state of Gujarat provided many of the city's Indian immigrants. The price of the meal is fixed at $32, and includes approximately 25 dishes organized into four courses. It's also all-you-can-eat. 409 3rd Ave, (212) 689-5666.<br>
                        &lt;&lt;just a reg. thaali, avoid&gt;&gt;<br>
                        <br>
                        Bombay Masala (148 W 49th St #2, 212-302-8150) this Times Square standard, successor to Ceylon India Inn, which occupied the space as late as 1968, has a $12.95 lunch buffet considered a good deal.<br>
                        <br>
                        Vegetarian Ham Banh Mi * Vietnamese baguette sandwiches present such a chorus of powerful flavors (pickled veggies, cilantro, jalapenos, doctored mayo) that it's hard to imagine that lack of real meat would make much of a difference. But there's something wonderful about the fake ham used in this banh mi * greasy, salty, and gelatinous that actually boosts the flavor of this excellent sandwich. Find it at: Banh Mi Place, 824 Washington Ave, Brooklyn,</p>
                        <br></p>
                    </div>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "misc_domino", "Misc_Domino", [], """
                <section>
                    <div id="misc_domino">
                        <br>
                        http://www.dominoguru.com/page.xsp? id=index.html<br>
                        <br>
                        LinkedIn - <a href="https://www.linkedin.com/topic/xpages-development">Xpages</a> stuff (incl presentations) & <a href="https://www.linkedin.com/topic/lotus-notes">Notes</a> stuff<br>
                        http://xpages.info/XPagesHome.nsf/Home.xsp<br>
                        https://xomino.com/<br>
                        http://xpages.tv/<br>
                        <a href="http://xpagescheatsheet.com/cheatsheet.nsf/home.xsp">XPages CheatSheet</a> Demo App(Tips & Tricks)<br>
                        XPages <a href="https://www.teamstudio.com/blog/topic/xpages">mobile development</a><br>
                        <a href="http://notesin9.com/">notesin9</a><br>
                        <a href="http://www.lotusguru.com/lotusguru/LGBlog.nsf/d6plinks/Is-There-Really-a-Shortage-of-Lotus-Notes-Developers">LACK of notes developers</a><br>
                        <a href="http://www.slideshare.net/sbasegmez/bp207-download">IBM Connect13 - Meet the Java Application Server You Already Own</a><br>
                        <a href="http://www.intec.co.uk/ibm-connect-2016-review/">ibm Connect 2016 review</a><br>
                        IBM <a href="http://www.ibm.com/blogs/zz/en/">Syndicated feeds</a> (Tons o'links)<br>
                        IBM Connect Sessions & Lotusphere Slides<br>
                        (esp check earlier xpages stuff, eg::<br>
                        BP308 The Journey to Becoming a Social Application Developer (2014)<br>
                        <br>
                        http://www.idonotes.com/IdoNotes/IdoConnect2013.nsf/archive?openview&title=Domino&type=cat&cat=null&tag=Domino<br>
                        https://developer.ibm.com/connect2cloud/<br>
                        <a href="http://heidloff.net/article/04122011020116AMNHE93V.htm">How to create your own Domino XPages Server in the IBM SmartCloud</a><br>
                        <a href="https://www-10.lotus.com/ldd/ddwiki.nsf">IBM Notes and Domino Application Development wiki</a><br>
                        <a href="https://greenhouse.lotus.com/catalog/">IBM Domino biz partner solutions</a><br>
                        <br>
                        XPages links:<br>
                        <br>
                        JSF <a href="http://www.jsftutorials.net/">Tutorials</a><br>
                        JSF Tuts from <a href="http://www.coreservlets.com/JSF-Tutorial/">Core Servlets</a><br>
                        http://openntf.org/<br>
                        http://dojotoolkit.org/<br>
                        <a href="http://www-10.lotus.com/ldd/ddwiki.nsf/dx/Whats_New_in_852_for_XPages">Whats_New in 8.52 for XPages</a><br>
                        <a href="http://www-10.lotus.com/ldd/ddwiki.nsf/dx/Client_Side_JavaScript_Libraries_in_XPages.htm">Client Side</a> JS Libraries in XPages<br>
                        http://www- 10.lotus.com/ldd/ddwiki.nsf/dx/Master_Table_of_Contents_for_XPages_Extensibility_APIs_Developer_Guide <b>IBM <a href="http://publib.boulder.ibm.com/infocenter/domhelp/v8r0/index.jsp?topic=/com.ibm.designer.domino.api.doc/r_wpdr_intro_c.html">XSP & js</a> API ref<br>
                        <a href="http://www-10.lotus.com/ldd/ddwiki.nsf/xsp/.ibmmodres/domino/OpenAttachment/ldd/ddwiki.nsf/01C426ED3170B96A8525776C00278CDC/attach/BP207%20Make%20your%20XPage%20Apps%20%27Pop%27%20with%20CSS%20and%20Themes.pdf">CSS & Themes</a> for XPgs<br>
                        IBM <a href="http://www-12.lotus.com/ldd/doc/oneuidoc/docpublic/index.htm">OneUI</a> Theme<br>
                        <br>
                        https://dojotoolkit.org<br>
                        <a href="https://openntf.org/XSnippets.nsf/snippetsByLanguage.xsp?cat=Java">OpenNTF java Xpages snippets</a><br>
                        <a href="https://github.com/edm00se/AnAppOfIceAndFire">A demo application, implemented in the XPages runtime, with a Domino NoSQL database, for Java HttpServlets and front-end development practices</a><br>
                        <a href="https://github.com/MWLUG/2014-Build-a-bean-workshop">build & deploy a simple, Java-based XPages appl on yr own laptop</a><br>
                        <a href="https://github.com/naveenmaurya/JavaCharts">Some dude (Medhu?) copied mChart!</a><br>
                        <a href="https://github.com/naholyr/json-server-gui">Create a local JSON Server for testing (v.gd!)</a><br>
                        Notes/Domino blogs/personal sites:<br>
                        Mat <a href="http://www.matnewman.com/webs/personal/matblog.nsf/dx/ibm-connect-2016-summary-conference-agenda-published">Newman</a><br>
                        Notes <a href="http://notesspeak.blogspot.com/2016/06/new-directions.html">Speak</a><br>
                        Cool 1-pg Notes <a href="https://quintessens.files.wordpress.com/2011/09/20111003-curriculum-vitae-petrus-kwinten.pdf">resume</a> from <a href="https://quintessens.wordpress.com/">this</a> guy.<br>
                        Domino <a href="http://dominogavin.blogspot.com/search/label/Domino">Gavin</a><br></b>
                    </div><b></b>
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "misc_java", "Misc Java", [], """
                <section>
                    <b></b>
                    <div id="misc_java">
                        <b>Items redacted (Depr?)</b>
<p>
These can be found @ an <a href='https://miketriv.bitbucket.io/index.html'>earlier repo</a><br>
Note:
<ul>
<li>There are many non-Java resources in dev/Java/Functional; incl early links to Scala, F# (TomP!) etc.</li>
<li>The above bkmarks version also contains various stuff redacted from desktop/bookmarks</li>
</ul>
                    </div><!--dev-Java-->
                </section>
""", "");
 TreeDataItm((gfxGetUNID "gfxItm"), "devOther", "dev Other", [], """
                <section>
                    <div id="devOther">

Docker Tutorial: Play with <a href='https://www.javacodegeeks.com/2018/07/docker-tutorial-containers.html'>Containers</a> (Simple Examples)
<br>
		<li>RedHat <a href='https://www.openshift.com/products/online/'>OpenShift</a> | AWS <a href='https://aws.amazon.com/free/'>FreeTier</a> | RackSpace <a href='http://jclouds.apache.org/guides/rackspace/'>hosting</a>
<br>
<span class='mTitle'>Outlook taskitem members/methods</span><br>
https://msdn.microsoft.com/en-us/library/microsoft.office.interop.outlook._taskitem_members.aspx
<br>
<hr>
<span class='mTitle'>JSON</span><br>
<br>http://www.json.org/
<br>http://www.jsoneditoronline.org/
<br>http://jsonlint.com/
<hr>
<span class='mTitle'>CouchDB</span><br>
<br>http://couchdb.apache.org/
<br>Apache CouchDB is open source database software that focuses on ease of use 
and having an architecture that "completely embraces the Web".[2] It has a 
document-oriented NoSQL database architecture and is implemented in the 
concurrency-oriented language Erlang; it uses JSON to store data, JavaScript 
as its query language using MapReduce, and HTTP for an API.[2]
<br>
http://couchdb.apache.org/fauxton-visual-guide/index.html
<hr>
<span class='mTitle'>PDF</span><br>

<br>Java <a href='https://github.com/mitoma/github2pdf/blob/master/src/main/java/in/tombo/github2pdf/PDFGenerator.java'>github 2 pdf</a> using <a href='http://developers.itextpdf.com/content/itext-7-jump-start-tutorial/examples/chapter-1'>itextpdf</a> Lib
<br>
<a href='https://github.com/GitbookIO/gitbook-pdf/blob/master/bin/gitbook-pdf.js'>JavaScript</a> PDF gen lib uses PhantomJS
<hr>
                        <p><br>
                        <b>VBA code snippet</b><br>
                        Selection.Find.Execute FindText:="http:", _Forward:=True, Wrap:=wdFindStop Selection.MoveLeft Unit:=wdCharacter, Count:=1 Selection.TypeParagraph Selection.TypeText Text:="<br>
                        " Selection.MoveRight Unit:=wdCharacter, Count:=15<br>
                        <br>
                        <hr>
                        <span class='mTitle'>Office365</span><br>
                                                <br><b>Working/manipulating MSO Files via REST: (3 links)</b><br>
                        <br>https://xomino.com/2016/08/01/reading-an-excel-file-from-onedrive-using-the-microsoft-graph- api/<br>
                        <br>MSDN <a href="https://msdn.microsoft.com/en-us/office/office365/api/api-catalog">Office365 API</a> Ref<br>
                        <br>Accessing MS Files using the <a href="https://graph.microsoft.io/en-us/graph-explorer">Graph API</a><br></p>
                        <p></p><br>
                    </div>
                </section>
""", "");
TreeDataItm((gfxGetUNID "gfxItm"), "recM2S", "TimeLine", [], """
                <section>
        		<div id="recM2S">
                    <img style="-webkit-user-select: none;margin: auto;cursor: zoom-in;" src="img/m2s_Snapshot.png" width="500">
                </div>
                </section>
""", "");
TreeDataItm((gfxGetUNID "gfxItm"), "recOther", "Amuse", [], """
                <section>
        		<div id="recOther">

<p>
<span class='mTitle'>Anil Agarval Venture Finance</span> -><br>
<img style="-webkit-user-select: none;margin: auto;cursor: zoom-in;" src="https://assets.amuniversal.com/7dbf84506d5101301d7a001dd8b71c47" width="500">
<p>
<hr>
<p>
<span id="zero">
    <img width="600" src="data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAA60AAAE7CAMAAAAB25eaAAADAFBMVEX///8AAADm5ubk5OQsLCww
MDA0NDQ4ODhCQkIpKSkkJCQ/Pz88PDwdHR0hISFRUVEMDAxGRkbOzs5YWFjb29smJibY2NjV1dVO
Tk7h4eEQEBDf399cXFzS0tIUFBNVVVUaGhrLy8tISEjd3d1LS0vIyMgXFxfFxcVgYGBjY2P2063A
wMBqamqTqVR2dnZtbW1wcHAJCQi0tLT9/f5zc3OxsbFlZWWsrKxKSkpnZ2fCwsKRkZGUlJShoaGn
p6eOjo6kpKR6enqJiYm9vb27u7u5ubm2trZ9fX2CgoKurq6pqamenp6WlpaampqLi4ucnJw6AACY
mJj/25CAf3+EhITq6uq2//+Ghob8/PwAAGa4uLjb//+SqFL///0AADr306v00an3+Un//7aUqlSQ
2/+TqlKWrFf//9uYrVkAOpBmtv+UqFju7u74+Pe2ZgBmAADbkDr40646kNsXGgny8vKQOgD/tmYA
Zrb/3Lb6/FAdIAr09kf117H82rKWrVOcsVwQEgWMn1Lmy6eRpVRDTCU7RCD+/vnu0q361q1xgEIh
JxApLhA0PBz+37h3h0b517Ffajbew6KbsVeDlE0vNhc6OgSHmk/b3kb6/Uk2LSL21awmHxZmOgAu
JhzXvZy7pYismHxMViqQfmf527aah27t70xXYzKjj3VANipqeT5kcD3RuJhxYk/l502QoldmkLZR
Rjg6ZrZ8jEtYSzxISA60nISKcmPErY5RXC9xcSCAcFvAwT05MylUUxTLs5NNQTOamy/buJDO0EO0
tjqoqTUAOma2Zjo6ZZBdUUIAOjpGPTAsMR13aVZkYxu22/9mtNu2kGZmOjppW0qQZjqMjStjVULb
2//b2rd+kEdldDfv0KB/gCQ6OmaQttuQkLa1to308mHs3oL5+Ojbtmb/29vr6Wa229uQtra2ttv0
88vd2G46Zmb18H7Jv22vrkzo5MPt7a/u6p1mZpCPhljz9JZmkJDL2Y+xk0Dv7uE6kLbbkGZnZVSa
k2TBwpT/tpCQ29v+ESbLAAFarUlEQVR42uzTf2ubQBgH8Kz1fqjniXNu2UiNlcS0GNogdWmrqTUa
jUmTElIQ8v5fyM6NwaBQ+kcHEZ4Phzw+93jnP98OAAAAAAAAAAAAAAAf5BMA4IhBWgFoC0grAG0B
aQWgLSCtALTFq7R2AABHB9IKQFtAWgFoC0grAG0BaQWgLd5Kq38/POSHvMgDP188LPwsy8IwyEd5
cAhXQRUEwbRYVdPHKgyq1Wr9uI7jaFvO61m8SdZR8vQcRS+75OlpualfojKt0yhZ75J6f3WzXKbX
5WZWJvFLWt7cXY/HptkbX5rmoOfqxqDLGFUpoaqhMmYwojJVQkTFCCGMuy4mA100uxirOpPIcjRK
mCJjhAkmBmUSQkSUSEaSZLHwfLijiHWJYejj/f5u0FVVgzDKXNYMEeL2emafUYQlGTOV6jqlBsGY
UMNQbykhqDlPlhFSZNmyFG5Z3HYcx9Y0R1O4wx3NcTyxROFxT3Q9R2FnX798+7ySbPuH7fBmhEuS
JEuKpnExqilEFfcgrjXfep7Nzs63lu1pnqNpni0KRzS95hqL9LHMuai43WxzTZG5otiOmBFvXPG0
89NhrYlpcbZoiKdiWRImxB0YffPiZnyJkFQqHeHk45z+8bt8v+9/ieofr9un7/H6F07+i87ReDOt
w2FQhMUiKw555me+n90vfH80WizCJK0eiuJQHIIgrIIiy4OH2XodzpJ9Ga+ravM8jVfhNI6et9tt
lG7rpJ7vZpNJEsXzsoyS+Gp7nYp0L5N5nU5EUCcXk15/cmHqpu7q/YGruvotZawJKhaLUYwIwhiL
5GCXEINRnRAithgiySj/iX5xb+bNaVtRFO+iXQJVCGzVkQ0mAsPAAFWRxSIJsYkdDwMdOnyG9vv/
23OfkqZtajdt03aaBxJClt5zMvnp3HvujcwBVp7XVJzkBZkTeK4gczi9rQxGWlkCgmWrhUUMOtTK
eBgwpkWtZ9tWR3JUgRMEyXH0fk/VJBHsS5ZlqKJIaxYI1EIGezCnZMBKFeQQGyUFfADGjJLBoGMi
177KX13dt3EZruML2Wy2oMicLNNFdJusWvjTKUQ24Z3lHm4DHk8AIhXMgktcBgJL1YIBWmlWnMS1
jEXQmKVlwCseBEL+tiKxiTIEM94FTgasqlG09Hqz+djhcIL/iLSmYKRovDn8I0RfpvQldPHxIqvv
iMXrowH7f6R1Nmgks2TamDNSG4PpbDCoPEBix0XnFHuzpOG6l1lj5rsNLw6jTTxedLrD7XZ7PB12
YeTHwSgMlqfJcTRpBcPd8TgKDns/2k2C0b7ZOh/iYXcyHC9aC9zXbDZtu1a0dUu3jJ6qSo7EA1LQ
B2ZFjQeMInjEMWRXUokoKCEANt3BpigKED9cJWiCQBRyhKtMoC0GjUkZiFqq9djqFjVRM8AuUY4J
odyGpdt6TxBVVQDoTrFp6j0dwGPgHFHLy4oiKwBVBv8YhWyV1A8vRifjNJtugFYhfDdX+fzVVChV
cQan8CFDojFBepUiaxBtWWFwlsChPMvNy2C+mj4IoNN0GlsWt8kZ0A6mGZ9ZDCWrAGVCEyeU+Drn
F0iI8TV9gPCyyNOfBc++Iv5au1iYK34UWt8n9XlQnyHz1QeMZ+h9ZryjFEcfQWL/p7Qm7mx2SYAs
UH2ApA4aD40BwB3Mgo49Ws1dN1n50FWEx+4m3g/3Y8S0tdaxuzyetqPxcDM8BetoE4xOo2A0GYLX
YThZbEfx+TTaL87dfbzZHaLWorVcLBbtbr1uF03T1GvQNEsydEskVAWiVEAwhzBV41TorUqoAmf6
KQS3O23sexqoosCW9jz2HI9jhtbkYb5XRfBtGPVFC7QKuJOeAuwOqK5uFSVoqQQ2Sc0dXTIIZoCP
VQTCXiYxA7DARJYNDoEwKVuqdiCL6SoOiUughC/Vdf711ZVHWqcwjiGI+G2I1hLDmkMEzuFKFu9C
Fgve9VzPFBSm2WzuNwcKnjcZQE9blfBkMq1gOszDaDWu8g+LKkXcClsMl+KhQnFCz6zrtt3u9wFr
4aNo63ua+sz4YED/DLpfvii0H01i/7e0zrxLkkynswYGaG0gGq5MG54799aHbeh7K2+a+L47W8fI
WTf77mQ0WZ5a9XpreDgsl8Nl4HfrT2EU7sat5TaYjE777ai1eNo+Lcb7RdBaBpOt64bb436y7HTG
XfuxbZsIg2tly5GAl9YzVCllMBVMlos5oFVUJQMiKUo8zu8eLk2CC0qMPbsWA3QLFLVq0UPSEcuY
TTX7rb7pgExDBJWknjyg0R3DEkCmCp6R9YJlnY4EUnHE4bwCxhQZfMikcUhceVABfFgUyzhlCDEN
JVplbKUZaG10BNyAQbDK0DdZ5rIlXIedzGEBhTJP0lDM9HTrOiWFpbEQXLar3mAVQeMJYWguBi5n
Kyps2jQuluN8zhNLJfw4ozCVp6cHIEdUb9dM267XmzUOsfDfpvWNiv0BqilYv4fp6/TFRv72/mGa
eH4Ux0+7XRxHPvyQwX3uKv3xK7a9ILd/HBT/JWD/17Qmnu8miIJpEKpzN0kQ/Xr+ar5auwSqN3fh
MA1PWx+R8HA03A8P56Ufxf5qMxnuDrvdZOVv4uh8HEdxMBm3glFrEgxP7XGn2xofJ5sgjhetcXc0
OXbr53azb5plw9SdslWGrmFA8AhWcAO2iB7SVqAn9UTwZUBROX1WccuIefFTzYDvhIt5IhGySLT2
B4NIh7RCNO3HblFHII3cllc1pKnEv9orWhLTaaDZ6+kgGaG4hUuIVZGTGYOEKZNNiom5AokoAAEv
zGNieqmUCoAlhahUyeevYx4kZlJ8cQ+F05BFuoeo5w2Ry1YZrTd3X1UPuUgt3TBI8b0K+G5uvrrJ
cJzGZ+lkKVVcgMjupx2Ds9S8zk/ruBzKW0q1lz1LCjx8LLP2aJqPtccORfF/j9YPCH+fU1NQxxC8
9btaofrN5388vrlTxHpceUvue9C+lM9+8deB/b/TOmeG8IxQnc0aUzdpzIAvbCWkrODU9y6ANQqG
B3+18tfbyXKxHx0Df7UO1+vtOfLDwznYLuAKj85+FISTU+u8HAfx4rjonpfhbo/3btlujs8nBMIT
mEy14mOvWAQsRUc0jR4UES8QS/atxhs4BIfMXBIBKySQ58aDSshsYBUsI99ksGLgSsr5QphMEmiF
ZCKFq6sCU1V6wzalaRx4vw7zpnitKJbJYqK8VmVyLoBRFseCTgWMZWEJZwr0lWSQWE3lEJ8pP29i
4tyrfK5PlGUpKuUBNzwm3IzZaOCAkxBgs7shrl/dtSsXC/JI6GIwYm9u7hQ8VWQFLFLOmlrCoJvJ
OUSaZa3e63xFwI34JhOuWKQEKVZ40bBMu16zkVu0lQL3t7Q1peB5USUxfYvrbzDN53Od6otoYrz0
Y3t+lf8ttC+J7DtM/1RI/P+ndZ4gRZ3P5iSv8/nMdenI9VfubOUlrpesPIw4GvorYLuJNtunp+3m
sNmNup3heHQO1sO1F24mo9D348kkiA8IlE/nyS5otY/j8RaYo7DTss1zp98at7qtftPuI2nVHRi3
0EDyTYlMgKdKOMSbswQJoyxi1ytL5BgPK/dngQGqlUEfwQxkSY8pdzXcSqMjqbjQMB/7NQNySS4v
bgCumEsQi3Usw7SVLCrmHZdJWnlOwlXgCu80+CRqGbmprwTOSElTWEup6UQWE53P5fMDI6OAcE4g
ec4qZFGRq5xlOkx2dYFj1wLOr25uuo2dyDglUb1jyvrVXVURVK5QIvkFgCxZ5pjEpjkrneCuXt1v
q1W6kxDG+dSi5kQV3nqxaBbtut1R/o62pgS8hfYlSX2HKYt2k7Hya/LueKvl33732cvjh+vLqSiU
fn1rqb6+TpX2g4mlX/gDef0kaG0A0hn0tJGgWHOZTkEsDGCI6jy5oKwzX4Hci+dvGpen9W6zA5T+
3A+j7aJrdpswmSKExHOobujP6cPfjA6b03m5QdA8nAT7PQLn4fnUtU/LbhfZ7qhv6hBW3S7DZbLI
CoL0SYwvi1RQU2mD92MAUkNyiDBOdO8rTUEm24YiXAFQpyyKpJ+6P5huy6KKWcr1dvsRdRrgj00k
XQXaHFxhlWwlXpQo2i5rWLtsaOTgUgxeQFBZwE5+7Jv4t9+09Xr9ZNg2JKvWfmzChlIIorSYksKC
78r9VW6Nu0A6vCSkq8h2EY0qxCpdw3GiwrhXIKKMtU7lDAeZUlMSVgB7A7mUOUnXsjhNMXKW5qdB
8guCad277Orr6woHfvHGDrqbKm5WFlVoq2WbtVqxtkDO/BdpfRlVpqm/VVQC9ZT5pV6K2/x333/2
58e3P7xypV9OVLVzzyD7vML+IbCfCq0VMpYG8wHC3gdwCnahqLOp5+LYvUzns4vnJaG7hjMcjZZx
tIlQng2C7WHYGo/Gi2jqRa6/263jw+WCuk2w2/i70dhut/bh8vwEi3hxiifLdmuy67YXE9Rx6ijh
oIBStiSYTQYYgoYytQSkEiAVQRmPSBUfpLZEW29w37AEKBhg7akCXU04gkawZgwHA68mgW/LeRy3
H2tlgziFmAJnjNRLMrAI5ifnSSyXyyomVgWZfihzaSSMpHDUqLiDh8H00nioMOcNbxSzLquykipf
mkwCKfDGX1/lugwthL8YXEEQAAy8WVzBpJXmRXiqsDC4epMZN5ryHeSUSfVXN5DWakbGAwvSCr8X
tMrVAmgkWJn+UliMS9X8q1ySGl532NgvwYRXhmtm9awiKmJFu2lzyl+glQh9yVb6raa+ppE7v8Pr
K9n/9rOPMh6Mm3fM1u5pofeI/R2F/QBePx1aoaxojBg0pknygIh4QLg2GrOVv0rcELUdJLCRv4s2
63Xkzv0oikLfvUTeNkzCTXxe7HwI7yryV8EyxA3beDsa7bbD4/CwHEVhtHuCSbzaLVuPbSrTQmCX
TWiWDY+Wmhmcoo66DBVZgB6ziJmyirzlOAALsEJ8ea5WyXm4DIAZQBEXUFrLfGQI2LBR8dsqK9Da
h92pY6J/CQNxL6QTtNLMMK50g1WEJABuOI6u4RP3qyqmp7INM3Y6jftc7vr2+pbGfQ5fKve56+vb
+51EThFjlV535Pi00Rphs4qsAh2FOGM5DhusJploxVOAboDaUucSqevYNbM3oJSO0zA4K0tNyyhk
qimtBGeJBeAsh02LSNnL1/mcidNpIM62tKLLUxBSBqm2jSqOycl/IW99WVbfjF/Gvp70M1FS/MNn
H3v8OLO/eju/HLxm42WJZeNFy+lTovVhkLjzWeMCYxhjNkjmyXwO/QSFo8u8MQ/9yAvX0Tp6Wofb
cI/wFiTPGv56PUPfhLuOn7aR76+hq1ES4yPYHJvHbnvZ6pwDCPH+FCbBqG7WFstWG+2IfXgilt4z
ipIGh0k3VCasBiLhtBcCcDEptDQkssCSDKNz5SHgCGqHBBJkiiwxBWdNYzl4cHWEy7hHN4ebgw1Y
NREvPo2CVXxzVMfQHHzXwCsF2VB0ur9AJSGNmqGULMOAE/XuIY7Wfrxp9evItu3FIQLCwCzlUgEm
FJCC1qdX+YqELwQmslYBkOKA5qLKLTwqmXnHsJ5Q04FQ3ij+RgOVOEIWS2lrVaGOSE3OMJyxMfLJ
YAamqZJipW7+9XUop4XX1HwiVDF3gUcogieeZRfRIaGXOf7P0coIfb6w+ts8FePys5Wkvv7xs39u
fP9d7e1CN9v3JRaB+YcD+4nR2mCeMDVBoKEJGSxSVRjByQXp6XruIhxexdF6E3pzfxUGqMYMDxvI
rOuv49UcnK/Wh138FIbrcOVF6y0yXD88wlbqjgHndgMTOfQXh8da/QhfalyvNS3T1A3dceDSkt0D
fEgJwRUFqpTEUlEV9R3ARSUWgnRVabSpxqMZIBHX4DSvCjgj17zBw7zO8UhSgX19P1paKjOTACYh
nBZygastWFK5bJSLBgwmCDMzkxUOS0mAn2ctDcxY4mSRp1+DI37vMlmOt89BnVMIEnAJD6qUtiZd
rq4qIikeQl4FuoYBT0kmcmE28dSEyAwpGSuxRFTwRhpZyExeWcuvqPe7akGhuJdcJ5aREvxYgqko
UZytfPn6tgZdfWtR0y/KCsM8hNUx4HbrsAIsQ8r+uc7DlNCXVfUXpA7EN/xkhp/9O2OmvF1xnn9P
Yl8o6rzj9dOjdQA/GLgi4vVccDvHjtidTd3LyoXoPjTIFV6tvNlsDnITd30IJuha2oRREPhkHg/3
8TpaRXGI5v9dGO8hxqPRJAgmnea2E6+gVE9P/XbrjPLrYtRpPppIWx0DpFqOZBokkiKMH5EGi4I5
LS3giAZ0kYxge5q7mNRvBL8HLGpUNuXxwfHG6j43WIgc61dSjWZ30TYEyoN5Sn6FMl1JrYqWYxUJ
VsnRe45EtjLBxVqnJMOhYFimHFMuUU9DijBXJSkDbgWeKrLM2MElCtNWbFYlf1/hSHB50CqAH6r8
AtbUGy4UAHDaQCgIuB+pq5HsBMS/AJW2DHUm1us6ngM4AcGtEsBcppDBDNUq1krVXEB9xFNQhKUX
QUuFXIXKTJQ7OBJwRSxsFg1RfsETfjkCfgHVtM9hcZdyo7gwkv7Nca+9qfEU056KlxT2i99axJ8g
rQ0SyMscXhKEdDafzi/YXxDk+p6LJqfB7OKufALa36zdabJ2Z158QGPwYrnbPXlz3BDF6FQahu6D
50ebYdMcu6votNj64aQbt/qIlSPvqY1gzbQfj4vj6VSr2bquW6jRFC0KfmHt0jAgq2mmqoowa8Cq
pjH9FIJcZUvdwEwoYUoBVYEIk7aNXO7B5vBVFtSe5LQW7RqVhUBq2hpl0Q04lCDW0NAybGgcIVkF
S4CLRzux7ogia8XHi9JMAFx2ij1VJJ+X3Cz6FTJp2grbiAkeOcIbBKgznu4gUSVikbGyMFiRM4xb
4AWpBVv0MEFT02E64UEky1uzKJU6RcsmO5i5vDfYKPrNsvuoDYJVce6yo6+v7h2sDewJ3gJrSaSg
W2D1ZeTxKIZR2ipqH97L9Mt/27/f+PuLTNV4I3ExSP0PxrfXbyytav69LPa5vkQcfJq0DqZzlG7c
OZR1nkzd6SzBp+e6tLnoGgbJ/iUBc2HkJdMk2h6W3U4Y7o/j1mEL4wkdxOt4NDlsNuj7j9Zxx16i
NBv6wzA6D1f+ZDWb+p63RGkEEVv3vGg1zaLl1PRi2SCflvXxsxZfR0VqKVFgJwmQMbKJGJ68tMrN
+rzAlJDTgCYruHKC7lfubzdNjqMk1sAUxVrTNA0gzxp/NcgqyCVsUXQ17Z6IJUCrIRJ/8IKhzZKE
KFIgWEGqAiKQSjqO3enqqob7NK2nsraHt6pGH9A8uEzc9Pr1bQMsQiN5IggAAaUCj1YJGhwmBWLk
YMkCSlEIzt3pTqQGJmKSd+q1ulU0VS5TxWxUsAGirDpEc2XeNimXpOtXV9NsFWdZkZU0FZtMK1o1
CCvcbezR0WQ7nMQi4T/D6vuwsvEu/q2oKSkSCqj/4fj2MSU2k/xaYUlgn+X1k6QVbjC1QSCknbMO
xJlLjYbYed6sMWgkQJQam8L6Af5LtG8tO4/tU6u9C0fbYAuCZ/NVvN1uh/4sieLIX09aB9/f7lun
p8UkWgcrL3Yjb6GbbTJDWsN+xwK5DsXCDoSBSqIUj8IAZp+SZBYlMVPNciyWFQBNvXGfFBmSPO0k
Fh2X9dOqkqt0RcpZDepW7EmPtm7ANBYINAqF2bMAUwgqCXKZJu8ZdHuBQl/yi8mHhrQWCIW0+VAW
EajX0cHxyBtlCZMwWJHQyiCIJY6MoqpYucpfz+UMEQky6Wae6bVIO7woxVXYoNAaiXR75kYqx5ET
xeEpUX80EW0IWLLK2v4xNwQ1S4sBVFavId9pnL/KjYA3zpeYtYSHShpvFzjUmHsOtLWIvLVWryFT
/yBan9XV9wJgMUU1+PGz/35820i9YuXhQwQ25fXTo/WB2iES2MCXaeMyHUxZQ9OFiPUSSCtrFPZW
l4bf6nTH7c5kcqy1u3XEtcfJcbldPQUHH1Wd+CnxKYSO4VANd2s3mCxqrWYNjmri+f5l3tEtPP11
vbWom6ZUtnQTYIlaT2RFU5EGM4d4QlaAPUN5aeoFicP7+4BkVmbesYa9ZY93SSXXGJmkvZqhUm0W
ppVjW6zjmGbBm00nEM9ENDUe68hSVQEniCdgA/YFpoSozwIiYCzp7UW/3+73+5BDDf0NkDFS07e1
E/a/37Bb3F5dXfuMVrhMgIc+ZaxU4Ao0NZgiWnmwShNzovQTd2e22zpURuEW4iFxGuM4gwEHnwT7
xFYiJ4TM8zynoSRQVCQuEBICMQkxvQh3vAQPAa/AFe/CWtuFA5QyiEH07LZJmrE9p1/WP6x/e7Ro
HRH+22HPxs/JlFNva/E7TqMDS+G+oHhCWCGlbNiwIhwrfDKzlKDrdDBGfZs4wm7WnhMIsCmsrDJV
e7V62HWT/wStr9aWPqAamQnrUcI4vvn/WZkIWDn3oer0LLAvE1hx9tHRWkHaCk8Eot7GAtKKiXSe
UGz3jVZlidbqEwRzvW5dm/WNHcwHZ8Sy9bqV1E1bd/G1ne6no1Nn3V/3y16l/7SboiS1eZzUZ4/z
7QB14zG8Tr7RTSL4bc/rOph1u6bl+CBPYwgLlmhsx/Q5bUsSThH0aipkVNwkd9Leo4bIlimo8PkH
U7Sd0t66KmukVQgo+kGWmkDDls9FJz+rxzJhhXaSXVWJDIcuq1NEGEwpmuUq9B5Jg8HhEj7ON4Pz
CP0p+LGmJ8uxnS6fBe4JsENKiS3QIlzzdCGfnmbfMTyOR3WfOGVWBqwkFJBTsCGwLGcp2VRpWZmG
ScOut+uBoydlTu85UoxPHE2nE9bIpiFWFAiHuUx6IyZe/+T0T7CAtZkEiayioYfM9N9u1sJ6Pelo
gtZ/jlVefF1W958SqE5u/t9WP3IrXqMc9hWBjXRVnH1ktGJwdcJqL1JTDKSXK/DvLMr9PhLXNbyH
qCtVVp0DOjSn5uMB2WrzehyGQXPmAAxVwOBPG6MpKlFozWKcp1ws9zEKe98cBvbkfDyicoWMeKyX
uko30MPTo226OsQVf2Mu26JcMYBJ8wM9TdGHpCC6VSIjk7ZIe4EsEzbL0lTzelj0C2D1keUlUXai
0cFIIidNoIqsCg5UHWRHSyPzpBfmCEqriLgh2yALtHYVsIaaUaW8qOBnL3rFctnD719eTnd7zAHO
HwfbnqWo2Xg0Kc7G6d2nsp8b5fN5bypM/NBWJr1ZWiTiAlOoHy6TVkCM6whve7k6txGgWw5Nl2xM
cbOZBHutkS2Co63RJJAwS+Eq3FD55GfT5vsEQ+GIZHwgGJbL+Y4WZ+2axXXLbIZhvSaVhLb+67oK
afrLCFi+5er9PwTAL9cXG1HNKZ/J/EVE/LJAHPH6UdFaXnb2yyVMhmjWwGiHCdcnTqX3+31MqXc6
6wYC3eFwh12apuikVs1qEyM21batyjTO41PRYeXfjRpPjHhbS69YXADQAZi+HrajfQPtoadhFa0G
Ew2cag1tfCga/mBdWhQkenkjahGrRlGxKvM72u+FLb+HkNfFi7lD6PSogwgYheCHapIE4gEIbnHK
ITvD1UW3lvZEowuLP+NgTdOieXd6JXg/AJtULSMJtuKya2mSyAil5rjsFeFfKqTxWaCBCTYmLl6D
m65x2gHZvvnUF2Ax/NQO0loeSGyDUnrZVxWFYEAqdqCBdlN2OX8Xx/VZueE1RklWvxADoI+MsB7R
ceIuqjDRHfGsrlFuTA2H2VHNfDbzAIBZIabDSdDKItPnP5EZIJhX8Nu4sEegkx1WZfkf0Pr3dPWD
/bcfOey/dvN/vKK+zilDhX2FV4FrxOtHRGs/vSCia7BaWcA0jCowWIXLH1e1dvsOGrAIi2kPRu1o
2Hxs2oHvKDJtfACG25mVtvD2P6wRTU9b2CWm4nnQ0/Mem6vBKcGi8ahxcgLL6E0HVRcBK6xEBiCC
PwIElaB3hqyxv+qqrAdpAirFAoIQRZA7yadbNB4FT/lcXsBTeayVaJpg6UiP5u2SqAnDJGXQX8GP
rng4J+eItMF6Mj+6yZLBH9yQY4BUUnQ1CaqQnII3o1efDw4sti0aS4Ta+EIZK10ogNx0uq8wZRWW
w5SdVN6vcrAlnlTWpQhrlqYGqiuyXBCpgFY5hstZCCH5TdjL1oOdFW0oraTAPYFklkPod+izfgFZ
sdgwLQp48R3I5Xrf/uRn8zZEN87bwTHbOCRaw1/hUoklRF3O1W0MJNaatiSqTP/At8Szv8mqQDXT
vOU63vy/r6IoEmt/N4H9wOtHQ6u3ZPT7tBA7veCDeSvDYZqYUNwdt9BRbe2mZziEmaCO5v62qtEp
rxE6xUBwZ89HD6P9uuz1G3g0nqZYGT3sz3M0cNYrr7zETmsmikvhdFJnesnsEYhiGo5WB/ZBZe7p
AHFUmc9RBlVcBouiBDwueHvuSag3SCv8u6s5dZJMG8xTDXKJi1ZgByqtifjUOBQQ1Zs1qqpG8nGD
YcH0wxdVJJoYNN2gjQkfJIXXKE7PdmgMcmzXHPaqm8G0g3jBq3QkhKugCGy9n9c/d1cuFIuYkCfp
oqCEdqvwMNElwSIWeIzfKVl8C1pxuis/zZNwWlD6WXVi7qyk3lFWsSKDMEVUzNelREkLlO4+n0vL
MEz8sXcE9Cm0sc4nPvHpioSnK6GH7Njtaoi8tfn3aI22hHhdVwWqmZjIVn9y8xbW9zUxVJDL/EWJ
+LXy8EdCK3JWr4K1XDcW3gLEeSJ3A8LwAmMaB13UKT5Hw4fdej8awVNYw/xqG1Vd12CHhLKVtOfH
w6hSzEGbPa9fTnv7SWt33e7A7oIN2d1lMq464aVd93Wzq1uW5WpIudjbN9B6IXUat5IoQV9BoZBc
TRM14aCcL28ZWhozWBvnl1Z5ebA19m1ogjBRzFWIuoEuaU+vw3cMcjUO9ggPP8UHQbTCxfIpsmbb
gJ5KIrvkzABnUhm0pkRnREE7RNUIHoJW3C8OMaNuMrnlXiyMUbsxOHzxuzaKixpApc9JKCv9+3gu
SCpoxCkficXJ9rhd9hoOi8+soUX9I7wy4IeN6T2RBZvstPKqO/iFBZ3vpM9+urB4Li69ixAmt/Hy
Jz75+Ux4h2eR4dDSg2qtCVrr8qtVpj/+4b6mq6IIXEjdYhk3b2cdxJtL/x/xKn7rj4PWPmoqHnZO
W3KvQ2SsXpG1FnwPP9OqhYR2Mhwezodx5/ww6tUu1fomCMPQUdTmY80kZwj7ZP/Sw/aI5RxiRqSV
YL01aM179cNTn6FxeTXahofAsUO/butdXe+aYgKHGRyFT6VBgh6mLiTRYNGI4zdmtPPLYzG99hUV
f96abruapreK/UEgxTiJI7RXtjTLALC9ZtWv+oawHgNT9HM0vYT8VQW7oiLGerIOj56rxVKENUag
EWODmjigwgK/kH3oe5yufFmDySkqB9OvG8kbqz+Ep1xIn8qVBxmAkVb0arJAG+QTVa7E84Q7b0xZ
rfJ61I0xpQWrSgwiLlPekbQiQyWtNDS9pxS/j4JiQa2e+WR6muJzEGbgywHb94nWpz/xaXSPUmzk
yiXDtP12rdb0g6TQ1tcT1r8bA+fuhF/p5m2twhfIK3zEXMRVrL+dvn4MtKY9SGt5ya1J+x5W30uj
NoricIO7CC8W0+EFA+VDjJgPNtXhcFa7qhYUUnNnfs9p+74JUFDfsczNqFzMFfLFQt4rQ/8643A7
QjLch26fhk0b83KX+6bvo+9qlHxLJZCOQU8vu6ViIt2IvlEN2vapj5BUd5ROH1RJ4SS6waQ26YyK
q5PF+5UAoUz7navDQdgO6/hpdAt2YKOEu7oW90Ep4X2BwDIo7qqarsNUKIuCbUKGY09XqHFMMBPs
wMolejMk9mxYNiJRgFTwCvWlsPESaMqW88XjunxUIL9ZmhaBNz6woM98/ixENyGMFRTDOYZkQ/ol
GCdLMi6xu5TguwBn5zAtB2KZloqXoLSmAOZ78/OZdFP8ANFmi7yUuLsA1lzZ4vsLwmpV120zqNVn
9UCVBa2vVIJ59oquQlhFGli4eXvri7dc+b8sOP1tef0YaAWbwNUre16RstrHiQfeYJcArevx/DGY
1cLr8f56Gl1nIbY5DC+b2qYmdx1kmroV+PD8uo5p2Q8UV2SWrL8stuvGZdICq41dZVo/bmqP7XAy
b/oIgrslN7Rd8GoQT4v7MCnRPiyqis+kGJERxgU0KWyvUB4IywMqT6ZiwFfsdLzFlSVk7h/OPSZs
W1d0e4Nd2xzoDKvNuotJWJcFGFgR3a6BANkFskhHTRM9WvZVsilJ9+2uJmHFaQFmAGvYvqpx8JX0
McZXJbZnIgsvqzyfo5sB38Qr+eLgvjHUaC3E03EmgGBGWzRJWVIadXForjBbldYlFieIDIFlKYUz
haM2pFUsUXDOQpzR/IWORm8MYT5X9PniNEqAflES9vOf+OSn1zKC9zgNyOzg2EGteqkGsqD1dWF9
VVfzd1So9M3bXD95x5++LHh9rZ8Tyevbp1V0F4mr50WgpgtR3kpHYee8DWH8PVweHzfbzeBSD8Ka
79cnx/uLo9rbwXEWWFVMxnFm1R+tvAJGuTnCvWxhNH1yXqPaPOpUzsPxw2XWq/fa8AX4pk1fE9QQ
VSaKKZ2/lFQsKiX1EwAxVOQEzraYX8x4B+g3CltuEjAZxWJl07Uwyc5p1a5r6kDSDoNqAGm1SgiY
Hb4PlDicEjiIt3ElgDW6Bi6ZYrBV7Eaa9B0Vwoo+FDfoJ0CIqY0kq0BRdSgmNrSAEhJYoW/CbM+j
ZuQz+XvNNyVQz4iUmKWE+jImBnJgGAuEZd+lpLW3CGMMvqNJN3iUsfg2gGEcxMLvxQRdVGbClTh7
tmHAA1Au4QWjKVpZ4iaMp8xnP5lby1BcvOPI3GsOZia7Wp/Vaobo4LwqrK/lqxnpFit383bX9+jl
+FzuBa8v5fWt0wq2QKiH3FVAiovMO4HZYvVwHN4P7x/rQTA5noaTMTbhH80C0w16YT08Pow6S0jn
tWnb9WpJ71YvO3YnC9xvob8aNdbHYQN3GGEr4tNwc92GV5s+dNdpi6qwAVDBgmi1yvhkMVic8xPA
8gZAO02nG7aMmLbkloCgrvJep3Rx3HMQAbr0FePcspzerKr3TAS7Gmq6vgOQXatrBnXTKLESo+qY
be2WwHUsLkz8pNWBhwJxaoQqY20ZyspMNivkkpZeztjiu8hnFAGb4lk5X4Drl9xFpWAWqggaLoin
T0Xfxnj1sFxpyaSXiss9U1EvjnYaFmOtn0IsTG1F9vynQlJ0AI7tZ3NlFZcjB5McQwo7y3320+m1
LPqurFlpCv9VfOyiU7/6WkTrS0/wS2H9EANvbrHKN297fY2RfCrzJ8PEq/L6xmkFmjBHCHFlhSmN
T89jJ2exn9cn09a85m/uz9PtddL07XBwCYLmBvujXcYYSz8e+17juKlWm81eEExhZCpCW/E8lcoO
G8SM+6vF/n7aWe+Gx8l2u732MHDKIXQOsYq6j3AukEsImoaEzhJzblhgR+K8nNxIpwcIuUuWU/N1
A64GTsS1F8XG1oaSIg4OOC5r6UGISXffhU/K4lwcN3yykaWWnFIJUTBKz5abJLFJxK5C5bA0V2HM
CroAGStaIFzhdA/xBVio8iqsKUsEjcQw3k0IoBKVXH6hJ3AL6kmCJVFWpisw2lb4HWHFit2lNtj1
NURdmDKM+9BdyW1VwSZT1s9xOJ3aikIXC88EFd8Jta19PlOWqbkiDZZQVxrmPp0rjLOigpzCVbII
B7oIhTdhaL3Q1r8nrFF/dX2LNb95+yt9izUjrhGwr8nr26a1iIIw8FowIkYUjGAYzKFGDI8+d4yw
m5v6JbwOtrO6aVUfZ5frvGbbhnU9H4fjp346jXuuZ5vBw+WwKIN1ZK2L1pqiu96N1mXs+H+C0Xh8
Pjxs7S6tFDpwE7vtcyMIWpBwORqNiwwPdB4KqRXX+uV0uScroDK09Y1KawOt7Peed6jasEWpjg+B
NXtBuLk06Za3kKQCUKS0JiTcgWeqW7I4QQCrI2BX2F8FdYI/5pcs05LWGAd1NPZ+6fin9tK+kGRH
2FFlkZ0KWhM8gz34IV3o25KwBRNOYTgEbsx+saixkbxm766okF/iEcxRm0iWhPc/2vlQ7M+ES4x1
hZGfJ1FC+6l47vOeCacE3YvAXdnmP4sd8MfgN56KaJUkjb+WadfD2aYqasIvMtYXleAPrOa4b5n2
xZuPYk1vsby/U256bmW9ZVqRrxZA7BLaSq9dkWUm9F0XnUa/NR3udaOHHRlO7OJg68L5MAwnNZRu
7lcIllED8eAoXncmrc5pMPbg12MPh5OyFchqY9jxnrATDAyMx/lpcqmbsPjYZon+Qm7oINhjlhgN
mhNSccAq4gt0mb1mm8V0RTiG4VSydBR2scBQe9mfolmDZSG0dhy7tt3OApa7XJaELbgjVFSXHLeE
TFUF1FrSSnJ6m94lhMLRdFyM0IBJiBZUlCmwyhcHGeQSsbHqKMiqXRXWJ17FL3L+DncICznvgp9Q
9GuJYEyExDRGxPA9V7TnfoCCexCjQAJnLMTcfI0sW6uklNLKjSM4P0t6CS52mMEplPec8cK79xRw
xOp+o/D5z+bSYwW6nRXos2KFmpprOX4tDB9Noa0vYP3z9ZdmiBo3PvpIWOWSOAKbi/T1FXnlW9cb
phVimi56dAaXy4SVaaz31MLOwav9uNOYtcPm4Nw5DUcdbgLROk2mp2lnUcx/9rOZAqRzt5y2OvfT
p+N+1Ec5OJPOe/sHDPR43gLVJQbUGJDddWajQ9NPIko0LLgihA84LmlaidkqaOV4nCb23mfRCUtM
zgGGB+5ghmlWDcGujqRUofkB6I29dYiSE7TUsTEpWp2dMSKkm45lqwh/da1rQSbdEiSWJeESQe2y
vwvrlZgejz+HroQSrwbnUcxwTdvggI5EcwSmZ9DQMTXuqphEITkZo0Ei8v2y1quihTM24oqER+Ku
iKRjuDHONxpIK3hFqYlS7LT6y6nAVLgK8aKQVnoTMdcqjnojgmGASVX91Humr2LaBzdBcpP59FhK
AXEMs14LXubThXQbwp4SUk5YEZ6whWUFtdm2WrL+nNYPGevL6pJgtfAxJKx/VW5i+nrA7/ZaOPwc
abxZWtm38fpUVrra87TMP+02VfiVDof5/Dw9Pa3Ho8Hk0pvVw+slHMNZ2Pfymc/mihXMp4xGjRX2
8z/Ve9V5o18o5GCqrZw7/ad+EfQ/LZkKY3u2zrm1PrWVZFwyDfRWZKPK7X4jKzB1laVXkMImqwF9
JJV0+0p2peDNLU1WYTHqipaPYlS5A8y9t3gAg8luYPrVIJht5/Mq91J0UFkqGTTP0kMMQEvEvITv
+ayaBphSjF3jIg8lpNT0JJA07CAIEFUzY44zHKafiRqYVRBuqzpMkfE7LugwK8qdQr4c4qIsaMVi
qxVn/D4mA1bCGR+uFq16jKjyaBhxqi0ewrkjfAtamZ7iBEvYGqmsuDO+ocsJ8XBpvTNLavUyOizx
gvniVKFDItrOjQMEEpNtDUVhNFybf1Fl+pCpvSKsKidFbz62tWc3J4P1irw+v429VVrTEFfmqjiP
Jk6K5VVjBKkcBI8Y9zyvy2uMpNfsql/DxHN1sz+hz+jlPvnZwrJzHS7G23IfI6wbyw3HFbCOHg6T
4OWSDdzFmIOoxUq/j8n2U9PSYkkdKHWTiqHDxa8JXKOdDQ2VhkPcBpuuSueDcCqFXqHRBE8IaA1c
a3HHYRE917zy3qQ5GA1U2/aDx3DTtnXThjvKAJ2090NyupYb+Gi6UlRpx6BNilSxbMsWSDyZFVUt
hLNAMnBgsaL+I6qVCCqxTBHFpIN2rm1IZPyOoCAwruE33cnAk+zHORuAS9RdIJsAqmyOKhvk71uU
ctlGzUbI4i78hbIJauungGcK5kNBqzi6Bs1NEFhBMjdWi4fza/PcWfVZAVx2Kc8JfuL1xGSeKAAY
uo8q2ywQ2vpqyvoXwprmX/X3bj7Cxe7r+B/K6xulldqaZhAspsXILIZvzqPT9mKGx+Z8j9ZOYzSc
hJN27WH4gJJT4E/WRWSo3q5ehWu3hfrUYnmompw566fLBWxhD15bDR5gElb/JTz+rcoYz7lhsYd2
XeargMR1ORJgiKk7mcZDLMMMdN9Quk6X2a169Ipnk0JpAzdF5i5rmGRFF8fue/vANKGkll4K4L6f
hLaqglaXT2+ZLlg3NIBq6RjXRinZ4tiPmF6/Ez58fKWiwBV7nrH4q9m+Hf9Ugl3MFDU3cvOSRFag
dPu+1k6ScVGc5XaLDWQCFspMoJlKnBUM30miGZTljGpCm2NSeBcnpaw6gTGRb6oQxGR09Ax8Pour
2D5YRL+cQhdeR1SL34FY976D7SgXrdVFj4ljWnHFuXMbXhiLtkrHrD0+bkMnovVDLfg1VjMB/v/b
Nx/n6jN7jeT1Ja5/mm14m7SmgasHWovcoT5fILve8dA63t/Xw565Pawbh2PVnxy3kmZfJpPBbrxK
ZzLFXTPcHk6rRjGNkZ2it36ohiu0aPvIgjO5PAS60mph+G7awQDLeLnYr9AQqobVtoUirgmPhSMO
4JKMKcI4S1Wll8lFAoZOjY4MFHQl9XGxPHEMA59UVPBG2tn7KcElX4NzqVdt12ynHc7DWeiUHMtx
uyU0amD35QSepncZeWMpahePBtBkMBpug9yJzUO5I3AilrTqNYclYyghgIVkRiYlgk02pG470Lgz
IrVT7Pxkp/PFuRGnUEsU4ej+SHqJO9o8UlhBU+wq4WUErgmBLTQV9wfP7wgpslVSiS+0XoEuN31h
B4c5LG4VxOKQrUlU0xGA81nYPaLo44M7IlOmUa5Dy/u6nc96gtZXU9Y/BcG5W6z/z1nz/8hi9pp+
XV6j97E3SSsKwUgxAVyxwLSTTZh0pbHAFi8z36wOz6P5rN2sVv22xi3CNL92bfW95cSVZbWzLFa8
HMJoRL+tYItmzmKFR+dzmQIMF4sptkTcYZ69fD8ZwXQMY9R0fA7D2ra+qddMp2oHFuJiScyO0e8K
ZF27XYOTF71SEzlnsrZIj9m2wWg5gmAdwPKOOFHccnHV1M12YNdqVd8PNk14rkx4hKGmXY1bFfMN
gHksp3lKhjhWrEFLRuQHZE2YTmBFIl7gM2nqgYt2MLkDqxIyzKiMixN84p4YiqUes04kafyZd4Vc
pZZk/MuUNaoDQ4xJJF5AmZQL5WVVxhNEjR/cSVxga4guRMonYl0uYipyVrAYHRQymkeH4qJkDF7v
QHBC0xJMfmmzYuFaEtV0/lyq1fbr98fNZRbRGv0tvi6sTx9lxvrna4DfsJl7TV6fg+G3SGsfWtqH
ugLWPBasSLD599F4ua/XNuvODDZ5wDAL0W+lNcGwH1uLNXJEjLC08hnstoBPpKmN+0OlyKJSTmy8
gFy1vBueRuvWw6A1HHTgYjyB3uM9WkD39V6zifgWqVatZMk0GWpwLbDn4gcQOBG7WoBOCSvFDto2
uqnC5kuyWegVO7XoK2+xscww8G1oa485dR2aDBzhvhCuJ00GnoisQSopLekQV14NUkSJhi0WqCRn
/jiBo1gObgQF9OI/H7yVpOILjLDZKct8CK5BgsoYFCUwTAbqdO9SN6mgjKHpRMQzW51iLr2c4UYC
dkcTBW5jLIy+Ed8igKY4TKQYwOEXmaXxgic8+4zAmbHx51IcUc8mNeAuatIJHsGLqLKFpCIS8cPL
5GEwCQWt1NRXYCWrORf/98Wbj3t9X1gRI3l9Fdc3SCvgLNPRL47WxDITptFXy9ZM1+xqD6WmrqlW
T9hR4dCGv7Crzw6VVaWFzb/xN7f8/Ccz5Z3HDSfopsBzgPp0rsjnAsHYig1bvoSXYasznZwn2DN8
fB4Pw8dRWHVNzsvVt5eZI6PlqbEWDL9vYFbpIAZWsAgCnpNX3BhJqCI7PFZSEzmvSg9FsCiuLigf
+34PkCKybtd6epeC7CYVkyYH2gijvZyquoV7GnAuGXBMMRclkpRAWoNxV+4ailxXd1xkneRLmJ3+
aAPkZXzhXngEIudo721a85VVPr3QxQ4R4EmUrRKCc6nXgKmrMDJgEmYFF8DTHiWxiktfMvrO5BE4
RtqaErRG4hq9LCdw3gujE0Zf4VfO0mgYubCIuyg9y8yuMVnfttG+GUyGx2PzButlMVjAGglrZIj4
ws3HvzioUPgLeX1ZGn6DtEIaPQhsGqJYIK7rRn/RGTYD2wlql+vG0v1as7m9HIe1+ujcqkCKK41T
T3cV1ftkptholGkMzuHhUUUYWTCfSMzNeUuI9Plh12kd5rPJ/fW+ud0025u6a7oGDEj3Fwy8BhwH
FXmr4dgOkOmqooOIVqm16i/bGFFnugqCDfxlQt5lHi9HWxSXW8P0Ldc0HcefNWvkXNe470sJUbNw
GatYrq7bNpBN0kthKNSj6I8eUPKVEShLQFdKGrAwQrDAW2Q6inZIAj3gC2QLQwUj3RhhiceTxNbB
29KpxOsFYTQPsoNrbvvYGrx4klNkkhJNReWEOoNwMYjHMTgiCn2N/BBRrekugj666T2TVkjsXVLK
3rEALBzOgJ09Xc7niwP5qIbf3gT1I47l99iOaH2prB8y1vz/eRT8s9vbH/9nnumI33QHXMnra8nr
m6MVkSxoRdbqPavrcr9u3W9D+E6vw9NuYFdnw0cInBP2LjuAzDLUojG9zJtBP1NYLvpANJf7fObz
uVwOvBZps0jTL9wvICFutPb79bjVWI/as+asCWd91dfZNA2C7RWFLNuulUQ8irKQ6zerZtclWSXY
kiyj7aUbXdIqvMQQXwNlXhrZESujSXRFUcqwzQATKBuMoARmCX0fXdFQZNKY3LIibDiO5pgGHuia
Jd3V6Wbg+Kno5CAiFZtLAd9kt2vCZRWlnxCzBJjBFwFM0HqE4JciC1EV0HA71Tg0c45K04MtA1aS
HUmxOyjT01XeqPQMknds2Z1lzJpAAIzflYXpRPQA0ap53u6FnohoxAdRMKddaWYSOS1xpzTjB6XX
Ufw8IpaX+Cuo7bBt1uqwhD5uIlo/8WrfJlfB//vo5j+8fnUbrd//sw/4we3td1+56cu86T+zvoIf
qfoarhRWnLw5Wjnh5rF9A1Hk6WpwPtSqPcc+D3bDyX0TFojxQ80MB4PxHnt5s/60bz3MRo1dv4gH
5D7Pf4bPf/rzuQysEbRaeH0YjlmzomivTqMONj5Ey3Y6D+toytT0UtLy/WqIVo2pWbajof/BPUOD
6rZuuparOw501dFdc5gu7LtGkpCCKuito4vDWiWtrlXxVvcOjBSW6duBHVSbkFYb93RL4Bt3FvtP
dNHT1bqGabHBy4oxJ3DYImVNGOSIQ7EDIZSNrMBUoWGsEEFIyWaKn0IW8RgJJ4xjRfoZB3qWxFg5
rnfQXj7ULElkt7JmbjHagJH8Rh1DNwLfzwBBRrESj0GpsIqLUIEaK4SXCgocWSEmpnwATU38ou5G
h7JiCo2kl44rsQ+kJqYeFNEVikvI422zXds+3k+ugta/BWvkCs7RSvvpm//s+unth/X1v3mPb//1
DT+lgD7f8N+jVdSGpdzfiYZx8tZojQ4rLMrBwnk4DS+HZuDXw+HDeLKtHdfLFXo4ur9bYja9gwO9
4tbTlIdmbXgF7GH1yU9+5SvYJigP0DnXLrLgPjjlzsJPy91hesYhJDuN8RRmKB1WJUS4FoJTqiX8
9o7vlxSgk9T9ap02X8d0TSir7Tt2K108u5pFr30SgTAqTzoTXGSjetUrLua6D4uT49tmtVat0+Rv
lRg2c7KdnVxF1kuugvzYNjSlq1vcd7wU9UejA2vgLjyYXFZLyJrlmyoUj2zSdy8TV8IKOEmo9BzI
0liMW9m45T3ev5PG2E9tedi2oW/3p/1qVUYaUJ7JKUotMIsQjPMZGL1ClWO0VLLEBQRxI11LqRiY
JZhiOI5nRPc9FlQWIs+7sfnLod9olhCG5CwHgqDVKirpTnM2OT0MtzdYL2EVrBLW4L/QuPkSnvPX
Ar1f3t7+/G/e5Zu3t9/66ys+3PBfpJVOiXfAFetv4kp1fVu0QgLFAm3iUn90nM4u1cDvPY5aD83Z
uHG6+O3J5FxePwyu2zFEbYc9+Lf7Tmu1KuY+y1+afxDYNWLFzRK9Cvo/fbiDO0+N6b6z301H51EH
G4JPB4Mty0tov7R1bvVrsK6KgmaXtCoOirrQR8Cq2zAgGTjdF8ob8OfqnHgTOyXqOOHIXakNz8Wj
WTNN0/Ud2ITDemB2deS14ojKHHGXFYANYvFMuiF8xg7c74ocpzQypOXxAPDJ6TVcdG0ktSnSSpIV
0ZhJERJqqYhDhWsJrEt0P1mgJiW8v5J9Zr8a9TS0V5FNoPd8MFPvo8Ov8hlEUJ1i3sq5d6ii6oI0
CR8p0Eo7/2dSCRL6vOA7JKbQ3cjfFO0yzMoWxwlFYUmTGQezdsW3Od11zWp1OBqf5oLWFykraBWw
8mBx/2kP/w9vb7/xIST+52jl+h/QypVCSe0Vdf3Es7q+KVrT3PZT7M7CmBimg/N8u8WYDTp402lY
u9edZmc09dZPld2l9hiaARo42B9xVeC96ePP5/jPgXNq6wJeiX6n8QS7f2t/wKDcaDpG+Nwa8XDM
w8fBY1tV6WKSYRHk5KisB4HYOtEyayEE3ITVoQRkUcU17/tw9Jvo3dDwKzqphg6LkwZWuqZXboQW
TIcgGYaLei0IfNwR0Sa0hqxGhkZNYg6Mmhbg1x1E2ZKYnGU4G1Wipeg4rnBTOPZWg5zGafMlF1lR
nEVkjCUOp6wAV9E1Qf9ItVCSovQKT5RsXmEAKSOhqLTmvkxU30UWwRQW892o6yMMjVB7hMSizMVF
SsEsAOWrsQ1Ext+RdnIqxBcSLnilvUtMzhlaNqkiFE9JMrIKpK2mXh+MplPRb30BK1klrDE0NW7+
w+tnhPXF+jdo/SZp/Q8uH7jmc3/aVuKvc1cy+6ZozacBLFDjBVSInh4mA1/370fH7XRwuT/MBiuv
3yh+dnC6nqfr9ek690bzRrmQIeX5Yh6cFzLosJJe0czpr7B/9mK1bkFe92PI6xjgjs7nw/RwejzO
2rYmQyeTSMEMC7b8MDTVGGhFQ7cZVNu2H/J4aY7jmINyeWBwJyYex5G7oqmSymYrD1xqzpe7mqGi
JMWNiW1Umky9a8DmT0yT9BjrTUcDjzJi6BJaraBVRy6sUp04Co5TNI267L4iqqTfKWkpCQopseIC
ipQvwErPMFs2QJXEwOhn+11Li9995nMJSQAJvLUu7MqqEh1D/blLG8GqSdk/sppVIK9MPlloJswi
a+V6R/bjYihPHAf9eb+KCFoeih3DQqxD003FiJptYs7pGc7mGOiqXp/MRydB6yvF4FwcUeHNf3r9
7Vz1F7di/ea5pBQtgvkBya+/vOEDwP/JdY8XgJ68UmsSuL4hWovADMAVcc7Oa3ExOtbhYX9qjMxZ
fbJeLtHhaXRGc8vfHtfFxa61a3Ra64ooIKNrk8kx2/XE0SfK/KrAyL5ao6yEQ9a1HvbYMLzReZqe
Hh4eRg/D4TFsbnRuz4KGaELWYfQ17NDEvI29ad7P0IYxHbw6aIUSDrz+VUVJWBKHchUFIUMMo7Px
WvEaAW13tEBg+BzRoKsZeFLeU02CiIfxI2RMFeBqmJ1TfQv9XMg4gJYJj6QgRlbADS+5qspclTOq
7Gti0eCE7++iOjDupApaOQgrO66DaJThK+u0qT+2ZrOUUxZzU7inGG+l+krcOob7LcUAsBiyR9E7
lowTTConoWQMHkW27B1xRBZfiJIJ/jvOz8Xf8weWRWmLDgwkzUAXFmbVCVwH7361yWQ4n0S0vlRW
/LkmsBPKzX94ka3vvLz2tx+qTlGsHK3v/nm4+9UXN/yXaBVD6vm/wPXFfhJviFavQBcTiStCWr3W
9NpsX8eV9chR5e24s1+s9vuJ09at0xPAREm4TypzCJ4xxp7J5Fn8Jeqc5KngtmWljI/lEshir/51
azzqTMfT8X4wH4ynk8F8W6+ahlPqSpJTrdVmphHMTdcNNpt2ENR7fi+o9tB39YPZqNyoqlg8+GoS
tCYVwMmZco6/VryWw0KV2JgfJkV8yYYOjBVqbzLmNvp7SyPmGsTQRZVJt+q+beCh4DcmQuWum5Ro
2scLuF1FJiQxdkwTvJIbqeESa8JkV9hyRZAsGa5IjJG3gkpWm4gqrRHiTASv4Bu4U1uzktqVmd9G
x3Sls0NBm0pVWWHmIBBKSHRe3EX3EYorYclZRtS8UnRyIbcMB8R7AOMBPHNUnk6qcEIjNq+ProOj
qDL9bVhlHPn05j++fvS32PoZMX2Glt9nfofmDn6Km7+i9cMN/z1auQ7PwfBzNPwS17dFK6JZwgrE
yv3xaHg/uB722C3CtNq2HY73ncP2CmfbdnJYwmqHilEuj0owjcU57hWBJ/A4EgA/PzAWFWHPQzu0
gb1eFqvletEHt6tGa7QdjqHLg+GkCSJ9tFPa9brdHNbMKg8WXA30thnUAttuw/DrlMxaozwyoaUl
oKHJPHIkuYQ4Us9ilXLLhkwaUErNcKG5mDvf3lcpvhKukMwVhnRU3aXcWnZJdfGp2xjtAfT8osfC
UuNkiH5GR0sCR7LJ1DFBQGnpBRNyNoaPbFKUkSGtaNHSdawwnsYj6f4nowxko5oS8ANw7EsJ21JS
V2Hnj2xOnF9AIymoVU2dUS1eg0Ezcuko7BXto4Q47paEJi6PuRNnsExsaYeki5E/nHgUTtkwVjnu
YOjhbI7/t4jWl7Dmrf9GGMxWDLl8+df2J5Z//DcJJK0vbvjv0Mr1B/bO5beNtQzjTeu5pONkGI+T
TMmkU0/G9Vj2sV3ja+6O7cS5EzVVqtCzISIE2iKkFpC6KK16kXpRhU6PzgY2bCrRRZFYsWCPEBtY
ARJig8R/wJ7neScllHBJgXJTv6TJxE7s5Jz88ryX53u/qT/D9Wgw/D9DazSnUEyDE9BGnp7Ruzg9
3cSWFIhcc6ODwBcGh9XljoxvSncnMHUPXZuxFMNgiHI6NcFHiFYKrzidDiNPMe8QvR8MjsBXdXi2
Dk5Yn8YpddOTGLsWwsRQwyChWmFxc7Jlg86sKxWmYq3mZbPcp9Ncb6dXHUS3PqTV0YAbVBSvjEah
M8HEUg0CSaHVAA2nnS3m2pPUzhi9Edn2xIwFE6IPbz/MTQHeWbbtwo0sIxWRz2qeiYxSA0LMRPFA
McAJBuRcGzZhhR3oKRUPbMoWOtgRDGSJvhOX8hQ441eBVqkaMd4dBFCSY6rkWY2bgQpaaSNm+wdR
ve+yQ2wFymDsHFAHs0xBz52TYpaMWtIRKceAqfRz2IkFwriSJBZxML9IUmMm04YM1LCwrelia3s7
ovUorNvvoMB00L456KhygcE3q7ooQb0trV98B7SeKOFv1d9W1/8ZWtG5ScpOOYTBiYlcfbW+sroG
j2Cvt35xcaPNLeWpNk6DTI+MZKrYADcyfuoSz2FB+CwRNEUWPdtorBOdAQyGc+k2z+nAfCfoKuSW
97Z5/NXS9OT6VMvjcH23VYRymi3XRkHW9VDhDc1sM4t5p2HTDUsrGWxIoy84oJ9Q5wt1BP1RRp2t
THlepgdKAwYSphc6GK3mUzQ1vV/zlhZauko3v2n7jdAKEAkjnLd0lLdYg6aemtK+kTHCXqADXTEd
MndVsAApUQI2zEBjFnRUJu0bnqu7diCDo4yAnVORumiTOBY/hqZKswetXQNDFqVShDsQIDt2HhHL
xaxpxPBkHAjDM7WQ7oJWhN54EzdtU+XXMG3F10FaETdDvaNNBvzzIdct67RCCwhP1dN9t1hYb0Ve
pqOwVt/43/8OaAV+sr4RVZX+pL3z1rTyrn/5wpwM62/j+j9Ca5rOwRQVMo1TqjYuzkJLq6tbLfRc
VmZhTt9YrKba3W40xYVlqKS0qpgL4QtHGEPTYszZpmITpsMCb9jM6UzAI9Hhsc3luaUuw2MeYVdd
W5vv5VHI9ZUhw/M1NEJdAGCYtgfVqTTDrGmGteZWLpUp+ig2wUlIhy+pJbbY6ck9nkYnN+1F1aIY
NbaFLUCYsa0TRMfqt/Cw+Bpw6BPYmu9j/2ozazo0GUOKaZAirTx0GZVloBwHiwAV+gfJYg8Tg0lx
yRvxdDHuKlCHhA80ULIeHkKBVOoqhU6qSYCRe+/EfgiUY2y64LvDA4OtiOJ+xc9XEAWHvaYRh0bS
/6sFnqOehh4DcWnp8g8JnhMAs6sjvdfqhi99HnmeaMo43kKIpYGrQo0DRCm9dem3HoU18a5gFVpl
LXAJrYLoocPwc/8VtJ7AePD1v4qrFIZP/Nesv02rMJdmt7Qz3atMcQrTIqxK81uzC5mRXGE6Rw8h
GjyjYtwfTp45eenUaDJJM+wwEJXpMEQed9FnzKuRBM+XzLR54hw35+QQE3dRftpZ7u7AKDG9MV/x
XR0lm0rTQ9bleY5mZG07tJtwPEBlbRyblkm0Q0NHEAtKNbr5GwFbqDQGUO8KmU4PKSE7Iqo9v7mA
p+rO63LiohM2LBWhrt9wQKqOjrGJFm7W90ClBVp5VqRpcayExq3wPtQM+S19EzLqCLBWamGzociu
1UgBNd2HtqImq8g50HbR4PMiiWWyy41wMnJCYlWCCVrxgWyUpYi+3h8AN8j8VsvX8z3X0VDJYuhr
eQVLkZHECovSitSeIfCc2EZaeWJsddrDBR9mUFjlq2TXioJyFvNnM1vcXu8JrUdgHTvqYHo3eSto
JcGHHdivAr3/DlppQpz4K5Vhiuv/Cq1jCYik6CGmCC/N1NdWpleWVtc69e3ZXn0sVV7ppjBqLwVe
R8ZHIa9JBsJnxBTMbJWgjgFcUMo1jBuBMHpB4rXosFDMNmwXWW9mLD3R4UTT8szGas+14kOG08rn
YSX0Ye9RqIFm2GSvFd3+prmSWzJVnuLogC85rVXDUoGHVFPV2dzSet5rOLWwtdSGsGbqpUBh1moh
lLQM4ApEkapSswMxRxhxp2jjHiuEi1GGgss81KgMFQe4LC4BNN2rhcWSDWb6KZmovarxEN9vjMvn
CAvf1DQ5/CNQY6AUuMrmV0bCPOsGEMeAG75YVV0wSMWl1KpGYXLqouvl847GWd4c5mSZWUuh/UI2
0klojrtYThY9FqcEBnszYx1kDiCyKhktnxffMCiHybpZWmxNrgutfwbryKfe2bEZxPHLR2nt++Pd
/zXaeuIyN9D9VVz/Z7SVsKH/wgEv1e4CxpBubtRXa+7qbKtQQAa6kB7DyC3sfOtwXxwbNiPjMPEP
j2BBVLlAKK+prHJrWvwSgJnU8oHJNMWbEKd5ziT6OuUK3EDhZmu7SS8i/AyM6hpeECdatOrb9Nkr
GhyHAds0cY1CyAiTUIHKeMyEqxEnzPI7y2SWZl16k1RA6rgwGsfZyLEdm3vps7aJOrPrG1q40TT9
bHV6vtaA3d82iX8cngs8lcZUFehyY10Au2LT1PqxJI9VLQ4tZ8gNpDwTlasG0BKuTZqepMIU4cqG
Sz/EG1mp+BX1ptqPpDSqCinBxY3ZeZgk2eYllTHwXuH5z/24gWINXpkuE3A+XDTbn4fPcefcAIvL
Ua8osjCTdgDuxwvlCdSZJg86OG/AynJw4cQ7Wp9/w8p0JBL+2lvmrVwE/F2sa2y7/hVc/3ci4RTb
rQmxMnV2uuX2dH1+cj5052eLxZny8nQ5MTqSWVheRscUPkP8jMkE5HV0fJROQ37VMBFOIipOAl68
kH6aERNjNFuQV2njYu4aPbQjJGuivbQ8vVJTNZSTcESOmHtVunORcjooBjVM5Jh2w1D9yPRLQ5Pu
y4gXC1gr7H1S6OCjr8KMgd7uDKY3OWjiAFGD+2RNFI3YsWk6cZiD3SbNFnYjbs2WVyenkBBPtwCq
6/txNohoe3QdvAMucZ/T/hu6hRnnCvLQaIqT6nt4cplBypNgOfXYYKmK9WGWoiiuVDpoq1iSNJ8n
TCGuBt82klKxKxE8tzS5trgdMvumitLkb/oBzVf4efrjtEyw1ETqATtD67On4zHOUoPnX7bpgFkW
ndjNkQFvQ4E7U0bZPWPbpYpQeSCtr2Ht9vWdP/HO1mdFXA9pPUxW5d7j14Tf/cJ5P+bfwPX4R1Bi
/d1P4XpH2po4mHbIFk55c2b94nxhcXVzfrq3ubEAujq5haXe1vJ0NZXmzwlL8Oip0VHGwXgBpiN4
w18Mcsrb8AGasGJxmhBtFYVl7fj1M6GeVV1HswXVpF7PUAKXZneZToYiLos+sCBC7RqsBcfZMSWu
PJlZ+qQUtUhgVcMuVtYv9go2VNUHr9FeneJiXofPOKAlyoe/sJYNXd/xYDOuTrR3Mumx3HqNfwcc
0/CRyarxWt4LtBgfD+4qcWBYtbwOWqOTbXiwB/fNkFu6M8QsFdPImqEAVrDF5qdUhYmtyj4TmGNF
2bc1WppoBQbq2Cu8uTlfAPrSEMLwREenq5Lsi6yKWz+SaYnC5YA5jDAFpgT2HNZZCaqhqmz5wAqJ
OGO73N5ueNmoJny464awjr0DJ/+b4ko2D2klinwnd/Lq0Pt7lFa549+2zvf15V7jOop1SOvbdXCO
Sevh+lfSCuIIGswRdDJVl+fquSnMDdleN91ShjMgdpZWVjdg+213MO0Qvwinzpw6A2kVbwTApDYn
GSJj4Q1UFdUlIDHCZDgHajmsGDUgUkpsxfuUa68WapoS2NlKgfGqRW3FK2nII5WDX99nlMriji5l
Xg0kG2JoUjTiyqgUkoSbkXVacd9CGZdMm2ap2q3m9YDdIMdq2IFdcG3PswwzO5XDt5iaWMgGhqdr
4Np0AGJcDVyPSXEcFqqa4ygxXXfzLtUOCxUmH8JrKGAJeKoW3MZQcZVRazTASbz44jBmqQmXisri
sjj3VV129kjVOOZktzfWF5tZW42zQoWlwejsoKyE1S8LIn0epMoM0oODIaOZiHxPYKmv4imWg52B
tBxDnXMNz6wVK0LrobIiR0HS+k6nBtPs+/3XKWcEpzh/5eKwG/ulv0gr73iXeetRDCTu+0viehxa
P/xQ3ly+fv0yrnh99DPIKl4+lHU5Wg8fPvzwX0TrAWR0NcDLlOvOwMnUsp181naay+mEZJ/tmXJn
dmmCZ1JBPE+dwg/Kv0zD3IBDfR2XNBUgQnmlrJQhqdzt2s7hcfGFMDlJb0cmLNLjWC7PFFT0NxrN
gq+bOtVKJQ6KDkeDbdo8zIJdVEAIjmSTq0bXjgpU8U+ItSyD/Rm4KlD9BbSWj6+0skuYg7Htmdx2
U0OMiwYRbJNOPB6stiHtEwvbNsPlhqH7PiyAgB+e+JrOJyvC8gh4DAOaHWoAUBnCikN+DfRrQIZG
n6PDMjaS2sgHiNIPrYpAR9qz4IwYR8MSERObcaStzDYh0Va4tYLCGP8+EFCE0gy8Ub46rfSLH2NA
1JQazebPwIDoKeeBU1oFWbDKzJgPThlmh0lRpPhmmdlFoZWwvlZWdlqNE+90Rd78Wg27W/8opVi/
WfjOoV8fV79e+Oyf+4SP3sGHI8DvaGHKTVxw/Ut9nGPTen2kmzp1/cPP8OO/XNC6/OFnAPTl1yor
7/5VtL62MoGtnVyuO7VdKeRlF8zidCc9xr/PmaXOxExrOs0fE8yNjw8DWPCaBKykFcdsyOcN40wl
xsC0S+ACC4VggBq9phkGR2ksQuFcdXrdi53W7PymCbsSfUJUJLZOLdMDrYFP/6/PXTd4MXQLqIrT
ME6vPvExxNGP2NWzPSSbYdbzgoaTn8lxgJkNSN2m7ZkEH+EuAC21OXWq4JF+jZG1HwTwEfvxBpG2
kDIXi80AIMPqlM3qMfRdFSChmq6Dp8albNzB/ZauAHKAAjYPQlZ6FdnCIbwxuBQppjQSankPGnkO
n8F4urS4fdHhgT90XigIC+BVhrdZ5lKgGcNUVSDn+ArG1EIr35B2MItwWkLjQcE18nLQagWdZohR
EVr/tHfzzuLgoxtuuH785i0Ca0TnUVf/kTvePa2MhRN/rTB8vCAYLJ6ZdVrlS5cvfwbi+ReZfvjw
+rXRM5cu3bxOVi+TWK5/mZdphO0WIrRQ7+E8mRrcurrmzSx0E4hrJ5Zt37T0AgpO46PwMA3jx8RZ
+ngdh7JCmIfHRxLUVihtKsVElnUmacf+0fEPWxOS4pQobkJKT7BFrdo2JMXvrVYsldWVGKuriELR
bvUCxKh+gEjVQDSsaOy4GlHcq0NfDZ0HWSka7kerFFYGkMZKsGObPTmgPT3FU13DEh5JujgNZpJT
uCM3l4+DOJ1RdYN6rtLJC9ejZRZt+IgNoqyi4WobNOEzPlVCR2+Y6mkZ+CJfCmmnm5/r9XS1yEiB
0Fd2zmoyMZGaC3+Wyv4wz0W2XTuP74RFbfqcNNmq4EC3pQxMI/AAJ8BIpSo67TUa+CL75ThKQk56
JrnRsOMDZmNRbZln4US0HpaDx7D/PHni3a+faX19P/n9n9zwC9yg/e5P4tufM14+uo7eIcNf3tX6
DAzD7FscBsNvSSsIvbZsfnqo2QGul4/CGkXKoxjFHeJQ4+21hRQbntfB9QGy/yytIyKDZDbdbpfr
c+uLvbXtZr5QWZvcmMa80i2PKqbFC+2lbgZF4XH8nPgZz6CMlkxK8wbV4ATglKAYuRLulyCMuGIl
sNjKBa9MXUlsmq2ccneGqaFi96a2bUOVZgm96tDW0HOQHFqWy4NX45KtqoxAQQrYojLGVbz1fR2q
mTV9rMC0KyRzqsPx44lMC0VgtG5C18y6LuQXjFlLI5wYt3CRs08twK9RtSlLHtBuEGovCORGzYcC
k1QZC9Pw2WCiGQESj6XRUAibhBDLxFYGKFIPo9mnPK1ZAmFgaqFLxBlQUsBiJxi2CQqrTLBgrO8x
rlBopeAXAL7IU0zZZIYqaiq5qvwb4DvZn0dOWTeW74DDyX2v2SwKrYcVJkjrp0+8X29sx5kdO1RX
iuvb0Xr5w/GWduGOtp6+HKF3VFmvn5qxBz/1KdTxUVWcX5lbLo+dvHbzOuh+Dexn/olIGMCBoSSS
PfiPyr1mD4MOF+E73HJq2+2JOXh2G5xJdjGRWa7nqKEjENZoX+Ao5JS3jI2z4sS0lr8mhBWPijdR
kZjtIfZwUinktnyXhtCmuwtLRRO42rA71nghVp1BuuZBWqAjELYdUGbHxbkPHTK0BjiFu0Hnjm4t
gPqaXt72OC4YbFbyrj1fTY2kmZyWXAcSnS8iGkbrhodEWsbF4U4HCXVupuBywJMcL6mBfj20HTPg
rgI/YMSNRzezAZurCus4+IZkKwGbsQjH8T2wwjQU75dKESiWRWaAJ+Nh3C7w4WPVdW1WlOj/Z0Xb
8WUjHmJmCrMqmauGB7OGAOdpSVijAhKBFaehdH8kHMY13mNFBn8CLWfasdgF7Q7CYqEmtB7CihLT
iffrzyxNiSOVpuPTCpFMmEO3bv00WL1+NBnFLYD15LIzcIFngl248Gn4YXT0KObnMsOXiDdgBbT/
VE0YcsdeqFC0ms/PVTfzrfnlvOe2SsvV9ex2SYWK6L0cWzHIORMIfeE9PPlH/+HwyChoTUK5kvg9
OYkyMYPrpHR1knxF5zVHPQW8ZDctuOI857ViA4XdxZkNRLHoNUYbOQcho+jiWHhnWoHvQwOhrYq4
EeIqomKSikvUiQMni+iyZKMejCJuoVZbR1UshwggPWPCDcE9RKbHoRJegBZqON2dMYNp5NSZ8kYL
WStBtcBosVkLnZDzEw2Hu9fRq/U8w8DzDcqWVFHTIY3uKDxQHJ4ozaTuKlhkBXUl2Zw6KBQySObk
fuqs4jt5TwGrkZ2X/4B5TGHdmNcSieNiMBZ5lyLHMRu1r/e1kt6D7BUaS6f/eQ6HoZSztkUZl4mp
qmbmW5XSCaxDWNt9feGJ9+tP182+Pk8MAck/j4WPFwhfvlkdevzguw9ueSM3qZJHpPfhqWp44c7j
pw8e3H/w9OMnj2/duHPh7JAeFmaXUuOXgHiUxv7j2ppISVFYZkQs9lrzMzgCyvUalhMuzk+uza+H
VkyHBGYgkClJTEdPXgKr2IiD1HWcwCL2xcI1X4flPwZOeE3SnSjBMWwRdDTxnihDbu90uu3cSsWE
t91ebm8FBizz+CVElwIZHdQ08DmiRW/YUFOpefK0dPxSylQlXOJj7jxBpsoTcxA2I0EMpznnYmM5
NZbZhn0J5mMXPgluxwsDaGsrl1uzYlYpw7y2vVHh4Tq11vbazMoUZp0jinZkCy3/GGhOoHGoi1Rw
VNSd8aRMlnWg77rcdMutrsAEJEZhLfNWvLIDOgTpBbg8AcNw8xVLwUMY+M7xj7Z99kgHRRKjXXhU
We4HAH8yrAms4lq0WczFQihOisQ1X2WJvBJXBgBCq2JlK6WW0PrHpDXxXlr/or3/wL/zZ7Hw8ZT1
+ujmuScvHr24pc0lJbZ9k1a0blKL2p2nL5794AfPn//g2aPvvbj/9PGdOyg2xILWRm4ctWKoK3D9
x90RXCM0H+3MTbaylclKzVQVx64tzhdXq3MFV+/HVBa/nhZUTyFvhqySVsbD48xPxwVMljdGeZEE
xckzyXE6GrH3FSrLKai4IKtcKUTCODqnujHv9582p6vLRdA3xN1hHMhJ959Dl5GMflAZbzJkjEDF
YpEniiwNCJ0J+YUQo9DUaqO/u5ntJMa6JceD2xCJrAeNxRtotbmR2pkyAHk4O4GwPdWtl2xvaqba
WVhaqk7biJwDNolcS8XygRYlsZ+bb3RwTSOE0zBxol1YajoaUgOZwS0eLDnAleYOIod3itCLmF4N
8GdPZzitkGuZIY4CcjQDVQHXrA6BOA5wksIyw1/KKjs+Yjo+H8FKWmk/HIgSV2YMsqUHD4UN9Xwg
I8CM1lJFaH0NK6S1dOL9OmJAtI7Ewsel9fKHN9OLZz/+3t1HT3/qLp+6/ufU4eOHO/bArRfPd/f3
P9rf371395ePfvUCKvv4/J3zqpOfrWaSNxEvf+bwD8BbamuS2SVJSnemOqstd7ZUtH2j0Zyqluvz
GxP1XoUKolmFeg6jc2E7xB4cFJkuYZ26BE9TAvSylTPOzR9JsIr/AEQ2lUus2minrrZTLECxXgyP
Exu4jIcZDeNc2Fr/YKO+vAa5iiEQ5IkSjBJjgFQzWJ0lMwKnBnEFClyKvKj0DlNVdaQGhuZZ3jRm
NdWsItyNc+zcOK6brbm0+IdxG6HycrrTgjyCcn1+giWw9tQcbIs4LHoZe4JspLm1phfYQROq7mga
MlUVUPHoCl0VMTedbK9UDD0XZS84mWRTu6GJWoI9mXpKbGOQZLlN621OuwZu561QYsbJ/dJJpQaz
NtVvMxoGqAROTBaxyB189tOSnAJMHrrBA3HkQ2SwhFXSW3k6NSbxtIKWU2g3XakyiS2CwdKF99L6
17o4Y0frwseqMT08OePeePDLj64+evBtd+4kVfLPaa0bn/740Tdv7+5+8IUv3N7f3//m/t6ru88f
vXiAmPjTg5q7tXPmGgT2hJSb3p7WhHgj2AvNzSxNVVprkzUWZYLWJkyIS5npkotcztyuI5YFrLQd
SomJtALbpLj8mQVwXAakFQXj8WQCmWp9uaDBcd4sLJbxFNTZRBJPJPoaOfy79U0Xsxsmu9WaKke9
nINrh3VhhryEEQa9qJAiSof3DD6pXRIOw2cYkFYdvBpmw5/aqdbi+jr+LiyXwpqJZRelLUMSPXtl
Z9W1AJqGCLu2hb31uXJmmElAaqJTnoEvuDi/NreyVfMh2ag1KcBO5W40g0G4NFz0rJuFoZFeZebR
CsVXolaEw6wei6bGIN9gkdVar7duc4QEU0tOpoBs4nP4MZBUotH/HE4hTigKK4ikOwJhNKSU17K/
9WDUi+SxEaxgntMROXpGvhW4kcOwls8Lra+lNfE+a/0r521sE9fhN2Lh4+ato7PWjfuf7O/dffnk
p2b70uU3MldBt6p/+glo/cIHH3xhd3d3b39vD8hevfv82bd++ODxjU8PKN5kLnnz8ocQajD7jzgP
h0kPjjhfXukZ4er6Rdspub47vzG90k7NzcNN6y4nhkeTYhEe5qAX1piE1/FxaClCYPE2caJEErbE
4bFcp7227uAX3phf2ZypTiSizJiNXQE22rCeK89U9MEhc3K552kKA0Dx60j5JCZ1YIk2CSkXXXb9
cq0qXHHOafJ1g/tUDRMmphJUz5rE35T6fBZgedDBlm05oDbEKKjwouvANYVpC47vmxfr3XJ6BJF7
dMpAJlffqFfLO7nyZN5C8Ct1X1UFDXgeVQVT3CZArwUKUVHmTFZ4sjJpxQVQlVPgFEOlkYIsm7Mb
rsr5LvI3hyjS+s9Nr6CUvic52ZFuQyauDIIPPIpRtQmoyqvUgVl2whL3BD6gsNKRwVCDOUFom9hq
1BRaD2AdoDHi/fpLMPB3/tAw/Da0JhfVGz98BQKf//DxtxeJ6+GdtDFdvzZtfOrWy7t7e1eufOEL
H1y5d+8eLnb3Prq9/+qTR999+vjGnbM+ws3EmZsPQetn3pbWyMLAxDLdnZzMm04rW/Ia8bgXNleX
Nqo4HrLUXJ5IoKAbdVEhr6MY0C9ZK/AcHj41Ok5eqbhsxp48M5Jb2dhZqzmW4YTbc9wkk8vIf59I
w+VVzFPpnWovwO+dUYL93jAwN0xOXhOLjkLJEDRl3ykJlTATcsebeRv32fkcd2ghtQzcwJdTrdbx
0J3NYkiHE0pCoe/zrZvNo4qEwJXjJ3zcZxeWM4jq+cIiNhUfe4Oq9XJ3pRlYTlyT4RCaJgXo01RH
BBgBRxaDXe4C5+AmAscWKS4UYMs5aRE/gFDVg8J0lacxxyiAUE5QyWiXChydEQnKFVSrhECuwU4L
0gpqmcgOCbuQUjZcKaik9aD1SnZpEY7+w8B5oaPIlnXt8DWtYyKtQyfer6MLB3fh1/FIoel4Vqax
cODxi6tAcf/uiycD9tIlBL+H0nr9TGYme7rvztOXV795BeoqCxHxF65cuUKZffXJs2/df3LjxrmY
Vdlh2guHxdtHwgksVG2XZtd6CIXnt2B5b273trcrxa3lTKo+157IIek8MIHwx4OuIhaW0BeYckMl
jdHC7anhiamV+lx+EZparrYJahovhHRMrId4JjmguZ3r7FRna3EM6MybkFEDYzpFXKUdwmyVhLKE
asSGRFsjVZI53Lyf8mvpcgCz4Xvw6IsHojcxNlHfgv0KtAbgFbd7Xq2ZRUzsW5ywZuisObXqaUQF
YBUBg+R5nIuc7s7MzKxsOb7JmrOBZFQGFCsWn82AXQjAi9mfpl6hD0ixtiQ7YqivvBXTRSXxNlvV
dtGKEUkZEh4jl3AQ9qsAnPTGFDmLXUxPeIFGR2VgObqdQL4eJyyVJRFbrMh3gZ7seRSvJMzWLNWx
swgn3BNYB9KK48H/i2YN/Tetvr5P8ZfxUFwF12Owite08+knv9q/feWD/f1f/vBGfy13U26PwuBr
icmip5y9cOHG/edX93YJqtAaQbu399FH+/eYwT6+c+HTSnOqe+Y6+rP8+uPTKpqHgi3aqe2FpeVy
pTTZC4Jwa3vW1f1sqzKXancw7wG7WhED4x+TVAS9Z65dA60QU8TFxPUMtZUup1FMMa0u8JzXxAQB
YOCbppk/2pOewXGvPDCmO7GyvjW1OVWzMImokJUtOJKWAVgoCX+Ryas0JKVwSl5xK1sfGuNUjerL
c2Bp3GWE6jiQPqSqM52ZLTcwPSxubbWdwPVK+aYd2jbZjjuBD8Dn0mOM4SUUjjxXLDylZ6a2Cln2
YdnWBVWoTyNx5W46nmsc+PBmRKVdDnahAka7xvkBGcMbwglhVWJWsFivLuoSEwPlc/0RrdGcGhIZ
hdpDTH1JvsS/MhZCpi8JqfwCcMqPsHgJbuUpaYqUKW2co4hIyHSz2HMktEoQ877G9FdXDEfDH+3i
HM8k3NYvPP3e/u17V6/ufvCDBzcGthPX2D6Vey+PTMbPn72Bdeenv/pkD0hTVgnq1atXP8DrF65A
X6++evbiwY07nzqnZZdHbl5+ePktnYcjcuxqF//am9Pl/NRWUTeR9XloEyLnm88AsRxrwTihij/W
KDo00m8FrqeGcZOo6ympCONkyCRMhZjnRAsxFJU5ocxVA7ZYY7T5w2KBkyJzU7YSR5BKBZvMx0+L
sHC3yaeoJIx8obd4JyWmqDaj0E1wUGPSWMGyHOgl0tDA5XB/s2HRPegUmjUOdrHlrYnOqxvkUTLF
Z9DH7znoplq19tgw/0cl5eRZbqfHgbOZZKINm7SvDCqOr0XdFZqo6G6CVjoNx0I1WAFmNA9KvBpp
IIE7YDY6PxL5sar7+flSGJ2eA4pxNyiNJj0RSx6bpUTNHpBO+g/vGqTQHjIqG14FXCk8SRzNPT+S
J7AApqt+1s5iJvMBrbSgYO/1iffrL60zfX0rFNdDj8QxaUVlqGt86sGjfQFx/+qj+3dOu8uX0EEV
+/6laePGk+++/N73Xn7rxfd+eeU2AI1gFYGF1F7BLbfB693nL7/7MZqwanMu+eHbaStKTAIVTEq5
9vRsu1bL22ahGdLPCt3SejtdzmQSDzCbM+PU2JPSwAGz6NWcGSWtrDwlUWViK5Oj1iJPIrJToVRk
VYrK6ch6iGFqBYuZGExCQ+eaF70YuxuDLKnIJhMIaFyj+Ucc9NKowOKxGJHe0tFlxR0TrRmHW2y4
08axLJRG6fAvlUKzFmZtD/dzhZzg60pbh6GxpefLicjOMSztDpZRUdwew16inUkTE8wU76JJR7AG
5vyAcqopeOHECGXIVBnzSnc0cvUKrkMKWBXXMGk14orl5B1dlUSbsOI/J2CLDmjFR8CTXSF8Ae6Q
YFqOCQCNZDayNkVPQaUV/R2IFp9maED+gCmKjDSOu1Yjm883a+I8FFhTU+9rTH8jFD6XOpK5HpPW
+AXQuoc09Mru/t3v/ejOQK1zLbI7XM8UBh5/99nVK1fu3v3lD55HtALRK1RYYAs53kUCi5T3o2++
evbywZM7F4bCzRFo81vQSlURBeSQ0tXeTN6FncDUVOKD032d9ZkFJK3iSYK/QeYSJJNSZWIMPJ4a
5jsslJiGx+lAHIMRMdpCx1GKuQk+tOBKHwa2pcPej2nD5WrPjg8hKeNvpFNxNHYgCStPBedAejVO
SMGqMBs1WbE450zGFhp6aOpWw4dNEKSGgNH2GmEWWEKwi3if90JkrK5pSp0pi/vhlDAb7PmYk5g2
xcW/LkkZVYOLcdqeJ2Y8nG+jTxY8l+b/BhJg8CBFalUBg4pKhwMiYZnqz4owE1fZjqMIVPQJI5A2
fDN0A10h5LQagq/TfxzhDbzFJyzNWr6wk4MFItXDiUwDUo0SaZUpFnKP6DkYJ6tsRcuA47AE42Wl
VHIPae17Hwj/zVD4iLgeLxIWbf1o7wrUcveD3U++9+RTp1vpKBi+tto4++DZq/3bkNGrr+5BSO/d
A6tYEgnvgthdvMcX7u3uXrmLetONOwPxXgrjKLn57ni0iiuf52Jg5ZbWNjxsboXLXonCLGjLYqcj
XicIEEHl8crEE8qKatN4YkSqTbwtSgKTaOZQs/CwrLN2qxMZqS+Jx58pbIari715TW0QOsoXPbQ0
9D9IK0/0535QMElEYRCmvmLFeCEA8yAbLeD2cstr+KYZIBJGZzVvMxy2i7bbrFVCT7TVDSm5vom0
Djw7vq6zJKW59QQ1VZaUUPkR2U0mx3KrsdNKaWV1iuMRzUK2oSus3gqtcZ31LXqI2GXiXnRRQSFH
g0pK2RpVMKS3igZXRoOtWnETA262UeUkDYEupp5GiA2C+YHU0kAew+rzoB+fS6YVhYU3ZrqkGqCK
6mJav9gr8NB8Xlg5vFbea4aVMCs1YYEVgbB64v36q7vSu0fE9Vi0UlufUls/YFy7u//q5YNbarHK
9un1YW/g1reu7u8Byr19vrv90Tc/+uib+/u3b+/e3rv6wT3GwyK2/Mr9/Vc/YH04Vixfh0fiuLQO
R0P3Exgb0e2UZxenm81Cy9Zkg4l0FsMNGCO4xwatG/xiJ6J+6xnxSIyfGacPEVdos7K8lgSysEeg
xJoi/xM8xxWOfpqXRujvTyREW9vlmfliqNAOwWlDqudq3L6CTWJY56TlSvMS9JUDjAiuxj047KsQ
WvAKm76vA0PfsWBjspslBPC1vJsNa7VKa7G16KJtA3tPnn2cwK3VajYqvY0AaKOHs55JHATASQb2
yQhWwRUpwczazFJuojPTRF+k4upgRijUIOkoKmOBUxKDdwCXBLG/KgTxVOUhpOMa43PN0w14OJhh
o8g0SBajk5PZYsUdKu7h6XMgFV/Pa9neLkLKiBkUc88rA14d9/L2aOMrbpWsV1J7TJWqbOWbns2/
TFI2JK2Zvr7/oil+/22rr89Npd4oCx+T1us7xoWPf7UX0bqLotEnj+5/u7+Yunb54aWF2J2Pn+3v
g0V2WL8AWgEtsL3NBUohsKSVokxkASzqTR/f6S9dgqXp2LSOcDe6DGBJVzMzc0u10F4MEWiKkgGO
YK2eGj6THManAUwQh58O0kp9Ba0ncRtldhS0ToDV4XEEy+MoMOWwJa66gIEumOhEdwTVWepZaMDu
7GBDXjavqTzlBWvI8aCzLIFyUFh0RiJAFXNhJKWIKOVwDYDLafkgzvTpc/BC8oq5NKiyuKViDz7e
IkLCSguD+bNhsYg7imZg4xJhcOBz5DeCVGzEoaQKo1GKzY+E2rEErE0LXRwLsjCpB034uEiLCjjo
IhZbBmWVtA5KLZcLMJMsqKBkk4bu8/xZ3XEsVIBiMYvGD5kLMSBDlSCP0dmQjJLJaAywWmJhBIqy
W1aJNszyLwCemB4uBtKi5JBa+qCkqSuibue38sjQnYJrCq2s6rnv09a/bZBIvyGux6a1a1x48q2r
pFWIu71799GDc0pr4tr1VO/8je/C5RRJKHi9eheu/mc/eP7JJ6ggs3uzd5DDglcCffv2/tXnL5+e
88duwoF8/Eg4wUiYFaBcub683CsiqGoVLFQ/xdTmb2PGy8nkWDc3durSNQS8YJUlYLIqniZiizXO
QHk0CZkdHRvbwWly9frsyuxavbxQX8iNJWggpjYD453y3OZWHu1QOX6NpvX+OMCNBgOeZx+HNlhN
oUUXsBri0rUMLnykk1Zf81Fa8vBiBqbvZWv5LDI3BITNpgt3e7hVKhXydqWYz9OEmC1hP52LFNTx
7aCh1zqweMhifM9qd5IX0S3wMyOBR6BR3fDirt0AD+SJfmF8vwa5IZlsuTKVBKgAScQVrAo+qC+h
0esYARhSORGGIay0YcShPzBADCmsDPTjMvhBA3TUSoopYR4irTHyjZDZ0bBizGXlbpqh6DtWXluZ
rLCYZQhR8uzXtKbP/h+mrYe/w1/H4XX/ZOIqtI4duoWPQSsrSWWj7zFppT4SWES7j+7fOF1aGJ/S
73z86Mpt3kFa90Didx88fXD/hz/84bdevnz07JN74HPv6i5dE/I5ABYm4l89VssnP3NsWseGEbWO
0M0zgbx1ZgXTDhen56aXSnFgQiOsX1mvJk6NddMjJ09eA67Yi46FMtPoyDiZlY9kCzQ4HU/iEub9
hTL2tmxMT8225sud6lxnIsWSclIizZ1yveDEFd8s4TiArDbEU4X7VXYxQC6ardEQTu5gBR6ayrMb
GYRyPyo9vhY8/OJ9cGz0hWlYyocgtYJp5SguFZuuXSkVIbAFbM9eLEFdbS/Mu8VaGMLk6zYc3dlq
JxgJMw4mqYRWFi+p/qyGdZc2N0MVzBlyOg1bqA0Hao5AVyeZLA2BKxqJ4dcXXGHpIIGqZfqQcLiT
w0Aj2YQai28Y9g+A8MGD2WdxjZNjTDmSVsXoVbwAbDAq8TH2yUpK4KsqQabNEciy1Spx8RAfHNmC
ZQYeogY8o3uwYZlpa/+Jf3z9FnOA3/n6CgYy/WOH7kTH2P0TKwFa/0Rcj0/rzboW0UreuCCvUNez
SqlcHIQnYm+XLBLF/Vffe/Dk1o0bt27d4r8nT3/47O7eN7+5vwtFlqQ3evvNRz/V6mdoGT5uJExx
ZTCcSeQwi3RrrYqDkVe6216DfYh+JWg268lkOjcyKvYlJKigk3Ym2CRGI1lFfRi6CWHl9FL8yqdh
NqxurK5vQKcLvTkcfZOjmjFJxNNUp+YxK8IKe5OTU6tbpZqvIBtT5SDUaGCY0Hqak1wcg7N2NRkm
7ENULcPyG6YFjBtorLpoziAYLtpIVkul7VKt1CzipVkrFStFoFsr9ir5fBia+UqlUgyhdxwi45Tq
3FIfEcrCEq8IrFzQ2gX78EhmaaqpndZdU7O0OGlhqsx+kox/kWmD0hxFTYlpJ2ACO1GbyUHUYPlZ
pMtmHPUlGVFIzERcZZ5StLEOYyjwE3F6MaN9ltE0pr/4LNlqrnL+C97pcTnPVY6DlZIwg2fZ+051
54Bl2w/pC3EjnzClFWnr4j8H0uFwpH/t1KTDR/gaBPI/ROv1vr6lN8T12LQuxQ8j4QONRKnp48da
Pn7242/d3Qe+EcV7rx599/79Bw+4JZ170m89uY8m7Cf39vZ3d0EpYcWb3f1HP413T7KmfMwOTjRd
FLhiP1y3utKr1qeXl8vtjYs1k7s3dVRWy0kxDia5Az3iE284UW2cF5E1YhTVp9GkaGyqu4ATq3q2
neepbo1id3mjnGbeiqIUJihO/oG9K42N4i/D/8LuzLSz7TCdHlM67XSns+xsdt1d1u12t6XHsr25
xBbBeiRoRBQ1RtEIJAgBTARijFwa/cIHTDTBK3yQYBMEvINHQjyixiPe8YxHTIyJz/NOS60VLWrj
EX902+nu0i7/f58+7/G8z1tBH1LNDu4YmdyzazKb0hpgwsmkLcIBV5m2hg8nffNN8Ch6NGjZIAg2
kQ5qmosw03M83w1QRjKcsmFx0s2ZymLu1EhVyaoVjGVPZtDUKJFyjQxi41w2my8FAJGLVs7UxEC8
nQe/bTilIEkrPuF7zvMByIgPavv1hiaNzk7cwxNaSqggxIhQGmtixBQoEIdRqTRlRXKFNFmDbsO3
Naa57EstLrXBjczKz6m70H1N0bn9ipQsji3iQwxujQLNHGhooq+poUllWaHKoiki/v+ULXM8AD2e
iI56G/f4uJpjWEtoncDqm3VA6z9vrr/8FXj1zL8JrSwz0Zb+zw0Q11YTTvubliNhwO0IguFDp993
7vjWute//9KzmLUyMUXD5oVnPnAEPZwPnL566W3ve/vZzx0/der4xY++79ILDx0Kn8OJujd/4O2f
M9peza+9Rm7tRcVFtsQl+oYLtUJ6rG+6f2bb6OCgJpNhpqYGkOnBm5+DrYtD6PsY/LL8yywVuO1A
N0ekQb34qW+Gw2F/BmIBP5HeEaBnOze9bTAp3EqT8AEHEW3gIFVTOFBu7A6aQnEwSVUaOE2sM0Xp
m0aZvrioaZ5NGbDn6woaNxaOajoum6g+bkEAcQDsRZGe5vMZRL/ZWcCzkqngGuUnbEzNo/SUCowA
WqbZ6aT8TpVUlY5jNJIiVPkmcOXHeHJ3pKfVzE3mU7pJODFdVjTmoVIWwuF7Wf64pGAOe6sxWqOW
0deN0Xufk4CCVPFs6RH3s7BDK/qomPhTsIQU0vXiMliRSVMRwfUFuBQ5I9VL1CDzTaE8it9W4YyR
7zOphthS0Apq3YX/u//paMX5N6J1S3I5FF4jWmm71JxqfP3102iYottKzOHgGpXhrVsvfARqxOXD
aTm0b1BbOnPmNAD7Xsr5j1++/r5Lh4BX/FVi/er7zyl5cWxaI1qlEIoDtM6M7C+MJQamd2zfn925
N+vEDMAEtgnGtgnIfzFuLnJDHpEIs7dKbpXgmNiFX0Qnx+XiiXmFP3RK88aNXXYkkhsZ2T7WRecX
vDUPeIpp6/Amq6Crgq++fbIe49YgHXAqpq674RXXTQoCXF3CE2oGWgmjUWPotulrTSYkv6VyVAvg
vGRYkEi6YEAwatEtZvZPotaEfWuIjBEJYxNAACtECx9TDqCMXDdm7BgnzwtEGQ3IEbTiyNi8XDTH
Rxp6/KH+PVPIVmnhBpdSxqyUIhKZLPWA53oacY8At5UMq3JuKIW1VHQn9oBsrnZk3rpFA2ZF4yuj
cDRUYkU3bLmyJsy4mi0gvBN3NL2scyW7wl14GkUhwsHcW4CYmQdgjbJaZeF7eZxTQHfqMVqL/4to
XV6H9ZJ/Hq2bkn8RCq/NRa1lVj117m1HEPEKWsOoF9HtW8+fP3v6zYdWoPWlIWYPAbWALeXBmJc7
fu7tV591kk8AEV96/7nPWXuOPrN2tMIsia5K9Czsn8yNDsTnuQYtv6t/yvZcU7fx0+jOzbf0NmMM
XeDKm3RYKbIFWsmv+JRci4SvtyU50NynhEtG92NafY8diTo7qxPCWIw10xkGgMFI1cNPt6622nPK
ZkC0Ua2Xfg58EsRFFzGejnqNZWvI7EwTPRHPA3jLdr0SBFARIqi1yK2BBVbNZCbz1QpKS5VqvgSe
RcWpkrEcJwNrFoC5koGa0qEKcc51+pIEJBAqA3PhFgqSK468Rr7nQM5gqzKRjKd32zEFoNJB7z54
Hi1OIFJnnelxFZgFIcBXrBwAWNeyOBfgIGoGoASeoUafF4wgiEuGv1w3ICvSqeyXyRuJrulxClUl
M/mY7XpGk3ArO88YEjSpWmazVaxhaOhqg1O5Qd4vu9LBobAz9q9B63uALFp581PevdLV+z0rHb9f
zJwU71c9xPt5Pr/yK7xk9TdZ5Sf+/JVoffEaIL9WAwkI1pfJdc3cumEmOHX87KU3PwstmhCVkoS+
4/T73/61M+8gfFcecjAOMct5ufdfP3/q9dc/cubQETR1Tl796PnjzsS+p1EegllDILV0De2AXcpw
sermdlSndk8i+YpqPl0crH6IGro6CNawv0otv4y1glh7N3bhPVtWwlTxsfR21USIiC6jjTy1ud/X
nMlJ7FYXHGD1hh01jZ1TEPaU5iz+kJacLfSMiGiu39SIK7wBsNx2CnyVff4kgj6QB7q2D3JtihqG
4zouBBFFJ2Vh9iQLi4hMKletFjN5CPAc1wKNOhnZtV6xDBeoruQcTtCU/WAkLf7PwvN0fSNYxXiM
txCqPF1dhUwV5sQDw34rFA4mv7sr/VaEoVJrksXMxCipkVlrKCYGHZrh4isx4a+XSBh4JMGypcyZ
N7o90RpD5hSiItBnYCtveK6io2CgApRKOWeUFXonoonLGhSIlfZR0kVqEpijcA6zOU1jrTxEKz10
Gv8VaGXs+bpPLuImhIucRWJ7DKml4FRA+eLVD71kCXorv4IY9q/+Jnxg+awTWpW6OnrmPj1ajzbv
7jl14a1HqFh61nJhGDT51a++8NDLVkE1fFzkSyff8Y4jGEi/fPxz19965tAhCBBPv/d8U77rqWZw
WjrbSS3g1/ikoygGEGFnsrnB6V1AikIHXUe392LnRhvEwZK1claOeSuKRjxgVXRtljabtaeThUym
oCFN62kodsI/rS9rFAsD/C+DnJbqw4wSGyxGWrf0zPa27Wno7lFSW8CtPU16NV/PqrCgFXKmKObC
NcPHKwKpchzOsmkd3KTbBoQ7pWKmGhCrqDKVYJuQKubwJzOZrWYt3I9MFvmjAQWt45k2Lm2wo+WZ
1eGENFsFnWwRyxHsyo1A5jsU3bBMZKArMW02RgAfvgjLjxGodF8U1+/o/iJ1E2BGiY1BsIgWiCh2
hIFc3MOMIFQPglP5RwyCoyrtx8XIUWwkItJNXbImjdDuSWTEZYg6TKkpiThD4bN1oBX4BRuLhirm
ehotb0zkrr69iNaBTf8itBJ+uAKaZN1Fy1fq6r6J/268JheSB+Uhgdhz6r7wzDM/Wv0Q90Ly01es
/ApE66pvwvMY8h9uecE6odVdQuuynmlNfw8OpYXo1lNvv3rk5DIyBZMsBvPP8iFKlwkWThInoW4C
Xs+eP3790hFong4dfuvZj+WaUQ9eO1opGGwLF2HM6BFVR8tem91THa3SdhssiOxR9fPbpvu62jbI
AWYRDnMYR9TQuJKiMGtNsrRqYHRuND4SBWn66Y1A7/5saTDNQVdIMLiEvWs/+ADrhTGKMt3REYBx
tB5yaatS2Q5OpvJQPm+KaB6ACXo1yqBdVIEDGwVQA9GjuAU7QTabClB25sF1tro/n0XndRJyfifj
2LbDVRYyK+cjDqZ7i25W9nBEIWzY8Egg/HgWR6bSAVfRTifG904VoJ30AEtdMX1krtAMizwiVOgC
OaMB2JRXKmeFxNpXrI49VWFBGGDi4A3tf6XIJFAleULmzK4U2FP+Npek015NDGEaoP1QeK9mBlW0
qPjrQafcEnxLE7iUIX4UotHAk2yT67y4MAjNrSW0wnv6X4NWEmJ4sRImsvZ8+SIkxNf99YfCv7MK
aCFaV3+TN/Jv8SM/XSe0ZrAcMsmWK9ljrWiFPhBuhe2V+q3n3gdvCEJx+UBdCGXhEw8lTGfAryfB
wh+9iNz1pS87c+TNV7920RzqCP3A19pvFQcXjsQNZBVVg5C/uG3b4K68C0267Tg69ERecXLbULyt
hVoIJq9iegisdoo+mLJhlocllW1JTAwPzcyjaWNNJuD7PTFSqRR3D9E+gm173sYqsZQSydT3NLpt
7dVIdzcs/qhfgjzdwGebebhOrUHx0WVFump7yBnRKPWhy0d4a/ugUhfzq9nJYoqALKZypRRIdS5b
ShVn80hqYQlu2y4XN/slJ5AVOWEXZhcshxeJFSCVLSGYyV3anyi1YRzxSomnd+3fW6j161t66HFs
cyFd2HDBG2NgvDHyDWPjmMK7qFoQQykxgBMjF8ngm0KNkuSvjKBV01RFAh0DqGUER1xKBa/1vqHT
YQZcPpktayJ8jIrteYSYtR0oSwhwMiti47JX1nUatOp+WSLhBMaR/3VoXQbgSpg853FOybCW2BMs
rX5I3j8Zrau/yWuW90iuhOQb+B2WH/pnThFoXRkK964JrYDVhj325vMfvXRYMPhncAR4//ahTljk
wV99+/X3XnrWy46AX992saE68GrMx64VrRupumNFGMSX3GV4qDtmxmuQMNiYxcpUM76jw/9yatsw
9j0yc6UWQoLeDm7VW9osjQvcz5GzdGF+YnoAvdvk2MRY354KotPs9qmZWoLqRhx8l1ErHcgatmpb
QqsHjXYTsVuiOpoTWwStjIbBNQZWJdOw0OeqVdzg8w0QZgOM35ZSbmlqsgihYS5fAmCzmdlsNZ/J
YUE49LIo/rIqy8VXls042vA1pHtatdAs/VRpJglcOYbAaxxiWHBKwHJDZmGof75vSMVGE25c1g3E
m4rs1WAsXC/FXM6m83imKnJEmTjVWF/Cx3qitfHxXKpcIeSgepIZsMjyda6PDO0PF13RFM/yGPXC
0HnKMPH1FYUg1cjnCLJt+mWEcJX9NzEN6YHJXyRaiFZQ678Orc9/0jJzYdKVO5blGasfksD4CWhd
9U3+Nlqf/69a8ppfidY1cyulwl2TkVOwFIYieNl66aUrPjz5UCh88oVXP/KR0wT3yZd+5NwWa+jo
U6FVrLuhjEjCm2gWwZlu9PcPGiZah+WR4aLLkA67DAvpeAvV/B29Gzb0bsS6OTJTC7mVemGpDNMK
PDGBJbAT+C+Rxr6ekSLalblMLuMMFcCtCUbD+DC2fedQBnMpXqJtKEqdereQaROyty3d2PeDs2lz
N8gJ0afFXcxgNbCjhggTobAN0QUsyaEAnpzNB1DtW6UcVBD52Smo+SsBBv4QBzuabzkovnAfFZsb
ru9Bk6/tSrQ3L/0yFXrlm0TDnUKv4YIQ4JUhexJjCeP9c/WbN21qbI2aKElToIGIGqdeNPjhnJuM
n6ut9CEUkCoK76TFN8tQlCeKYwtNYaBlwjN0uoeLK9MiR0bo400Nv9C2GRh0mCoH2cCnJwDZm3vt
eNWAYMOO0TUilC+jul5GsoBEweSvpiW0bl1ntPJi+bxiBVpXPfRGSUzXjFZGwEsR8XqhNVhEK0Ph
tXIr4SrK/oFsz6mLXzt8WDo44RFBBD//W4ePErB0LOWkzkuhJT67SZl6mg5OS6+EwhzDAf0NG2os
FbiaCiaKWXNVx0WxEUipVEcTyS50aqiLwEH8yEFWXLPOxI9Sd+pKjqEiCWuIgb7xCfDSrj2DU9ks
DQYHanBjGkjEZRNOX250PD1S2VkYLlEtpQKjoFdmdSwyAa+8dTe2goV8A4GwbXt0ykfCanCoPANm
zWanIA2eqmTzVgoNm0o+Ozeby0LBxE6rxYVWhgy/WpofQ3nIZudD256m87gUmcKqkpCrwJbXS7r+
Lhk6Y0Q5NpFVejbhbKnXylRT6UAYhcOL5kyhip/r4qIyAyuN0Vj9EvGxzyOGEZRE4AC1DXRA1DQR
Jyk0F5X2D1Ee1paRi+Qzge35NN/3o6EEAjN4YPTwmyGsV/i968ObApEIXc413/OMx2iFqH8d0bqy
bruCW1c9tHzP59eEVhzksUQkQ+v1QqtWV1eTxHVZzrS2KtNboGTYMKZuhanwyZNS6+V5EkpXw5do
lV4sLuCrBrTWZ58GreQTUkoXb4lphHuujeopNADW1Cw8ebMjY71dAxioqSXaQK1tZFH6RLR1SJGG
fof0EA6TVjowIaqG8VIa2sPa6J69u/rn8nPbh/pkbRUXpNM8MbEd9ZudedfjxqYGq16S1W4IDkXO
FFJrD+RNUAnbgJwNvJYR11powIAnHYNeEdVZWKNBApELnFwmYOemSCGTUUTD1XF84BMxsIeCqRkz
aR8BSgzQam1mpCt4DdNXajp6GdbjM0BWsngaLBOu8cRYv9Eovzq2NNjQC6G6rDKAZbpKJhWDFs6G
A63hFinyn8oBWOocQg0DZR9N4rSEI0sjORwQVcTUkVOtsstKrJKBPShHUN+2UF3CeL0ZgbqJQI55
iJiJa0qltOgidfO7o1hsIJfPW77vp8RFjePDreuM1tX6BD7jydKFj9fhfHhtaF1u87xg3dDaCrQu
h8Jr5lZY8SMYPrAxVw/94SVIl57Mo7QlfQLXAuMhWuFKfHZrffZVT4FWrkkWcu1sQ4A7n9Wz2y0l
ytlSSApMzUHnBjXgzq6xmXT7ho59hGWHEFOor0S7FUExd6Vz+TKwyklW6PY4fbdj2+hM/96pqZn+
cRqVxnHIrHjGRH4uXdhVUSOcJfMiW0il2KcGbt0keSvYDE0cFkNt20Sb1QpMmixBKoAImD4QpVSA
BDWLBk7RCqq5UjGfmnSCDNdC5vJctAyAQ1xh6xAAajaTXigod6bDzHlxtyzRKnkrVRKM7ENmJViF
XBFsTOwBtRKtmxpVF2Um21dVGbklWBELs3pEaKoGy7pEIiEnpSWZWF+yU6I+mG5MNFrDE2T2hnDV
zHBcnX+rlSSqwr4O/1q37GACUBf9BYNjX4Z0VCLWNJtUDuSIdyLDadVxDdMYdQ3PySyh1V5ntBIv
r3sCWuWhVedNRN9aI+HnSOd21ata3pr+zw4XIFOo/UXiuhasPpt7z/d1xqe01289/9GPHDl85Ilo
pW2aIHMlYqmBegxoDLOf3RR5Km6lqp+H5Lqxdz6jb0tmREVupAwNnYt0l8B1YwsUQNAqcWlrPCk/
6YLYDoqDWXPi8mVZISeWpAPQCo+PpdOFmf7peeas8T8zPkR3ZEcw0jczs7fiYm2VWi/ZKrQDdM4F
VAlWJotNKlUE7OIEIBtA0DSNTN7miFwuqCAAnsugg2Pk8hAzTRbRubEcyJeqKRd/I4VWbbkMfBng
RNfkbKrdn+CrILsubVaAF9NiLNxBYuV9RLIsL+CgQ6HSE74YiDdsg+PsMeYInA3H1JvQaSvVhaoq
s+lMYQXJ/IQGh/J+cdMj3mQ/spiu6hoEEFCJ4cVxhasibnF8b0GCVfHQH55LeQqrT7wz5rCwpHDD
juq6jag3t+Izsjp9NZAqmG4AK1ZHZnAQCNfm1hWtPEhJn4DWVQ8tU+6a0PocPG+9D7ZQ/yNoZb+1
d2Z/Sbt4AS6kHz39DnRNCcfV5wj9g6Hqx8OE7eoDnyb6sF3fXF98Gm6l81l7GABClWRFldlxhy4k
MWgMTCU2mdxVyoy2d7IODPJBS5UDcaDIcPt5KCkAq4Jd2bdlGSnOZcpcB5Ue4PKMXbUkGzei85Ib
Z99r24uDO2amh+FWBj5q7CaldpN+gFZgg/DY1O0yjdPRygClAnKURjj5lG0EkxlWl2azmSzgCXXE
CCbiskz3IG3CsI2mldAs5pJl6iJAsDHWh2xrIoEjO3nkhBEQU1Z+lIAhbOOQWqUAkRyMdQOqDNO3
RMsGhAgAGcwjWBYSlyRxfMF0OdlONIOiagpVhJyhk2c0ShxMw2AujSRcVUoZiVYwJpGqii2GouDL
c0LBLZvOYMbyxC6YVK47thnuj4zqgdsoi6okeY4KWk2jTJs4NKuW0Iod4EfXCa2vXCHaXY3W1Q+t
aOfwK/xttDLZXd/D7xEZW0Jr19rQSg/Sox2Jwq7cp88uPLy9cPz1F953FQPmJ5fj3UVlMG7EKlfg
nMTA65L2fxX9osz0geubI8WnzFubadZJz78BC2mQ7XIvk+aVZotBVBvbU9ZSg4XmTpEGh+TTRY7q
WuxLEq40LWXq1y6LbgCJ+ACoKZ7oouchNmsQrGLXL8Ub2h8mJyrFqanBPTsGSxFYJYBbwWAsNPFK
MkUAWKOeB3p6z3NySFZBMB5+JgE/sGk1X53CAHrJyQUZDLPOVovZHH5igwBJLVqQUCuCaQ2PKkAT
wkEdYwRVoDXJWF2iccr3BaeUR8gbDgNh3vDa8frHJoLGTYJVvDVR2U+BP+EYDpmLaz7RGImJyahU
fpjSijchNQ884To5oBXPILjpdQWCjjH6RYkZHVeuiEU1TVP1soYgwlUNNzsy5XhURDREY1QxKmq4
qhXANWJS2CJ6xS0qZmhamSmC6yyhdaxQVzexHmh9OXlz6Z5PLD77eyvQuuqhN34wLPHKE+Qr/G20
vkHCYFUt/WDFa6LY6VP/orz1ADZXCVoTa0brs7k3o7bd/9jFhdt371y7eefhhVP0I8Xax5XkKlPm
sCf9wNVLV8+cROVY6FfuXo1WcKv6VDVhWS0BazRkoDvqW/WSFUVvUcUu/7ndw5ZSaZ6ZSMMyGNvl
OhnsEoKyi4MZIKPnRb/AXnGPoJswEAFICo/GSbOC1jgOwUrHQ9xQHa7tzm8fnKvYOYeL/clgm0Rz
uGXT5q2bid2tnMuBLAHMomlG6O5dtl0IDQ2/UkIIDHwWq5Au5YNKNoWtVFkY6hq0/7ZIgijWOLYB
EADsHAqAzDYLyucGFL4RshIZLEmFpeIkmkOm8fIPxDRSBC+sO+wAQz0oZKiKjD8cb2UtiampgsFU
XHEklZGwGPHjkG+p+5Xn0B6xHqcx7LvIWlp8RKiPT33VL2OKtmx43B4d061MddbxkSKTg3XE9AoO
7WEUzWE3lyfK7XcRzgcB8roPmaXxGK3jdXXWeqCVPzjfmHgO2ZG1oN+2tHwLOeaKZ6x66LWQ97e0
fAkIXPEVnohWGQmQQyXj0lnRt30NIP9PbkifGKuhEPpnXmp/fxK9azD40NmHX39w/96Jdx67cf/2
5VPnz73/I6ePvPnNL13SAssF3g699NLXrp+9/t63XsWjcGSCY8TqYtPL2MHZUt559JkDTxMJt9Ey
CckbCpilVAyWP3ArgNfCjp26MtqSxA8vtIZt6TjS147eZmAP3IqAkkaI7QJZmrgA80JSggWaPCHM
SLIEjHi4BqYioxKt1JyL6+FoNtc/05/SOL4d69m0FRxGZNRt7e7eunnr1m6iFxABF+nIOr0Yh1sN
p0SHlyCftzAAB3LNu7Bw4fxqBYpaRIM+hYq+h/YsJwGAUQN14ZRpazb6pHPye4KvTo6MGQhEQ2UE
IwXecBEO/A6MBY2LSg3E57SPQhQbI8rYRhVrboAPGGyFPp9blHWFhSIAGWwqbiytks2yDIVr/AGz
Cr9GTZ9EKZb+Kkdi9RTauQhpbCgcHHCpjWKTJuvfVR09mhRk/oBmPWBsxAwdf7dV7GMtE9TMGX1V
MUsp27UFrena2DwSs/VAKy9Eky8cGJ5VaF35EIlwtWb/b6D1JRQIT0x8i6B93rqglcLD+bGVLZze
v0ut+4btd1/5+v1rJ47h3Lhx7cHtC6dOXcZ8ufhBrCgkIcR9+2WMn58/+7Wvnjl8GFGx4FgexFl6
2uEzbzvXmOp/9dOglUWWNkJtniEdvZioiINFyuheMzbWRuHsBky1tsQ7qWRqThfAnVJZBVrFfYxF
ZaiaQl9wQJe8xXXKRHUcLFqbh2BC/rtwfxUbr4Tw9Eguv2e4b9bR7azWI6HvZszikFWJVgEvKk8I
NVUyDJIzKgmRpQKSqRRG4VKp6mQWJOsYTo7+hiWyi809GuJRZFtlIBQ1Zc3yDYTGur4bvyWk1CtH
AgPCMzy8FHmEXPOVxodHot14UYArb7iApolopUKJG5KZkzIi5iSutFoo8RdTB7AwTtgSjcokXBTB
My5k6Q1XV2syMQdCjOlcjGWbuseXa+g+snNDx/Q8ilkKFYexsu/kwK06TjS2uyIlaX5pLomHxpGj
fKhU2akK9JWP0dq0Xi5qLwdJMrTl+eKVujr1h6uesuqhN30JfPrllV/hyYdIXHm1OhL+J2vCdYvc
ulRmWkMkTMlh5q0Prt04ePCdx27eeXT70R3g9TIGVi9ef98HDr+ZnoawQDyC0Bgmwi9838XjVxZu
XTi+aPDyQgzgvOMQrfrPHIG9BEwQqY948wfed7lhcuDVb3nLi9aKViJNmo29uxvqtcCKRMSZFEWc
oaFS0NXCydYNHGiNN7Ov2pXonxigSlHIsl1CR8AWO3JYqaFXP3Egw+0kUrTqa2PpWlKckNqBlHh6
LJlohtXwfP+wkZkZ3bEd+XGskbEvqBToQCxMxOIGfDT1ABFR/jxadsqxNZe9VAuQzeRKKATPZnK7
S2i4VlLVoII+q+sGFiJllJFBwxB2eAiFy7YXs7nIUduWwMvgqwrr0lA1iYgfCTuplRNCglTepFa2
d7IJQCVcpe7Fi8aILop6CW2BVrmsNzU/ig/hLmhZciCOhqITFrFSPe8lHdeTWwEzoAxPMQOOrKPD
pIMjgVNd5t5sXzdTMKyQtfDszZrQ8ctaD0TM+UCLhtbDaPEylEYgbPgc1ncoj36M1t0sM/1Xnucu
I5Gsuy6nrq5xYvxp0fqq8aE/fufbxw4eBK1+/eHC1+8du3Hn67cucMD8/W/9yNXT3Pn4Dladzlz9
yNfOXrhy+8Gj28Dr+cvnrr/3/W/7yNUzNAVn5QkHq9ORzb756tsvRLb1wkONqsY19ltJh4hjWybM
udKMgRhLfmUb1dJ0/3wH9EmJto30OuzsSst6jcLe8XgSpBmuyhC1Ab4AeZV7oNoLAyyqtpNckzX8
5IyzPlwbSDQDBZT012oClyR2a8y6+b2DU9tG90ThzMSVwpT3M2sltQpcuR+cO9R03bNRZ7LdIOV7
TNDcXCqoZLbDcgm6RtgZwogU8zguWrO+4xlgKV+jM5LH9XOIow0T9LO/JkE4Kk0JMcuQWvjSdG9Y
dFry7sc/rzbjRMH2+CXSg1QaSOVprIfZAw5FwqRVJcprLzDDLT2yWpYsyt6oipqtwJUYFo84Bgrs
z7Jny4qwU+HaO93DSICv4d/oI8em+sMHACm9IhpdxbSqjom01gSISwG6PTZHfWQNNCNlTTHZvzVc
F4M4IVqxahNlpv5n/ivPkuBw/arDLDLtIVoHngqtB/Zt+P0vv//tEwevPbh1BZWmmwePEbcLNFy6
fPbt73vb6TNcA3ladj6+/tbX79y8ee3+o4UL2Dl3nE9421VQMM5hwSzM+0+++asfPR+beRWKzQDr
2tBKbsQfDKO3JQvZQdnfG0PJ0i1O1goJrlOOt20EuW5sHh1BZNueKIym00gAJeiXmJdEBGLiovHQ
lIzzPKQn/tyMJWtjYyA0RphYYpeuobWTFAPj9PzOYjCyd3B4uN+qF8uIhlZ2NyUS3tQtpWEiuIHk
qlFXZ/mgD9+ndseGA1POySIehkDPNVAMZoGJ0+uuAYR6kBNzGBbH3+OZvumjabJ9HA78aATHJZQP
/ciXejYsBzOmD9f3MLku7Fcawak8Egrz4CXGNBmuIepIk1TsqpbjhyValo6oclBUloxUolcIV0YA
xGkfR6nnemgGwIaLhBoVMTxdU3lwP0reeV+jcxrtWMUC3UrN2gaeZTjZagrTA4A6aVWGC0jH+BxQ
N000gJa4daJAXf9/5XmJlKOEWonbdThUCRdWorVtbcrDt3z3l7/5/s27C7du379249jBa/fv3n1w
/+7thSsXzr/73Z87d+4szrmLFy9eufXw7r0bSG9PXLtz99HX8QSYHn7uIspOX3vbpUuncc4cOfyy
k4ffeu64UXsLVRdrRmvYzJD+49i2FIz28FsfM6UlK79nOg5fwy6idd+G3qGYPQHwJQt980CtcCuI
VTa0gqwWf+jJsLxqlrYru65pKBAJa86goVxZGE/jL8u0d23X/ky2f3qi0D8Skwn0elDsJp4tjIQl
lcWkK6ezNRaauPvcSoEqLQjsU1DwlyqVDHLWSYzjIBgG7wLLZQ8E68VAWSYgjhtU+Cg7xRB4bptI
19BQ4q8OxsJsQjGseNw4DsWIMn8DCp7INTEuZ+mL7/iellFAa4TrM+p5ZJhNNY0UW6O8JsE2AEo6
iRLwCx26wcKENy3SZGOkWtbgo8gxA13nvo6IEgqQ0Xc1nHy+EsB7AoeP+q6qOSkKn9GpyWQrji+r
vMKVmPWAt+f6uIjonmcCuMtobfivtf9eLlGtl0xi6z+EVm4yf8t3f/yrnzy69fX7NwHFm3dvC4Pe
Q2B8C7bB4YEX6QKT2oMHT5xA7fjgjZvX8ATg9TgfOgcr8Pe99a3w8Of56IUet79j476jBw7Q9vDZ
a0Ar7a5D+WFLYdADbZBc/ZyLMqpTgyY4mYbtd0t8R2W6PT3eNz8wPz2OWFLmF8JZlTAXDPVBnYuV
1S4Kl2TzKxo4eJBBcDI9P14YH6s1M8vtbIflUf9grFgYLwztsSiK6ImSW4nRrRIMAyr1iphlq+QN
W4DoIiWlyC5locGagte3gZoTZf4IlIOKa4vzdhlRo2vh0vWIAA/YRR5Z7CuMpfnCw9ECIlZSV1xL
sWl5ZK45XusbUohPptJMXgWriNbZRCFf4jAdJUZjHiRUWjR0exGBYEwFE9rsn4bAopSiPsx0wccy
k+q70PWylKsL+HQvpvArcISilA8cT9W4lF0D6XqVfH6uarpesH0y67CILDsU+BaNmUzpzUijGDah
U7WM1pm6upZn/jsPRcU8n1kfZmUgbPwj3ErXX8D1l9/69c9+8n0y68KVhQcoEd+4ee/+AzLoLRwI
Jx7dv3Pv5gmi9eAxlKQAWDzh7qPbDxeuXLl4+TLeLoN/eTt/6vhn/5CfHY0fJVrXwq3UATKaZe9i
etKOClpV+uRHlfIoRPzJQhvC4IHtiY5OrF2tDYyPIxKmB4TsE5eh1XRC4uEwtOQNAOADxPFAkggB
RsCxWItDbm1uw4xdW3N6sL9PjQ5OzE/vyEgkDNd+ETKxJNwdloXhkCLbIdncSCEWBsWaJjRNKTRs
MHiTykgdmGMolk1tYgrJqg8qlrqUZ0MloXk+JPIgsEgwPCFDUnLS8rFdpuN4lnzUwhJTstC/v4F8
ytuidBlXJHoVWSIYlIr9EK+2NWhq7HvJkhyFaGVYys6MGqN/krj1Ly9SZgdZtx2XLRoCH3EtXZqi
PDGQKRrGjIDZ29WJ66ASTFYh2ioNzmEVtKXHQnNThREwRxZ8HWoN+aaauZy39sGE85n/n792BuH9
XXj6vFXOi6A9/P0vfvHLX/30+z9/ePzWXVAooHj/2k0g8s79Bw8eAKkIgQFRwDU8x975TkAWOe4d
QPbrDx8+XACmF25duUJs30a96l1mrr/9KOC6BrRSg0+K7ELqWstrCN2kgqnZXMySa97QW5vu2NfZ
XJiAQURyYiweT9eQtPLp7N+IBh5/e6l9KeyEC+JA+qtg11oCkia2L8dr42PjAxQowIUC3Lp3uF9t
1If7duxyGinjb+oBKPgm5LpJWq5IXFmVAVuC6zGarjMeRqsjD6w6FUylUw2BfDVAIxbvg8B1Haas
vlk2IZGIeR4gbgC/Uezew8uWGIDLah+rJNraBbXiTsWiE1PxgenRFHQa9IdiW4lwxY1oBaAUE5Va
IVgpAJuGVda5CFK2QvO9iioX0RchD6NyHK5d5QXxTa2hZmIG11Rl8IZMaYIkVWiQEQTgIUPjnci5
bRTN0LLKjRTztMqaQoZumJ7YhUdUMbiDcAT1M660xVfQlyLhcaA18l8bCq/z4Q9/X+HpOziEqsD1
wKtf/d0f//h3b7t84fY1cOf92wsPH1wjg+LcuHEDMF0+Jx6jFk/AM67duwdU4zxAyktoX7t399aF
dxuoDK+NW6kX7BU1YVvSUFht5E+ZY1ETp+zt3ZgudELSPz6wYUNbfCwJr/1CjbQEAqUQiISEfzET
vnBqdFEdLwJ/cmoNmWK6bywZr9XSlCeIciIuwfJY367I5sb88Mxuo5GRcJggQh4hXdcwWQRY8cOp
lRHy0QPCxDtwp1+GMjawadRv4gZ2BaeiYGPhA9nW8Knkg5sCm7Q2bQHBVoMiVWbUT0DKBY6gNgwM
FlWHeOEDfbkGgjTkemFXXLPhWl8Fa1LZL2ClRwSUmlTyI0XFZ4yHwyxUQS+WmSwgSnsX2c3aSEvR
UNtbgtkbF72Lozi4WANSyyJ18DX0l6PM1E3NNGxm4zBztHJz2QyRyTqw9MRjusrxfJX2anK9jFZy
61Bd3egz/z+rz7Pr6oohWgf+EbSiN4oM9tXf/cofXn/u0bdRR/r6lSu3798Ed95Hsnos5NXHIGVA
zAO08gjLnriBc+3etWsA97F3nrj26NbxRmtm3wFZuvx3a8LtdCcNxbtWlN1BWhukqhq9u4LmjYk0
0tbmWhfGcNqh/MfeDHRy+FfYpJXAd1ENIhM5ONwERZYiDuLgVmxcHk4k5yn0Ep8V6JsGiNl4sn8K
Ji/K7h1TfiO1ETKaxne4SZ2JeSNNxxAJa2ZYMtI0NheplbBcqBGDwIcY0QWpWhxABzghoTBdjMNy
4xVQTfEhezpKNKgRigJRfuR7firpK4/0c/C5ZNy7I/RhZLIqLdcQuZgRqp8lNkCcMI7g2nZWhF1D
Q75K9BKrhKtoKBY/FQFF0+KuV4AaB5Dzncp2y9eR2dKGjfCnmUuIWl2lFKLsmQ6ieEhBuH02AwsO
RBC6inqZpLToD0EzQn8XfMqWW8y0PT9UHgpap/+/Hf2vn80IhPsKi1qmVcrDtRm+YClcs9Xzh2/9
9Ns3H9y6cPveiWMn7jy6tfDg3rWbRGZ4wovlT+Xg4p08xC4+HDwBrcWDh8eb3NpR7pn7e2gF8pbY
ZmCHxZ8uCGhgiDRlRFQ4285AvbQPkXCyfR+kwIhhuZIqHv6kcyqH+a78c6k7hNgYg664EpE86syc
nRsrDI/0dyXHAVb+NVHMExGoOo0aPWBPv1q1m9jSXEwPmSCKJAEH3MrCDjDKpeYsxqgGi5/cf4M3
sCvgiZwVYHU9wDVwHHZw7LLrG2aMZMwVbsB51NzJbw9fN2ndSIdJTF0IVZE04x52ivnCEjWrZzMp
FTgVuDIaFlfyViXKxJWcKep8hRIH3yRhypCMGIAzexXuZWBMjDYIXnFwL6Nlw4T0Kp+jWxp36EWZ
f2LWyGclG8p+RaPVuGO7rmlyp3sGeEXmGtiaiQS3rKuskUdYQg4IcMiECVwQcfmxThhoLf7XCiTW
99TVNS2hNbk2tL6IZ3mzFK4PvOXofLlp8Cs//g0qxLfu3njnO8GQV27feXCX1eITi6GvHODxMVqX
7lqCLO/FJepV5xsGO14t3+FFf5tbkbImkGCODu4enXXr63UFAV6uqLoIu8ANZkdnYuO+DvyD4EqK
mLcX+WY6CcUSQBo6e7aHkvhOwSstYADXdsEuy03YXbwjNZpsTxbIrNMZ1Gas6TgZbGB8l9EobVbI
HhqFxBbbJcQIgCrkyj2mVBNoZlmjvl+0dqDWlI+Ck0ZHFOSpDjqwaMZydMy1oBO2NYbHrB+XDVAO
cl1dr8qQbfPYcByolKJYOPYnVoyMARgTEawDkDwNyqvolkowPwCoUgdrIghF+qCSPEGiLGFBR6gQ
qIJU/IZrrZdKMD5w7SoVxLK0hjYvHKuBPLiYmq1UUBnjEh1QI0XAIEy6TpkmIgP+bvIhzfLsEoQg
vm2Uqk42N2k7vq+DWxWF/x1Iq9RWWLhD10mzjvsYrROF6f7/k+tfOxYyBKB1HGhd48QcA1TB62PA
Aq0bhvTI+Ku++/Lf/frtj+4Ad/ceHl+4e+3RAjuxi2hdQuNfJLISJy+dsM9zA8FwrrZPbJ/e8jfR
Gu8qoBa0PShxmiUlGlhkUxXdSrnislnbmOjd1wE+Qs+1kwWpRK1GPhaHGDlyIS4M4mHagdMMUwla
MjDq7ZucHMMMwARm0/c3kUtbW40ktEIT25wGqdy0xiydVCZjpKGvylagRf5shvQwKktOfZ1iYY/l
YQqbUo4LEYHhQfnj0jgKVIuMFhc28ao7JQvHYChpozKDMw07qN1wF3b275yRXe0M/inkwBvbOggY
2sj7KKKN7dLRQRJZhLwBqWzk9FCdT9qEzWBJREpR1UtVPA3lIVzzHctGOAAqLkOfJmar4j8q3MrW
S9muZIoBku2cpcbEE1YKySb/nfzlYhmAH8IH24KOMp8PIPTIzOaLTh4b+8r0+KeBMOXCeC5uhsrD
dZm+vTTfCrT29cN86MAz/z+rB9H7p9GaWOt8K7NUgpRIFbyGd7XPxrR2oPb3X/nj737ybYzkLFx4
cPPbqBghiSWHvhNVpxu8OHFT2jnCpkSnsOzyRz4DYsYHCx+aasY3+nvcilpQe9c2NTMRT4/mDTqY
UCpnQOpm6SYIIoOa6YZORI29+xALg4iSLOtKzwPcuuiagms490N/CGYVW3CyLKxjWJMatabJYem+
wnAKSWewbYepBOn0YMZr7Rb3tAZTV3qETRl9smWylLxuBXDpngCuofs9CIRXLt1C3QBxIq0MORDq
upbFRmsAhjVyga/Rq0hm5+AWzsds06n17bYBK5RsPdvOzSSESdsXTV2YQw804ySxcbpvr7eFLyYk
1h50WQlVvJSmHgW0qugYI9hpxqKMfNEehayRFmcx8WtSJArmAZxxzaG5RZkir4BCNoCDPMJ4z7cc
lKMEsYrKopGJqpHlsk6mQQDiBRaihlwRPWYLzqvZHBIGy4sxWGY0rGsmN+YhV1fwCa1j4ESzAq1o
ufY88/+zavxmqL9vVQPniWglOPnh6NFXHSWYFhF7IJExg44XveWZA+zn/Ib9nIU7B4/dXXj9hdv3
DxKtN+5jDPYYQHvn0f2bAO8JiJ+AVzwm+SpbPFKPusEPx+49OmuNP/stb/l7aO3qQhw7ZRfQ10gO
+vTbjDKgs/WIq2ncnLS3PQkLGCjyW+Aa3DZdSE+kk1JDlU0ZzYz8ya0If5HIAqi0OEKgjAkAfEhO
DFW3ifigfWLP1LYC6zjzpQxMvyINpC2mpmoQg/uRiBDIrgSplJhCP4kGyf4Y9wmjxDSK7HQfNRgX
d4BzWQJO+bRWqwQOGjpuYPgELtjLKPmuuCT6RtHWVNHAAxVs7TjFYakFS8pOe/v5MTAswTo6GRPn
GaksdUsTh82lHvSX8HtFyrKT+exutmpi2BiLMjSrxBxiU8VKOLoolJC2NfLbcMJONtfgSgFY3VTK
zRumEeRcZK4AG1f5oQdraWUTQmHXVfRiSrPsYmCU4OnoT2KD3lxxLlOpWIDrn9i7Etim/jrORt/R
vW6P8hg84Mnb6ht7D5r2Mbqupdu6lm0t7HJ2OINRpjExGqZO0XiMxCzqUIPL4gk4IAOFBIxERMIh
eAeJRqOiiUe8YozGW+MRjfr5/N7cGJsHXvH6beu6ttt/+9NPP9/j8/18EThAeUFNpWtCVJl1yLL4
ftwUcOtCUXhfG3ZXHVjz//No+2b/PqL1r3R6oYJp/MjhzRhSgSPD4fGnLqB1r2FXql/72t1rXvtU
9HOe9ZOzP3vj297+TNSL3vL5DwOaL3/lh2+87/MfBlrf/cH3ff5tr3z721kFXiwUM0bmByrCb2Pk
/PZ33/rAlf1A6+6/NIODeHVDTklyhjwr9kbUIyyTVAW8YVI0pyNQ3IhBdKxkg13RUFdPN7hVrPsX
G4qFSELYquGSSmEcuJcK2OJPbEmM9jQG5mQYtoOlxEaYf2uZUA0RIfhLSiUkWPQHyGW7hFfEIVZq
QzUKwKqINa6kkCjplfmdzvXHiIpBUy4CYRcCJwvFYd2yGBY7uOIaLm7xsmlksNTlyiEtAiCzMUno
ju7F785YmIza3NsGUtrZ2le0QkiicQhWft4u+qx4316L4pCrh8DOkYJJq1LVLnCSANwWEqVevFPg
CzWHcAqOcNSGapMoh1lFysvU20YOil8MNTGom/G7MBNlo9WGlgMyLNsw6w3fA8laSaOSwJJ3GGVk
U4nhArRMMfhhIBUwaPmdibu2jsIxsY4PBen8crR2/vtnrk+CJvhfeULIWtuWofXP+gkLYG7YX7FM
1ERQaUi0VPMmOB+2xJL7j5B5RXw8/s3Nm774k+9//Yc3XvG+j7yTDErp/wffBhJ925dfcePD73w7
bvgUlE8E69tugXRfzhD5w+9+960v3/ggpttf+c6PvnXn+FOB1j/PrdA4oNHqKIWW1gI0NJTohNRE
HBEb+FVBfUTuxkbWzdWi2PuExs59Ld2YmANI2WTFAVjZPRVz3TQ3CjYYg2RBrZua9rYlWvFoPBzh
MmAPrPcn+wtWvQh9UWvdVZNvG43UiWyVEBHpKo8IhMGt0MCKjoUKxKJpAaggEBa9SAA45iDmdcys
YcFYApGlR32/pTMIxoiOa0A3b3g+2DUqaRkNqgnUkvGNpomUV7P1DkwjgFs5v9e6r3Vvd2tnezJa
w9eNgFzJ9g1i9oaBQEOD4acVU9RxI+RTzcnCdhEMG4yo8/UAYarYoayIUhROoOoNLVSnQOyO4ZWy
upHwYhnDjVuQBPNWrps0Ed/zN3OcMAeJQMF+oTgyAnpN+IWEP5IqJ3ybDnGAK9kVUUMMWTm32y4I
omPCTzgoCjMUNv7t5Yf/4peTI0gOOtsWGziNf8lPGDg80NifVZXbF+9f/eQ9ORLvgEoQHHikS7bz
G3GVX0CXj4/x7/745z943Rved+udKAojtH0LcItGDdGKm6AqfguuPJNR70c/D80/UPvBz3/0w7du
vA/VKSS4b/vBF8d3P/0vVZnQGaWcKQf1jcP+IJMsOdFqw/pHlXUVKVkBPsE0SoPVSzVmchq7u3ci
egw0ERuCpgcZlp1Xrolk2orOK7C9EWbg/fv2NAHZra3Nm5o60gmVbvrlvrxSw/iSECg3761w2oWH
vRJeNAhBU90uYeAvcx0bAMDNqYyEVRIsHcFt0AzEBPjkZblzOQoFMbJYesGkQU62QWMJ8K1neDp7
tNyiDmoF0Dn6YkZdRTJ2ChUi/Bnb2vZ3DkBSVF/LgjTkwYJWuZ8H1+C7FN6OG8MUIdgo1SrUC6K1
5PmeDrNiTZMUuPlLEdwt65quctVXYJGWUaKAdtD3UUjqhuulEy7khI4WYxsKTRngnuu4dBAsK8JW
2lVckK/pWOVSyU8nR8rxkot9l4Mjvmt6GVtFYKGxc5XlTiDKKmP4EiP35hJaReL6d5Lrs1aZL/3P
Rit6rTDNFbrDv8KrfzekEAcOFuQT9z85f+HsmTtnL98NR/zGw0DmEwe31Wp9G8cRJz8VkgZWjJ8+
/s1v7hw98Zoffhu8+fJbN97yqQ+//JlA6edf8SkB4Fufev37Poh2DlkWcwHA8afe9+oP4os3fOCj
70TE/I3vPhVo/ct56xNo9tKjhGUzJIshkpDXlUXpMw75IfeG9tAFEDFuYPK9vqW1h1omsCpYORAa
AM7URJBXgxyWjVfuQW/raGrqRoQZTfc0t3UiE06MGCoQ5IRqEeRi+1oBYMlJEPIHY99BOIz3RWqt
l9QIoQp6FXymmkjxdBMpHtXAKp7xSAM9VGYs38jalB5mgVLXwzU4iyUt10ulsqgyWaioGqRZ8JcW
Q+sH9kdSWO1E1orQce++4WIxFarhhO26QMUf/DqigQN6ZE4AAYImRwALCjQgDVT0eDluaQ7boFII
M3IRYBK8b0YsG+F2BrGyRpBqdL/AA+So42R8I1+qeFbcs1BGyqY9MY4TpbW44ahoEtuoBeNPi9Bk
FS9sRawMGS0gUXaz2HhpeDoZNaYCsRb2FZRKmGvgdjn+TRlvcQ8OtYcMhSGJdf4t0fpCztf8abSK
+//xpxF6/s79y4tMC2jdujpaqzHlfOLBhUuzUzsmz03duXD5/kU31zSOm3dVbUn2BitsdgcqJ5As
BtVO/OwH3//611/+ESDybQyJ3/nBt3zqo+9++Svfjkm7V3z53VQgfhjyJ4gW3/359734Ux9+20ff
8oYPQLj47Z98l1DF+5/fjY5fFf4JzegDSoYk1HJKxHXlkFryWNisrzXAnZQnbqgmua7HIIuYWhES
KOA40OxtJlSFDwODYJLrka2N3X37Grv2t5SQmVodyNJQPkmkFbgtSHW1KAZrfqEZHaFcBLM3Aq1C
0i8gW7tLBMfc+a+Se5ibMdQUW8o1B1kEHZoyNtCqQ/Fu25xG9y1Tz1pZq+jH07Zn64VCBWsiSwUL
YWVWj8QYIcMhxlLY9uCBWhDK5+bm7r2dwwlDwQ6MQJ7BC34OhBoNNFHCoxmEZqB3lE0KFJSYns5X
4hDoo3ekAJSOimOqnPhJ65oBZQatH6BV5ihNhPG8wZV4yUT7aDxOnTCUHPiFUhHVMlSBVGTgMVyi
RuYgCQcBJ0axQcTLDxb5ULomW2mG+TFVh1rai7d7pUHPjIUgAaEgxAq4dTFxBbliCfjh/6P1oad9
12IgvLwkvHXV+tLhndmaU588M33u3MyhY4dOTk5emr86Fxt94hNGtKqqbfHWI7vHx1F4EmilNXj1
Pm3u5vWffOPbX//IjU99EBhFXekjH/gUElj0WG99+RWf+vAzwbLvvHXj9QyYP3zjFchtP3zjLW+5
9cpnfv/H31yzmzXhvxQJc7RzczuLmGHu3eYEl0qxTiKONFYJ14a6KOtl/QjkuhHqCGHyIqZB8dEI
it2wnlcDSQTPZrLrkSNP2Dd0sLu92Klj6bDfDgYIhTVYyTTUalLtNjZGIrkuzOYMRZgqCm7FrQG5
gt9ERZhFVDAZIsUYBbLBjDYbr0j8AVMuaY1zICeJbctJpK+2m8TGuXg6nvYTsO7X46XSqKHpoB9V
M/wkqDWbNOBMJlomnHyJ723CCG4r99WGMUQQwBT9miAUXqg3RUP0KTQcjgcYsgnqs7WI7RUGU/GM
DoyxZ6rqlOSbigmEpi2dLqksNEElCTDFqOaNmR5I388jvHVBiQaPbcK7vMvSTVauQduBEIuJuOfq
iZFUKlks5gdHbdtLJkupZIF+w5ajITBQvVQuXi4bCLvpSq5SEi0I5OFQuAv/zv9H68JpqKoaALUK
bcRSICxUwquidfeR9WXp1NUzU+eOzhybmDg0cfRl06fPPlC0rt5yFDNOxfXjTz38xK0HxqGfCKj4
QKt66vKZc1/6xjd+8Nvf/uDbX//2t4FJ1JHeRn3Tuz/6hk995J28Br4FTBEkv+EVN96GVi2++PrP
vwu0Pv0v+jKBCrkqzgZ/0Nk6hiem41oRSOa0JIJPbtXX9je2oD+zWezUaGzphvYpUBESo2KChQZH
KDIhayXNbgazkmOb+D/Gjqp1dUqkMy7HZMjbg0UTWLa8jSlhJNW592BfbLsYjyORBePfbHPiwFcb
UGWqSpAiPaRvGKCbMfWkxRoSQJpGLAgdrQ8YIFSki78H6YRveX664pWSlULcVHRHaN4RuSazthdT
AAqo4mkIgxKzPQQq6ko4YRAraZ1wxQkCYXGFZaZtXJGMNBg9GuSWOuFnlEa6isko7SxUmqFx5Q5m
9GJYA+clIK9S2IXV2JWJoM1KykQcEE+P5osFNw7VFXfSAqA2IG7GGKnbINeoZSItTcNs1a6MtPe1
++URLP6CqB9BSaWUNvA6BI2EysS9MjyayKVtVYtQygRll7eEVnZcGQp3FauqpH8IWj++sJpm4crH
AleWp/xSLKR6FGVPFh4t31p6mnFXBk3Qli22epFA65PET1syR3z2Q/f/Qw+GCJWuIBBepo34k9z6
9PVFZdvVC5NHD42NHTq0Y8eOsbFjL5u8c/OikcxG0SHYc+SpG3rzg/s3Ea0C3odb1FOfvXZ8Zmxs
anb2S1968je+8Y3vf+8HP/zh94Dbr3/91gc+8HnEvFAgorb0qVvPfOVH3/eK991CrPyBGz/8xne/
Oc6Rgb/keYizGdPhERaD8QZdnJweTgRGXWgoKI5WEza7mzZsFMtu0PHoOUj/heDvJFiZvIrl6hQK
b2D+yosnMm0dyOXgVo2t4GElMaJA7SM8s2uwTE7COrktDWCxkJ71nS1CvCSam0vjaXAErUfNhodh
pGo6SGCJ1hhqRJiV8w0ueEokANUURsriKJ2mvEQ2nrUsP4nFG6illjFoxrJSRgUJw7FXd1GJl2Uv
6dOHF0RpgrLNtp6WnC/DeTyoSeOXaWCzlxks3hq2k+ohWJZRATJ08KqDKXeA1E2O5PJZO17Qolx3
zAFyO4MoOcLyVgnsKEsSEmQN3wEulBHc2mjepEr9oz5HhqBCAmBV/EQF5Ag4ltI+CDWmZxHsxoBs
u31oMFHKD3eWR+En4btGKpkyqOKCshL1qXQhnx8Z1LmOi81W1N/SlQCtTQ+Fwl0glPV/P1ppCvrT
3rcAhMDUdzbM0jKJaH1L1Sdwa9VqaKVnyxfWfPEt/Jorq57zjiULww2/rPq0kOZW4bznM/xpNI34
yoYNn6uqWrr/H3p2Mw5eLRBenVtJlZ2ZbXPzl47OHDo0tiM4hw4dm75z/uIcpGtGcetTx9vicljv
ZKFJtHIO90bBrS+b2bFjYsehk2NjX/rSl/DxoQ8BtcDtDy4/uPG9738duP0eCk0f/PbXb914w5s/
+O6v//B17/rtj775WuGl9te4f2/cvFVRKJALQYyA1W5mDAksdBIWYz+I58I5LG+l3GEjNLawgOAf
yq4MCBU92IVhlsCXl+9CIoF7mvoMuSaihcGmISOLfcS4Vk+dARaf1wiVECCJck2GuAgiYWKV/ipk
NQjnI+zViNEUVFEQ7tEdLatzzw0mPj3f8ONooriVVGKEbckUuDOO4BE6iRTWbsAfvGLENBlCeR15
oscEEyGlZakgR02iUYPJRpCe6yw5NcHEDX+NgFKDDg5thEXvtSFMSjVxZLRZbA4Q+MX+YgFkB1Ek
fgwnDjLQ4aMprFumX8hyV0bGcQIGZzE5wbZSoR1l3qjFv8XOgCV1hz/VxlL3BOrYVsqJpS03w0Ug
xjBarMVc175i2Uhj+6WfKFWS9IujNMQxUvn2oQIM1ijXMEHrsD3UBVqXh8IdVRAg/r1oJUbF56ct
K+a+lExImL1oJVp5nXcKqPNWuoI/ZWUk/IzFn7742H9KJMznfJ+g1lZQ67IBnFXRikbrgXLNrrvX
pmcmiNXggGSPTp6+fGJbKDXUfGTNeF7bUhXOj3MP8+6AW5G3Hj22Y+LYsWMTALf4ppNALM5PZi/M
/+x75FsEyj/7wC+/9/0fvPfEG970vZ//4mujbb9CD/evQKugQ1jta0pgQyIpHPPSJdrzSVhk7Dlh
DGeWWYvaEKx02tnWA2qFPIJopTZicWdbMN/KBJaQxbROb1JCSmfI3OgEjXttLXfK4Z2bibFamYmh
UCs1MG1l0hiwKq5zDj0EPoVyH8ylRhyVQzYx6AvxjooSjEkThUQpkRhtL5VylXKpMpi0kkCu78d9
7MlBVFxKFIYNCZM4oukC+oGTZ8oG94G3vLitmch8qYWKRN2SWb+dMMUHD66xwRREwzxUMyMxZTka
4KYOw7TTiUp7hflx0lBVAhImowA/DljXiNtOREL4DhWzIiRYdLOwUAWulFN0wFA0aA9ZLcuozLZt
P5mOQxfFLquLvg6FElaqWC7kcu0dRT9dLowWynm/5CfLccPlAK9VSA0Psi8eCgW9IcQcGSElXQiF
A3Lt6hjAP/XfjdYXEn48j6CVMCU2V6KV9z734QeLh/+JvPVJ4tPig/4ZaJWqqhIdQGsgjVgRCK9A
61PXHG62tzV88vS5sUMTglZ5JibGxiYnT8+fUDvhLLpmPFGza5eUG2fYLHZFdmq3508jcsajgdKT
E/g8gWuHZiaOTcxMTM2engbgQbhj189f+9DJD/3s/txo4ze/CUtRIWr8y2hdu6F6czU6Mx7RSlfc
iKPQ8cuOSFA1Zcu+JtU01Lk7MXGDpiuD32YI9MWa1gVrTyEaDnbA4jE0v8fZCtFFU8vOshThemHO
ociuEWxHBExrFblOtDLZpMGtDQsY2b5YiYUWAUE5WzUqVEsRLqBC+wOoQ4PEcNNc3ZryE8jmBnOl
ZGGwkkiVQafxUtz3Emm0bFKlkWIip2sZ3fd1MKmtiFYJ2h8yEkgHsabqRGjXoIIUDd+pQ4uVrxh/
3HAnmJYF6iB9hSMT8lX+PpwwEHKpQiKRS2TtRNL3MqA3jcUw3RTWShaQyDVUVE4xraSLN2b4XAPK
/Hx7AT0XoJWJK/6shANwWl7K9QppS0URDIJ/jyUx3e0cTZRHRtuH2ss5BPWJ0cFUqZLKF/wEBMa6
nsyPgNeRjYfZ2+ILW0YL0NrIUBjk2hqQK6Sx4b8XrS8BTy7y7PuRai5H63NXQSsxuJCqLi1f/pNo
FaT9IQWP+eegFeW2OoJ1URqxLBDeugpad6/tVLfMzc8eX2RWgVbw5cy565evJpoA0CPxbVUNRhvk
iEAapBIb++WLF2aJVjyM7/weXpvAmZzYMfalMZxpgHkKTaFzp8/frx9pFE3bNcH5S2jdDLACrYe7
NBCgmB2JWsJ5vl6yYtFUwZIl5p2DjYtLT5t6W3aiyhQcYBLAFQI+4aUt4LoJHxiWQ2O2qKBwhZga
O5skuyLXBAvCsTAjCmYlDmjHr4TE6A02auCz8Hoht2E1OtqKRpQjqqQuNiRNGxkbysAp8GoqmUuB
XfvLpeFcvFBIohbju0k/DV5N+nGvUo6jSQKhRArgieppWJdKkioECTbzSOCLb5oYPXPsMDPWwL4i
qDRt/+NUEEkXRE8HQjcGRDIPdaNpkPdIPp20kDLrjITxC1LwC4yaLjQZYuFqlCb8coi3R4RZFNZt
5TsKSDJxTNe3VYgdEPkirk/BYyrpAqJpGwd/sGOAPP1UudQ+mCjkUrl8fnS0nBjJl4uDiCCiTjpf
SMfjSOUljTvrTIUGOMGYxvI6U1cf/A9L/zi0Eqp/HVrph8a7WD5arCD9abSytvTPQus442CgtS2o
MT0ijVgdrVvb5S23z08dHwP2Hj5jO45PXfissx/j44dT4YZMfv1uIUEEWptL4fvXpo4Cn4+eMd42
MTNzEoRLyB+bmZwkWsPlRm7W2P1XevVXb918ACXh6p4I1xxKFApr1AIIXbpRKiC4o7tQONfMvip7
qljzuBdiPaoPgdGAWxc4lqwKagVqYX7f3NRTSKVkmcUriSAF6mvxvG8AQLEFnXGmiHgbZEUgQkyQ
AivACbkNfkyME2MIhjl4krFNOi85NsDqepVEueyX0I7s7+sfGYFMANI8mpYicfVThWLKy6L56qV1
0BgwO6LbSDCzqgztIqCl1Ic0OQPQxUCuEjJER3WNsMiVgwF0UuyuoD69FAgDpTHA29Q4VIp6kV0p
FRGRZ+MJN5NRkZ86nDpgok33KMzlBJsfZTqUIu61kClrSKwHS3GTDmkRx+cwPRovcd1FwTfrcS+t
7aJFI7ziTCueQySc7xtAVXiov7+znM/nBorDlfbRlBU37HginkqzLxSqCcbiM1pMW0Trw3Wmjj5Y
cjb+vWh93iLOxI1/FVqD1csr+zSroxW15X9OJLwE1v1/qsa0dfPKSPiJeWnL7Qsr0coQd+rsZ/NN
42vGW0eKLWvHAdVgC12HfurqncljQOaKw7rysZcdxzl6FCkteHby3KX526HBTU99jB1zUDxsBWI3
b2hjFSjMIBhgxTMApChbFZ9DJTRAkNrIosHytYPNwV5HYjSwSuEdOMAzsBoks42weJH1sq5HaqFZ
QmEJaBUODFzsv4WxbxDzAsEhQWcLb7gW+H7Xc6sjev4xkJLGnoWwikhbBjagg1UhmxU6n9xgheWk
YjleALFCVZss5f1CAaL4dBLV2biTHSkVCjm8cGhRKj+QQ9JRkEYMOs3OZEdD/Oqlgp03vBCA5edF
gQSCgQgSUwTOOhJEVYHGdyRulfGKQA8Wg20mh+IIiq5opoQqnRwW5kkQ/POTGtRubVB+wcR2DqBM
t7KODSdVoNXIFhIF33LKMFut5EdMDC0YtuEXBwdyff05+KPnhgfLxZH2kbzfPjxcRCMH4/ipcjyj
cPOz8KPAUQJupWnsUp2pDWjtGMK/9ta/C60vXbj6BbLsn0QrbxEw/Tg/BT8D9xGMK9D6okfR+hwU
nJbQyst/aDk4J6h13xK1/lVoPbGSW0mUx85dunCtGSHshubGtUEUS8iNj8pzn5xdjVongM9jR3dM
nb506fTs1NjMDPLfk0SrNLz5cdB6YDNHUWlCqNRrYZw6kCr8b6lBjA4WXKrpfUOua5CKMBJu3lM0
uYMKYb9ouRKz7Ljy4EseYXiIs37PziHMo0CuU4sUFWCtxed1aNFwCTogAFTysOZaS3/+dYLDArRS
QFQjaWy42Oh0RNmSxIdtCeFSKj/KpLVS8pGujqIgXIonC6VC0s8m/XJcZ0iZViUTPtowHe5HIye1
f19/HsUhNl1t0CBQColDSIJLOMZjNM4cGYUogm/ya2Ax87A3KSphNHLjSh1TExUjG8QaT9PF2EZ8
rlOaj1ZQBkiFoRnXqcqQbOJG+pzReAllaSPKASAUwgwTGCN+sx5S5xjiBSNlJf2RbNqx4pA8FDdi
ZihjZLPlYv9A+0B/vpjv6uoaruSKgwgiygMD6NY6upcoVwq6ArFyYAClUIocoPVhcm0NyJWVpiN/
VwdHcORzAMLnB92WVdHKbyEw3yEy1Bd8IYAdL6oE0T5pzTL0r+BWbrjif2jp/gWC/tgjl49fDi4v
UesK1SHBuhKtu5+Yk9bNvR956yPoYzI6Mz07+8VxsOmRIwhjF4vI6dqLF6aR6E6sgteZc9Onz5y/
eXP+wplL0zNHQbUvu/T+23Lb4d2PtW0ZSTYXsHagNhutr2f2qtE2V5L1YmHAh76pvX1QrqnXpDrU
itCD2dlIR29SKvT8eAc2hVBCNHXEe2CksqeIbw4rugkyxSyZPujFtBo0cfAlWjckskAtFOCjilFw
MDEXMG2dhHxSVHYoeuc6YtNGXmdhm0YStifFcjJRKlYSBXwGPP0CAOxXECJ7XtqNatAWJMq26xfz
8XJ750DHoOXYcej3XJvCBtuRVctEwmrFGKYLO17brgs8ZvjBCdsgNhfsH5IclKOZPVcUGxEn9Y6G
BQ0j+7gOSriceGMcTNMXLq/ECIIt4BrMpwPhMfAu+7smujn0DI8gsndB15Zt4W9KJIYrWBvt22nL
y9AEw0r7ZVS6B/Jt/X0Yn+4r4OUo15koQNmUz7oGVMOFhGvJDBZCnC+gRjQSCdC6RK4icyVc2/Hv
Pf73oPXJi4lncOUdq6KVMOb5vUBr8MjFW5c9B0WCuhytzw9kF7h56X4egn3Z5eOedVVV6aG+riVl
xLIa059C65rNHdq6bZcvnTu0Aq0T4MqJabRIl+wkeKW6JbL9s5cmj65EK5qvM1Nn5q9cPIFz+/7V
91+bnZw4du7Mg1OZvU9l1vvXopX7qtZueuLataUwPBq4mbQ+LJaice12NjeqhFzfsLKGktNr2Fap
UfZsWt+9F2Nw9PhGRMwri0aCmxgqk3Dpd+8rNbWKq0p1Ic0FFXR0thfzrqEgOw6J7W2BSQTNyYiO
xV4rbwRm6+iSSx80RpiQuhMWdtaKeYBJAXqIYiJVKZayPnQQJhZEFrxkGoOgo0nLljXTSbTlS34Z
5eK41Z9NFcCEcPbHk9yhpkm2dMXJjjqIh7UwV0mBOh0jYfGVg68UXMTDwyaw8F3EvF1QlLJpRKiZ
UD6mfAMaQRf4T0I9DDgCqTI5TkZPOAaIxjGdzkMDJ5ArMmUN/xEVyiYOCagW+zRIhl0HO31S8XKh
kIaIGbosO5NBh8hPJIq5QqUrv39fR1tbz3DBT2JferbcnyqNDiSTJoZdPdsJ1nfSZkbi9qIArQ+R
a+8fyXUo9/hwFVHs0vkcdAyLVwAtXPsd9yHzcb9+yGn/SSgEPwe34Opbqp7x1QV6XLYUkjco9OIP
WjcEttgc+ZYq5QvP4c9cuH/x9/jYssvHH7xxhlZkrUvU+qfQeuCgvm7dveurpKETIg+d/tEBFJaE
rD9A6/pK+MT81AQe/yhax06enL12+eKpUycuXrw9d+rFFy9fmJ2emYbMIh6UqP5qbqWUCetX1+5j
dCgWtwCueJP0jKIaJla56tHy/n35XlNCMBtOdEMm3AMHcBH/opODawyIRebKxJZLloUvWUtcqg3l
u/vjTjJXGC0VB7sGcwNxqFwjGVlqCIBJfuViuV2i/MoOjgAra011ikJpBEhVZdWFO1nTaNvgB2QT
QdpKS+wkxEtGsoQmK0QFaUyXJVF+NSp+cSSV1KFzdyzACpPacEEC66ZSloKDbRgUR3H5JZYBQAWC
ByiIUmsCMZM4xGswcguLF5nSR2bwuFDMmG3p6WTFN03Ipmw1pfMnqqocmPUDNvSD4XhfOCx8nHgZ
ZY9FR4TBsXEZD9dsw6Z3o2fB3hvqjrSdsgyUtW1g37RTo6XRxCj25w0ODXR2t+0fqFgW2jlWAihG
vp7w3LxLxxuSKxNXGZd6gFbhOLWs5ypi4WLV/6gHIv5ueSAA61JBeAW1rhIJj29Kb6m6D3XESqYU
aJ1taxpfhBrA+tSWzNyDM+fQXyUbL89zZ6bO3j116urN89fOXJv/7NyrTl05P3vu0idPaR1r8Z2P
gVZmmhvQcN3Q1FNWRE2pht7yYclBv0JH/8XRyt293U15STaMePveJ7TCwbOnp1n8tYAl3nEQCnNn
a+AhHJyevFbjNsMTtBnX9+xp6cLux844+hU60Cqx2cpDgQS9XXiN1wV8GYbWKzoKrSBW2zHMSEY3
Pdu13CT7rClAJYH2KoQ9vp9ys6kSgIjYEA4Lrhbx0nYlp1MLETEdF0JaIElBF9nwswXXc4AfoEgJ
sZZKPIFZ4c2LW2MZieLDP8I1eCXBJVaikw0XzM4irlgQZcSzMT3oBiNZBUa5HINj53TSxxv5lDCV
ZLGLLvDoFtaEqowrSMYBLh06YfxVEHtA4GxwBsezkfUiQc/lUtkS6mXxQr4V24O68uU00nEL1hUo
E+/bXyx0lJMOnSAJV2H/L/bvBCs+l8h1KRYeEnCtXvM/d8CsysACtbY+Qq2blqh17SojOIfLdVUn
zp8+eixQCR/i4TWKCk8em7r+2dFN40+nyRrqRFjC+oRC3cX50y8Tzdbl2J44eun81bm7nzxzeuzo
0aOz199/8VWvunJ2dv5ufeqJ4wvGbH8dWrfit8ZAavWBzZuru03hglDPFRD1Cn03XbUGlaJoqlho
M2Up29Hb27O+E5ur9oI/RebKrhXfOXIu7MjEKmWsawVEBy0tR/hycysf3NTTu69QwcCMEw1hm+mC
qQswurAAsoH4IF7FW0hzMg4kEagFY72cWFiFIlMWAW05GUdLtVBEDyfpo0BseBgAzUL8m0+oSHMT
kO4mVESHcpTBZsTJGAjHXbiMZWxXVRiYkvQUcpJE49B6YXlG1+KaRbDyNKxjBxheh5LYRkXuRA8I
SkaX7V+qIRQcJ0rPQ1kVcS8gCdiQYRVhJYyLMErtIFax2oZlLfooxWJZh9M6UXq8IB9H2Yr+37pO
awg8yPQMpOcIICyv2N7b29lXHk0UkyaUWolsOVkaxcidY2k0D+AbB6XE/tiAWx8i126idSEWHmAw
vHHN/9hB8yoyvADWQMa0OrWuRCsQOKzsmrt5ZzlaA8BCgDh97YTZehiLNnhgIXFg2Gy4d3b23KPM
egg5644Ld088ODu7Y2YHCsyT06fff3vXqZsXrl50hsZZpPrruZVRMJWHmMR5YhNkbWi314ilEKoE
osAUjh0LgRvoaqTE+/bt3Llzf0f3zu69e4hM4JOoFYtuNgVL0fGi3rOziUXjg12JVDdbsAvNWLiV
9vR0Dre3F0o2mrANAZECD4Hib9dCWBz0UFhlQtsDojzwDevCluUBsK4PYQQ6qvECGTYFtMYxMmqA
6bxsKl5RJfifUEFB+xPWYDXEsHHbMBwNzoTMTu1MJLbgcUaXDOGi3xBSiEYcJVgpJ34dIQ5GVg0w
i00ZIYkPUPhYVcPMGsAtMzymDxr6uBn2hcTIkgiJ67UIqnIhQa0SiDeKO/gDWHgK0R0ZvxoQilI3
pQ0ZpNNUU5hoBiH/oN7fiMfxF2LkfKCnZV9uZMQvxBPpQnx0FFqoeCHpckouEizSYb9VkZgyi2Bp
kVxZaHoUrr1r/pfOU/EXq8MDi2BlHPyo6DCg1rWrzbe2WrXb7509fhRsOYH3pYgYrdNj02duy4WN
f1y+untrq3n7/vnT05Mr0TqxY/r8lQcXZl/2suMvexnIdWby2r2GV128etvOLWatf22/9cDaaky6
4X0r8NSSR4DGukjUVvFsZpCngSMobqoL2+XWbuxk7ajkqIlu5gpX5qc4AXLJn/ySW86aG5t7hwdb
1wfu/LyHXmWt7eW0RfcGRQFIapEyojVEoIo6LMmW2augVmiJFRu6I3RMTcOE6MezoTcELOHUGYfE
MJmCJ0QBXZSUR70ERrWRTKoKxBh0clIMFwg34lYkA5h7KciXFJNtSUrvpfo6smC4Plh7wWxcVmjv
CHEI+zVImvm7BFl1bUjV0UbSJLHR3AiYE10a0+HKZFAjS8qqBJ2F2LVBo19AiB4SgXs/2yv10DwC
xbiH8SruV2LAJPWC9FDLEK06vlXWHYqKHZXJrW2nTJ2C5uLQvmIB/dgUCk1xH/KKoVIinzKj7K8K
dlXEf4fLNRbRSrgG5HowaLoKuA6zMmyt+d85R/D3esOrxMErqXUlWkF6m4YyW+Yuz05OTggELqL1
JHwkrt+5/sn7ct+G6gMHDmDeZX2/NXf3/OzMDKj3UVkEBMJnzp+ZBEd/aXpqanps7Pjp91+sqnqx
OYCk9THRevjAgWoE79XwSYPnScGCEkeEdBK85SXhUYriLHcZYmZkoGfPE5o6sgkstcHe5CYBTgAX
PAs0Co7FLvQ9zXtwI6pMfX09YreMWOgGZm3a0zuUQx3FAr4MiqXqaqJJV2oIwMo3Yd3LwRcMv9bI
queCW7Np24So1zOiLnyI/FQJT1lEwgmMZ1tuyk/6FruwhfJolDQXAewcHUojrspJG6pnY4LOt+gU
LimOAt1SVIN5BVUFeKupr+W2RkzDhQjbmlCkDiglWgN+F6MFpmarwbYaSW0F3jhrR0BRYgVvNjZk
lCgE/GKZFAUScj1v0fCfkOn4ipcCHI0VKuKKBSGFykSaIwpOp6+bkDlkhPWUqplcAmAKhylMBHYM
+RbchN0E5PyQTBShTPYtDA8Ik0VZo6kb3/GLRYOWHNG6WGhabLqi0jTcXwXLgzX/K+cA/trSIlj3
rV5iWqDWtatOoz+hUr8Nwt9zRzEzhxh2LDgTR49PX3tw8+y1T9Y5hb7Wffs7chUvFrl84fQY5m1W
NHzwNcZdpzH1eunM2fMXzsyOHZ89fwXi7YEniDn2x0Er955vRgOn+vDatdAh7c1B/B7Y9NGuWoHr
IZ/I3AqhyjVmsXVPY0+utP9g8156H67fA2gi7iWtNhKTEDAhBsaBl3ZPW0vzE4TYX4yuE9i9rR35
EpCVGrFYZQ3XKKMDEQ7g8AR1YUCX4IXtNzT4CHNpB4w5NJqseLbhelayXCqn0gSpZ2aiqayBR9lQ
GbJ6g4EWh9MrJQ96I06vydgaSe9vE8a7EBnKKOPaMZaDFPxRYewqj9bhNDSEaumnD6oPi0CYFzjb
QP4h7jOmLRStNaKuRkjSJxXEGhWztirv0dCEDdYg08IJwFuoMVHNiZ6zzBIxM0xSLTujLA8JAxsB
V0bUvNOMEtaIKIJXAt1GaJFM5JKu6yZcqDFcVJDLiUS2Egc1xwB3MHmU0z/Av8S8V7TkANfFLs7y
WBhw3S46Of8Tp0gF03KwLuveLKPWtasuwDnSa9WfQjIKXS8PmjP8NPOl09cuz3322uzZK7djHrgj
bZlXruDryWOAMtC64hDfl85ceP8nf3PvwSfPnp6cOntv17ro+iNr4B/+WGg9AOkhxEzV1bTirwZi
PcyMy4wR8fyVNMTBElI7ho2Eb42ZOtjYVmonWvdiEgf7WPH3443BcMCgXJwO+QT49eAeepNyYF3I
npDc9u5r6+rD0OZIHhyOTLKuJjEoCZcXvPGddmrsnnD3spKxXD/uWvTdtenrYjh8+qbBuF42G6cM
WI8ZWRoYoefJeMDl81zW8CjEkyj/wOoI8EyD/zQ89zXoIjKmaUQkxLygvNp6aCHx3kD9MncU8O+W
WGgCt+JAzbyljoyIdwGzEOMMCUfQIuJb/NyYWOSMtFVX2PLEXXgQfxhxypcEoFUKPPxJs6y44y62
ZyXhai6RFcVWjnpKMGSNvWWday85y2NkMeuTH8p6FhpQOnXSlssRHA8wB8WzvWtj3ifAPAAcoHVZ
LPwoXGP4l3/imv+BEyZY+x8C65+Ig0mtq6MVm+QO7HNDp+CiNjV57rhIOqn0nb4+f3cO5d/J2bOX
r1y5f/v23aufnT97afrkyUM8K6CKt6OwnLg7d2ru9sUTpz57dmr62r11dd7m3U/f/fhopUy4ei1D
YVxsaLHksMJnlli7pEmi92pD4CYaO1D6wxdlpOvg3p1AZOPe5j2tWJWOq7hsYhYL4DbtRJ2Jy9Cb
uGWGWSuFiCReBGUdQ/nB9o6+wRLU65GaGrdUsyUsVAgCowttHXJrWPJoJIbeJhs33KLs6BxU1bNG
2jCSnp0VIyuuRfPguMpAEOMsFgDnaAguHdPmEACU/LYc0g3TUY1c3gbAHArhCVMCdTsFzDW4AisL
cG0drFm2CZ7fVseNWpgDYnwrLyKV/CibDLiVMGrOtHXjvRE4MbLzCZ6tB1QFSCW+4z+CCCXMLqzo
Y/NVTxTtgn4QYSxTiCLxVklPmoYUidoaonUcU0fOkMh6Prz6Ee47ppnJIBpGqGHJqsatkzSLMtLc
fYlWMDSPAq0CrkTrYuq6KGkiXMv4pzfW/Lcf1pd2tQdgDURMi5LD5XOtglpx/sS6qsN7yqG5i/cu
37xw5s4sDoLZ+ZtXTsxdOX9p+tjJ6etnL5yfp33p6WmI9YnUQGV49KEm7cTYBIRMn5ybu/3Zm/Pn
b1757IUpcOu6sH/g6ZRWPG4kTKSCVTcDrUAsvYX53GSfkIZCEsklKqnh2ho+Vetqza69I8mBPXv3
7u+oxNH9LJWL+Y6DKCsxxGC8S8fPZlBsc7B8vImkyw8scm0Z6Mj159v2dQx5poFhlIaIGXgJB3il
lEgwLdEKX5Y4B7jTFo4XbI0z6MzvoekK0widUbKLG2wwK+J3zTaT6QhfWrjCOANwZ9hmVcSeU855
J1OIiCOkSVaW6hD8Akq4Juxntq8Dx4aRmoYoWgZW8TvUBg1TjiSxBBWWg23KMk28JS67A+QYfBC2
JFUCrwYHk8ICsvjpnGUICBl8znmJetwhgxqDDi4SXHwQ8DgSfC5UGsZIEs0dQbUG9BxQ+huOi5QV
doqcoLUsFLfi0C2jWqVlVcy7o4UrvFFjSoDWDYvk+lDqugTXdnQ11v2X77NqwvNba+8XvRtBrcsl
h4+WmFZHKxehj8MYrXbL9lNzVy4DlGcvzN+8d3+uYe7q+aljx8ag7j93bhLn3HHAk5ltcDjH+hC3
ItG9fvPiqbvvvzOFSfYLF84ArVfXhVIHuLfu8dBaXX0YdSYgFodo3YxtU41tnhbiky0CD4So0V9K
O54O70O6V9eALYz9PnR+fkQTqgEuW1Khn8u1NOP1HEUmqCd2dncHubyoCOOaaMZiD3Bb63680HV1
9rupnK6E8AogFqEDIeuW0MryMNoqZpzKAZtINR3D8SzTMmExCLGhD+MlDLL66axrmYYOab5fyqiQ
+2RoOhq1vbgjo6xjhhQXcM2oLK4aoKcIoUEAEk/c/kaLKNSmYemG+SAAlxUg3L4rmEivwd8r9hcA
b2EhkSBcFQ0FJHZimMMyFaXmOMLYF2AL1xGoSPNZl6vlYfYPbJJ1AVWRzcKdReJuH7wQoHYtOkBS
CFBW+ToQsLlKIQYC33QlbSExisPj3I75tqFyn5gkO/hOBcOtJsTLNj6C3RoBWgVcH05dFyVNf4Rr
bRVH6P6Lj0IdP8A6MNSxImldjIP/IlppEby51a8Dt967e/vi3atXr969e/fqvQeX56+dnjwG0dIx
hMY4R88BrEhYF0wmJqYvAZG4BV/wZnAwNIZ3588goD5+bvbS7CS5VUocQEv3Mbn1wGGg9TDjYSJ2
swDtxvxghFQQkrmSPJM1Mh6eHnU1csyV4EMYUpOWplksSuJpRkaQFY6hZvyuFqomANcWgLZJLMuh
cEJEZbhobgIjd/fCtCyXNxPFrCU11Nc9rEcQjRxqEjAYjhKuh6DXszlNrhq2alIiwbYMvEhRcwGt
FwoGEjnPqA85+bzuJjxTVjgXHh+1dDkZ4n4Z9F8zaO8IH3zDUEJqSNTQBJqIJZG4sgwdJlq5GkCS
GkQzidbj4Cx2ZEKEosBqDVNFhp1idSY3ZnJhpQ41JXeQ4OsamNmQstHKbaip5XAgUuRgcXo94Uq8
kgnRBZL4i2DqT1dk0T4CzzIbVYhUdmaFvbmRSutp2y27FhL3iAFqJYuj06pIjqVqRgSxcBrsqogT
2OItj4UXK01tC3Dt728v4Z+/Zs1/6xkXUfDqYA04ZHkc/KfROr4hl6m/ffnCnetnbz548ODe1av3
Lp8/e2YWoKPOAXS6dAhNIZw4Nnb9/XfnZ1FHXujg0Mlpy7ar70fMfP7M7PS5meOzZ69uUQcPo+78
mGgVWCW78mJzsNx8Y19J4hMurGUyuhxBUZWFUNGlhA1hFN1B00QbVNVUA5laRmd3EaGoBCNAv4Vi
JgiJewMl8cb1kBLzRX4vLpDK9iKBaOnt7OyzVK/gKcgbWVpaQiveWWcCWmWHTVSaebvIVh1TtZmI
srHhZrOeKDVV8CTGbGgELx8uHkVvNESI2CMeh4PSaDgE8xMQM6jZd2Ji66JhaSpn0KXa4IhIOOjw
oqS0DrIlwEYLBXZq22up9iWkgs3KIEUkneQ9NHRZ5MUdFAYDLpaKu0VuKxgVF9zLDOImdqmqkojU
OoFJmSVhsUeHzJweSptyhJG2EBDSe0L0ZEHT4NmMgx6V53vZvAUlF8jWcrNRQb98gaRrK4pqvm/Y
KE/LpraI1sW68FKlaTm75hANVz1hzX/lqeBPizwK1oUK06px8Opo5cKq6j5t+4n561OT07BUOn3p
zp07l05PTU9P4uxY/QDER6fm7554/5RAKz7Gxs5NX7+3bhcV/SdOPJi/M30SHZy72+yOI4+PVqA0
YFdyKyVNXCXXazPriti249DYmmshYIpLD9MQFbuW61ilQRcdzTgdrmOyaNDKuC+qGX77HigjWnro
YiocYBZ2jwuN4s4eOJC04YWuNUv7sIgQBfPwksOl3LDBD1RjoyafpzbgSkGe7eq6B7jajpe22HlE
68angilhhLVUwdVdnUJcWU1j0NWA3miYoaaSThgJLqQzMuyU6lAcQ/6na0CVACs+OHAL+WMDMFpP
o+MQY/NgLTu0D0LrIAkoscZE/MJ4gumsBXyCKREQZ6nuBZ7JvaTsOi5XRixC6CIuxrcwX62hLx1B
GeIQAbNpfoPakTWZtTLcRlFAFIghyKaaEcmxqrtwTIaxf0U3NBsiraSH9FW4PLMuDcM2xPlWHCus
AHRcBOI0kutiG+dPwdWq+i9d78rXoWJ7P8Dat1QOFhWmR5LWv4jWp1f3erUnPntn+rioBb8MIiSW
hpGjzqzsqi6pnGbuPJi7eH4aE6xCdki0Xrv64lP3rz747NX7F6+8/87k8dPz97e7rQKtf1PeKoJg
CJq4w2ZTc0FBaVOyfRNdD0cMgrP3B4zY2WwSiWTBtgED7GuyHZaN0UuoldjgkSjhURVvCGsjOUwn
+jpEafN6HpAr8vye3r3NB3vbkx4KLAuNzQUtU3ibGiZmWRKujWh6Mp5CyZPLbaB/gp7W4JKYjG57
tPqk7yEKUEkDwS78DaHtYR1GUiFyMiw0SfOaqXJ4zVAINLQ2hYTKNNAi0Tm4QPtF2kRBAhGqXVeb
DTXgv4qadwNngwIxPys+EcqKGQeTY4kqXlPoDSeIlbM8Xtzi3mQ2ZQBXBrtAJq7iMPCFIplpBbGK
K/iQkGRysq6Go7UoU4coomKkLJbT4dB4DY8w9ZFYEaOvfjaO2rhjGLbl6dFgLboiGrTBMp6sx+6s
CfwHJpYLsfAyuB58FK4Bve5c8192GOM35MCs1BsuA2tQYVo1aeVZxaH0D9yd7W9T9xXHCY3vvcl1
cnu5zXqB29zUNeF6uLaT+iHGzy7Eju04smxkVG3SpGkV0uDFBC+qCtaWtoNuaxnbNClFPLRFKxto
QqtaJoTgbcX6qlKlbX/Nvt9zQ0xI0gF77H4hjuMk4LT34+/5nfP9nXMkFRlZ/uz2R8f9UBf70tN4
l3ubwYrEE6R1eermjY98WvkDJ05dvHbn2sULJ0+evXj93PLlU+9evXlrKr7/yBaMvHrEnPATh49R
WHciHfwcF86V700PQwrsRJRpJWipjWmKBtKz2EM52WQ/htlthocmLGhxQH8qE03UkzEIiq6BQdW0
qkg5YYBzZnbb0/xP5DsTcQM/xf7yS9i/Nkos7PqmYBIKQOSW96VZf8C00BPNF1LDxeBkRsJhqKzN
8TEGRz6lIzUrojlsCIhRsyg8qqoZS0ojfMvN2Q5VLWhT/lgwMWEkYP8Icy44jEQwW1nImp4aHpma
GGX1iCdtkfDCO50R0FOBR2SPqEIDmS9SfG4Vkdhk2rPiLvbuIVdXKMOAMkBiJasOohhK05DMohhb
VPEhlXl2OfiKG3IKCeYd36ys0/nE7HBozvC8ShJ9kx0OQWcxy9BpOOZMIDEd6o70S9Skn7AqFRyZ
n7u6dWVUs5G6EldvCMnh/yurxIEhrIrAujSAdd6HdeMM0+a0HtleC5z/8gYKNeCTjLLlofRD25RW
NoT46OL1V5fh7j/NnhPIOzHLdPbGpRsncXTno7PuuXOg9ca1c1OxXWxs+oi0+oEwzMKstT6BNmk4
W/5iVIHIIAeLjZHjSj9f1Y0mMeqh7llOPFuJckwczsN4AE6sdMo4Yj6pVai8OIOBiWBhF17bX1xA
mmkvqjdYnJT6LEa6zhf3708tzFcjClNMkzJUA+/kRG5Xum7D1O84Bgi1DPaNsLBntVz2ZvIcVnIi
VtxKY7YiaI3MJQwIUhgOhQk9EgmjJhtz3VbE9i33Om9MeIQcG6kwlEYgZlJhlfYztEaMBjhSWRrN
+KjyOY2P0MFEhEgS9VUPkD1FgCWsdCM6mUIs6thh7DTD3LyKURPE4juxiYV4EkCwyuMDgJaA0sGo
30teSf+rEbzhLseF6UFuhxUV9IU8aaVaSabT0G729o8AWlNnsKwhjczkse65GN1s4nAj+1as0iri
Osg0DXBlIWeAa24IS93yf7PG8euM53IMg5fWKCtbkg4qrYMU0+a0Qlm3p4xzdy6d/Eg8/Vy8lRtg
uyGspBMHbM6f/+rCcflG8k20WeQ5cfr0+++e/Pz88sfHP/r0+uRE9SketHtUWlfXVo5elf/Fuxuw
8RoOTOZOBKc95nTTReWklltq4pCOnjWMRLLa78Vz1dow0im+moxyC4irDmDo0jlFs+Pzz+xuMPxA
bpiv8nIOB3aKVjOzsGdfKW2OTK+AyjUNTgRWqi1gUd0sShdwSJBT3Y643EXT0uSxN4qHliiw6yds
DZ8EIE3aXBD8GDZ2gWGjG41U+pi2yOluKIxYwTDqH9hV0/mOtLAOTLBdxcJLDGikPZmh7/g0OcU7
XzJGhyHJJtCRJUcARProWZIiC0XXyOxN5WOwIQdRYdFUKavCJgy0oYAogonxaYTSShPjBLDXgSrP
A5B7wRU6OiIKy+oQQ1oFS0eUAHcEZzBHopGEYehhN2ujqTjsyeI45Dweeg8R8+jxoI5lQ3yl5ezX
49ogrrT4C6/dIazClv+LtTiE1SOsncX7YOUpubW2CG5aH4R16zpat5fN8TuXT70vldMH6fRLNYNP
/a/DBnH84rXzaNf//mkhmhKMhuFoHnwGsJ746Oyl5XNf3f7o1IfnnwzPHpHm/I/qZRJU5SQB355j
0WV3LGjHYbD14lk4c2F7y6LRSLVRSls1+N6SlXgsUeomev06W41OofBBIQGuKFfwWma1A9cPqp3t
+d1SbF1pjAhYMYA5WS0UkWvq6SOTMgCHeIrZD0LLuz4sISebTlSQETagiUYo7iDwtkNwRDAd7LFp
f6QStRQzEjeoWRJZwieoaDbUFRNqYgkn2w0HTNop2C0GwqtqoltwGaHSMolIGEngEdnAAlbQOkZp
3UFpFW1lWhZJNpKq3Nu9glGwqoMTCZATu/ftKbnwXHDIjUZ5ZCyMN+l4SBYVdUIMExPjRBNPU4RZ
fpxZZtiRNAPfyTceWgerJJyeRtgPkRhwYQ7G6xS24FBYUxq26cCdoTQ8VRwFaSG9ZGoRpN+iQut2
n9ZBpmmA66pNYiCv7hDWti3f+LVzCMsrrYMVYfC6dPAgDt6c1he2FvUdtz48dfwEmomuSOpaYO8L
h1funXnle7evnT/31cVThBUIIwg+fub0325f/vgsmn6fvHH5cxzUQdfva9NTiWdxbOAxaPVxxUfA
ineU1nHOxsILuhWGJxcTFI12IlbKFNCmAZ6iWM3yulDcSsS0YnGMjIMocSgy7Xs0yCs4WjOGnCg8
CdzHRXDEjn39Wc3hGHJUb0qx6sLs/peKWY2zNWYYCgNTnxG++3mmUS0U8dAgDc/AX4aBRDBNwQiP
nbSHnaxXiYVw4EYOHgAFeO/Dfh9uK5uLx/p4rm1Hd9roTcq9ImuUJrsbAx++xOzAwtOXkotM+Zga
9x3LWDPsc8gGMHBCUS6FU4S3JIkY+pIJJON79tcdnoNwXSus41E524PFf09F3Ual2DPHRHH1T8EP
i65KvoqBsB6ywK8ct2OTGKaQVQ34A1AjbXFsDxJrIWzFMfgSOWoZ3GW7JvSUNWTDQXoJGa6wE84m
Sj6t2wdb1w1xHWxeW8C1ND2EdWDLN3odG8KaLg1gLQ/C4DXKukGlVWBdT+vBXfGxVzEO8l2YGyCQ
WA/sVe+nVfas7584fvWz5aOInk/4UTELsidPnf7bp598funqhauf3rx77vqHF949dfGTSWXpKZnU
/Ig54WPbhFVxMx3ArDn8Kk89t62RTNZqiCcRidbbyX4vm00sotdgFIOT6osxdMpvRSyTYyPGcLwM
LUcnWLYQFx+uO+7DxmkDYsZJy+3Zy1e2vWAVl8xLs2XMTcN/xT2F/NwUHfw0Q4iisjkTaVmZsxwy
IijGWI4056fr13Itey6dRYJJssQGXBJOkM3w6QqGyiTSOKge8TQUVyocvOw4USfRqTqc1QpHIN1D
VhBMoK0b80tPTqHWy6F2vkViDGrrR+J8SjRTIfD1a6K+8xC/F5VZUAuKigLGbGkhETaxQXYsnfQB
bfBKFRWyR8aDIX7OTT0FHdmngCnZJOiofDuU0nIANn+Qm2GN/6jOsT2GG3IhnKhfwcdlxeDesixh
lD2gbI4GYMoNP2xyTJCdzZaKDUkbElcmDDfGdU2uyZfX9iTtBNu3fHMXYX2yvxms65V1Pa0bdHo5
vKuiLd+5iZ3ru7AAMys84FT8+wNaTyH3xGM2n10/v/zFpZM/Qo8IInzm+IVPP7t06szta1eu3Pn8
80/uXL+GAzjHb187N559Ck2yHp3W1V2rFFx34rfB0dr5er1Xb+Z6rWqp28+hX3zCwzioHKZEIf7t
1HEApurAEQBn+yivdNQreChER4jJtCe7Ok2g9oEHVFyRcw3oK47qzIPV/bMFHMFpFUFrphnksXMA
I7DODCwSXJOjMBImKhFktWwDmFpuWHaw0FVkuLy0hZt4AuUisINr19HQXS3txmqwP8U1LWjFMVLD
8bqZTlqzWVwx8UR0nYVjCNk4E8HjkE//JC1pncYfFHqlW7/I/AzOwyPtQ8apl0wDyWKkL+Ze2Wgi
7LYVE9JqGia/iNcpLGCMNzIbZL0aKV/KOZDHH5X6y95QEgyr+Oupj/IXAl0KJ97R/H8OL4e2hSb+
RshyrXoCU7jinguKZbqyZZumzYqa6yGYMHSjm6wtZVJ+kt9X141xfcnHdW00XOoP8XI/vOUbul44
iGff3gjW+YeFdaNOL0f21EOjt768dPXk+7IwgMrnU+o4A3ox4uZ9uIZP3vjwyjkMhDx5QobSIYA+
c/z2h3dunsV29fPl5St3rn/12UWgf/Xylcm5xZV+TI9cb6WXSWqupHXnU9u3zS5WkVEqt4qpcr5V
q8U6mWKiUq8merE2ZoZ6WYwXNqkGiCHRX4nN/TUxr2pBURQ2EKcusRgJ6x8wrsyizrpv394X5xuz
Vex765lGqpFPTE1JuXXVHCzESn9QNlhRbQgKzl1bITTYtSS3xBk2Hnay0aznRXEa3VVVNAnVUBWl
WQIegWrBRW9eWCU0lHI8N5lfrMfwc4A8yOQQ95Qi/cCTTSL8ibF+Q3I0nsG/K8N5BFYeLEBmV8CC
LnNr7HuXKIEByf4KbaZOpYW8+zCP+ZnfCXwYZak1KA1laEbkB2yBg36hhjtWgs8Z7eyFiE+YETZx
T1PwfE2mwB2nj7HL8H1mMYw2n+QmIGtocCWDVRXGsWjc8qIWhl9ZiVahWdy37wFa1+C6635cB5vX
FV6rM0PS0P8buF7wj8dtAOv8wyrrRrTCJXz4mbw2du4ujpmfepfuCErsuoURdLALnzh5+8PPl8/f
vXnj5PsrTHMa3Y2b5z+/ffz42YuXL+Ogzu0LJ0+/+9HH1yeV0raDDIQfS1vFzMQPOJi+rRRDH/gW
TstAU/MFhBfNVrWfrLS6acMtlfIlTx0hoZSnadxMD8+lXdqcxgMoEMI9wW0ccyC8TLFVUy0XF3N1
Yd+eTGrffLmAad5GEhNe0joysFLdpLbO+EuY9TnCYCu0OUkyK2zAAMkxqyFc0boNJ3/a89jVEwDq
2F+nrZCiaW5QGUV/moQW8nIYPm6CB71Tr8SjQZvqFKLKY8uKk2vIheF14t6h9yn+FhRXmagMVOXJ
+MnpKamXSo+JyATVUs7KiNRyoMEE7yEQh1FCQ8UFXweUNEiNUkTBpuR88ShgZazNYHgc8BN6/sX8
yE/TDtNfNE1AN5nttcCjjZM3kNZk1qu4VoxnndLw+PcrhheJegabK3N8j23hRQpRRn2p3Eyt0Loh
ris2CZzIoU9iNRq+J6/gtSu8Nrd8w9YL96zB0xvBymM398P6rc1gXU8r3o4901fx/+nWlS8/uwzW
zmJn+gp8TXDyA93BOvO9s7cvffbVleW7X3x8AZUa7GB9XI9DW1+9e/H4K69ghOup908A+e9d/fju
ObX0zKC36SP6hEVXKbBYT+zNV+qxdn+pvKtVbbcaZXTtrRXymFjRyONePRkcGcelPoarfWoSC7rq
Rjx1AmpjcuoFLiWTr/ymhlwocznjAcshKEo4Wmtmyu06fDdzXewr9dFJgZNckNMZufUxYcl1SlHs
LHp6ox+2wYMmrsKNMaeqax5s/bVqUmEux2B+OB62zfAc2AiaMUgRyjeVWLaiaoYW5kE7B1f/HAsw
YvSFvRBPnVjyVgZ+IAymI2OMSj+FZ0Fi+bSAKxQVi0Evc0RCGRstIXygYsKNFAzQmsiMmpwAJpQS
NfswK3Q3YU2MiclpVDRXXFB45y2LT1k2G/Xzx9w8zKG0ymqVZWTr3ayHA64eTjI4GDmbtbpRL40x
WZ4LcnGQIovtKn67WLVanE/tmfUj4X+Aq9ia7o+G74XDK/pqb/nmrMEFH4S4bqCsDwEraOX7Rl3U
nmmFRpxYLDx67vyVT659dumGbxLmITmuM7wDCzFYxYb13PLnOPN6XFLB37tH69mPz135+OQrP/oe
Wk7Ak/gRQ+Nzav3pY4yDH4fWY8coqyvh8Iu1WjWB9hjQ03qhtdTZ22q3+vXOYrzbaXUyixV9Wi50
zp/ihR4IZWFAVBQjZgAqp4q8bQiAcLDTMC5EwIrdYpBXLGQKpkDHY/evkIOaIbaJKzlgBL+Dftv+
fR4EDyi2F/WSHpJM8CiH9GH6GGSg5IRmpWNsh6Rrc1AWN1axLJh5JsCHGnWrdhIRYqm8K+GobCll
wBwcMdRxIAS6cKgVtPrzlDnfjvzjA/9JeqiA6bT/pHxa0cvNPz4jeirn7aCHoo+EUQxNWHDU46N4
DZkPZy+miRUZvnd0jsgOQ12pt/IuQMvx9nozHWJim8lgvJuaa7FNBPS0W4k5MHh6toNVi0ZcO4uG
53GYyvpxNiTm8CoDwX+11Jjdsz/lZ5k2x5UH6Aa5pvvldYXX0tgQ1o5vRsLphYNrB1NNbgDr2mzw
enewwIo/G9F6ZGfOUK3y3j2FShiCs3zlky+v3fwQEe2nn3568eINJHlvXLz46aXLn9388vqtc8vX
P0P7iFdOg1TgutJH+MzfPl1e/uLCis/4zMmrl67dXXZLu45BWR+b1sPCK273JhOl3GymnF8sFDOl
6mK7mWsslHGn1y7N4qCbwit7ehIXPQocOsU0EjbEax6BAmBjqUlDXFvRJQ2DIJGTOri55Zy5kQCS
olBbVZ1AhZN0SA9hJncYFK82eyE5U9M4I8CphwmWV3GGfFyEi619FR4JUqGRw2LpU4IuImbLTocV
DK40dcyzaidwGjZRTttmOtOCotFvBcq5w0ZkwNOsfLGZxmhW8M/bHfwXqekyJYBPg1LPJzZGMy8D
W58w0gWBBvi4RYXGVMX3r0VM0CrOfdhFxidC7I8zwW+SdDAFnElhvjG9vAIspJ7b4ECylNSGodbA
VWPHpyDzRiZ2rbEKRxDMGWkbkoqcMHwpcwkMgsxi3mUl4eKIUTiLKAO9YJqN1EsvNppC60a4iglR
ck1ygm6dvA54dYe4Klv+19eDuz5zaCj/eLBulZv1sv1EQ5syXjp88CdHDrzEI96jM0M7zt+6e/2T
T65fh0P/i5tffIm7d28to4MLWL146t2PZHQcyz2SfGLb7wtfXrn74cXbV69evX3j4sdfXF9W0/so
rJzH8Vi0+s5DSutzLS+aK883MI07M5sq1+ulfLfQa3e72cX52caegg5dwuWLNBK2lRoupzSAjdtW
wradMDz+SPfYYdhwg2yC7dNKXPFDUtkZCWDPyLtAD8jIlFbiIRorqMhxOaIjM+ZsJ8nhTHFUZQh9
ABOz8GCkFnfBJVWWqjU+YiQiCjIyCU1aMTj9XC9W0YK1emT3bF3T60sByQ/xBCDVVbyG0zTzSzwM
iHcMDgL5vK4amvxCDn+ahPHNl0wJeuVvZQoX+SIzzIYvE7JHBa8TIriC9gg+HZP4mCLrSzQIJdoM
q6UmZNcdlRpMV6KOTnBsBaGbtoMGrLABo3oVpu85HpX5mG5ymxfHrp3njxwXrrJuoZQr55vF2RdT
i0LrelwfSA2vVF5X5XUQDguvPVwb/+tjOI5teJHTFPEwsK7dtPIdtK5bT1dGhusYdYO3Azuf3pZy
pmcCEYY6weFRxkxcSHrcuo4+MJcvXvjb6dPr/Ygn/nbp2vLydUH7q0/u3lKji7sPDFwRj07rSucI
pob3oCtDq1cvlqv1cmo2ly+0apXMUiVSKpVxxq1QVcELrih2t9fcNGay2JDSsJW2Nc2TEf9wMOF6
0+j4k9GIuFghRSBc5E0yLyP8HamBKveh0z4j/mAN2bYKMKAEUqwhAZyoteMRWAspcaP8QT0dTcQj
NsNsBNoIH1Fr1AMeFFVX5LR4OAvbhK3aiJEdOxR383kHJJHrYTBDwqdAK9a0fAC3pJagEk5+4M1q
NQmef/EF0i6FfwzAiiwiOCZpAY0lJN0w1RFZoqXMiE9IZphrHIvCKmlhJoKxVOnvIq5j+JiNmKUr
fClCiM3zTprB170QJm65jkmvMBiNeHXaRSzPy6KRcqWX6PXirgfnRK1XWmi2Fwvl2YVOTmh9ANfn
1uLqb17XyOua7DB5bQeGuLT/UcsE5/6vX4WhoeT9HdP2PSysgusG2vpMYnyku1Ua8TOP9Ux2RE00
Cq1qN+E5ztzozIw6Z05MTt268/nNj69+9C5Gaqwb9IqK61m4DKevXL97ZfkWEinJ1E4M4xjEwY/s
jmAmGAuR8FOdaKvYqMfzmVyltJjPFBbm89V8NdYtFgq1uqPpExO0wAcVM1SrwQEYM9ykC9NwDcii
cGKGTECqB5nsZB8T2G5kZLPMWGPUCrgm8Pg4G5dBjzRd5YMsnBBXcspWvhPDMvCZKkV1CmHGBGGF
KBGtaczlSUsXCY0H5mVokwqXf7KXdIESFC+IeBJ1H68WNqp5PM9KPJAPoJzCpy452yliCnXlWFmB
1UcVrGJJzot7WN/eT5GHNFIzAal4pqDgVEzJP02oYl7SVGabaX7g92GHDGzxid8uYpy906m6QFlc
FtLiVJf+EDrPyOMuz7+h1wQ7jMNVCEBDqKZG8EKeRuNGnFZA13POUbfpELG6+VisjTQ9mipbiX67
Wmm3S9VyY7ZRSgita3EdeIYHm1e/lOPvXlfD4bW8VmaGuMwXtvyvrcNfE0EOYF1nN9wUVt5uSOvO
RW1cyz1z4NgRjr94JhcI5rcdOYZ1GGtvdnT4peee7aNYeGsZI+PQcWkdrIyGj5+8fH5yxAzxNd1Z
3LPz8JGf/GRg5X/snDCk9SUvnppd6sVa5Wq/U+gstpr789Vut7M4m4ob+ihnJE+zK6BtB42IjQwH
tqymE016sS46bMdNljlVUw8BUpVZF2mNMobyhhbCV4JUPvarZjiNS1jOdWJHC3iFi5l7LXylIDkC
DQag40i8ipuB41wJ6zTSVeGg5sGRx3Nl1KzhALZzhhvzdEgetT+gRyv5atWLlaq9nBNCe4sSU17i
WJrA/Fgsupn4CAVWwuB72S3+EU5nhFtGyaBcSjbkD4Iq6sjPeOvPOlb5KTFlsRVU8hZ/AnISDqBK
EYcwi2uCbdhMsiqxMu6AdUX6qwVQbNXDCls76kYYsYEFz4dmcs9hhWwb+aSYhfOuOdhWOAveS2PU
ZTOf6PZyi+VGqhCvCK0P4romGJZo+AF5RTg84JXACq9tzwfW/V8JiQ828Wz2bf71J4aGhjH+fDBB
4+FghbhuSOsLx7a1suZcopTa9dSxFw5mnDFr17HVWa1PdRX16YPHnp3PdOoR/cr1D2+cOnN6Pa4n
vn315rmZ6WH157egIm6l+ewTR777k+++8Li0ElO8IxI+UHL7swC1W62WS4XWYrFUa+daeRQH5mMj
4zyzAlhRU9U1ywhaNmcDs9lIOunGaxEria4sWQM+G9sAl6pGNaWyQE8VGur8E6GI+AgJcy0qoGR0
yK6A4h+ivI0hWqWQmrjOxyBEkDDGkTwkM4ZjeNDFSfBohDg8MW+Y/vZ1Qgk5thVPhpHFIuO6jcuN
G+5EJN+uwmbrqDQ0U1pBDBUaf6YkzcQ5sWPcpvLPPdshZZa3pJVDtdgITZoBj6y4I3CX2HGfKV5/
Kjy+Lj0j8AFUklYxYZLeAD9IagoiyxVQxCyM5RdyQKs8ysN0dkg15uZUUwecSbZL1gGqZVimHnFc
J+7Eot12p9ru5vulcj2fypQL1Xx5tjFbbC067lpaBdf1m9dVeV1JDj/Ia35VYNuhIVn6U1v+2+tY
fMhfmc2/Z2poqDxowvQIsHJtlHPevj+pBu1ku/zszudigbHYdlR1uLCTfa4dDD598LtHjhw58HQm
qpy78tntU2egrutovXHt6MzRX7/11p9++9bPjo6atdS3jh0Bri88Lq1cZPaZRKaDmW3RaCzfyVWb
7dRCqVJvpmYLe/KBSRZZR3X0Kahk1RAcgKqbReJSQT8+VjRDSAMHPRMeQDsS11TpwEk54ggd/MH1
yM9I7Pg0azAsgqwc9A4gv4wtqLQTRloKMEgXY2Z1gkBBpUAxdmYFFroIq+CEgn8oDjmNuMFRlmCh
06z2ulZoRJRPCeGXUKwqnFf1Mn4HVw+EFfA2zkBYLIewRNAhzEwXZBaQirBzVOs9XKdXo3N6lmlL
whOhFZ+KKP4If4wV0dX1AAJt9vxm6KvGJSmF8Fn2u1gkm0Gy/DfgO6iUwcwUaRFY/saSI4uy66F4
JBACoxJmeHMaIhjXRhWbrmAvEanUC4XqYqnU6ZXK5YXF2Uwzk5l9cd+eQrObFHPaWlzpGR6khtfJ
6yAc3pjXquFDsqOx5b+3ngaHXCMV3LS+9jr34+CHgpWcEtdNaCWux7bvLdcNuPFC9uh0qHhsCzjF
QmT8REsd3g33IA2Kh781Gxs//wnU9cw6Wt+/cW3y1bfee+ONN978zTsf/OzoVMBa2HoEk+kek1Y/
Et56eGujtthO8JANysyZYiaPVqK5WG//nkxCHZtinigc5YbJC1sRFOirtTDb6EPR0O4FhUKORsQ+
zDQsRMmGyaPWgqcQqfLDKC9VGnTZUkFhYYcTYsQ/gEdpJfIfIghM6hBY8CsiDSihrtRlfAhgS4d/
Mp02IpDxaZobVMMlrgEdD5DxSCudbeR7+X61269XsJXuok8SfpipaAQJnBQ7DnFlmDsmuWhxUDHB
5EfAIrP3buBxktPl2H0HUeSVAqyYEKGQ5BEbcBCpyFB5SRmzHosAQaEBEcyyjuNbEQOEFUqqiNc4
SKewIu9BPEUO2AkBW01B+TYYortZxloFOW16zgWsGhomZ5OlRr1VQJEtv5gpzC4U8bZvL6YgLJbS
FaF1Ha5r1PV+eb3nRFzD66CeA2BJbDXypA9L4Ln/wi52qzUkayZY58K92qbfOzs0ZIBW38K08YHW
9bWbzWkVFHe+WE06yGPO7DDm2eyBC9vYA+XgROow0WWMfuAld+LcF5+eXRcJv0Jaf/rBb1577Ze/
fO3Nd3779k+PjkfKTx/BQfTHj4TZO2JXtV7tVj2rEot1kbXYXyg1y81WOdPJBiCGQbjPa50q4uSY
5yQiloctE5p7JWoJ2wvLIJZgqI1UcBho4uBpkOYcmbAvWiTNiejbGUdmZ5zXPno4jbEcieuekjdB
LyNMQKLFY/iA+6N+sYTY4/4YwuFx1GHoE9Rs+hBDkJ5kEIkvqOuE5nling2RG30uUi54TqfaWGjU
8xgUOTpl4vsm2ZcUyur7DRkuSKMXiiqx5AcxLou8+gVXfkqkoasyY8rfjDOhJBopEku85JnKWHl1
VARe8lGC64rCEluxS6gqINRkyrrOghCxF7FlPwkzaDKwCMN8DGJNaayqI/U0B/MknFnwTWTrsIPm
C7lKoVUs7y/CIbqwsH9hdqmci2X9nPCGuG4ur/vnN+NVBFYUth2bGPKXtmvLf25t59aZa9Lr3Vv4
zNj0B3CYqLEuDt5cWXnzdbRiQTmfeG5bqm9NT4YzB45wUVsPHl4wx5s7jwDc71JstzacsXNfXUIT
4QdoPQ5aj771l9ee/8EPfvD8D//wq9/+/OiY3XniyGN6mZ7YDlph7X9qyckm6vAi1HLJfDVXKJYX
iouZ2fmSC5lQUaiIZoqLdXDqVCKxbC1WXcp3u0mYjZysEc/aTsIxlSAuQiR6TVeDGxeefjDKgiQH
nYIkXsNIVYm0BsdEMbFkM4l3qJD0t4cGgTeojiRi6Zwn5LQHocUDM048oDeKy1bT4M0LR9wAcs3S
WNCUA7WsnowoRq6d7peX8g0UeywdBE3FxqZBGPEEkfiDG4gs5BWiSm319ZTSynf8kZtVZ9UoSAWf
hBWoiopSa4d5C4YVPm9mjYExBdQPKEgqfgXwK7HFKCs2ZE8L8rmqRJQ7V8oqz+KgHaPJYZABaYqs
G4h8QzBrGSA27NmoZ4Udzq5tpXqVpcZiKd9plFPzs+V5+B0ymVwXrhB/37oW1ycGuaaBsWmtvD7I
q9RfHwS2Gh1aWTP/iWYT22irkmXW+70+F1jFLSPiTe1N+KJMVN6zuZN/vbLK2tTZyA+Hn9qXMNVw
OtmtlwopTlFciAVGFg4c5PQN4Ap1bXg7jt759NRpnGp9f9AIBq2EPzs387N3DmG9/OMfHzr0xu/e
ProjmP/WANdH7h0BM//2vYl0Mh5zuu2lVqmUrJQbnc5SsZtfiAcnRnU3WemWMsUc3LndyFK1hsZl
sTragtaqeIPr0DSttBMy4DgMY6hoKBiEasoQYEDEDDGP0+FTUMhhdVAdPIhvGKV1AI/4BRFmaCbk
Hse5AUB4gZgyDbJYSrGFFkJKuc3FF5ApxYVsJeteGGjArwvlGWavMimFhryY48Cph2xUrmrSqmGN
jfv7Vka9siQjTG5nxB4h0PppJl9eRWwFWwnSVUFVwBsdZWgrCIrVwbf7TlBR/SZr5NU/wMrAF4rL
PS35DvqNonQlhP9IOmnld1G0kQ4OwbVpmCENdLLzd9iOW66Nz7SQDXI9iz08YrX8Uqrcg+W63CjP
76/O7yvvB2eZUr6dWM0J+7hulmt6CF4HAjsAlpvYqgv18pfy4r/rgN2Rbe7QynpSrff71bWrj6ew
42tiYX0wnEpoHcC6qbJybcY/F3ew+3sWr0UNHZ7rPbQ50gLhFQMhU0/HnltITA0dvXn7e6eF1kEL
mJOXl2de/e0ff/Wr37z5/Hee/+Gh3/zuzzNPGsXthPUxad3+xNN9d7EG44HTa2LWT6xSXOzEagvl
RldHcGdFeqmF4lKv3a+4yVqrEE/DEhfLJno52wHk3WgokradaNzVjKgoC/eOUjxUSeuwxm7X1CGF
J18ZUhqQXzqdyCv9RaO8tnHD/Zxp60xT6UQ9wMW4c2JqlHCNCLOInFEqstgf2MGBgxBTzYoyR48J
d8dilwqi4pHsxvJLrbyucjirgdQzflh4nKS+Al5+YG11mhpKub13Kn4VWfmcXg0yKJtxxrSgVaqn
fm5bgXoquE9Z1dmCXJEMsHyvv0Cy3waR3QrDkNeg5rKZkrJS6lJY0TEdBZ4wD84IRCPBsGk6lg2C
DSNshE3bnHOyYexBcNpmfyNTyC3M5lvFDDwAcISWl0rJajuS6AitG+Eq0fD63Su9Eut5LQqvg4rO
6h62TYntx8eH7q3xyLf+paAeqAZWYl8Q6XWrG69RyPvX5YX3bdKNdL2yPiStvN36zD6Elp5jsQUo
W2JZpSdk90nzxJGn8l7g9ZmZO5cvnJB5GoNz65iDPvn6z9566+0P3vvDj7//w+//8DcfvDozkV7A
T8nf/6i0crLcM10nWYjD5lePo+qO3Ewpv9TLLc3uy41M6HjRzizMou7cXKzbcKj2k716Hcdc+rWK
Fa2gAUzIi1hhs99KRB0DmzWqplytfhaJlyg+k0AQ4S2TswwCR6TLpuRkIJy4WilOPBCLr3EUuQCO
kaxBVpbFLcE2bf5J8jG0plDxZtpISicN23PZ0IFUiw+Dd1S0YKtU6ktFz4C1Cv6pELPHrBlzAPsk
E70ymmq1yjqY7UFOsQir3CPGY9JoSZO0GYRSTq/6NR3mwZjxJaFwIKU9DeljP9W7esCO6k+6A6oE
ufRAhE0NuQA5f46MNtt5u2EDSV/LBpvQ0zkd74aKJAAKZjxpZMeTHNdV6uzb3Sx16ANoNVL7Fvan
5hvNdqueb8ejEgnfM+dsgOvm8rqGVxFY8fuviYgHMTGWBapWlzmLtMnjLzrov+UM3be0e2C2N1wa
vuXg5srkj1Ren2JaCyveHoLWAbKoIu18dj5VhgUBqZ1EpfGtg/I4WZ3tqlNH3/750ek7l06hccSg
qQRaSlz48PzM0Suf3P3ZW3994+Xnv/Pj19774Kcz44mdjIUfY9/63NYDu6Om1a9Ea/1kLGbNpbvl
1FK7NL+EUoGrBSOl+VRmqdVvLqZasXh/qV5K5pIJnGWL2xqqrmhnO4eAEzkeL+rYQY2dV8IglIlP
A1csOOL0QtrdaUeio2ACX+KpUOkKI/lf1aTS+hP5kZvCZFdADC6kRhvALTGElwJ/BTaesEgAaBhq
2Q7c8JILOdfi+BiE1cgKYyQNRczWEskkbBJevJ22A4Qd/w5hBa2AFZmsyekVWrEE05VME7JLq7Ri
8Ya0ciq60Eer0j0fMF1J+Ayaz6lTcDZHHJ04MyIWUJFuE6cxbplBVmDZD6E1RAiOMFP2qyoP7QPg
kGG7Hoz7cAOHg1YI36bbim5FOfwnHE3WEdhblcpiuZDKgM58MYVeEQv7XpwtFheXOu12vZeMVf2c
8GqgN1gruG7G6977eSWwPq8+sA8qrBArzKaHn7yfsTF3aTf05lG0dFsxOjJ035oZdeurlJbapU1W
ZPMhtM8hft5s8ONaZX1oWunAlwUnkzj/JB1w+IivumhlWnBGjv70rT/+/tcz5764+iO0jnh/oK0n
Tl68i4cvfXjlpz9/7w/E9Y133h56MvziAYjyI9O6HZHwtrphZXl+FSb6WtiNtZYWe7VifjHVdOwY
GrMstOZxUSwU8ol0IpHHIzAdolNTMmpH4w7niXqcAmfAG2EyuiNxEJCwOxdWmEwJuZo8zO0oZ++L
l52WAMWPHieQRg4qYmtnAE1JEiR844HmqtgTIlaWfisQXNZ7gKUCf2E0COGJVvGE0u6cpuK1gE1K
VbKDmeZWrFtBGjsf1ecUjtJg3spPATOYpuNiZvLeQVasMamuTpLnaWF1xyqtOPs6EZDxMwEiCuyx
8IJDWjWVZmgmmXQ77Fm6b9rCZiAoukt7peJXsCQ1DgOzznnmZkBmuEqLSAVKa2fj2SC2qKiKma4q
rf91zw4FHctlV6pkCy+QyXaz3SwXm+1OM1MoNpD+nF+YT6X6zWZ/KdeL9qWLmi+ra3DdvrG8bqqv
qwJbGAA7IHaArKhsPabtGHpgPYlBB0Z3Yfe3DjwA7+Gdz86WPBjLdlCb13A6nKitcrqKae7BtfI4
O6umNmYLFZ/oCq0bz9Dga5ncPCStA31d/xBfcXbnjdGjv/7gnR/+8YPXX4e4vvJt0Lq6Th8/+9Wr
U19cvfrZlVf/9N7LL3/nBy//5oPXZwIddlF75EgYT3tXwgxF6/DKZ61EPWtE26VWuY8Wyov5fjIb
ye/H+Tmcy6/OLrWr+dliLlHpVvMVFOo7i7lKDYMsoAgR4AbbR7qeRd9ebLKCroUqIRANagYqhmAT
DmFQjGolloY7FEvWJRlD4jCAJKZU1nxcje2IFTaSGVU0DowhtrQh0oyo6EhJQVuRFjadCALJORej
5LP1SsKmpxHeRttgewglFInX0tV0BeXjui1HxkcZ/DIJDDbBLjashHMl/hU4ZYmuUmgHB+eAK4/i
cB6Q5HoBnsIYGIsMM0ogv0GDw7EUZLMJqzYCkaVoBnw15gkdRZWpfSZSSIbq961SsJgh4/aUg9Y1
zTVD+CYFL3K2q3Nal+Nadr1q1ZLxarWEjh6ZfrvcyC20Z2eR/SwWC/lCJ4eDOPVof4VWIVVu16jr
INk02L1iyfb1vv3rQGDvB3YgsWuwEWRl9TxMvh161AX7mkFKuTbkNH/fuh9bWqw2HYQzu25MK2hd
Fwc/Eq1Cp/iY1qwjW4vpkZlX337njUO/fOOdX79+9IsLp3FgbrAwYe7y9aPXLx4/+8XyT39LcX3t
h3/92cxYfBeE+TH6MmUisIqjoUolm3Zi3TjSwovNerNYb85nSq1Eq1nIFVP93FIJVYKlfi2ardXw
WAv/96q1Uq2fhUGihral5pwWdE0OM0YQqtuOjQcgI5rrxuGiMPFFHfnO0HBI9522koViU0QsXcJg
FHVBdzYNGzBqP7p8ScOlrUsqhrE01FfDuVY5gjcGVQoZpu1WoslSbQk7Zl2FfKquHdbH6eWYi6fj
1aVGqQRLraaOUjxRX5VGUPQ7rpj5V6c7z0hHKCGUb1xyX3qnTk5LFUaRBLAqJ9vpRZIbRc6yyi52
pYGL1G9W+o9qdPzjrlRpwSX2p4BV1R2LaDLioC0Tmjpn2gb/e2lMsIXZIlgPsz+TpplG2MrSZGYY
9dxSp9hslnKtzGx5sZTaj4ajuUK7s1DOd0q9SmKVVsFUbjfndSCva3gdCKwfEa+GxH5MDGIHGjtA
dkBtFVsqSwug3etmgGJCmG6kYxLybianA0RbqyvfWsUW/z6gnNq0jPN1tBJVrMeg1Q+I+UEW6d3Z
CY++/tMP3nnz5e//+OU/fHB05pMbTAsPFjpGYOe6fPPqKUD71q++f+jNQ8//5a3XnzT2Pxatz3qY
pFLFMaxe1KuhkVG/U+xXm+VyvrzQXNhfKi3Wo8l+rbfYSnVgburj6HSsFs/Va71KtNoolNteJOR0
4zTJQQ90dj7SNHYppP+Q2qPN8WpVVdzC9aS50BUFVEpdx5TxiOwAwcs2hEhahZXRdhBBG3qAX9Lh
v6P7AHElxzcOizV4XNoUjoQMCxmkaKXXjtUMQ8OuGEMcNWhRAI6LQMhw2o1yJ1ODg1gfYb8kcA73
ElyFuMMwGJ35Vxrz35NQPIDHhVXBVbiVbSulVcEz8vsJy1FXhrAAcLWFMEmVkg3JxjdL9Yo2EUDO
NzzCs+sINUwzbFgaoghu7rmtJcIc+2EDTgTKDIOJLas4YTYltV0rbtUSVq+dKXQKBVjNUoVGuZVK
ze5PgaTWQqnTL0Wr0QGtcknydnNcB7wS2AGvA4ElrysKu1ZiW2u0bg2zxPZhVpuUruE0twZU4tlZ
v+Tf9hcLshuf0sErwqa0DqT1USPh9Q9998jTBWPy9Vevv/fDX7785puHXvvFz2bufPq3+8T1fUzP
OX389pfnr3986uIXR99+7weH3nz5x78B1drC43RRe7aE0gt6aEXRsCu2FHMimMabK5UXMJu3mM/M
FnLlxUK71q1ly7vL8cVqPVdKdIuVfD5ZRRIHs4LjmO/W6yVNK8sgUKHNHRcj8two7Jsy5tQIMtiT
KiSolctQDzMnakFaeD6V52ODMlnRiuDQbCQRSxga231jorIZsaxk1AHIARn6hCiXxwB43g2uIMuK
1rJZvJp0PctAw0G4GILB8JwCAUarKN1IZOOYItNJ2CPSjhAxNO2FHIMs527kQKt/qFaolSX+CKzV
5jNcYxOSFxM/BH8PiqXfwNsvTUnXJ5oJhyUdBk7ZPkMqUlJ1FlSRbsNh8xDR1Iy0MQd1FV8l88QG
wmCL05R1bF7xpqvwIUJu9RDuopLNMdOWlUi08uiO0CwsplLFTnEhVdy/D/+PGqlyuQ75zQqta3Hd
TF7X6euA14HAisL6wD5ArGCzEbNcTBB9/SoJo2vlFIK5ltNFWUv31qK/hFlZ1mYzaKsoB69v9r0m
x/TwtG5O70+OPR1TJyf//NtfvXkITqU3Dx165+2jVz4+e4LTOAbiiomQFz85d+3shctHf/2753/5
nZdffuNPR4eUslRrH5HWUsJ1ou16NBvLeV4uEYm0u3A85PEqPt+rlQv5pUYGF0crW0HH/RwGsdgh
w/OMWLu7mIh369FK1NA4TRVzIGQOG9upOaoWiWh0RczhatRDQTbRl3rOMHemc1QkfKZDjGnoCXPq
Iq18ShCxIUSZ8R8vc9ONxCCt4TkOhAT6o9j7GmGekoO9H+bgoOYgFkdZNWaB2KSmwIQ4YnpxS4XN
nmdps/F4Dru6rhU3FBnYOjnNFt9TPAXPiFhg5DvviJLKm9wBxXIHH9ktTsSS+kgaJcaV8ZAUUN5j
TknA44OUVpWbdZlRx0MK9/qZAkXV1hQdvg64fhng03GI1zLAikydDs9EgCVZHVwrVFwbbzobCjtG
yI6kvWi1WM40ms18J4VdK4rgs3tTGcC0hD6PyUroflr9TMpm8jrQV6wBr5JwosDSkTgAFiHxKrFN
IXYF2XXMEtuHW5TSBzenA0x9SJuyClxyb5Xajiz6mqyNUEJFtrp5lsmPhf8JWjm/hu3BX+wpk0ff
/sUfn8du9Ds/+M7LKM68ihGSr5xZQytmVp388PrNC6D15+9857UfgNbfHh0a7hx4DFqrCdtKlCpe
vFCDo9+1IvkcutdiXG1uttNBxrGIPVExlY+X9u1JlStOKxZL4tBlMo7qXyTRc7yKZ1q2HXE0hUqp
s1VJDSYtePxllloIV6P0yoeznbZAxojsAxOnJxFyq4VUle4CPzUM3XEMyGlaZ0gZMC1XAsMw6tFU
G9U2nSDtCZRRdxoybfQdU8MYV0TzXVXB4YMApdi1dbLkuV59obBU7qYdE17nEXZkGkPmd5xlV7/M
OrnS/5Ab1BWFFUxFXAVXWp0AOVDTVBI3ysy2OEBkFyv2QeFz5UiRyhs+V8KrBOmDBLvEehhUcoZ8
CBCGbNdVVTCtDWPclgrpNB1w6eqKPBpCJIy0MfuWuyEXX4vi7I1joW/EYqHVbCx26t1qcWG+2YK9
H/tXhD/NZD0d09fQSkofQl4H+rpWYCUiXs05DSRWiB0gu4ZZLNHIdYtsbrDWbk4FU+F0AGmhXCjL
wt1VagdCy/zzJtHk7k3NERIK/7O0IsG0qxuYef3nqKL++Ptv/vB50HrovQ+Onr928d0HaP02+gpf
vnThxk1Ewt8/tELrSGvrwUentZa2jIQXT/aqDpwympbu1xJJuIAXcs12o7Pw4mwmVy+XsTXCUcpW
P9HuJZeqsUqtEndwMNoww04cIStOFMGniwsVzJpwz6UnptSoK06doGLjtCYY87d2zJD6p05EWuCx
w12kfP9O29n/RpHXcVw82h2YhXEcq6OODDfO9Wa8YWbA6XTn9qmzdzBLH3az2TVLLhhNmmuaVH4w
3A+GKLQHePIgIhCS0/jAeUFBczEYlRijvxrxJxOTu7/FX3y/v1063VuKLuqn9GlbWs/si8/T+/P5
TEzwCU1RrJDRTtD7FnV4caStKDXJTORQnNEixJk8TsNYGEVi3VU5mNLEzbsQtEJ+X1RCKE5UFKgm
9DhpzPcWFrtdtzgBZYVYF4F+auHgXvpW2GD5EreA7wO5g9utMKE5zMfS8bsKPKu6WUYavIj/xUVC
ORAk4j8E75isU6UPtsks/wbjXdGrsXXdN2yVy1tsWy1ITGSLWKjH4++GasiIMpjrahxbwCeAVbUY
DztGM0ibnuZEHvbadZC4NBY7R47PLZU7cLXVY7W5tu+6gZPTulPySlxz/7oDr0MRMT1sDmxO7MDL
5tBuLwXl8PIl/zC3POgd9qc5psJqueGz4d9M288bPk+uNL2wLXEd3c3/39HKifLPB7sPn7lw6fzr
ZxEGg9az7z24ePowtP0/+xCtX/36F978/lvff+fPZx5urCwjEj5//cyu3UvP4lsDV+uFYYKsR7Oz
JNaQiKZpkvj99uyR9pEjs0iJGnVIho9gUdfSXCNuzLegru62IzOsYEhLi3quqlgsA8m8J4oGI4Zf
7T37C5bowxToS1E8orqdzVNp8+nN1iVe0c2QwDh1QDwtI0FDCFEeUKB7muDtiJIRQvmgF1X8NOp9
XI6FF40CpBJcHzol8fay5lV6/W6o7cEdyajd7IQBL8boqhK5jUa5VQ0UrkHmchfOvR+YwBzOQK1P
FPnRJqSPY2IRCFMjgfql2NOEgQBJQaxLQtknFRGCYBa9XSGeApGs7oqv7BF5uoyYGSJCip0JLXhG
vGEogYKCHCvCegFOVS3IoBIZNr4Cx1vE1QOq/tUS2KV7lSwW2L0wqSPm7yHYXZqfW0BnPER1uHqk
PFeee3VuCUva2+UUVXFf0DqK607F4SFec2AZEG9FxLmHJbGjyFbz+JTQCgOBAxNA5mzyjbC8hLTU
IabbOd1O6fx222I2j4wXFiLO0D357vJOJ+UGUq9nppX1pW+feO745MfWL36wcW4ZUfAyaF2+efcM
xJh//+2HaQWv3/vud//0jx9d/WBlFd+7cgi07nkmWj3N444fs6kZvdQHpk6QZV0Ue3p+o3XstdrL
R5YqFb9Xn+kstLNa9dVatdnvLviLPexraiy5WVqPYnOSuNmmHmqam3jofxqWprt4SpZsRrySjbUP
+BbR/mCMW4RAiZmdVETkyPlPcI3ntkZPqRR1yvFU9HG8NIMXcnVOn6ioplp4AnPsW3aQ+wJXxKdy
jMpU7PfSXhZoxQMH92j1vk9BkIIQ28SwSqUP/bJWhPYCKuOpA3Cb+ycODhYsMgKmlp+MElDaYMIV
b7fKwsh08Z9XoKtkqMtyEaUdoLQoTrZSy0+SWVmi6gNcFgblI9FRpoqS8URRN6AkMQGqYYpFaeoE
E1Tq9lXT0TXoowk4GtUcwEFlWJEMRYJrDftZvbvUN5rdtD7bme2hHO9zbcRC1sCk1FylMt+rcxWV
JmgdxjV3r6O85v51WC+Rt3QA7CCHHSV22NvBhopBpLDzRONXaDmlQ/50C9PZx3Z885fmv3j7r622
dz1RNvwCHh6n4zqua/3a8WR6/cq9jeWVtbVDy4cOLa+8d//W+uFde/72k599Z4TWr3/rzZ//4szd
m6srJ08u07ciEoZyZHzf6jlu6ClaZJhpGOlOs4nuadhs+d1q1KnVcAunhqzWbx9b9JsuNhbU2416
ZbZ2vF2rV5ouhDYInIuUzcooJ1m2LKEirKLaa/Z8BTmaopimaejsfCDA5dOdzpH9VZZTqP/d3L0k
yTwIY7qsiioS5YOSUlISU1JlwzELTPf4KOZtsLsQv6M0sbkWH6t8+a9GX0NP0pk8ML1bT9LIsVRl
Eh0gJTD8CL2mQC8AbRy1mCZ6YHYQ4BLJbeee4WnZweFjAzU/XLHgGkqqIrw13P6UGLLZFCfhhX6T
GalY4w/UwDSNvVi8yOAa4gnEtlQnTnKsvCTjrW7qWqnIPKHAFFdM3RgKdCWSOA4rZP0W/iMpM1FL
illvVOoYkOs1mtnibGWh1S6HjXYVtOJu9cx8NfPLfhYbZpRHwk9xr6PlpmFec2BfHAKWLnZA7ADZ
UWaJT85tboLM3IYLSIJSYUOcHofN5Jb/3jyBHtjBJ17wSSGFzGkdjYVhz0Yrp+ROfO2Yu/c0ctbV
108eOnRy7eTrN9YuXTj99l+n3/7Dn5C35qw+lkj89teXr76/jECYkTDy1kLtjWfo4BiOq2iQk6Ma
XOkbRpZ63XatPHf8yKvH2hhgmVtaKgdGEgWthb6fVRdxHw4r0RPD7YU+DjpgBloxZeZyRdMswosy
7eShib0ICkXPo6DLFO4KdY9Vki0F+lcK2bk0F7kaImU+jTnhlmWJFqSmKeka/Inimi7kPfBGJTMV
o9g8ClCanILcV4J8AIc2MGuDBVAK0r1u7Bi90CuAVjUKvQp8TxEJoFFRCkm733IktGK53olY7tt7
kLCSUcGmoBUf4M3molQ+TCX/Zg5LpCGOAHpFHp8EmnSgyC/pTFWiC05hVA7jM8o8aCx7kzsm6wji
KYZEZm+xPcNJeg1fYsOHATX0WDq6NAVLx9/Gj4VDLrA6zg1XFvILW4vQJQuaZcwotKp4ji41GguN
+hxIPQLV8MxSr46Gmok+s5HTOsLr09LX3L8OZ7BDwA6IPZYTS9seoebU5ujyNbcc0JzSEX96fIvT
I8OW/97cxQpjNGyOPOuLmA4ArblzfWqhaawjAV8+8Tl/Yv3W9Y1VcPo64mDS+vDK6b/86kdvv/PL
b3yIVhyb+8L3//DDRw/P3zi5duikqDIdto+deIaJOR2hWeKHUSAZZa/EgyuJt4AhrFePHZtZaFdn
4Lfcbpaiz9pv9mqVCuoajSBOuxm6oJoLha4G4uB2ZMOAJ+CzTBX1GNZJENQBT64u4pJPNidFQbhU
UmIDX6QogvXVCSZ0nm6WUNlVJPgqWXUTRUdOi2aRLPPLuus6kVFEQMyhbjtR8JO5IngK0aiFcpIJ
9+J2NVzL2A0WFETPEFtMmkWMukkmj2rBC7MQDFwx4ZrLDdlvHWyLoE5YCIUHK5rwIIzvQDBkyUXI
koSvlMRWlqLIyJljM/rlNM7gCBXA5R98E6X7e8XI62BLlcqTIywAaxonjUC7GAuUuM2VWauKb2Xl
uMCHFIqZdJVq/9jDXGCt4WdpeYGH/8q9rNs5OoubCkfm0XMtY+dd5GqG6z6R1gGn4t0or7QdeRUe
dtjFktgBOqPMDnE7yu/csNW2Z6dbQe8WpseEvfbaUf7S1/Brc98+Aiyj4VNP2CSRAdenCPvHp5WC
JuD6tXn0bu7eXIGvRInp0OuHlldvXz3zxz/87m30W7+BSDjH9QfYrfbdH7/75zN3UBCmI15ZRb/1
Y+YrTFvHpRWxqpLEcZioehBoBtLYwEva2Px+dGahN/fa7OJSY6HXrsx2fK8XdHrlJho4fqW1mKLP
40ZhhGE1pJ08J1qSbLYZVQoCWHGxbIWT1IXNEzJQ5bNeCnB5/IXFJAuRsOiIFJgTGpZaNMwit4jR
tSj8B4AtRhv+VS/IphY7kCFrRWqlTE+BfhbxN0LhCXQ7HA8BQYCEldsloJZyPC01C5FWmizZExOl
UhF7UqcEhfSd5A82aNcMCk6boTDJFJjyPV3toI/D+VuxAoP3Ypm1isRUyJWmBndy2KMS8+pkdjCJ
z1uxfAAPURDN8i8rbXasaaIdzQXpBdAqi7I3na045SxPUj+hlyTFLhUhINbdxNT8Zt3vN3rt6txM
c6FebRw5QvVnrTY7f7zSqixkgZP71qe616fzOgwsic1dbO5jj+bskB7YIK0ERAT3P7H5HNI87N0E
dQvSV7cZPx8ueG3/RROU+T9BMdwZiYVHvOv4vvXbXzoa7zp94fbqyiHgBwDpLy+hefPu797+9U/e
+h7ut+YGjf8333r3rz+8eG0FUTPs7MrNO+sHnJdPPAOttqYq3Yh7Fpxy6qALnwR6jPx09hUs0qsd
6cV+JXKXFuabc0udKivEC0a00PB0IwrjRNE8eQpPSvgKVUPCuZutf3hNjSvCzJmMETJGwbnBvgBQ
hSxe6GkxmMNQEqTCBYHRAlhFxYXPXUSO8Cp4vtKNyaaJj+BsTBm0hAsKhIeTRQNuhOesilNwr/xb
Rd2FZDnTDhxAeVVBeavUq+A/yXUN0w1Upsv7Ho++cWZukLQKYgWtDHyBKrzuwNPChF8F2iSXi7m5
nUVmsRqxO6L9TVaJKl5YRBJ6Jn4Od8+PkTjLcLVst+JF6LhU0d1RkXfYKsClD0VV2LItU6UfLohe
a5FDeEVJD5HCKzqolTQ4YyOt9JrdertWewnhb1bBMGO1jDOQGJtbmputtiIU2RJ9J1oHnIoPduL1
qcCOEMuwmMjmfpYIbXGbs4vXIcOjAxuNenNOBZ+v4PjqY3tl8Gv5WwfA5qkz2e/gGT39hD7Oa5/K
10c8zbuOU2M69YI/uX7x3toqGjdrm7SevXl9/RfvvvurP/79x9/amm4Vl6uQtL71+3+cuXVv4wbc
ML55dQU64enkZeiMx6ZVLalKP/AbvutX/cT33CB04UH75aVWHU+DpDvXKPfn0jAEqxiB7jdRiFxA
kcntRWhEJFD66pGmIcX0FPCE+FfzNK2EmpIsoWjlQgvLMirFCsLt0A9RnSdzdoXk4mNL5dOzNMln
M5eood7Eo6u2imRawnMXsXSxhPBaTX0dg3UTUuR6kbhwiqkbHOAwdM0Nu5WyYWJF25SaeKmmxzFA
NVRuYkS2u2ffgcGYzcHNEJdAsjkj3okyMEkmyuBW9FsFsIJjURPmaRrmmQx1xUgq3SZHe9ic4aVJ
oezfnzDi5X8qEUWggMs/qKrhb3EKH/EGQUS0AEkwO63iHxq5pEFYyP8PWHSisHqC6kPFiU20sy1L
4Q4JZCjNpWbWxjGxI/OVNvY887pue24Jvhb9kkozcBXI/nNanxoOP51XApuXnIZcbE4sLPd3ZJa2
vSCU2xCbfBWEktEhTGFHaUOYvpyb+LXsAQ+rrPJ/DT7DodcnqCSGYuEdvesYisNTn1qULl+8x97p
obW1NQAI7e+1h+t//u07v/7F79787le3pa08NPfW7//wR+w9XMO0HL775I3VaxfX9/vPf/EZ5ltN
x4wwHtr1HOoiIG6D9lfLvEa1Mr/kN6Nk8WjVXTrarvdrZdSc5ivdDm45LMxXMGHne0VohtBzUdGv
sWC6Am5i/ClBU49uoStp5uRgkwKWAJNacWwcT0fmsLyRwz4Hei08gigjdZMRWk4VwBlCcsOEVynC
pzmapMUQt1tZOsm7FaoXmbzFDiU/Blm570XXu91m11L2YDe4Uvd9H1UnSQ2VInJeNynJvMwqjMfs
hEd97Gr5hhEwvv640ETfu4n2QH1IWkXPlNsKGcFubu9myplPuw427wsVBL+MUptd5MlpTqEPpo64
6BAdGwNiKzzEQFimRwW9piV2qYluLnNj7hA2bdWEjsJW8MYIoC7rRv3O/EsztWYj8Hs4VFVfKleQ
FtZbS43I89EpN0doHW3m8IOdeR12sCR2xMXCtsPzmFlASxsqCe1kR3LLc9MhTgWfLw4Zf+2oKnLL
h+O9z3VRH9rvT5XEyOHWIe86Lq1Y4t9WDly5dP7GWeSsiG1h51dW7l1c/81P/vb2bzDfui0OxuX0
b77121/96Mrd98+tnEd+u8aJuWtX1ycWP4ERnrHnW3UviBc9rWlYYaPup0YCjb7rJI6HAw6zmD9P
jy52sbK0jqdLbeH4sVfmqrMLc4sLzSAMygpIc7NuFIXdjgEH67Viw9CwTwciAAhv/EDTRYbHYLGI
OLGAZWN8qmtKkYdKeUBjUlHVAPI66J3MIiV6cD+mkRgmCFTi0CsibTNiVKDQ6NCQhXL5RMlBFCyr
MVI1qB5QrjVLkwjgA/B/AMcEYtS/vDT1LSTHRtoNZPZXSR7pFLASST7GlitXpIm7lHSreADvBakA
lSzTsGgCAbDKfFIieWRUqH7xe/GRIFboszZzWnZ1mKyzcC1oRW5dFF0dVUYEoaqmBqdPGaK8qdGS
bN2CtJKKRi5Ug77L0g2tl0UQURiJq3iaHwHLmaU6anzHXptD1Xtp7tjsUq0/02lUykvHWp20Fzqx
leetT+P1yf6VwNKI6w7AkliB7DZ4cmgJ0aAetEVuDm+O5+PqERglpXnUO/CnOaYvDJt4bFDuGvAK
G/Ldu2DDxaY3qPwHriOVpty7jk/rkv6x03evbayeu3EWHZlDcLCr5+9emf77L9/5zd9+/4NvDeWs
33rz9/94+9bd90+eFW5Y0Hrvynpx/jnM243vW1M8MQItdHS35nstj8fIYziqetTNMr/VW2g3+v1W
ddFpLPKW1Xw9XaxWK4utWi3UJvYULbNsRC0nMQCQW3RRmgT+qA25UQxgNQmxnrg7Z2ECjkGjUEE4
yG4pJ6CDKhV0SClcU9exIoUpsBN4LvJhtHIDNzLQnkSX1XId6HoMCYdfoS3kxKsyUWDYrUrcn2p6
shH4KXauHNiPEDMwAwXdR7RgXV2xuZdULArObzoL7f70QYJIRIVPJaX8IqndOtPOzxkI7wGaIk8V
GkKxppASrRIbqvSbNOEXBccFfgeVS3CcYj6ngAia8S2WexsII1C+tUXnBuECl5Ui3lUtq4CHYCyu
SZYRRF6UJKapAdVu2A+W5jBa4Tfq1WNHjzeStNWuzVehOVzARsCl8mKn3E8jIx6awRkjfYUN8ZoD
C8uBzYndRg8sh5bY5uDSiO/oR2R0AGlOKW0bpc9vt6HkeYTX41s5MMdyisM7ifHIU9aU8s24tJ6a
CSenLj68/2DjvbXVFeaiaysbUAj/4fu/fefnP/7Bd5iuPrZvvvmTP7x9+c7NZXwfcV07efLce9fP
fKz0Eg5DPkMkHJkOVA5LmaXNZT7aBIYVc5tatQOVWNZ1o1YHl4AqEYCtOBHy2dDDUtXAa/ZLCGMl
LSwnYaK7aSy2+yJlVDyZDVNb95wi5q5ZNFHRnFDgM1VVRkpb1E2Zud4EZ1tZ/EwSMK4HhoLs1fSD
Vj1BahdocJeuwqc8XBplUYolS3tRnRUBJSXzEi8xQiWxG0jriobYGF1VdUJyS0oJ0YGvIVSW0EPZ
3HS4aZsk0kRblY1VESHzFdziq3w/jS8M2N6kdXN0XmaRSBSGVXwEOmGTFH4wh8V7NmEFz+zpADw8
LKpPJcTPdKU83lWSzQDZ/ISQ/qtA2lIhtLYAPnJ5/nju5oc+K418I7bxNQ39smaAqkGt3G326kde
m+sGvXIV9RUkseiG459OLGkvNzRN6Y/QuiOvfL+TgyWvT3CxnxpGNvd4tBzaAbhb7PJNbuRTEEpG
c0zB6QioHx+yofp0zusWsDR8NL/rw1KJTxLXT+6M69b91jGc6yePNew9p69cvHtz7dyN1eWTy8sP
Lq7/4p0333rzra9+5Qdf/zppZRj8vW+8+e5vfnjx/u0br0OaiKz19eXXX1+9fWH9M86zbVHTUi+r
lP2ludDodLNy3de6/UDTGjiOv7hQyZyo40dBHEXleQx8VCqQpDbKlVYaJgogciCsCJMILkOTbAsz
Mk6mQ88DuaAjWa4ppO1FW6R4kE6oeE6zHhq6aCyK7EwzNDmBAzU9ifQhtoSkx/ddPHuhEYY0AvoI
GaBYoDH1Y0XF1jV86hpwR9zD4Oiloti9xuQVT/X9mHrdi5KxA+WkE+qoXykAe9+AyUFdaeuF463T
eKE3HWSye8VsDj/fKhxzi9MeCfljkS1XNlhBLRtPgx5NUcUjzFjFJ8zkJwSzkqKSPpbUCnCudkFW
DFdVEdennikVKEfk3mAJGYRlogIuM3MVM3Wq6fV8bxH/9SbAdbhlMgyXOr1uD9WE46/V2riqUJnv
VJGvNRrtDgBeqDaaiWLnWqZx/Ouog6WNAktiaTk9tJxZYXlJ6OmWMzpM6TCnn4N28MO/M+c1LxBv
syNcnrh3+5P9qMB1p9G5Aa5j9FvFKY0XKhDIPbp14fq9mxsrN26sIBX9zc/f/O73eB0dnIq1h1/5
3ld//PM//+jW9dvnbiAEPgsvvAzx/6EHF3cd8KgSHp9W6AlbtUbSaypKrVPpGQhLMdzacLr1VtZf
LCeZ1mylhmOEPdf0O92mX3Z9bI4IFQZysYMUMgjR8TTgKXRL19hJxKY+R1fwxIOzAUpC9CPBEbHM
oml2rFqD0RT4PrVoeknJ1OGw8HQ3Gp5vmPh1umxrupOYngrpol4yXM8GrIrNEJQ72ywJkicvjTVD
h8RC123bMXXcxKJkabcW9C2E0w7iaSAjwbMOFi0JZIXbHIzDIRgWqOarSffzI3440AjDcLlnEq5d
tzSNG37hQFktg4myEjpLogQM/AoqaJOApqyjzKQbOvBllov/MN6L1xPTkYyIOXUILT97NUjKS6qt
I7a3kdTyXzU6a4ttbNePNNUu6rqJ7L3ZhHgJyuw6po1fqaIa7HfKiPzQbz1S6cwd5+WpNHQUM6d1
fP86msHmwJLYPI3FnyGHBxvOLnN2hy3ncyQz/TCnjzH9VP5udKovHznIDZ9wO9TLQ3eYgStpzXEd
vTM33rzcCZyqerWn7F0/c/U6E9iVe7fWf/WTt7751dze+uoPfoC5m9O37t8+e5bFKGGY2Nm492jX
tId5uWfY9BI3vc58amZNxVucm3MUJU4qSRYoc+2FRr8exqHuQdXveX7WD3GzzfO0pBk4qNVKkMrF
shmGIbAIXHZdwgRFJkr1da5CkMUeBXFoAk1YQe5u3WHPX2KfUga6sSpDOZio8mZGa3v9RNwuxRPb
DeFTXFPVWFNyDc0MkxJ/CjJhNGdM0GwGvmIFoUWxglLitPoenl3fbTn9eR0ieQ1yXEsp7j1ID7m1
I03ASBb5Oi0+3RrE4aNU/Isvbo3l4P6zJJUkKKTgHHUdx0NEAi4mWbkTmbsPxYOTrmShj8pNSgoW
I6PQKxJdTrHanPtj8QwleK/fFTd7OHrPKRtdRe2JxWH84fdqbhBACBFEyMvRitWNJEuTqNYql10s
9XjteLvXK9ewPfbY3NLs/AzP4czOLFZDZPq5qn98XkeBpQ0DmzvZHJ8PeVpyO2yjdI4wChuGlP8k
jNjWLxzllbZNW+HzdM5HcqtjCvZpFzb4dtzNEVjf/4kXa6khP7p18e61m/cfrUPO/93t9i3cwHl7
+gK0xIfOI109eZ6GTPfBw8u7PibNfvpZ+q1ulkadKDleT5rHZuY9XfMbC17oRZCKY7n03GLdQyuz
mXRTDEAvzJeXKmkUmJq6d9IuaWHDhpS87wemZU/acGVB1wskXZUVk09iLg4WBzTgXKjzoW7fsSW2
GXk7nWK7SVFBZfeV7kl1Ay+OYy9E0TTyzMCB746cbtjAReEgK4e2JU0oftqJHOS5Sai5mqS4OmNT
/ChpEvdyuD2iGLtNJ1RtA4JjpLXoz9AObBHLD8gjYcwfIq58YBfi5sFXBzM50EdZFDKgPOs4OkeH
Bt0aoQsu8A0hK9AxIjPnkQDbpHzSZrzLb0CZVy8WFWTnmm0aINHQbbrgoiQmFRSdP15nLM3KdxI2
ITWMwgDVJhN1pqgSRVm91avX+8oiot+lJq5W1WtHjkOqgmRt8Xht5ni1HiN9yWvC/z2vObAjxA7F
xbTh7JLgDtDl65Dx05xQMjoS9W5x+slhy4F97F+Ba95/zY0dIW5w23bDMhjgClp3KgyPByukwl/G
1Nyp59vG/sOHb12/Blr/8u7vf/zj73//zU176603//S7H6HTs4GVTcvLZ88uC1vDgokLp3ftmso+
h37r2LQ2Gl691k1nelG5vtTzXaOERiokEhqU5P1e2PD9Vpvbpl0t8Ruh2+35Td8PTVnzg9iptMpe
6vpF1nmSWDGamYa8zKEmYrA7ASGhjLcW0lbLcVEL4hdYBy2WGAfiA5lPZrsAs10DtDrQ8Wcm8tCo
HGWVKIsCN/Dd1PFcw7Lw9He9zDP4XEdDxwCp+CNJ8NGIu6GVwL3IIHUgiyyxCAWSpx7Xggf8CWc6
eOixKBhGBeLm1m/sDsbDHM8ZpLr7maFOFI0kjR2ZIzcS8JxiNsr9pCSV1TL0pGQqCeE1LRPiB5CL
VzpMqrtQXEIoUnJsTetm/b6rS7JKxCUSi78sw8kidcCPUJQo8BEIG9ASQvKkaGHYXeyC8EYHlGbY
P1n2/NZ8bbY9g3Ec6BDbaLm2ZyqGoplRTusYvOKjMYAdRla42VFoR3zukAflu2FMd+aUv27oNw54
3Z6+5kLIXA7VGFYOO7jUMRQLj3jXcWDlplKkneD1udfS3Yd3Xb4LWg//8I+//vuv/vaHd9559+ew
n/7257/64/rV6xtnz66snL2R2zksb4LrN14irOPSivpuc67ntpuOj20cvgcnlnQRkkYptvLrRug5
/cWmjzb8Av70QghqUg/6+oLm+0bSaGTNuRh+TC05jZbfLFejIAvQYJBEZocUjNp+uCbkqJIFbSJ8
ShGkQWmHxo0Ld6BRW1GEXykpk1qExosdJ46GUNHyk8ZiiJARRScrVhzDMg1JuFHD2i0xZ2TaW5Lw
M6EksCUIkMWZ1+k9bg+ynxSextZxkebgAFSBKl8fH8wgnGBxqMk6QHj/puPFN/Are/egTCtbTqKh
bg13yax0j9jsQlIZG8gaytWIfeEnJQWwgj8e8AJ8KEzR5TKOQAZtRYkRYJtVbHKklTsfLZ37lhCN
qLIutglrWlDSAydSDD+JJQUIukG33k1R2PNRZeq34VoDz2s0MCU6W2theK690OaUd4QkpDUWrYLX
EQe7E7BPQpa2PVDFa04uXncwfnHLxN8bxfQTo5ZLrEbSV/AqgOUrYWWD6MDQ7Ugb+0y3xcKwZ6SV
QTDvyn3k1EdfOLLQ9KxHl289vHYbtO5GAlQq/eYvf//n337XT//297/+EJslDp07t7J2fuM27eb7
tNsPr6yfvnx6ckHUmb48Hq1pFPY6/eZS6LU61YrvBJVW3eh2E4cbXYJ+N058X1H8wDCi2dlWpVYJ
NHZXm9WuEzeqvXorsg10bLw067lGN1JCBypA+KDNlA0eVcHkmiLBkTqhoTiKrCoIFgExT9hAaIzU
0mVpBuJFM4T74lRBSZVMI/WTTgzdsWmq0DECbxVK46mJPRTpyqpodKgyqjoQUYAISSww3YfNS3ut
qFHtNC1kmZI8iIPzHYbb3CwfGyBMccQAZBCK6tNmDkuSD0LHJMlIr1GIVlK0XorcCMExV8QIomNT
tGW7SO9Z5E5Rukt+IEuWRP7gY+lbgTX/PzBMRMKhY6tkGPNwKoreDpJdW0GsbFmqZsZoPLmIf3XF
Z8UdKu5waalerrWyRjPsQSTRCBwnbOKSNLSxM2W/0uWca62eGFHUHqX12QNiAjviYmlD/IxASxsp
Dw2zyZctREcwHQY1/42jW99e2M7rANhcaPzK7C7YJz4ysAIqxU9LXccpMp3AiY0vfepY10BR5PLV
h/c2zp2/fuUzcQXzo2EQhH63XGuYb69jDdN7q2vvbdx8cOnefdj1hw/v3HmIC66nH124tb/7uVPj
0xoFUbmSBq1+/UXshYg0vd8Is8irLDWg2weobqsRoiGTxVrYzNw4MRMdRR0ncFwlrkdxGMhIvAIX
5Emq0+8VDAMVIZ0rmcSYCQdZGemimBQGUEUge3NKnDG3UVySHA+/UDeNyCraseEmTNPgTzSzJMPv
yGyY2LbBWxTw0th0CqOfYtXUkRTOhssWertw3Tx0w73gsEmzXsWGi8RJMLL+MWE5lwRSmEB20E8l
o/nOQxiWmKJ2TL97cC96rRyqV11Njf0QQ+SET4gkhPKqIJM6XtBgSKtaCjvMfMH0DCrJcLncM4UX
OE9H0RHsV3wT9OtMUpHlllDPLjEzQD/WcIIgMRVbV+FiG5lpoYclK0kUoOvT89MEYu3js4tdw8Dn
Ub+Gpd/1fnnhSGsWu3jSbtqbzWl9dge7M7E5siQot+H0cgwbzk2HIB21/Hc9KRwmsCQ2F0ihp6vw
DN62PYi7Ba1PxnWcQPi552cWGoH511/88eKFhx9cu70KWi9P91/55MdfeQ1irddeefFoOomT6Peu
XboHRnFg7uLVq1dv3bpy5cqjR49OHz594f6Fg97RN8anFZ3JWqfvNY83EOlmjhXPz7X6md9eavR6
qDfpIbR7EbymD41TpkMRh3TKMhQrUZysG5uegvTQ1dwIJckojnoWGiuGJdFbwv3xhAR3gSuK5yhO
okP9ABQVRzcUNP4lR1MNaIxl5Ge64VtqyKETmbpf4CChN+mhKGU7qR+Z+JEqvBpQKMEbmyiYoiUi
YcLdUGRL5SJfwHpwHx3slN1sL8721KJS4D7SfDguF0YMmOXDbKjmRMMG2O7HowyDd3P0FP0hLTBs
p+fZsmyLOByhwwFOzgnxRgHeF7xxupfjvTpgVSXDlLE8WHALONUCNyS7TtCvNxQVjwgxFEJgKC4l
ijvglt0U8WxJzOKbBtqwPMula8hh46iHhACFtmPH56FfcQwnRN2vulRudCrQyR5bqHWycqM6Suuz
Z7A7E5uHxduRzRPMYXj5SoTzz0ds2JkOSMUv2W74fEDsaDicT9/ScskxHt0FK+fHIuUnxcK0/5xW
SJmeWwgV+Y+XL1+988H7589Cfnj2xsb1K/uqPJVO++KJz1f0fY/ub5z/4OLlM5cvX77ySMB6C2/x
/syZW/dv3j2gd742Pq1Lbjg7y9UuXqs2X/akuIq7SNBJsBPfQ/tzYSnzIoTLWqyYEboJug6NIqF1
XWSVmi1bJiSGdsHphV4wSbEdPmEzkumaoiPCCxDjSllQb1ViJ0hN8FvgrhPVhlspqFztwqOtJubm
9NDTVaTEiYU9CiiwpEtlp6ignYtKk+8p6NqCVwmFpmZkGtxnRFGCuO+K5g1WpE3DueKARjHgyQ8F
nRUQh8gWlvtNtldhW9AOSMajudSJb3Yd3I8NL/t2W5KKIm8YGyBI6xtc7yuz0Ivoe3ovNEpU/II9
sDrJMXyLo38crwGApVKJ6anM0RuRoaIg7HimV4auCxkvkeamqRK0lfy/03azCKJoR1HBqE59omSz
9u2FmdtPoGhy27WFWiOExWja+mVk5/02dgrXFspY91GuzR57FlppuQQP5O4I7CiyNPI1mmI+3Ug2
bIjSnNMhE79vZObgCeHwYCpoeD7g5fou2Ee3cDV3jIX/887Nc8f0qUcXH969fu32xqGVFQy5rtzY
uHt5/+yXToC+b+NQ+kfni/sf3d24scFNTZcv3v3g3qVr1y5dwptr7z+4dPfO3QfvXT9d6H6JP27M
mnCKezcLSdPTopnZRmxqcGVQiteqs/1mZ84NKqmBPqGXhR7C3sRxTEMzAhfPPSVxE6dIx6l1g1aY
JBrKuTbU+VyGi+aqLGmNhAfS7CBGQdf1Q87VkFREjYoFZ8I7V7rYoAs/iqzWUTCGF4VKnMETT0Lr
riRoYEqhWtAcFb/O80ILDhdqCBSabMMpygCcG8V5REfACt96cHpaSqPZtKXv3sOuzUGqCgeD6AMy
SSwApm1yDBsEwzw6t5XognxskrFLUhyjKq2iwRTaLPMOth3iPetCJb3IUhqwk2Su37coMUQeIFu6
XLJZG5bYfdZVIzAjWBq4CrxwQaS5OvJSHd1cXrqBODtSTCVi91oxYwi2VS71D+ooMYWRHza7ldqR
Kg/Te54bhWGUognebVXaNWzfWZijd3lWWmlPA/bTOxCbUzTgdnzjX6ONYprbE5dcENehcPgxsNtn
YyHG4MXJPVvT6Y74nZ8dxfU/Vwl/qrzv8JU7125unDt3bnX5EDqpyzduPzyzD7TCt546deJLM95n
Lj98cG71vUt3zuw6fecBmqz41lW8ga2+f+398ysfXJ5yP/qRb395XN8KFdvxltZvuzqeAmi/hA7E
bmmjihs31c5SbbaRGPhCojoVSIATtFign+8nLvJL2/VluAVDU1jDdFTTKHm2OGZIUY9S4nE0NYx6
nq57rJOahkqhk64XJAWdVyWOE1SI8AMUBMwu5Ovw2Yrfi7wUajxUm5Auq3BcmBZQ4FcdfFlD5QYx
tB1rFoRTu7mIkMJ6HmcVsE7xstVBc3ZxNkgKOFEl5t/ALNEUH9NEKXgALzSJgmDhXAWuWxVjQM05
XCtGgBBloSYXQBTG/kQ/h/dtVFwOsFAOshHxgz6JH0iargI+i4/opZINzzyJMnGJbR0k9NB9BR6U
JBTzW1iRjsCEEg5Ls3zPr/T8CGm753puE6hqiWfiJ5Uc7PpuhCjJZVmneqyaxq6mGEFoOGm3mfp+
tpgutedaC+2XXzw6MwatYwKbg/tkZgHAUI7JNzuaIDs3/NUdOH3uKbyO3gQRvOYmaAWuL1HbNPMY
1+6ocxX2n9P6fGMfRtHPncNCJi47BK7L525fOL2v+ulT9Kxf/NoRc9/lh7fRW107e/v+mfVHl9bO
YuXw8vLrMAzZnT179ty5a1dPy5868e1vf/vL413WgJBwtq+Ffd1GT0XOvHKEk5Cua6RB1MmOHD1+
vNxcSjV4Uw8MURnhQjynAC7TCLWSiZqmi79qpk1DcyRXm1Q1pKJIJfu+AiWimzVDZLZJYiAMBGuI
c1GlcQMDCvc0DLqK5ZhqSTcly7JcZHZFJ3b9DC2LLOWyExkY63CzioOGCFQ/3LZrxh4Cc65PnOL2
4qn9mALnRrV9B0WhCWsqFuuv1ku41Er66EiF5duCB2J9fGVw+1w8JB6c5juCS80/YmpLN33XAT4N
6J+V2OAs3CTnV7mkbbcFahLdFpemdE0CffC0EoUaHF1FKGxYaNCCXrDseOKYcuqnplkoMrAo4Nu5
4VGzUL+O/Wq3HnIpsIuSu++6PKZR4sKKqD0XzgS6FjfK5aVG0AggSHTiJI5arSAE5GlQx3miVu3l
F14asyY8fg6bO9kdoN0EbxuIfHnSJwKYp3vTJ7eTcl4H0XAeDg+ABbL5mKwQUKVsvr4xwLUsaM1x
HZvWz1enDl+5fu7cWYAKUuFdV87hDtW+2kdBK2bVX0j2n354bRnS4LUbN25ePHP6AmZhXz8JW1m5
IbzryurqzQund7/2JUTN4/nWlmHU25HnVxU9aHYzONjqQpChlEFdrKpjKalt9JutFmYrQyerY0km
1ooEaadZyXqVVh9T0eFcdTHtZ+XFalMLPMPBjEAGBx0kQeT7seYYzUbWS12kWRISMccChXoRZVwu
STOixa4CPVJqiw1jmmvbHGP3/bSOslaaaVqBvdyiaiDgVFQbe8YJuwcvVMSqJ96qg1/FQVcYU9ap
vSgzyZVZQ93Hku7jHS6wrX1pglg+jlc8nPPL7ya8AJyfYLAdwKFqjf5mLwhdSzZTDRkoaeWwOVcv
uVmz5GmmSZUSsvmiTC+qWLznyLNbdJslmf0dhPomQvwwbTZ9VM50qcQOFMrBulYyQgQncQ976tIo
4qphTuV4Qb0cu4ilteZsrd5MYtOoL5YzP3Yd0I2KHTywH/lI6EN3sYdJnBc//uJc9b+nNferT/Ww
T4N2fNuBUrjW4X8jdr7wnm9727KcVsghp3ehIjx45s8P1YXHpfUjJ772cuHw+oXba4dgyxAAk9aN
O4yET33kxBdPfaK15/StB2tnXz+JsZsbh+5fXb984doa9ghzDHZ17fx7Nx9cu/bgEpxx5XOnxs1b
FxQnaSVaUJtpoA/fV82gcsTRKjgwWOK2L40dUojjY03JfM9H9WbpeCUMmotx1kqR37aX5qB5ClzH
9r2yp6BYJHGyRo1NP8bUeayoRpoitg3Mbr1aVwpMbE0EtJA/ubIWwFFDhGxahs3ODIrEpseGjeHE
9aDc6fS8BMUd1ZHlxGPFSlb4jbKM57Q6CUUjhsDhVJGyAtbp/eIIHUAqNboTPNQ6ADRflAYW+ZBw
nISTn9Dj7iPB1C89PgBJbqf3FnnXLfN7Wb3cDTXVdL1A4UZCsU1YTLM6XsIlqm4oSwY6xwgeCKvC
NrCkUhpsq8xfpQJybRMdUS/qtvw4tlXLllkwl8Cljj8lHV9YxCXWBgIUPAJkJd2PupLiaTOdTjfx
jLjvV5oNr+m5DmIX0438uIefp2mJGWXVzuzHnz/aztUR/z2wBDVn90ms5sw+G7efHrH8J+f2tAu0
5HVkn+oA2HywXeiRRTj80uaqplfGo3W0zBTvO3z5/sY5+EuwSlrZwdm38NlTUDlhZROc6Rqw5Bam
5eX37l1E4/XS2jm41bWb9+7euXjl8hnYOuZwjr2Bczpj0XrUCeO6ZjYXqh+341YX6jg3Xpyr1hIz
hnqm0kANs2lAA8zmJwJbBVIIuBIzsi3Hb0bQEcHwhs8ythuMxGO/1aB7NUuqEiDHSn0vNozAcjPP
Q28UcTCAtBBJOygtGZA0QV4syXiCGp4TaEHgyCWQ4QYpjkmUs1BB/VeHNwq4v1SHe7X0xIKkcOrg
3v04EAmDUxXdmz17sbV3ajeU9/COHCuncYqG76GTEIoH/BFJKd+BSVFfEjAjhx3UgwXoWM8GEDUH
wr9q2w/1guX5BsX7Mg9/cEWEPmlqyEx1E2k778BZXEInabaO2L6IkF3WYShEWRQPG4mPxnnUne02
XSqIudeb28AVWQPhaoBz8+VqIzBUkwImDufrWqgEOs6cZlizDs0IhJ9BVokNTTVjfBEhiRsj7Q3i
IKhXX33hhVcXwjFoHaNMnBO7M7M5sDm9o7bTN438tH/La+5eh2dzCCwtn24nrRQ9prxw9YbY/fLx
J+A6znjrov2Z9QsPVrdoXT53/t6V6TLkDqc+0SicuXrvPcB6aJl7XZZXbt6/dQaiptvnNx5cv3OR
XdfLsCtX1g/o1a99+cR4tKZm0lxwjYVqKJXcDpDyu+KSWdhA9mQpSeY24A96fpcaV4UblBzVb6aR
H+sWGPXqvTDUwJMdNVNPaxhWXFlIofLPeJ8myrqR3zWhpFAdW2FZNdKQdBoliIEdw1MndRBtAlE9
Qz4naZTalVz+4wCxcOKh6tTs9LNmz+VzXpNNXTJ5bFzi7kQuFt4DHT+MYTC2H2LuG552au8UZ+Tw
Qp8qcD0gXgEvWMxlwyQ0PwjJLwiMuUKNY3IFOfZ8x/SyRr2fRZpplfzAlcR6Jp6W4nsoDU1ZYg8L
/znoEuObLNuwEAGjKcPb0URPtS0NpTc0ZBITlzAqrqvZ1Dch5If8XzItnSIInNjsNnBgyzXwtw00
e1BochCXBIFf70cJ4pogg344xKSraypUUDiG6TqKCWZ7lZmjz790dLaf/e9oHaI0d7f/BtpRdIc/
GSE0t/F5Ja7DvA5vtCCsOa34hgOsDgvv+sn/hlYel9t7+Mr991YEridB6+rJS7emmy++ceK5OXUa
jdZVPEzXynfLG/eRu+Ju5L07l0+fvnzrwsO7d6/fv3f96pmJ1pfG9a0NtG7qlQWIptQsnk0RWTX9
bliGNpiNGheKh3Krb4Tljq54VqGIVDPwwjqeVYZuG57lQvRq6wWeOcQyea+SosbroviR9AO1aEDA
GCYVy0aXB6TqYtATQz6RYSKoLRpagbOqYYSZFAf6C0+ZkMXhFyRnsaclfmhRBmA0Mu4apVpRVQwV
p9bRucH+f/RrACvcKibKDwJW8Qd2YGuH4eDuI/wqJ8xh9KCC0cGKfr4KWocN34tRHjVMfUdD7t3C
HAPiXDPzXAiquOhwcGFOZikYLRpNo6eLVRRyWRpDXRcdVRSNbRNdZBax5SI6WZofRrhLgtaMJYJg
G1+xoYWwOIgbLaZBWK+WXdMKTATTFr4Nj6dQG/ZaQdbtuT76Zx7aOKgy0WUrOnvWop/ml4+88vGX
jtSy+hi0jh8UP53Y0WxT2NM+wcuY9vQL7/k2mCEDrDDy/CLD4Ve/9ERcx5m/eeNVY//6xftrNwDr
MojEHaprV6e7L7zxfMv64dXr76EFyy/AwPPZlY1r12+duQxxxIU7Dz+49P7t2xsbG2sb128djD77
Zfy8sVT93bmjxysoK1pSnB3txip6nYuLgBUZUjep1qE+rRp2ozZreL5VVLzUcaESTgx4P62SxWjU
lySt5KmIjDO0CcGVbmtwlp4mmUnDx5OpGYcRei/I+FActrgawW9lBmZvoLvPPBXRZmayC2TUYzPx
bDR3EH1HDc9NIl2RbJPbnSwN2ZqhTlLYB1gZh+4lrAyC8ToNZuld9xFd4rbpLUnmvmmhSZpGvfdx
y5XkbtuoNqhCkdyBAJEaJkwk0KMZXoRarRYBrBjlWB4tFxuYWBvGZjUF/1M4rmDbGmL6REVbi3Gv
XeDGC10tGY6GNNRG8Rd9MATDfrMZxDznBZZNF1VjXYiBEfa3u2HWn51LIk1J6KWRFKD+7mURknfN
dQMoRCMuxAgyBDnw6EAWmkxEKEmUtdGmmKk0o/F86/hONud3TMDGInPLo+cvT+QVwD3xoCVtCFaB
6+bwbHMXZ+fwBrA+I63E9RMV/TNnLtxcXeaOUpzVWF1GR6b1/HMVa9+t6ze53XC7ra4CzfXD67e4
Z4KdV9i51UsXDsSIncejdfbo8+VU04NGHDa6s6i1BoljNJYqkeOFUBA3YgPa1yCt9t2oHikBNA5w
GLpsQvWLw1VLS71QnYC0IUosw5RcIOWmQeopgMzU4nozXUTtGDoGC/1H1QJ2sgq9kmKitkR/lARB
E6QavhJ7OppEqKWEmuNYstYMgwiqRroet2AhtFR1qJN0G5Srk1PY/I9aMLusYJZJK0dbgSrXBQvw
Hm9Ew6t44OAgheXXB/HwoATFDaVihbAgXOS2gFUtWU6luohWSgspuJbYiAGMgl2kZmkwtMrhGwlU
cpW3bZU0k4oRuD1Vgesr6rKKmpPi8DAGQl4nDg2YC+b8BOm/YnFaHX9D48UfNLrSxdDrYolz5MRB
xLvXrmKh/uSZvbqTNoFtokVpmCZRAomTqiBhNSSG0YiUZ2dwJb3lw/5ftJLRJyL7n3CbgzoGryO/
/D9wr8Mbo4jpFqsDWjFL8C/2zubXhSgM476V4qjjY8LRqRqcE2NmMEbH1zUVpoKKdJJr0Z0QiVhd
KwsfweIiIoi9JQsLK/+Df4D/xvOcNqqGUImPcB/MnTudlEh/9z3vvM953+3kFQWdL/2H8ybRtc3t
Vbfuv0Sz/j6S0/4F0to4u22nQqH16RX25P8kTqBDwebDw9WrHzy6Y6s3mMdx4cmlNy/q8gDMhxPR
evZAHE15lbwQQRYf8nUgwkh2gnOh0gfb7WK621GRqMUhap6Y6NAJ48jkbWUHpe07LQEa6hM6CkNV
E3Gka4lKXDDoOcJv91SqnENFcSYTrseC5Ar7LEm7CB1RnrVD9h5Ou0GYwrnkylQr5Kcqz3tKCFEo
PxOOB/d+TWJNWV3qCNvMvzocV4HJOnbKHDmFf6lhUQWMlIVyCKsdntGo45wE8zc0JJUHQLq4zvrN
qL1EvbF9sXHdpHdkH9rFoZakgZmn4mIZ6ke2AzgW4vgDGNndwaHhCimqwc8jAyMhl+uguMa2Sx4k
+Ng30YkyShs3M3kOgh3BKQRNblnAUdbyotBRkJ+bNplUhtZgV6JwK4wIc6TN3MDkGDfuJBnq0xLP
kuFwbDlKJdisfvLEif1HOJxIl2j9lchSY4Hwp7VgBOnonT/XlxdKtZxxXi2xI1lYKbs5b8d8q8YX
S+HJxree35Is3/0QCeoNknnp8q5HzxqnTgbrZhBwL7MGO9SgO3+fN9y9f/3F7O3+QLjl6eMZsWfB
3slojddo0RNeNJWnUWxg5UeOFgb5mUihG9C+kzgNeoFBNJV+WMsOdrK86OXI1JQwU/mZrAJjcCvM
i7Nx1G7CKpDIELuuXTiQHKNRvQ9RwkVVJ2ADU0kXBZa2FYE408tMNcKsKaX8tO2uMDo1qVGy0hJO
lvcwz65SQ0ATbJiml9AbVEOnsWEL0FXYGLOcjghbYsWhvhLeqd3bwSqZHHbyrtunwXUbVomura/y
hMvdAbp8BWrY43ZCPpi+sa4Sa1fF5zp5GmTtMFVNwfzaY58lug45EQTWyoqqcm4jE2pm255sCsG9
ttYdiZzWa1mXhCdwizBIUVtCSSGNaxH12IZft7DNyJG6V0wpFaftPHc9JQB4rOgykQk9TIXRPvvp
yFDpNE0ETCI1vAHWG64bd8/s2QOHdyiQZv9aWsuRrnSF+s5SuXQTv44oHb33eBTnSZnX8rxoaoxX
nI5Cq52KE8+nFm36WVr3so3afrHx1sPZ15fBI2mdfdbotiszD15evghUyagV/U6Ekyvfh6zk3LkM
UpnVXrr9asZju5fzk9CaHPCl72iVRUYWxbli+lCndxBLLuGFR/FJKAzawp9u46OlEiGSLM27p33P
9fMsN2jl5SytiWg6OJsl+b6jTYO3aR/RInWbWvuAs5KEGjWh1jJAGLhaOtxvoqJICk8ahbcJsRW1
HehAuVGP+8dpU84jrWK/0y06UiMkr5DekmqLY4nZXQXuPnxdtxzG4Pp2iKhuZ/BcBULrNiVtDEY8
ElgSi9LN0GiIl4ZGpYFsGIaWLR1+wyN3ozcW6yByEc8Q9lF2yZANsCilq+x4DE7tdHfOX62ioEpQ
mywCo+iKxL4imnAvSTaE8ZSsNBk4jQBgHObHJjiOjxjMmV4c56qNRoMmxPFsOg6Mm+SpkZIesZaQ
YNlVvjZYGWcCKayfSP5jogTfOC3Uf6r0RHbRnbRz5Cj6CSMp/j20ltLX8as/rvG5UaWLIw2vfbuW
U54FMtI4rXY3UH0+FJFWauLYCsSurj/YWj3D1BXBFd6H2Yd1I1fdf/EGriUsfofq40V2jsAu16eP
H+xGNL5zE1fRMhy0fpipntswIa2dU0IJodPgcCYOBQe7WX748P6p6UNKREHh+OY0hiK1UyNdEfoa
HxA/OqNkpJr+FJ5FHlXYHhac6hVhRWL1J6Pu4exwaHwl/UArw0lMizGnRqPTiyOVMnHiKizkBL7x
TQ0xvKUj/GzwOVwSBw1Dk8tKos3tpgptolZrscd5TxVsv2FU4640OyMKtNYbDeC6kphSxJHEWugs
twC1zjA7gHU4kcoeiCXPeSfHbViIcRgUcFZVdaqEoCMhjJLMGFRURIjqFHf8sH8wGzbS3d+s2O4u
cBMjePqeDbKyhXDrLrXTQuxOOK+qHDgSXWSqNVyj8xhhl71uuB5uCiS+xoNJJFNI1X0X1Voflz2n
6rnpdIrzNAk8N1E6Um4eHKJPBP+D/JtNqrDf8SAM/1On8gi+xd9Iaxlakja5xuH99m3l8FrOXke8
UqUWbUNYobXHCcCez4PrRD0P0Zbp2ppuY/4MGgrf6PctrauXr7x199HrS/07I1ovIG2FXj+ffXz3
AXbKvZ3tX6b9ibH1zuzMovjYj9M6p39RC367ythOHl+/L3vfZ6yO4TrGK/TV/jIjWnG3BAE/Sysb
vVw7FtTn70bfpZsX+lfwlOne7t23rj9+fQXLXM6xghBWue3mDgxMd5/dv/7u7uPZ97dh7re04rU3
95fLk+fnaP2vteDPa+EP/ZpURPub2et4fKXKsH5GK7S1smGM1r9Gc7T+R1rwzwqgfjW8lnklsNQ4
q4R1ROug4koH5Bytc/pRzdE6kXe5FF2hrw+LHmpA6hiso/ZMjK1ztH5k5w6NAABCGAj23/W/i8Bg
M+z2cIMirKl1L9v6MR/V5zx5Ys1p/dQKqBUuUCu0UCu0UCu0UCu0UCu0eOzZMU7DQBBG4ZmKG+UI
HIACCUWisJAiUhgUiZhj0ND5EmnoKRAdAlHQoDQpUuQE6RJvqsRx6Yn+7Psu4JV3n2yPqRVQQa2A
CmoFVFAroIJaARXUioxc1e6+NlXUioxMfet+aKKoFWej+HH32ZBa+7Dw427vLFJR7138YjX/Migq
vTGm1j6U3qGySI/e9kmwekZP3phQ605ArbG3s3sZ/6q9jn6lDyS1qtVaWZzuZUxMUvGw+5jIEG/C
PXp+Gxx6OVWtH8vL5Hvw6g3dXc241jSBmDETjlJ6/FErD3fwr1bONeNa+YMTahr9aG3XmrzXnlSm
h1qpNUQ6aH5zbRHatbYHFj42OdRKrRv2zliniigIoKU/wLf4CdQvdobkVSYvbkE2LxH4DBo6/uHF
wg+gQEMjEBNsQAuMmtDZGC2MLIsen+PkZKLI87nTsW9m7tyZe3bv3r27/BVZv2FCnFZwvTzanzn+
NRloHWgVucl58Juj41E3AE9naZbPd7rfz+Zw29u+07k7OJ2dlGhl0MeF4a2j453e6Sv0kUkf6Z0Q
qBm7K0uK0zp5cmVxcBFbr4f58kWI7vfc7XQqz95WNBDPZDc61qBVkik9qMjS0vrrefDWbti0wE/d
sGTaOn7AT5cPHZH9swKtnDs4js8kFn5H6I0YI+JKk7KebgubPJXWadjyTfPJPr+quz3c7Zc04pow
EcV+jw+hVUcYPVikXTMLRCvz4GSjUZ9x5N6ou/ixcxBaz0eYMKgKtHLr2lD2jASiidKoMeKu8qRw
votG0WPsrYVJvmk+uqq7a3otNJqSRswbZzX6zSiAVh9hsQe3fouxOLRez4Nt58Lhz6Nn8ihk8qls
j3JaCWhKUX3sRWnEGHFXkpSU1vhDvB3XMKGV7IaK1d01lK+o4bTGTD48n6u1jrD21jexLyitzIND
Ksezk6s7F7L14+hpr47e3R5d/0SOT2erq0fH4Kq0xoj6HwjlYPZ+ZWXl9QsG6pzy+PFJd8e8O1db
MUbMlSaFcR3b7z1292g7Ga15mDHfz1ZfvxiFdfO6u8M+5It3q0e74UwiGkIrJ6n9V6tPjsOZW5IZ
e3D7T/UWhtb2F5XfmJ/FboEPxbkYfZu9TN5/t8KM2czUaY0/UPz1rqadEqH0dSV8/m6vArgs8Zoa
I+7Kk3Kp97I7MD5buZITEkV7W7uhtx4mV6peicwGZzV3dGZvRKFEw2kFtvvP+/YfQauNMOlBSZaR
1r4wm+EiE87GEE0xm2A1d3dzzhnZaM2xaSkbbU/nG22458VSjBFxpUnJ14Rb2fbsYfI3zpOlhrq7
Q45QKNFwWqNyC62STOlBRZaR1m5MMgzILqkNRyjm1C7SLWoVWjfwlFhtZs/xNvhVjBFxpUnJaV3X
S4KHSb7vP5fhW3M3bkKhXENpRTcYkytLptfNZRlppQg/E0yyGYkUh9xixTHMOFan1aHi6kWLjBsx
RsSVJSX+iY3QKmGSbxz58HV35DcUyjSEVlK1GUqNdZ7MBd1csRi03huRhpD7kO4mHT3MZZI5rdIa
Xfl5nLgiIG6MuCtPCuMtKohImKRWLkU1d9NkqUA0rAHCTU/lnkyvm8vy0co8OIyEzeTCk9LUhmqi
uQS0SlKg1XtYxytGvZGwU3WHP4IXDWuAkRAvjprMgdbCPJgxNs0IJnd2a8FqwhLQqkmB1rgt6w/S
6h2pu+N66BreAHWNtGoyB1p9HpzetpLtnFasImHMgOq0NlI4udk0Y0RceVIirRzql1YXntY+0qlr
WAPctia0pskcaK3OgylLFLKdF7MRIpHiKtPWk+07o7AniBqHUaHGiLvypEBr9NkdTndgeph1Wuvu
QMw1nFawricz68F/Tyvz4DKtPlHy1RB/3squUWpG4QIiYaSIMWKu6rTGLXSn8S0WC9NpVXe3QCvn
7d+glR4MtIZ5sO+WlWKybSdZeyrvZcLX5xgQHtsfn0ROsFRjxFx5UiKt5EXeYpEwy7TibnFp9WT2
PRhoTZlwWvcf3DStjAuM2MweC8cOqhmbe7m0ijFirjwp0Bpf88SUyBAJs0Yr7v5JWi+TSQ8GWpM3
XeQOFLn5mTALyXjoN4ivrM03jjKCRzVGxJUlRWjlLdHku4AWptPq7haL1jkN68GwyhRevbkBWgOR
9Tfm8Ds+yxpfzwhzY8Rd1WmN71YHDx6m01p350v6ruG0Tuu0xh4Ma8L5vnAvS2GB30/I0JovVbPi
FBtnFFyMwjvNboyIK0mK08qbKKG7FqbTKu5u5QmO0CrJpAfDExz5JKkR5hMlKbHTSmgUNh8ZvYu9
7e7owTPOxmqMiCtJitOaroB5mE6ruLud3RH+vBWNvAfD81adB0OR0qpWrD3Vv6LWZJMmGueTJImI
MaKuCNZplWiKYdZprbtjNdA1fn/nIcmUTA206jyYHaFFWluspMT2hVIOg3uRVjV2Wj0pTqvv6PQw
nda6OwIJe85MwwYEqcqs0ZC6DbTaPDhOX51Wfa299vVvKimFk+1qparjypIiGo3Q2iwKrWMiCXiq
hr+Dk78xRzIHWuvzYH8S67TCWSOO/D9r5N+G4KsfXFvTz1e6MeKu6IvdbcnvTTlMp7Xujr6EhT3R
kAERdYGVWksyvW5fdnz39bLQ2sJVEIq1/9NYeCNDZYMK0w4nWad1crTDY8mwukPdwvpj3/CdS7l7
9xUb/MQYEVeSlHyuuDGerelLbh6m01p3N1+qFphUw2nl1SNubjgiyZQegLO9578stF739W6UD9+/
XMbzLkiaxuIgWB2u8YzRLuGE0X/gnytr3MzM17w6pxQyyOMTNQ4iriQp8ST45vrAwWF2pyB9LNFa
d9fLp/6jbB9B0zScVk58D5/zkW9olWRWetBgHWVZaP3a3hnrNA4FUXS7/MB+y35CamvbdNtEmwJF
KQKfQZOOn6BxTwOiAprQIFJEAiQ6JKgowDHWFb6yrkZY8rNzT/3eMG881884zzO4FsQCei64fH0q
ivltcmQaXxw+C/R8Px7nJ7g9q27LVAaaje46O9ze7DY+/HHkAlnQk4E2pYOCD27uHsd5tsukqqZo
UWbzpiEa0k2t1rg5LO+icBbXXo1QakUkatVNFwdQqwqmXsGS/WGGr9ZD7DME763aMBd4Z7WK6v7z
usE5qZWZicmEMKWDgi0F05bNo9Uao2qNm3vL+OCWGqHUCg9o3VCrCGbDCry3MoeceWAmUgX5Tse0
ZVKhYG7DMHzHMqcv5nZlf8efbHLUqVaTgTSlg8KBnWG8FCu7GVdr3BwuFt0kxQiCvTmvPaCQWkUw
aQV7+38rQknM6PVsQVVwnpoUEdNtxtpjYAaM7l6eaDia6yBjlln9VMwpd1BZyMlAmhJBoc/jkEnb
1fekI4SbjfH+V3h7MYmbg7ZqjaWAGEHAQfIAHafmCK4Mpr5uyz16J6xAv75V+Yr05RGBVNzmo6yc
9NCaJ2dlW0KInz7x4VfNcnLclA7K9KzsJ4lmmEfvVdPDdWCN7YeMtVh1+8ApSzEi6sFx6cE6mGG8
gu7pgVrTh2qmiXKAYVM9bfwMxHNromWQksNqbSvv/k9EqkVM7UPWWq1WawfQaUFR112bSqxEfIXV
GsZqTQ5Sk2g6oU2l1X6lwmoNY7Umx99MdPhox9TAsFqt1g7A725gi0qOPzc1yAdhq9Vq7QCqtjX9
fb0Sxx0jprpvoF9htYaxWtODDsSI445xU4N7DrZardYOII3p445xU8PbWa1Wq7UbcH4NXF5NEjCV
Mlar1dod082fr+ZGo+f7dSqm0qU61atGDPJWZbUaM2ysVmP6AqvVGJMwVqsxfcFqNaYvWK3G9AWr
1Zi+8MsYY4wxxhhjjDHGmJb4AMB7T/AsEkNoAAAAAElFTkSuQmCC" alt="zero" />
</span><!-- "zero"-->
<p>

<table style="border: 1px solid black;">
<tr>
<td style="width: 30%; border: 1px solid black;">
<img width = "100"src="https://frinkiac.com/img/S03E03/754118.jpg"><br>
"Smithers, the monkeys are messing with the compiler again"
</td>
<td style="width: 30%; border: 1px solid black;">
<img width ="100" src="https://tv-fanatic-res.cloudinary.com/iu/s--Q_B72iNX--/t_full/cs_srgb,f_auto,fl_strip_profile.lossy,q_auto:420/v1371141961/waylon-smithers-pic.png"><br>
"I'll take care of it, Sir."
</td>
<td style="width: 30%;border: 1px solid black;">
<img width = "100%" src="https://lans-soapbox.com/wp-content/uploads/2012/06/excellent-mr-burns.gif" alt="Mr. Burns">
</td>
<br>
</tr>
</table>
<p>
<hr><p>

	Quote from MB ('the terminal') -><br>
	<b><i>especially appropriate for the monkeyBastas</i></b><br>
"Make them feel like they're getting laid when they're actually getting f**ked"

<p>
<hr><p>

<b>Photochrome Prints from the Lib. of Cong. [ca. 1890-1910]<b>
<br>Bombay. <a href='https://www.loc.gov/pictures/resource/ppmsca.41429/?co=pgz'>Pydownee</a> Street
<br>Bombay. <a href='https://www.loc.gov/pictures/resource/ppmsca.41431/?co=pgz'>Girgaum</a>  Road
<br>(Rights Advisory: No known restrictions on publication.)
<hr>
                </div>
                </section>
""", "")]

    let both = appendAble1 @ appendAble
    printfn "res: Appendable %A recs" (both.Length)
    //res: Appendable 50  recs

    both
    |> List.map (fun itm -> 
                    let (TreeDataItm(u,d,t,tg,c,n)) = itm
                    let m = Regex.Matches(c, "(.*?)<div(.*?)>(.*?)\n", RegexOptions.Multiline)
                    printfn "div:%A tit:%A containedDivCount:%A" d t (m.Count)) |> ignore
                    

res: Appendable 50 recs
div:"recM2S" tit:"TimeLine" containedDivCount:1
div:"recOther" tit:"Rec" containedDivCount:1
div:"sartorial" tit:"Sartorial" containedDivCount:1
div:"planning" tit:"Planning" containedDivCount:33
div:"audio" tit:"Audio" containedDivCount:8
div:"fin" tit:"Fin" containedDivCount:1
div:"re" tit:"RE" containedDivCount:1
div:"furniture" tit:"Furniture" containedDivCount:83
div:"storage" tit:"Storage" containedDivCount:1
div:"desi" tit:"Desi" containedDivCount:2
div:"tv" tit:"TV" containedDivCount:1
div:"music" tit:"Music" containedDivCount:3
div:"elevateLinks" tit:"ElevateLinks" containedDivCount:1
div:"buddhism" tit:"Buddhism" containedDivCount:1
div:"travelNYC" tit:"Travel - NYC" containedDivCount:1
div:"NYCeat" tit:"NYC eatingOut" containedDivCount:1
div:"misc_domino" tit:"Misc_Domino" containedDivCount:1
div:"misc_java" tit:"Misc Java" containedDivCount:1
div:"devOther" tit:"dev Other" containedDivCount:1
div:"recM2S" tit:"TimeLine" containedDivCount:1
div:"recOther" tit:"Amuse" containedDivCount:1
div:"devNotes" tit:"              mBoxes Redux?" containedDivCount:0
div:"devNotes" tit:"Due Diligence" containedDivCount:0
div:"devNotes" tit:"VC Info" containedDivCount:0
div:"devNotes" tit:"Founder Info" containedDivCount:0
div:"devNotes" tit:"Founder Info" containedDivCount:0
div:"devNotes" tit:"             Svr Hosting" containedDivCount:0
div:"devNotes" tit:"IBM Acquires Database-As-A-Service Startup Compose" containedDivCount:0
div:"devNotes" tit:"Going solo" containedDivCount:0
div:"devNotes" tit:"Markdown Links" containedDivCount:0
div:"devNotes" tit:"Cookie alternatives" containedDivCount:0
div:"devNotes" tit:"             Functional JS" containedDivCount:0
div:"devNotes" tit:"Colors" containedDivCount:0
div:"devNotes" tit:"Agile and CI/CD" containedDivCount:0
div:"devNotes" tit:"Mongo Queries" containedDivCount:0
div:"devNotes" tit:"Mongo Nested Docs" containedDivCount:0
div:"devNotes" tit:"Mongo Dynamic/ExpandoObject" containedDivCount:0
div:"devNotes" tit:"No POCO with &amp; without LINQ" containedDivCount:0
div:"devNotes" tit:"Qry w/o Classes (on BsonDoc)" containedDivCount:0
div:"devNotes" tit:"             query ExpandoObject with regular LINQ" containedDivCount:0
div:"devNotes" tit:"Mongo Expando" containedDivCount:0
div:"devNotes" tit:"Indie music submissions (Founder Story)" containedDivCount:0
div:"devNotes" tit:"Sales" containedDivCount:0
div:"devNotes" tit:"SEO" containedDivCount:0
div:"devNotes" tit:"Product Demos" containedDivCount:0
div:"devNotes" tit:"             UI/UX in Ent S/w" containedDivCount:0
div:"devNotes" tit:"Making LLMs work for you" containedDivCount:0
div:"devNotes" tit:"TaskLists, Msft ToDo & adding schema extensions etc. (customizing)" containedDivCount:0
div:"devNotes" tit:"Webhooks SaaS options" containedDivCount:0
div:"devNotes" tit:"MongoDB to keep its hands off application building" containedDivCount:0