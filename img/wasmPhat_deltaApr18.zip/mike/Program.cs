﻿using System;
using System.Runtime.InteropServices.JavaScript;
using Trivedi;

Console.WriteLine("Hello, Browser!");

public partial class MyClass
{
    [JSExport]
    internal static string Greeting()
    {
        var text = $"Hello, World! Greetings from {GetHRef()}";
        Console.WriteLine("Console writeline in Greeting methd: " + text);
        var strL = (Trivedi.Core.stat(text,"x")).ToString();

//        var deS = (Core.deSerToList("")).ToString();

        return (text + "<hr><br><b>(from fs Core invocation):</b>" + strL);
    }

    [JSExport]
    internal static string refreshCfg()
    {
       let hardCoded = """
    {
      isDebug: true, 
      popup:true, 
      parseOnLoad: true, 
      useCustomLogger:true,
      mData : [
          { UNID: 1, id: "root", name: "Root", type: "base", population: "6 billion"},
          { UNID: 5, id: "devIdris", name: "Idris", type: "layer3", parent: "dev" },
          { UNID: 10, id: "dev", name: "dev", type: "layer2", population: "6 billion", parent: "career"}
      ],
      debugPrintStr : "dojoConfig"
    }
"""
        return hardCoded;
    }


    [JSImport("window.location.href", "main.js")]
    internal static partial string GetHRef();
}
